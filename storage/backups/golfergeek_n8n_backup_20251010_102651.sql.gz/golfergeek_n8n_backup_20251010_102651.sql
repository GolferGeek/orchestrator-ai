--
-- PostgreSQL database dump
--

-- Dumped from database version 15.8
-- Dumped by pg_dump version 15.8

-- Started on 2025-10-10 15:26:51 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS postgres;
--
-- TOC entry 4303 (class 1262 OID 5)
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4304 (class 0 OID 0)
-- Dependencies: 4303
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- TOC entry 4306 (class 0 OID 0)
-- Name: postgres; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE postgres SET "app.settings.jwt_secret" TO 'super-secret-jwt-token-with-at-least-32-characters-long';
ALTER DATABASE postgres SET "app.settings.jwt_exp" TO '3600';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 22 (class 2615 OID 16758)
-- Name: n8n; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA n8n;


ALTER SCHEMA n8n OWNER TO postgres;

--
-- TOC entry 4307 (class 0 OID 0)
-- Dependencies: 22
-- Name: SCHEMA n8n; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA n8n IS 'Schema for n8n workflow automation tables and data';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 360 (class 1259 OID 20076)
-- Name: annotation_tag_entity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.annotation_tag_entity (
    id character varying(16) NOT NULL,
    name character varying(24) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.annotation_tag_entity OWNER TO postgres;

--
-- TOC entry 345 (class 1259 OID 19603)
-- Name: auth_identity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.auth_identity (
    "userId" uuid,
    "providerId" character varying(64) NOT NULL,
    "providerType" character varying(32) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.auth_identity OWNER TO postgres;

--
-- TOC entry 347 (class 1259 OID 19616)
-- Name: auth_provider_sync_history; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.auth_provider_sync_history (
    id integer NOT NULL,
    "providerType" character varying(32) NOT NULL,
    "runMode" text NOT NULL,
    status text NOT NULL,
    "startedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    scanned integer NOT NULL,
    created integer NOT NULL,
    updated integer NOT NULL,
    disabled integer NOT NULL,
    error text
);


ALTER TABLE n8n.auth_provider_sync_history OWNER TO postgres;

--
-- TOC entry 346 (class 1259 OID 19615)
-- Name: auth_provider_sync_history_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

CREATE SEQUENCE n8n.auth_provider_sync_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE n8n.auth_provider_sync_history_id_seq OWNER TO postgres;

--
-- TOC entry 4308 (class 0 OID 0)
-- Dependencies: 346
-- Name: auth_provider_sync_history_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: postgres
--

ALTER SEQUENCE n8n.auth_provider_sync_history_id_seq OWNED BY n8n.auth_provider_sync_history.id;


--
-- TOC entry 332 (class 1259 OID 19319)
-- Name: credentials_entity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.credentials_entity (
    name character varying(128) NOT NULL,
    data text NOT NULL,
    type character varying(128) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    id character varying(36) NOT NULL,
    "isManaged" boolean DEFAULT false NOT NULL
);


ALTER TABLE n8n.credentials_entity OWNER TO postgres;

--
-- TOC entry 377 (class 1259 OID 20462)
-- Name: data_table; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.data_table (
    id character varying(36) NOT NULL,
    name character varying(128) NOT NULL,
    "projectId" character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.data_table OWNER TO postgres;

--
-- TOC entry 378 (class 1259 OID 20476)
-- Name: data_table_column; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.data_table_column (
    id character varying(36) NOT NULL,
    name character varying(128) NOT NULL,
    type character varying(32) NOT NULL,
    index integer NOT NULL,
    "dataTableId" character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.data_table_column OWNER TO postgres;

--
-- TOC entry 4309 (class 0 OID 0)
-- Dependencies: 378
-- Name: COLUMN data_table_column.type; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.data_table_column.type IS 'Expected: string, number, boolean, or date (not enforced as a constraint)';


--
-- TOC entry 4310 (class 0 OID 0)
-- Dependencies: 378
-- Name: COLUMN data_table_column.index; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.data_table_column.index IS 'Column order, starting from 0 (0 = first column)';


--
-- TOC entry 344 (class 1259 OID 19572)
-- Name: event_destinations; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.event_destinations (
    id uuid NOT NULL,
    destination jsonb NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.event_destinations OWNER TO postgres;

--
-- TOC entry 361 (class 1259 OID 20084)
-- Name: execution_annotation_tags; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.execution_annotation_tags (
    "annotationId" integer NOT NULL,
    "tagId" character varying(24) NOT NULL
);


ALTER TABLE n8n.execution_annotation_tags OWNER TO postgres;

--
-- TOC entry 359 (class 1259 OID 20060)
-- Name: execution_annotations; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.execution_annotations (
    id integer NOT NULL,
    "executionId" integer NOT NULL,
    vote character varying(6),
    note text,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.execution_annotations OWNER TO postgres;

--
-- TOC entry 358 (class 1259 OID 20059)
-- Name: execution_annotations_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

CREATE SEQUENCE n8n.execution_annotations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE n8n.execution_annotations_id_seq OWNER TO postgres;

--
-- TOC entry 4311 (class 0 OID 0)
-- Dependencies: 358
-- Name: execution_annotations_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: postgres
--

ALTER SEQUENCE n8n.execution_annotations_id_seq OWNED BY n8n.execution_annotations.id;


--
-- TOC entry 349 (class 1259 OID 19711)
-- Name: execution_data; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.execution_data (
    "executionId" integer NOT NULL,
    "workflowData" json NOT NULL,
    data text NOT NULL
);


ALTER TABLE n8n.execution_data OWNER TO postgres;

--
-- TOC entry 334 (class 1259 OID 19329)
-- Name: execution_entity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.execution_entity (
    id integer NOT NULL,
    finished boolean NOT NULL,
    mode character varying NOT NULL,
    "retryOf" character varying,
    "retrySuccessId" character varying,
    "startedAt" timestamp(3) with time zone,
    "stoppedAt" timestamp(3) with time zone,
    "waitTill" timestamp(3) with time zone,
    status character varying NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    "deletedAt" timestamp(3) with time zone,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.execution_entity OWNER TO postgres;

--
-- TOC entry 333 (class 1259 OID 19328)
-- Name: execution_entity_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

CREATE SEQUENCE n8n.execution_entity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE n8n.execution_entity_id_seq OWNER TO postgres;

--
-- TOC entry 4312 (class 0 OID 0)
-- Dependencies: 333
-- Name: execution_entity_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: postgres
--

ALTER SEQUENCE n8n.execution_entity_id_seq OWNED BY n8n.execution_entity.id;


--
-- TOC entry 356 (class 1259 OID 20035)
-- Name: execution_metadata; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.execution_metadata (
    id integer NOT NULL,
    "executionId" integer NOT NULL,
    key character varying(255) NOT NULL,
    value text NOT NULL
);


ALTER TABLE n8n.execution_metadata OWNER TO postgres;

--
-- TOC entry 355 (class 1259 OID 20034)
-- Name: execution_metadata_temp_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

CREATE SEQUENCE n8n.execution_metadata_temp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE n8n.execution_metadata_temp_id_seq OWNER TO postgres;

--
-- TOC entry 4313 (class 0 OID 0)
-- Dependencies: 355
-- Name: execution_metadata_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: postgres
--

ALTER SEQUENCE n8n.execution_metadata_temp_id_seq OWNED BY n8n.execution_metadata.id;


--
-- TOC entry 364 (class 1259 OID 20228)
-- Name: folder; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.folder (
    id character varying(36) NOT NULL,
    name character varying(128) NOT NULL,
    "parentFolderId" character varying(36),
    "projectId" character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.folder OWNER TO postgres;

--
-- TOC entry 365 (class 1259 OID 20246)
-- Name: folder_tag; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.folder_tag (
    "folderId" character varying(36) NOT NULL,
    "tagId" character varying(36) NOT NULL
);


ALTER TABLE n8n.folder_tag OWNER TO postgres;

--
-- TOC entry 371 (class 1259 OID 20342)
-- Name: insights_by_period; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.insights_by_period (
    id integer NOT NULL,
    "metaId" integer NOT NULL,
    type integer NOT NULL,
    value integer NOT NULL,
    "periodUnit" integer NOT NULL,
    "periodStart" timestamp(0) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE n8n.insights_by_period OWNER TO postgres;

--
-- TOC entry 4314 (class 0 OID 0)
-- Dependencies: 371
-- Name: COLUMN insights_by_period.type; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.insights_by_period.type IS '0: time_saved_minutes, 1: runtime_milliseconds, 2: success, 3: failure';


--
-- TOC entry 4315 (class 0 OID 0)
-- Dependencies: 371
-- Name: COLUMN insights_by_period."periodUnit"; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.insights_by_period."periodUnit" IS '0: hour, 1: day, 2: week';


--
-- TOC entry 370 (class 1259 OID 20341)
-- Name: insights_by_period_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

ALTER TABLE n8n.insights_by_period ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME n8n.insights_by_period_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 367 (class 1259 OID 20313)
-- Name: insights_metadata; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.insights_metadata (
    "metaId" integer NOT NULL,
    "workflowId" character varying(16),
    "projectId" character varying(36),
    "workflowName" character varying(128) NOT NULL,
    "projectName" character varying(255) NOT NULL
);


ALTER TABLE n8n.insights_metadata OWNER TO postgres;

--
-- TOC entry 366 (class 1259 OID 20312)
-- Name: insights_metadata_metaId_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

ALTER TABLE n8n.insights_metadata ALTER COLUMN "metaId" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME n8n."insights_metadata_metaId_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 369 (class 1259 OID 20330)
-- Name: insights_raw; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.insights_raw (
    id integer NOT NULL,
    "metaId" integer NOT NULL,
    type integer NOT NULL,
    value integer NOT NULL,
    "timestamp" timestamp(0) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE n8n.insights_raw OWNER TO postgres;

--
-- TOC entry 4316 (class 0 OID 0)
-- Dependencies: 369
-- Name: COLUMN insights_raw.type; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.insights_raw.type IS '0: time_saved_minutes, 1: runtime_milliseconds, 2: success, 3: failure';


--
-- TOC entry 368 (class 1259 OID 20329)
-- Name: insights_raw_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

ALTER TABLE n8n.insights_raw ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME n8n.insights_raw_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 342 (class 1259 OID 19521)
-- Name: installed_nodes; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.installed_nodes (
    name character varying(200) NOT NULL,
    type character varying(200) NOT NULL,
    "latestVersion" integer DEFAULT 1 NOT NULL,
    package character varying(241) NOT NULL
);


ALTER TABLE n8n.installed_nodes OWNER TO postgres;

--
-- TOC entry 341 (class 1259 OID 19514)
-- Name: installed_packages; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.installed_packages (
    "packageName" character varying(214) NOT NULL,
    "installedVersion" character varying(50) NOT NULL,
    "authorName" character varying(70),
    "authorEmail" character varying(70),
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.installed_packages OWNER TO postgres;

--
-- TOC entry 357 (class 1259 OID 20049)
-- Name: invalid_auth_token; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.invalid_auth_token (
    token character varying(512) NOT NULL,
    "expiresAt" timestamp(3) with time zone NOT NULL
);


ALTER TABLE n8n.invalid_auth_token OWNER TO postgres;

--
-- TOC entry 324 (class 1259 OID 19009)
-- Name: migration_metadata; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.migration_metadata (
    migration_file text NOT NULL,
    source text NOT NULL,
    workflow_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    synced_at timestamp with time zone DEFAULT now(),
    notes text,
    CONSTRAINT migration_metadata_source_check CHECK ((source = ANY (ARRAY['dev'::text, 'prod'::text, 'staging'::text])))
);


ALTER TABLE n8n.migration_metadata OWNER TO postgres;

--
-- TOC entry 4317 (class 0 OID 0)
-- Dependencies: 324
-- Name: TABLE migration_metadata; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON TABLE n8n.migration_metadata IS 'Tracks n8n workflow migration sources and metadata (moved to n8n schema for better organization)';


--
-- TOC entry 4318 (class 0 OID 0)
-- Dependencies: 324
-- Name: COLUMN migration_metadata.source; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.migration_metadata.source IS 'Origin of the migration: dev, prod, or staging';


--
-- TOC entry 4319 (class 0 OID 0)
-- Dependencies: 324
-- Name: COLUMN migration_metadata.workflow_id; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.migration_metadata.workflow_id IS 'References the n8n workflow this migration manages';


--
-- TOC entry 331 (class 1259 OID 19310)
-- Name: migrations; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE n8n.migrations OWNER TO postgres;

--
-- TOC entry 330 (class 1259 OID 19309)
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

CREATE SEQUENCE n8n.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE n8n.migrations_id_seq OWNER TO postgres;

--
-- TOC entry 4320 (class 0 OID 0)
-- Dependencies: 330
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: postgres
--

ALTER SEQUENCE n8n.migrations_id_seq OWNED BY n8n.migrations.id;


--
-- TOC entry 323 (class 1259 OID 18993)
-- Name: n8n_workflows; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.n8n_workflows (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    active boolean DEFAULT true,
    nodes jsonb DEFAULT '[]'::jsonb NOT NULL,
    connections jsonb DEFAULT '{}'::jsonb NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE n8n.n8n_workflows OWNER TO postgres;

--
-- TOC entry 4321 (class 0 OID 0)
-- Dependencies: 323
-- Name: TABLE n8n_workflows; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON TABLE n8n.n8n_workflows IS 'Stores n8n workflow definitions for sync between environments (moved from public schema)';


--
-- TOC entry 363 (class 1259 OID 20117)
-- Name: processed_data; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.processed_data (
    "workflowId" character varying(36) NOT NULL,
    context character varying(255) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    value text NOT NULL
);


ALTER TABLE n8n.processed_data OWNER TO postgres;

--
-- TOC entry 351 (class 1259 OID 19954)
-- Name: project; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.project (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    icon json,
    description character varying(512)
);


ALTER TABLE n8n.project OWNER TO postgres;

--
-- TOC entry 352 (class 1259 OID 19961)
-- Name: project_relation; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.project_relation (
    "projectId" character varying(36) NOT NULL,
    "userId" uuid NOT NULL,
    role character varying NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.project_relation OWNER TO postgres;

--
-- TOC entry 375 (class 1259 OID 20398)
-- Name: role; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.role (
    slug character varying(128) NOT NULL,
    "displayName" text,
    description text,
    "roleType" text,
    "systemRole" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.role OWNER TO postgres;

--
-- TOC entry 4322 (class 0 OID 0)
-- Dependencies: 375
-- Name: COLUMN role.slug; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.role.slug IS 'Unique identifier of the role for example: "global:owner"';


--
-- TOC entry 4323 (class 0 OID 0)
-- Dependencies: 375
-- Name: COLUMN role."displayName"; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.role."displayName" IS 'Name used to display in the UI';


--
-- TOC entry 4324 (class 0 OID 0)
-- Dependencies: 375
-- Name: COLUMN role.description; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.role.description IS 'Text describing the scope in more detail of users';


--
-- TOC entry 4325 (class 0 OID 0)
-- Dependencies: 375
-- Name: COLUMN role."roleType"; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.role."roleType" IS 'Type of the role, e.g., global, project, or workflow';


--
-- TOC entry 4326 (class 0 OID 0)
-- Dependencies: 375
-- Name: COLUMN role."systemRole"; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.role."systemRole" IS 'Indicates if the role is managed by the system and cannot be edited';


--
-- TOC entry 376 (class 1259 OID 20406)
-- Name: role_scope; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.role_scope (
    "roleSlug" character varying(128) NOT NULL,
    "scopeSlug" character varying(128) NOT NULL
);


ALTER TABLE n8n.role_scope OWNER TO postgres;

--
-- TOC entry 374 (class 1259 OID 20391)
-- Name: scope; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.scope (
    slug character varying(128) NOT NULL,
    "displayName" text,
    description text
);


ALTER TABLE n8n.scope OWNER TO postgres;

--
-- TOC entry 4327 (class 0 OID 0)
-- Dependencies: 374
-- Name: COLUMN scope.slug; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.scope.slug IS 'Unique identifier of the scope for example: "project:create"';


--
-- TOC entry 4328 (class 0 OID 0)
-- Dependencies: 374
-- Name: COLUMN scope."displayName"; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.scope."displayName" IS 'Name used to display in the UI';


--
-- TOC entry 4329 (class 0 OID 0)
-- Dependencies: 374
-- Name: COLUMN scope.description; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.scope.description IS 'Text describing the scope in more detail of users';


--
-- TOC entry 340 (class 1259 OID 19506)
-- Name: settings; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.settings (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    "loadOnStartup" boolean DEFAULT false NOT NULL
);


ALTER TABLE n8n.settings OWNER TO postgres;

--
-- TOC entry 353 (class 1259 OID 19989)
-- Name: shared_credentials; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.shared_credentials (
    "credentialsId" character varying(36) NOT NULL,
    "projectId" character varying(36) NOT NULL,
    role text NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.shared_credentials OWNER TO postgres;

--
-- TOC entry 354 (class 1259 OID 20015)
-- Name: shared_workflow; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.shared_workflow (
    "workflowId" character varying(36) NOT NULL,
    "projectId" character varying(36) NOT NULL,
    role text NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.shared_workflow OWNER TO postgres;

--
-- TOC entry 337 (class 1259 OID 19357)
-- Name: tag_entity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.tag_entity (
    name character varying(24) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    id character varying(36) NOT NULL
);


ALTER TABLE n8n.tag_entity OWNER TO postgres;

--
-- TOC entry 373 (class 1259 OID 20369)
-- Name: test_case_execution; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.test_case_execution (
    id character varying(36) NOT NULL,
    "testRunId" character varying(36) NOT NULL,
    "executionId" integer,
    status character varying NOT NULL,
    "runAt" timestamp(3) with time zone,
    "completedAt" timestamp(3) with time zone,
    "errorCode" character varying,
    "errorDetails" json,
    metrics json,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    inputs json,
    outputs json
);


ALTER TABLE n8n.test_case_execution OWNER TO postgres;

--
-- TOC entry 372 (class 1259 OID 20354)
-- Name: test_run; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.test_run (
    id character varying(36) NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    status character varying NOT NULL,
    "errorCode" character varying,
    "errorDetails" json,
    "runAt" timestamp(3) with time zone,
    "completedAt" timestamp(3) with time zone,
    metrics json,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.test_run OWNER TO postgres;

--
-- TOC entry 339 (class 1259 OID 19443)
-- Name: user; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n."user" (
    id uuid DEFAULT uuid_in((OVERLAY(OVERLAY(md5((((random())::text || ':'::text) || (clock_timestamp())::text)) PLACING '4'::text FROM 13) PLACING to_hex((floor(((random() * (((11 - 8) + 1))::double precision) + (8)::double precision)))::integer) FROM 17))::cstring) NOT NULL,
    email character varying(255),
    "firstName" character varying(32),
    "lastName" character varying(32),
    password character varying(255),
    "personalizationAnswers" json,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    settings json,
    disabled boolean DEFAULT false NOT NULL,
    "mfaEnabled" boolean DEFAULT false NOT NULL,
    "mfaSecret" text,
    "mfaRecoveryCodes" text,
    "lastActiveAt" date,
    "roleSlug" character varying(128) DEFAULT 'global:member'::character varying NOT NULL
);


ALTER TABLE n8n."user" OWNER TO postgres;

--
-- TOC entry 362 (class 1259 OID 20101)
-- Name: user_api_keys; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.user_api_keys (
    id character varying(36) NOT NULL,
    "userId" uuid NOT NULL,
    label character varying(100) NOT NULL,
    "apiKey" character varying NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    scopes json
);


ALTER TABLE n8n.user_api_keys OWNER TO postgres;

--
-- TOC entry 348 (class 1259 OID 19627)
-- Name: variables; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.variables (
    key character varying(50) NOT NULL,
    type character varying(50) DEFAULT 'string'::character varying NOT NULL,
    value character varying(255),
    id character varying(36) NOT NULL
);


ALTER TABLE n8n.variables OWNER TO postgres;

--
-- TOC entry 336 (class 1259 OID 19347)
-- Name: webhook_entity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.webhook_entity (
    "webhookPath" character varying NOT NULL,
    method character varying NOT NULL,
    node character varying NOT NULL,
    "webhookId" character varying,
    "pathLength" integer,
    "workflowId" character varying(36) NOT NULL
);


ALTER TABLE n8n.webhook_entity OWNER TO postgres;

--
-- TOC entry 335 (class 1259 OID 19339)
-- Name: workflow_entity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.workflow_entity (
    name character varying(128) NOT NULL,
    active boolean NOT NULL,
    nodes json NOT NULL,
    connections json NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    settings json,
    "staticData" json,
    "pinData" json,
    "versionId" character(36),
    "triggerCount" integer DEFAULT 0 NOT NULL,
    id character varying(36) NOT NULL,
    meta json,
    "parentFolderId" character varying(36) DEFAULT NULL::character varying,
    "isArchived" boolean DEFAULT false NOT NULL
);


ALTER TABLE n8n.workflow_entity OWNER TO postgres;

--
-- TOC entry 350 (class 1259 OID 19725)
-- Name: workflow_history; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.workflow_history (
    "versionId" character varying(36) NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    authors character varying(255) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    nodes json NOT NULL,
    connections json NOT NULL
);


ALTER TABLE n8n.workflow_history OWNER TO postgres;

--
-- TOC entry 343 (class 1259 OID 19542)
-- Name: workflow_statistics; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.workflow_statistics (
    count integer DEFAULT 0,
    "latestEvent" timestamp(3) with time zone,
    name character varying(128) NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    "rootCount" integer DEFAULT 0
);


ALTER TABLE n8n.workflow_statistics OWNER TO postgres;

--
-- TOC entry 338 (class 1259 OID 19364)
-- Name: workflows_tags; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.workflows_tags (
    "workflowId" character varying(36) NOT NULL,
    "tagId" character varying(36) NOT NULL
);


ALTER TABLE n8n.workflows_tags OWNER TO postgres;

--
-- TOC entry 3885 (class 2604 OID 19619)
-- Name: auth_provider_sync_history id; Type: DEFAULT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.auth_provider_sync_history ALTER COLUMN id SET DEFAULT nextval('n8n.auth_provider_sync_history_id_seq'::regclass);


--
-- TOC entry 3900 (class 2604 OID 20063)
-- Name: execution_annotations id; Type: DEFAULT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_annotations ALTER COLUMN id SET DEFAULT nextval('n8n.execution_annotations_id_seq'::regclass);


--
-- TOC entry 3860 (class 2604 OID 19332)
-- Name: execution_entity id; Type: DEFAULT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_entity ALTER COLUMN id SET DEFAULT nextval('n8n.execution_entity_id_seq'::regclass);


--
-- TOC entry 3899 (class 2604 OID 20038)
-- Name: execution_metadata id; Type: DEFAULT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_metadata ALTER COLUMN id SET DEFAULT nextval('n8n.execution_metadata_temp_id_seq'::regclass);


--
-- TOC entry 3856 (class 2604 OID 19313)
-- Name: migrations id; Type: DEFAULT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.migrations ALTER COLUMN id SET DEFAULT nextval('n8n.migrations_id_seq'::regclass);


--
-- TOC entry 4279 (class 0 OID 20076)
-- Dependencies: 360
-- Data for Name: annotation_tag_entity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.annotation_tag_entity (id, name, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4264 (class 0 OID 19603)
-- Dependencies: 345
-- Data for Name: auth_identity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.auth_identity ("userId", "providerId", "providerType", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4266 (class 0 OID 19616)
-- Dependencies: 347
-- Data for Name: auth_provider_sync_history; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.auth_provider_sync_history (id, "providerType", "runMode", status, "startedAt", "endedAt", scanned, created, updated, disabled, error) FROM stdin;
\.


--
-- TOC entry 4251 (class 0 OID 19319)
-- Dependencies: 332
-- Data for Name: credentials_entity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.credentials_entity (name, data, type, "createdAt", "updatedAt", id, "isManaged") FROM stdin;
OpenAi account	U2FsdGVkX1+mnTyiaiCAEXHtV70KWtgtLuMkBMcq4TRlJ/lyXB7pN0d1lm5y0KpPaK9iEptg/ulmMH74gSvaJ5zt66NIwJoTyYDHDHo7jYVSIqibtEGSj2vWGA0CUrXBzHhhSyS4HiC9HyJujLbJ9akrj4rl8p22pdgqh1joWXyZwyo7BdjOn5shPzKrRpJwRTQnoorp13NF/gJfoIrAremU1h04U/PEltlTEBS3b/12ahzBtobmeuNES0qsp4e//wg2Elx6pXDgq92MQJC2xw==	openAiApi	2025-10-10 12:48:44.887+00	2025-10-10 12:51:03.155+00	7tuOlNCTiyjK0BzN	f
\.


--
-- TOC entry 4296 (class 0 OID 20462)
-- Dependencies: 377
-- Data for Name: data_table; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.data_table (id, name, "projectId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4297 (class 0 OID 20476)
-- Dependencies: 378
-- Data for Name: data_table_column; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.data_table_column (id, name, type, index, "dataTableId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4263 (class 0 OID 19572)
-- Dependencies: 344
-- Data for Name: event_destinations; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.event_destinations (id, destination, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4280 (class 0 OID 20084)
-- Dependencies: 361
-- Data for Name: execution_annotation_tags; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.execution_annotation_tags ("annotationId", "tagId") FROM stdin;
\.


--
-- TOC entry 4278 (class 0 OID 20060)
-- Dependencies: 359
-- Data for Name: execution_annotations; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.execution_annotations (id, "executionId", vote, note, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4268 (class 0 OID 19711)
-- Dependencies: 349
-- Data for Name: execution_data; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.execution_data ("executionId", "workflowData", data) FROM stdin;
1	{"id":"Q08T7oMX2dZslqV4","name":"Marketing Swarm - Major Announcement","active":false,"nodes":[{"parameters":{"multipleMethods":false,"httpMethod":"POST","path":"marketing-swarm","authentication":"none","responseMode":"responseNode","webhookNotice":"","options":{}},"id":"webhook","name":"Webhook Trigger","type":"n8n-nodes-base.webhook","typeVersion":2,"position":[112,112],"webhookId":"7f338c6b-a9bb-446b-9a1d-702739d89a51"},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"started"},{"name":"taskId","type":"string","value":"={{ $json.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"initialization"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":1},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusStart","name":"Status: Started","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[304,0]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusStart","name":"Send Status: Started","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[512,0]},{"parameters":{"oldVersionNotice":"","resource":"text","operation":"complete","model":"gpt-3.5-turbo-instruct","prompt":"=Write a compelling web post announcement for: {{ $json.announcement }}. Include headline, introduction, key features, and call-to-action. Format as HTML.","simplifyOutput":true,"options":{"maxTokens":1000,"temperature":0.7},"requestOptions":{}},"id":"webPost","name":"Generate Web Post","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[304,208],"credentials":{"openAiApi":{"id":"B2oF5F10osX9S0yy","name":"OpenAi account"}}},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"web_post_complete"},{"name":"webPost","type":"string","value":"={{ $json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":2},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusWebPost","name":"Status: Web Post Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[512,208]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusWebPost","name":"Send Status: Web Post","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[704,112]},{"parameters":{"oldVersionNotice":"","resource":"text","operation":"complete","model":"gpt-3.5-turbo-instruct","prompt":"=Create SEO-optimized content for: {{ $json.announcement }}. Include meta title, meta description, keywords, and structured data JSON-LD.","simplifyOutput":true,"options":{"maxTokens":800,"temperature":0.5},"requestOptions":{}},"id":"seoContent","name":"Generate SEO Content","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[704,304],"credentials":{"openAiApi":{"id":"B2oF5F10osX9S0yy","name":"OpenAi account"}}},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"seo_complete"},{"name":"seoContent","type":"string","value":"={{ $json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":3},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusSEO","name":"Status: SEO Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[912,304]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusSEO","name":"Send Status: SEO","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1104,208]},{"parameters":{"oldVersionNotice":"","resource":"text","operation":"complete","model":"gpt-3.5-turbo-instruct","prompt":"=Create social media posts for: {{ $json.announcement }}. Generate posts for Twitter/X (280 chars), LinkedIn (professional, 1300 chars), and Facebook (engaging, 500 chars). Include relevant hashtags.","simplifyOutput":true,"options":{"maxTokens":1200,"temperature":0.8},"requestOptions":{}},"id":"socialMedia","name":"Generate Social Media","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[1104,400],"credentials":{"openAiApi":{"id":"B2oF5F10osX9S0yy","name":"OpenAi account"}}},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"social_media_complete"},{"name":"socialMedia","type":"string","value":"={{ $('Generate Social Media').item.json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":4},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusSocial","name":"Status: Social Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1312,400]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusSocial","name":"Send Status: Social","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1504,304]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"completed"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"webPost","type":"string","value":"={{ $('Status: Web Post Done').item.json.webPost }}"},{"name":"seoContent","type":"string","value":"={{ $('Status: SEO Done').item.json.seoContent }}"},{"name":"socialMedia","type":"string","value":"={{ $('Status: Social Done').item.json.socialMedia }}"},{"name":"sequence","type":"number","value":5},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"finalOutput","name":"Final Output","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1504,512]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusComplete","name":"Send Status: Complete","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1712,512]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"completed"},{"name":"taskId","type":"string","value":"={{ $('Final Output').item.json.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $('Final Output').item.json.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Final Output').item.json.userId }}"},{"name":"executionId","type":"string","value":"={{ $('Final Output').item.json.executionId }}"},{"name":"timestamp","type":"string","value":"={{ $('Final Output').item.json.timestamp }}"},{"name":"webPost","type":"string","value":"={{ $('Final Output').item.json.webPost }}"},{"name":"seoContent","type":"string","value":"={{ $('Final Output').item.json.seoContent }}"},{"name":"socialMedia","type":"string","value":"={{ $('Final Output').item.json.socialMedia }}"}]},"includeOtherFields":false,"options":{}},"id":"finalResponse","name":"Final Response","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1920,512]},{"parameters":{"generalNotice":"","respondWith":"json","webhookNotice":"","responseBody":"={{ $json }}","options":{}},"id":"respondWebhook","name":"Respond to Webhook","type":"n8n-nodes-base.respondToWebhook","typeVersion":1.1,"position":[2112,512]}],"connections":{"Webhook Trigger":{"main":[[{"node":"Status: Started","type":"main","index":0},{"node":"Generate Web Post","type":"main","index":0}]]},"Status: Started":{"main":[[{"node":"Send Status: Started","type":"main","index":0}]]},"Generate Web Post":{"main":[[{"node":"Status: Web Post Done","type":"main","index":0}]]},"Status: Web Post Done":{"main":[[{"node":"Send Status: Web Post","type":"main","index":0},{"node":"Generate SEO Content","type":"main","index":0}]]},"Generate SEO Content":{"main":[[{"node":"Status: SEO Done","type":"main","index":0}]]},"Status: SEO Done":{"main":[[{"node":"Send Status: SEO","type":"main","index":0},{"node":"Generate Social Media","type":"main","index":0}]]},"Generate Social Media":{"main":[[{"node":"Status: Social Done","type":"main","index":0}]]},"Status: Social Done":{"main":[[{"node":"Send Status: Social","type":"main","index":0},{"node":"Final Output","type":"main","index":0}]]},"Final Output":{"main":[[{"node":"Send Status: Complete","type":"main","index":0}]]},"Send Status: Complete":{"main":[[{"node":"Final Response","type":"main","index":0}]]},"Final Response":{"main":[[{"node":"Respond to Webhook","type":"main","index":0}]]}},"settings":{},"staticData":{},"pinData":{}}	[{"startData":"1","resultData":"2","executionData":"3"},{},{"runData":"4","pinData":"5","lastNodeExecuted":"6","error":"7"},{"contextData":"8","nodeExecutionStack":"9","waitingExecution":"10"},{"Webhook Trigger":"11","Status: Started":"12","Generate Web Post":"13"},{},"Generate Web Post",{"level":"14","shouldReport":false,"tags":"15","message":"16","stack":"17"},{},["18","19"],{},["20"],["21"],["22"],"info",{},"Credential with ID \\"B2oF5F10osX9S0yy\\" does not exist for type \\"openAiApi\\".","Error: Credential with ID \\"B2oF5F10osX9S0yy\\" does not exist for type \\"openAiApi\\".\\n    at CredentialsHelper.getCredentials (/usr/local/lib/node_modules/n8n/src/credentials-helper.ts:273:11)\\n    at processTicksAndRejections (node:internal/process/task_queues:105:5)\\n    at CredentialsHelper.getDecrypted (/usr/local/lib/node_modules/n8n/src/credentials-helper.ts:339:23)\\n    at ExecuteContext._getCredentials (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/node-execution-context/node-execution-context.ts:360:31)\\n    at ExecuteContext.getCredentials (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/node-execution-context/base-execute-context.ts:100:10)\\n    at RoutingNode.prepareCredentials (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/routing-node.ts:1105:7)\\n    at RoutingNode.runNode (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/routing-node.ts:71:50)\\n    at ExecuteContext.versionedNodeType.execute (/usr/local/lib/node_modules/n8n/src/node-types.ts:60:18)\\n    at WorkflowExecute.executeNode (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:1265:8)\\n    at WorkflowExecute.runNode (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:1446:11)",{"node":"23","data":"24","source":"25"},{"node":"26","data":"27","source":"28"},{"startTime":1760100475181,"executionIndex":0,"source":"29","hints":"30","executionTime":0,"executionStatus":"31","data":"32"},{"startTime":1760100475182,"executionIndex":1,"source":"33","hints":"34","executionTime":11,"executionStatus":"31","data":"35"},{"startTime":1760100475194,"executionIndex":2,"source":"36","hints":"37","executionTime":10,"executionStatus":"38","error":"39"},{"parameters":"40","id":"41","name":"6","type":"42","typeVersion":1.1,"position":"43","credentials":"44"},{"main":"45"},{"main":"36"},{"parameters":"46","id":"47","name":"48","type":"49","typeVersion":4.2,"position":"50"},{"main":"51"},{"main":"52"},[],[],"success",{"main":"53"},["54"],[],{"main":"55"},["56"],[],"error",{"level":"14","shouldReport":false,"tags":"15","message":"16","stack":"17"},{"oldVersionNotice":"57","resource":"58","operation":"59","model":"60","prompt":"61","simplifyOutput":true,"options":"62","requestOptions":"63"},"webPost","n8n-nodes-base.openAi",[304,208],{"openAiApi":"64"},["65"],{"preBuiltAgentsCalloutHttpRequest":"57","curlImport":"57","method":"66","url":"67","authentication":"68","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"69","specifyBody":"69","jsonBody":"70","options":"71","infoMessage":"57"},"webhookStatusStart","Send Status: Started","n8n-nodes-base.httpRequest",[512,0],["72"],["73"],["74"],{"previousNode":"75"},["72"],{"previousNode":"75"},"","text","complete","gpt-3.5-turbo-instruct","=Write a compelling web post announcement for: {{ $json.announcement }}. Include headline, introduction, key features, and call-to-action. Format as HTML.",{"maxTokens":1000,"temperature":0.7},{},{"id":"76","name":"77"},["78"],"POST","={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","none","json","={{ JSON.stringify($json) }}",{},["79"],{"previousNode":"80"},["81"],"Webhook Trigger","B2oF5F10osX9S0yy","OpenAi account",{"json":"82","pairedItem":"83"},{"json":"84","pairedItem":"85"},"Status: Started",{"json":"82","pairedItem":"86"},{"headers":"87","params":"88","query":"89","body":"90","webhookUrl":"91","executionMode":"92"},{"item":0},{"status":"93","taskId":null,"executionId":"94","timestamp":"95","step":"96","conversationId":null,"userId":null,"sequence":1,"totalSteps":5},{"item":0},{"item":0},{"content-type":"97","user-agent":"98","accept":"99","cache-control":"100","postman-token":"101","host":"102","accept-encoding":"103","connection":"104","content-length":"105"},{},{},{"announcement":"106"},"http://localhost:5678/webhook-test/marketing-swarm","test","started","1","2025-10-10T07:47:55.187-05:00","initialization","application/json","PostmanRuntime/7.48.0","*/*","no-cache","40922ae4-b0e5-429d-a1b0-2632d152c3f3","localhost:5678","gzip, deflate, br","keep-alive","75","We are introducing OrchestratorAI for small businesses!"]
2	{"id":"Q08T7oMX2dZslqV4","name":"Marketing Swarm - Major Announcement","active":false,"nodes":[{"parameters":{"multipleMethods":false,"httpMethod":"POST","path":"marketing-swarm","authentication":"none","responseMode":"responseNode","webhookNotice":"","options":{}},"id":"webhook","name":"Webhook Trigger","type":"n8n-nodes-base.webhook","typeVersion":2,"position":[112,112],"webhookId":"7f338c6b-a9bb-446b-9a1d-702739d89a51"},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"started"},{"name":"taskId","type":"string","value":"={{ $json.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"initialization"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":1},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusStart","name":"Status: Started","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[304,0]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusStart","name":"Send Status: Started","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[512,0]},{"parameters":{"oldVersionNotice":"","resource":"text","operation":"complete","model":"gpt-3.5-turbo-instruct","prompt":"=Write a compelling web post announcement for: {{ $json.announcement }}. Include headline, introduction, key features, and call-to-action. Format as HTML.","simplifyOutput":true,"options":{"maxTokens":1000,"temperature":0.7},"requestOptions":{}},"id":"webPost","name":"Generate Web Post","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[304,208],"credentials":{"openAiApi":{"id":"7tuOlNCTiyjK0BzN","name":"OpenAi account"}}},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"web_post_complete"},{"name":"webPost","type":"string","value":"={{ $json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":2},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusWebPost","name":"Status: Web Post Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[512,208]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusWebPost","name":"Send Status: Web Post","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[704,112]},{"parameters":{"oldVersionNotice":"","resource":"text","operation":"complete","model":"gpt-3.5-turbo-instruct","prompt":"=Create SEO-optimized content for: {{ $json.announcement }}. Include meta title, meta description, keywords, and structured data JSON-LD.","simplifyOutput":true,"options":{"maxTokens":800,"temperature":0.5},"requestOptions":{}},"id":"seoContent","name":"Generate SEO Content","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[704,304],"credentials":{"openAiApi":{"id":"7tuOlNCTiyjK0BzN","name":"OpenAi account"}}},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"seo_complete"},{"name":"seoContent","type":"string","value":"={{ $json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":3},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusSEO","name":"Status: SEO Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[912,304]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusSEO","name":"Send Status: SEO","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1104,208]},{"parameters":{"oldVersionNotice":"","resource":"text","operation":"complete","model":"gpt-3.5-turbo-instruct","prompt":"=Create social media posts for: {{ $json.announcement }}. Generate posts for Twitter/X (280 chars), LinkedIn (professional, 1300 chars), and Facebook (engaging, 500 chars). Include relevant hashtags.","simplifyOutput":true,"options":{"maxTokens":1200,"temperature":0.8},"requestOptions":{}},"id":"socialMedia","name":"Generate Social Media","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[1104,400],"credentials":{"openAiApi":{"id":"7tuOlNCTiyjK0BzN","name":"OpenAi account"}}},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"social_media_complete"},{"name":"socialMedia","type":"string","value":"={{ $('Generate Social Media').item.json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":4},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusSocial","name":"Status: Social Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1312,400]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusSocial","name":"Send Status: Social","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1504,304]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"completed"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"webPost","type":"string","value":"={{ $('Status: Web Post Done').item.json.webPost }}"},{"name":"seoContent","type":"string","value":"={{ $('Status: SEO Done').item.json.seoContent }}"},{"name":"socialMedia","type":"string","value":"={{ $('Status: Social Done').item.json.socialMedia }}"},{"name":"sequence","type":"number","value":5},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"finalOutput","name":"Final Output","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1504,512]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusComplete","name":"Send Status: Complete","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1712,512]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"completed"},{"name":"taskId","type":"string","value":"={{ $('Final Output').item.json.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $('Final Output').item.json.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Final Output').item.json.userId }}"},{"name":"executionId","type":"string","value":"={{ $('Final Output').item.json.executionId }}"},{"name":"timestamp","type":"string","value":"={{ $('Final Output').item.json.timestamp }}"},{"name":"webPost","type":"string","value":"={{ $('Final Output').item.json.webPost }}"},{"name":"seoContent","type":"string","value":"={{ $('Final Output').item.json.seoContent }}"},{"name":"socialMedia","type":"string","value":"={{ $('Final Output').item.json.socialMedia }}"}]},"includeOtherFields":false,"options":{}},"id":"finalResponse","name":"Final Response","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1920,512]},{"parameters":{"generalNotice":"","respondWith":"json","webhookNotice":"","responseBody":"={{ $json }}","options":{}},"id":"respondWebhook","name":"Respond to Webhook","type":"n8n-nodes-base.respondToWebhook","typeVersion":1.1,"position":[2112,512]}],"connections":{"Webhook Trigger":{"main":[[{"node":"Status: Started","type":"main","index":0},{"node":"Generate Web Post","type":"main","index":0}]]},"Status: Started":{"main":[[{"node":"Send Status: Started","type":"main","index":0}]]},"Generate Web Post":{"main":[[{"node":"Status: Web Post Done","type":"main","index":0}]]},"Status: Web Post Done":{"main":[[{"node":"Send Status: Web Post","type":"main","index":0},{"node":"Generate SEO Content","type":"main","index":0}]]},"Generate SEO Content":{"main":[[{"node":"Status: SEO Done","type":"main","index":0}]]},"Status: SEO Done":{"main":[[{"node":"Send Status: SEO","type":"main","index":0},{"node":"Generate Social Media","type":"main","index":0}]]},"Generate Social Media":{"main":[[{"node":"Status: Social Done","type":"main","index":0}]]},"Status: Social Done":{"main":[[{"node":"Send Status: Social","type":"main","index":0},{"node":"Final Output","type":"main","index":0}]]},"Final Output":{"main":[[{"node":"Send Status: Complete","type":"main","index":0}]]},"Send Status: Complete":{"main":[[{"node":"Final Response","type":"main","index":0}]]},"Final Response":{"main":[[{"node":"Respond to Webhook","type":"main","index":0}]]}},"settings":{},"staticData":{},"pinData":{}}	[{"startData":"1","resultData":"2","executionData":"3"},{},{"runData":"4","pinData":"5","lastNodeExecuted":"6","error":"7"},{"contextData":"8","nodeExecutionStack":"9","waitingExecution":"10"},{"Webhook Trigger":"11","Status: Started":"12","Generate Web Post":"13"},{},"Generate Web Post",{"level":"14","tags":"15","description":"16","errorResponse":"17","timestamp":1760100572458,"context":"18","functionality":"19","name":"20","node":"21","messages":"22","httpCode":"23","message":"24","stack":"25"},{},["26","27"],{},["28"],["29"],["30"],"warning",{},"Incorrect API key provided: sk-proj-**********************************************************************************************************************************************************************************************************************************************************nF7I. You can find your API key at https://platform.openai.com/account/api-keys.",{"body":"31","headers":"32","statusCode":401,"statusMessage":"33"},{"itemIndex":0,"runIndex":0},"regular","NodeApiError",{"parameters":"34","id":"35","name":"6","type":"36","typeVersion":1.1,"position":"37","credentials":"38"},[],"401","Authorization failed - please check your credentials","NodeApiError: Authorization failed - please check your credentials\\n    at ExecuteSingleContext.sendErrorPostReceive (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-nodes-base@file+packages+nodes-base_@aws-sdk+credential-providers@3.808.0_asn1.js@5_afd197edb2c1f848eae21a96a97fab23/node_modules/n8n-nodes-base/nodes/OpenAi/GenericFunctions.ts:15:9)\\n    at RoutingNode.runPostReceiveAction (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/routing-node.ts:309:24)\\n    at RoutingNode.postProcessResponseData (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/routing-node.ts:494:30)\\n    at /usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/routing-node.ts:732:17\\n    at processTicksAndRejections (node:internal/process/task_queues:105:5)\\n    at RoutingNode.makeRequest (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/routing-node.ts:725:19)\\n    at async Promise.allSettled (index 0)\\n    at RoutingNode.runNode (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/routing-node.ts:234:29)\\n    at ExecuteContext.versionedNodeType.execute (/usr/local/lib/node_modules/n8n/src/node-types.ts:60:18)\\n    at WorkflowExecute.executeNode (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:1265:8)",{"node":"39","data":"40","source":"41"},{"node":"42","data":"43","source":"44"},{"startTime":1760100572124,"executionIndex":0,"source":"45","hints":"46","executionTime":0,"executionStatus":"47","data":"48"},{"startTime":1760100572124,"executionIndex":1,"source":"49","hints":"50","executionTime":1,"executionStatus":"47","data":"51"},{"startTime":1760100572125,"executionIndex":2,"source":"52","hints":"53","executionTime":336,"executionStatus":"54","error":"55"},{"error":"56"},{"date":"57","content-type":"58","content-length":"59","connection":"60","vary":"61","x-request-id":"62","x-envoy-upstream-service-time":"63","x-openai-proxy-wasm":"64","cf-cache-status":"65","set-cookie":"66","strict-transport-security":"67","x-content-type-options":"68","server":"69","cf-ray":"70","alt-svc":"71"},"Unauthorized",{"oldVersionNotice":"72","resource":"73","operation":"74","model":"75","prompt":"76","simplifyOutput":true,"options":"77","requestOptions":"78"},"webPost","n8n-nodes-base.openAi",[304,208],{"openAiApi":"79"},{"parameters":"80","id":"35","name":"6","type":"36","typeVersion":1.1,"position":"81","credentials":"82"},{"main":"83"},{"main":"52"},{"parameters":"84","id":"85","name":"86","type":"87","typeVersion":4.2,"position":"88"},{"main":"89"},{"main":"90"},[],[],"success",{"main":"91"},["92"],[],{"main":"93"},["94"],[],"error",{"level":"14","tags":"15","description":"16","errorResponse":"17","timestamp":1760100572458,"context":"18","functionality":"19","name":"20","node":"21","messages":"22","httpCode":"23","message":"24","stack":"25"},{"message":"16","type":"95","param":null,"code":"96"},"Fri, 10 Oct 2025 12:49:32 GMT","application/json; charset=utf-8","512","close","Origin","req_51f47ee3478746958c5e43a051fc23f5","54","v0.1","DYNAMIC","__cf_bm=_F9RfvEEp3OcUl8fGxcu2rx2hcuUEd3V5Z.YvDcgoWw-1760100572-1.0.1.1-OgShJQzkKOMcUDvutxBNnmLDLuW16_TUXceMnxkAoJz8_Mci3JSyVoabXWJ9VBGPhNJQ2YdoaBF5IVD2D.co6XZlhTMU1eI9myGd1ibgPOQ; path=/; expires=Fri, 10-Oct-25 13:19:32 GMT; domain=.api.openai.com; HttpOnly; Secure; SameSite=None, _cfuvid=Yc2d0WsFY9rVWzGQ97a91Svp.S_y.geF5nUadANksV8-1760100572514-0.0.1.1-604800000; path=/; domain=.api.openai.com; HttpOnly; Secure; SameSite=None","max-age=31536000; includeSubDomains; preload","nosniff","cloudflare","98c63d012a7390c2-EWR","h3=\\":443\\"; ma=86400","","text","complete","gpt-3.5-turbo-instruct","=Write a compelling web post announcement for: {{ $json.announcement }}. Include headline, introduction, key features, and call-to-action. Format as HTML.",{"maxTokens":1000,"temperature":0.7},{},{"id":"97","name":"98"},{"oldVersionNotice":"72","resource":"73","operation":"74","model":"75","prompt":"76","simplifyOutput":true,"options":"99","requestOptions":"100"},[304,208],{"openAiApi":"101"},["102"],{"preBuiltAgentsCalloutHttpRequest":"72","curlImport":"72","method":"103","url":"104","authentication":"105","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"106","specifyBody":"106","jsonBody":"107","options":"108","infoMessage":"72"},"webhookStatusStart","Send Status: Started","n8n-nodes-base.httpRequest",[512,0],["109"],["110"],["111"],{"previousNode":"112"},["109"],{"previousNode":"112"},"invalid_request_error","invalid_api_key","7tuOlNCTiyjK0BzN","OpenAi account",{"maxTokens":1000,"temperature":0.7},{},{"id":"97","name":"98"},["113"],"POST","={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","none","json","={{ JSON.stringify($json) }}",{},["114"],{"previousNode":"115"},["116"],"Webhook Trigger",{"json":"117","pairedItem":"118"},{"json":"119","pairedItem":"120"},"Status: Started",{"json":"117","pairedItem":"121"},{"headers":"122","params":"123","query":"124","body":"125","webhookUrl":"126","executionMode":"127"},{"item":0},{"status":"128","taskId":null,"executionId":"129","timestamp":"130","step":"131","conversationId":null,"userId":null,"sequence":1,"totalSteps":5},{"item":0},{"item":0},{"content-type":"132","user-agent":"133","accept":"134","cache-control":"135","postman-token":"136","host":"137","accept-encoding":"138","connection":"139","content-length":"140"},{},{},{"announcement":"141"},"http://localhost:5678/webhook-test/marketing-swarm","test","started","2","2025-10-10T07:49:32.125-05:00","initialization","application/json","PostmanRuntime/7.48.0","*/*","no-cache","0a7eaddf-9884-4a1e-8325-91a6cefa29ce","localhost:5678","gzip, deflate, br","keep-alive","75","We are introducing OrchestratorAI for small businesses!"]
3	{"id":"Q08T7oMX2dZslqV4","name":"Marketing Swarm - Major Announcement","active":false,"nodes":[{"parameters":{"multipleMethods":false,"httpMethod":"POST","path":"marketing-swarm","authentication":"none","responseMode":"responseNode","webhookNotice":"","options":{}},"id":"webhook","name":"Webhook Trigger","type":"n8n-nodes-base.webhook","typeVersion":2,"position":[112,112],"webhookId":"7f338c6b-a9bb-446b-9a1d-702739d89a51"},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"started"},{"name":"taskId","type":"string","value":"={{ $json.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"initialization"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":1},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusStart","name":"Status: Started","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[304,0]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusStart","name":"Send Status: Started","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[512,0]},{"parameters":{"oldVersionNotice":"","resource":"text","operation":"complete","model":"gpt-3.5-turbo-instruct","prompt":"=Write a compelling web post announcement for: {{ $json.announcement }}. Include headline, introduction, key features, and call-to-action. Format as HTML.","simplifyOutput":true,"options":{"maxTokens":1000,"temperature":0.7},"requestOptions":{}},"id":"webPost","name":"Generate Web Post","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[304,208],"credentials":{"openAiApi":{"id":"7tuOlNCTiyjK0BzN","name":"OpenAi account"}}},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"web_post_complete"},{"name":"webPost","type":"string","value":"={{ $json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":2},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusWebPost","name":"Status: Web Post Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[512,208]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusWebPost","name":"Send Status: Web Post","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[704,112]},{"parameters":{"oldVersionNotice":"","resource":"text","operation":"complete","model":"gpt-3.5-turbo-instruct","prompt":"=Create SEO-optimized content for: {{ $json.announcement }}. Include meta title, meta description, keywords, and structured data JSON-LD.","simplifyOutput":true,"options":{"maxTokens":800,"temperature":0.5},"requestOptions":{}},"id":"seoContent","name":"Generate SEO Content","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[704,304],"credentials":{"openAiApi":{"id":"7tuOlNCTiyjK0BzN","name":"OpenAi account"}}},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"seo_complete"},{"name":"seoContent","type":"string","value":"={{ $json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":3},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusSEO","name":"Status: SEO Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[912,304]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusSEO","name":"Send Status: SEO","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1104,208]},{"parameters":{"oldVersionNotice":"","resource":"text","operation":"complete","model":"gpt-3.5-turbo-instruct","prompt":"=Create social media posts for: {{ $json.announcement }}. Generate posts for Twitter/X (280 chars), LinkedIn (professional, 1300 chars), and Facebook (engaging, 500 chars). Include relevant hashtags.","simplifyOutput":true,"options":{"maxTokens":1200,"temperature":0.8},"requestOptions":{}},"id":"socialMedia","name":"Generate Social Media","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[1104,400],"credentials":{"openAiApi":{"id":"7tuOlNCTiyjK0BzN","name":"OpenAi account"}}},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"social_media_complete"},{"name":"socialMedia","type":"string","value":"={{ $('Generate Social Media').item.json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":4},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusSocial","name":"Status: Social Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1312,400]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusSocial","name":"Send Status: Social","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1504,304]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"completed"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"webPost","type":"string","value":"={{ $('Status: Web Post Done').item.json.webPost }}"},{"name":"seoContent","type":"string","value":"={{ $('Status: SEO Done').item.json.seoContent }}"},{"name":"socialMedia","type":"string","value":"={{ $('Status: Social Done').item.json.socialMedia }}"},{"name":"sequence","type":"number","value":5},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"finalOutput","name":"Final Output","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1504,512]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusComplete","name":"Send Status: Complete","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1712,512]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"completed"},{"name":"taskId","type":"string","value":"={{ $('Final Output').item.json.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $('Final Output').item.json.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Final Output').item.json.userId }}"},{"name":"executionId","type":"string","value":"={{ $('Final Output').item.json.executionId }}"},{"name":"timestamp","type":"string","value":"={{ $('Final Output').item.json.timestamp }}"},{"name":"webPost","type":"string","value":"={{ $('Final Output').item.json.webPost }}"},{"name":"seoContent","type":"string","value":"={{ $('Final Output').item.json.seoContent }}"},{"name":"socialMedia","type":"string","value":"={{ $('Final Output').item.json.socialMedia }}"}]},"includeOtherFields":false,"options":{}},"id":"finalResponse","name":"Final Response","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1920,512]},{"parameters":{"generalNotice":"","respondWith":"json","webhookNotice":"","responseBody":"={{ $json }}","options":{}},"id":"respondWebhook","name":"Respond to Webhook","type":"n8n-nodes-base.respondToWebhook","typeVersion":1.1,"position":[2112,512]}],"connections":{"Webhook Trigger":{"main":[[{"node":"Status: Started","type":"main","index":0},{"node":"Generate Web Post","type":"main","index":0}]]},"Status: Started":{"main":[[{"node":"Send Status: Started","type":"main","index":0}]]},"Generate Web Post":{"main":[[{"node":"Status: Web Post Done","type":"main","index":0}]]},"Status: Web Post Done":{"main":[[{"node":"Send Status: Web Post","type":"main","index":0},{"node":"Generate SEO Content","type":"main","index":0}]]},"Generate SEO Content":{"main":[[{"node":"Status: SEO Done","type":"main","index":0}]]},"Status: SEO Done":{"main":[[{"node":"Send Status: SEO","type":"main","index":0},{"node":"Generate Social Media","type":"main","index":0}]]},"Generate Social Media":{"main":[[{"node":"Status: Social Done","type":"main","index":0}]]},"Status: Social Done":{"main":[[{"node":"Send Status: Social","type":"main","index":0},{"node":"Final Output","type":"main","index":0}]]},"Final Output":{"main":[[{"node":"Send Status: Complete","type":"main","index":0}]]},"Send Status: Complete":{"main":[[{"node":"Final Response","type":"main","index":0}]]},"Final Response":{"main":[[{"node":"Respond to Webhook","type":"main","index":0}]]}},"settings":{},"staticData":{},"pinData":{}}	[{"startData":"1","resultData":"2","executionData":"3"},{},{"runData":"4","pinData":"5","lastNodeExecuted":"6","error":"7"},{"contextData":"8","nodeExecutionStack":"9","waitingExecution":"10"},{"Webhook Trigger":"11","Status: Started":"12","Generate Web Post":"13","Send Status: Started":"14"},{},"Send Status: Started",{"level":"15","tags":"16","description":"17","timestamp":1760100701302,"context":"18","functionality":"19","name":"20","node":"21","messages":"22","httpCode":"23","message":"24","stack":"25"},{},["26","27"],{},["28"],["29"],["30"],["31"],"warning",{},"Not Found",{"itemIndex":0,"request":"32"},"regular","NodeApiError",{"parameters":"33","id":"34","name":"6","type":"35","typeVersion":4.2,"position":"36"},["37"],"404","The resource you are requesting could not be found","NodeApiError: The resource you are requesting could not be found\\n    at ExecuteContext.execute (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-nodes-base@file+packages+nodes-base_@aws-sdk+credential-providers@3.808.0_asn1.js@5_afd197edb2c1f848eae21a96a97fab23/node_modules/n8n-nodes-base/nodes/HttpRequest/V3/HttpRequestV3.node.ts:847:16)\\n    at processTicksAndRejections (node:internal/process/task_queues:105:5)\\n    at WorkflowExecute.executeNode (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:1265:8)\\n    at WorkflowExecute.runNode (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:1446:11)\\n    at /usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:1847:27\\n    at /usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:2461:11",{"node":"38","data":"39","source":"40"},{"node":"41","data":"42","source":"43"},{"startTime":1760100698353,"executionIndex":0,"source":"44","hints":"45","executionTime":0,"executionStatus":"46","data":"47"},{"startTime":1760100698354,"executionIndex":1,"source":"48","hints":"49","executionTime":1,"executionStatus":"46","data":"50"},{"startTime":1760100698355,"executionIndex":2,"source":"51","hints":"52","executionTime":2916,"executionStatus":"46","data":"53"},{"startTime":1760100701272,"executionIndex":3,"source":"54","hints":"55","executionTime":35,"executionStatus":"56","error":"57"},{"body":"58","headers":"59","method":"60","uri":"61","gzip":true,"rejectUnauthorized":true,"followRedirect":true,"resolveWithFullResponse":true,"followAllRedirects":true,"timeout":300000,"encoding":null,"json":false,"useStream":true},{"preBuiltAgentsCalloutHttpRequest":"62","curlImport":"62","method":"60","url":"63","authentication":"64","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"65","specifyBody":"65","jsonBody":"66","options":"67","infoMessage":"62"},"webhookStatusStart","n8n-nodes-base.httpRequest",[512,0],"404 - \\"{\\\\\\"message\\\\\\":\\\\\\"Cannot POST /webhooks/status\\\\\\",\\\\\\"error\\\\\\":\\\\\\"Not Found\\\\\\",\\\\\\"statusCode\\\\\\":404}\\"",{"parameters":"68","id":"34","name":"6","type":"35","typeVersion":4.2,"position":"69"},{"main":"70"},{"main":"54"},{"parameters":"71","id":"72","name":"73","type":"74","typeVersion":3.4,"position":"75"},{"main":"76"},{"main":"77"},[],[],"success",{"main":"78"},["79"],[],{"main":"80"},["81"],[],{"main":"82"},["83"],[],"error",{"level":"15","tags":"16","description":"17","timestamp":1760100701302,"context":"18","functionality":"19","name":"20","node":"21","messages":"22","httpCode":"23","message":"24","stack":"25"},{"status":"84","taskId":null,"executionId":"85","timestamp":"86","step":"87","conversationId":null,"userId":null,"sequence":1,"totalSteps":5},{"accept":"88"},"POST","http://host.docker.internal:7100/webhooks/status","","={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","none","json","={{ JSON.stringify($json) }}",{},{"preBuiltAgentsCalloutHttpRequest":"62","curlImport":"62","method":"60","url":"63","authentication":"64","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"65","specifyBody":"65","jsonBody":"66","options":"89","infoMessage":"62"},[512,0],["90"],{"mode":"91","duplicateItem":false,"assignments":"92","includeOtherFields":false,"options":"93"},"statusWebPost","Status: Web Post Done","n8n-nodes-base.set",[512,208],["94"],["95"],["96"],{"previousNode":"97"},["98"],{"previousNode":"97"},["94"],{"previousNode":"99"},"started","3","2025-10-10T07:51:38.355-05:00","initialization","application/json,text/html,application/xhtml+xml,application/xml,text/*;q=0.9, image/*;q=0.8, */*;q=0.7",{},["100"],"manual",{"assignments":"101"},{},["102"],{"previousNode":"103"},["104"],"Webhook Trigger",["105"],"Status: Started",{"json":"106","pairedItem":"107"},["108","109","110","111","112","113","114","115","116","117"],{"json":"118","pairedItem":"119"},"Generate Web Post",{"json":"120","pairedItem":"121"},{"json":"106","pairedItem":"122"},{"status":"84","taskId":null,"executionId":"85","timestamp":"86","step":"87","conversationId":null,"userId":null,"sequence":1,"totalSteps":5},{"item":0},{"name":"123","type":"124","value":"125"},{"name":"126","type":"124","value":"127"},{"name":"128","type":"124","value":"129"},{"name":"130","type":"124","value":"131"},{"name":"132","type":"124","value":"133"},{"name":"134","type":"124","value":"135"},{"name":"136","type":"124","value":"137"},{"name":"138","type":"124","value":"139"},{"name":"140","type":"141","value":2},{"name":"142","type":"141","value":5},{"text":"143","index":0,"logprobs":null,"finish_reason":"144"},{"item":0},{"headers":"145","params":"146","query":"147","body":"148","webhookUrl":"149","executionMode":"150"},{"item":0},{"item":0},"status","string","in_progress","taskId","={{ $('Webhook Trigger').item.json.body.taskId }}","executionId","={{ $execution.id }}","timestamp","={{ $now.toISO() }}","step","web_post_complete","webPost","={{ $json.text }}","conversationId","={{ $('Webhook Trigger').item.json.body.conversationId }}","userId","={{ $('Webhook Trigger').item.json.body.userId }}","sequence","number","totalSteps","<h1>Welcome to the All-New Website Redesign!</h1>\\n\\n<p>Attention all users! We are excited to announce the launch of our brand new website redesign! Our team has been hard at work to bring you an improved and user-friendly browsing experience. We can't wait for you to see all the new features and updates.</p>\\n\\n<h2>Key Features:</h2>\\n<ul>\\n  <li>Modern and sleek design</li>\\n  <li>Streamlined navigation for easier browsing</li>\\n  <li>Improved search functionality</li>\\n  <li>Responsive design for seamless mobile access</li>\\n  <li>Enhanced security measures for a safe browsing experience</li>\\n</ul>\\n\\n<p>Our goal with this redesign is to make your experience on our website effortless and enjoyable. We have listened to your feedback and made necessary changes to provide you with the best possible browsing experience.</p>\\n\\n<p>So what are you waiting for? Head over to our website and check out the new design for yourself! We would love to hear your thoughts and feedback. Thank you for your continued support.</p>\\n\\n<p>Sincerely,</p>\\n<p>The [Company Name] Team</p>\\n\\n<p><strong>Call-to-Action:</strong> Visit our website now and experience the all-new redesign!</p>","stop",{"content-type":"151","user-agent":"152","accept":"153","cache-control":"154","postman-token":"155","host":"156","accept-encoding":"157","connection":"158","content-length":"159"},{},{},{"announcement":"160"},"http://localhost:5678/webhook-test/marketing-swarm","test","application/json","PostmanRuntime/7.48.0","*/*","no-cache","06384261-a66d-4353-bdd0-98a0999d241b","localhost:5678","gzip, deflate, br","keep-alive","75","We are introducing OrchestratorAI for small businesses!"]
4	{"id":"Q08T7oMX2dZslqV4","name":"Marketing Swarm - Major Announcement","active":false,"nodes":[{"parameters":{"multipleMethods":false,"httpMethod":"POST","path":"marketing-swarm","authentication":"none","responseMode":"responseNode","webhookNotice":"","options":{}},"id":"webhook","name":"Webhook Trigger","type":"n8n-nodes-base.webhook","typeVersion":2,"position":[112,112],"webhookId":"7f338c6b-a9bb-446b-9a1d-702739d89a51"},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"started"},{"name":"taskId","type":"string","value":"={{ $json.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"initialization"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":1},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusStart","name":"Status: Started","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[304,0]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusStart","name":"Send Status: Started","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[512,0]},{"parameters":{"oldVersionNotice":"","resource":"text","operation":"complete","model":"gpt-3.5-turbo-instruct","prompt":"=Write a compelling web post announcement for: {{ $json.announcement }}. Include headline, introduction, key features, and call-to-action. Format as HTML.","simplifyOutput":true,"options":{"maxTokens":1000,"temperature":0.7},"requestOptions":{}},"id":"webPost","name":"Generate Web Post","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[304,208],"credentials":{"openAiApi":{"id":"7tuOlNCTiyjK0BzN","name":"OpenAi account"}}},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"web_post_complete"},{"name":"webPost","type":"string","value":"={{ $json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":2},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusWebPost","name":"Status: Web Post Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[512,208]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusWebPost","name":"Send Status: Web Post","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[704,112]},{"parameters":{"oldVersionNotice":"","resource":"text","operation":"complete","model":"gpt-3.5-turbo-instruct","prompt":"=Create SEO-optimized content for: {{ $json.announcement }}. Include meta title, meta description, keywords, and structured data JSON-LD.","simplifyOutput":true,"options":{"maxTokens":800,"temperature":0.5},"requestOptions":{}},"id":"seoContent","name":"Generate SEO Content","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[704,304],"credentials":{"openAiApi":{"id":"7tuOlNCTiyjK0BzN","name":"OpenAi account"}}},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"seo_complete"},{"name":"seoContent","type":"string","value":"={{ $json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":3},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusSEO","name":"Status: SEO Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[912,304]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusSEO","name":"Send Status: SEO","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1104,208]},{"parameters":{"oldVersionNotice":"","resource":"text","operation":"complete","model":"gpt-3.5-turbo-instruct","prompt":"=Create social media posts for: {{ $json.announcement }}. Generate posts for Twitter/X (280 chars), LinkedIn (professional, 1300 chars), and Facebook (engaging, 500 chars). Include relevant hashtags.","simplifyOutput":true,"options":{"maxTokens":1200,"temperature":0.8},"requestOptions":{}},"id":"socialMedia","name":"Generate Social Media","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[1104,400],"credentials":{"openAiApi":{"id":"7tuOlNCTiyjK0BzN","name":"OpenAi account"}}},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"social_media_complete"},{"name":"socialMedia","type":"string","value":"={{ $('Generate Social Media').item.json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":4},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusSocial","name":"Status: Social Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1312,400]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusSocial","name":"Send Status: Social","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1504,304]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"completed"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"webPost","type":"string","value":"={{ $('Status: Web Post Done').item.json.webPost }}"},{"name":"seoContent","type":"string","value":"={{ $('Status: SEO Done').item.json.seoContent }}"},{"name":"socialMedia","type":"string","value":"={{ $('Status: Social Done').item.json.socialMedia }}"},{"name":"sequence","type":"number","value":5},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"finalOutput","name":"Final Output","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1504,512]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusComplete","name":"Send Status: Complete","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1712,512]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"completed"},{"name":"taskId","type":"string","value":"={{ $('Final Output').item.json.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $('Final Output').item.json.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Final Output').item.json.userId }}"},{"name":"executionId","type":"string","value":"={{ $('Final Output').item.json.executionId }}"},{"name":"timestamp","type":"string","value":"={{ $('Final Output').item.json.timestamp }}"},{"name":"webPost","type":"string","value":"={{ $('Final Output').item.json.webPost }}"},{"name":"seoContent","type":"string","value":"={{ $('Final Output').item.json.seoContent }}"},{"name":"socialMedia","type":"string","value":"={{ $('Final Output').item.json.socialMedia }}"}]},"includeOtherFields":false,"options":{}},"id":"finalResponse","name":"Final Response","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1920,512]},{"parameters":{"generalNotice":"","respondWith":"json","webhookNotice":"","responseBody":"={{ $json }}","options":{}},"id":"respondWebhook","name":"Respond to Webhook","type":"n8n-nodes-base.respondToWebhook","typeVersion":1.1,"position":[2112,512]}],"connections":{"Webhook Trigger":{"main":[[{"node":"Status: Started","type":"main","index":0},{"node":"Generate Web Post","type":"main","index":0}]]},"Status: Started":{"main":[[{"node":"Send Status: Started","type":"main","index":0}]]},"Generate Web Post":{"main":[[{"node":"Status: Web Post Done","type":"main","index":0}]]},"Status: Web Post Done":{"main":[[{"node":"Send Status: Web Post","type":"main","index":0},{"node":"Generate SEO Content","type":"main","index":0}]]},"Generate SEO Content":{"main":[[{"node":"Status: SEO Done","type":"main","index":0}]]},"Status: SEO Done":{"main":[[{"node":"Send Status: SEO","type":"main","index":0},{"node":"Generate Social Media","type":"main","index":0}]]},"Generate Social Media":{"main":[[{"node":"Status: Social Done","type":"main","index":0}]]},"Status: Social Done":{"main":[[{"node":"Send Status: Social","type":"main","index":0},{"node":"Final Output","type":"main","index":0}]]},"Final Output":{"main":[[{"node":"Send Status: Complete","type":"main","index":0}]]},"Send Status: Complete":{"main":[[{"node":"Final Response","type":"main","index":0}]]},"Final Response":{"main":[[{"node":"Respond to Webhook","type":"main","index":0}]]}},"settings":{},"pinData":{}}	[{"startData":"1","resultData":"2","executionData":"3"},{"destinationNode":"4","runNodeFilter":"5"},{"runData":"6","pinData":"7","lastNodeExecuted":"4","error":"8"},{"contextData":"9","nodeExecutionStack":"10","metadata":"11","waitingExecution":"12","waitingExecutionSource":"13"},"Send Status: Started",["14","15","4"],{"Webhook Trigger":"16","Status: Started":"17","Send Status: Started":"18"},{},{"level":"19","tags":"20","description":"21","timestamp":1760100828616,"context":"22","functionality":"23","name":"24","node":"25","messages":"26","httpCode":"27","message":"28","stack":"29"},{},["30"],{},{},{},"Webhook Trigger","Status: Started",["31"],["32"],["33"],"warning",{},"Not Found",{"itemIndex":0,"request":"34"},"regular","NodeApiError",{"parameters":"35","id":"36","name":"4","type":"37","typeVersion":4.2,"position":"38"},["39"],"404","The resource you are requesting could not be found","NodeApiError: The resource you are requesting could not be found\\n    at ExecuteContext.execute (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-nodes-base@file+packages+nodes-base_@aws-sdk+credential-providers@3.808.0_asn1.js@5_afd197edb2c1f848eae21a96a97fab23/node_modules/n8n-nodes-base/nodes/HttpRequest/V3/HttpRequestV3.node.ts:847:16)\\n    at processTicksAndRejections (node:internal/process/task_queues:105:5)\\n    at WorkflowExecute.executeNode (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:1265:8)\\n    at WorkflowExecute.runNode (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:1446:11)\\n    at /usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:1847:27\\n    at /usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:2461:11",{"node":"40","data":"41","source":"42"},{"startTime":1760100698353,"executionIndex":0,"source":"43","hints":"44","executionTime":0,"executionStatus":"45","data":"46"},{"startTime":1760100698354,"executionIndex":1,"source":"47","hints":"48","executionTime":1,"executionStatus":"45","data":"49"},{"startTime":1760100828611,"executionIndex":2,"source":"50","hints":"51","executionTime":6,"executionStatus":"52","error":"53"},{"body":"54","headers":"55","method":"56","uri":"57","gzip":true,"rejectUnauthorized":true,"followRedirect":true,"resolveWithFullResponse":true,"followAllRedirects":true,"timeout":300000,"encoding":null,"json":false,"useStream":true},{"preBuiltAgentsCalloutHttpRequest":"58","curlImport":"58","method":"56","url":"59","authentication":"60","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"61","specifyBody":"61","jsonBody":"62","options":"63","infoMessage":"58"},"webhookStatusStart","n8n-nodes-base.httpRequest",[512,0],"404 - \\"{\\\\\\"message\\\\\\":\\\\\\"Cannot POST /webhooks/status\\\\\\",\\\\\\"error\\\\\\":\\\\\\"Not Found\\\\\\",\\\\\\"statusCode\\\\\\":404}\\"",{"parameters":"64","id":"36","name":"4","type":"37","typeVersion":4.2,"position":"65"},{"main":"66"},{"main":"50"},[],[],"success",{"main":"67"},["68"],[],{"main":"69"},["70"],[],"error",{"level":"19","tags":"20","description":"21","timestamp":1760100828616,"context":"22","functionality":"23","name":"24","node":"25","messages":"26","httpCode":"27","message":"28","stack":"29"},{"status":"71","taskId":null,"executionId":"72","timestamp":"73","step":"74","conversationId":null,"userId":null,"sequence":1,"totalSteps":5},{"accept":"75"},"POST","http://host.docker.internal:7100/webhooks/status","","={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","none","json","={{ JSON.stringify($json) }}",{},{"preBuiltAgentsCalloutHttpRequest":"58","curlImport":"58","method":"56","url":"59","authentication":"60","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"61","specifyBody":"61","jsonBody":"62","options":"76","infoMessage":"58"},[512,0],["77"],["78"],{"previousNode":"14"},["79"],{"previousNode":"15","previousNodeOutput":0,"previousNodeRun":0},"started","3","2025-10-10T07:51:38.355-05:00","initialization","application/json,text/html,application/xhtml+xml,application/xml,text/*;q=0.9, image/*;q=0.8, */*;q=0.7",{},["80"],["81"],["82"],{"json":"83","pairedItem":"84"},{"json":"85","pairedItem":"86"},{"json":"83","pairedItem":"87"},{"status":"71","taskId":null,"executionId":"72","timestamp":"73","step":"74","conversationId":null,"userId":null,"sequence":1,"totalSteps":5},{"item":0},{"headers":"88","params":"89","query":"90","body":"91","webhookUrl":"92","executionMode":"93"},{"item":0},{"item":0},{"content-type":"94","user-agent":"95","accept":"96","cache-control":"97","postman-token":"98","host":"99","accept-encoding":"100","connection":"101","content-length":"102"},{},{},{"announcement":"103"},"http://localhost:5678/webhook-test/marketing-swarm","test","application/json","PostmanRuntime/7.48.0","*/*","no-cache","06384261-a66d-4353-bdd0-98a0999d241b","localhost:5678","gzip, deflate, br","keep-alive","75","We are introducing OrchestratorAI for small businesses!"]
5	{"id":"Q08T7oMX2dZslqV4","name":"Marketing Swarm - Major Announcement","active":true,"isArchived":false,"createdAt":"2025-10-09T23:04:05.011Z","updatedAt":"2025-10-10T13:37:05.078Z","nodes":[{"parameters":{"multipleMethods":false,"httpMethod":"POST","path":"marketing-swarm","authentication":"none","responseMode":"responseNode","webhookNotice":"","options":{}},"id":"webhook","name":"Webhook Trigger","type":"n8n-nodes-base.webhook","typeVersion":2,"position":[112,112],"webhookId":"7f338c6b-a9bb-446b-9a1d-702739d89a51"},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"started"},{"name":"taskId","type":"string","value":"={{ $json.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"initialization"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":1},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusStart","name":"Status: Started","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[304,0]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusStart","name":"Send Status: Started","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[512,0]},{"parameters":{"oldVersionNotice":"","resource":"text","operation":"complete","model":"gpt-3.5-turbo-instruct","prompt":"=Write a compelling web post announcement for: {{ $json.announcement }}. Include headline, introduction, key features, and call-to-action. Format as HTML.","simplifyOutput":true,"options":{"maxTokens":1000,"temperature":0.7},"requestOptions":{}},"id":"webPost","name":"Generate Web Post","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[304,208],"credentials":{"openAiApi":{"id":"B2oF5F10osX9S0yy","name":"OpenAi account"}}},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"web_post_complete"},{"name":"webPost","type":"string","value":"={{ $json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":2},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusWebPost","name":"Status: Web Post Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[512,208]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusWebPost","name":"Send Status: Web Post","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[704,100]},{"parameters":{"oldVersionNotice":"","resource":"text","operation":"complete","model":"gpt-3.5-turbo-instruct","prompt":"=Create SEO-optimized content for: {{ $json.announcement }}. Include meta title, meta description, keywords, and structured data JSON-LD.","simplifyOutput":true,"options":{"maxTokens":800,"temperature":0.5},"requestOptions":{}},"id":"seoContent","name":"Generate SEO Content","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[704,300],"credentials":{"openAiApi":{"id":"B2oF5F10osX9S0yy","name":"OpenAi account"}}},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"seo_complete"},{"name":"seoContent","type":"string","value":"={{ $json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":3},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusSEO","name":"Status: SEO Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[912,300]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusSEO","name":"Send Status: SEO","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1104,200]},{"parameters":{"oldVersionNotice":"","resource":"text","operation":"complete","model":"gpt-3.5-turbo-instruct","prompt":"=Create social media posts for: {{ $json.announcement }}. Generate posts for Twitter/X (280 chars), LinkedIn (professional, 1300 chars), and Facebook (engaging, 500 chars). Include relevant hashtags.","simplifyOutput":true,"options":{"maxTokens":1200,"temperature":0.8},"requestOptions":{}},"id":"socialMedia","name":"Generate Social Media","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[1104,400],"credentials":{"openAiApi":{"id":"B2oF5F10osX9S0yy","name":"OpenAi account"}}},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"social_media_complete"},{"name":"socialMedia","type":"string","value":"={{ $('Generate Social Media').item.json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":4},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusSocial","name":"Status: Social Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1312,400]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusSocial","name":"Send Status: Social","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1504,300]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"completed"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"webPost","type":"string","value":"={{ $('Status: Web Post Done').item.json.webPost }}"},{"name":"seoContent","type":"string","value":"={{ $('Status: SEO Done').item.json.seoContent }}"},{"name":"socialMedia","type":"string","value":"={{ $('Status: Social Done').item.json.socialMedia }}"},{"name":"sequence","type":"number","value":5},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"finalOutput","name":"Final Output","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1504,500]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusComplete","name":"Send Status: Complete","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1712,500]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"completed"},{"name":"taskId","type":"string","value":"={{ $('Final Output').item.json.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $('Final Output').item.json.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Final Output').item.json.userId }}"},{"name":"executionId","type":"string","value":"={{ $('Final Output').item.json.executionId }}"},{"name":"timestamp","type":"string","value":"={{ $('Final Output').item.json.timestamp }}"},{"name":"webPost","type":"string","value":"={{ $('Final Output').item.json.webPost }}"},{"name":"seoContent","type":"string","value":"={{ $('Final Output').item.json.seoContent }}"},{"name":"socialMedia","type":"string","value":"={{ $('Final Output').item.json.socialMedia }}"}]},"includeOtherFields":false,"options":{}},"id":"finalResponse","name":"Final Response","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1912,500]},{"parameters":{"generalNotice":"","respondWith":"json","webhookNotice":"","responseBody":"={{ $json }}","options":{}},"id":"respondWebhook","name":"Respond to Webhook","type":"n8n-nodes-base.respondToWebhook","typeVersion":1.1,"position":[2112,500]}],"connections":{"Webhook Trigger":{"main":[[{"node":"Status: Started","type":"main","index":0},{"node":"Generate Web Post","type":"main","index":0}]]},"Status: Started":{"main":[[{"node":"Send Status: Started","type":"main","index":0}]]},"Generate Web Post":{"main":[[{"node":"Status: Web Post Done","type":"main","index":0}]]},"Status: Web Post Done":{"main":[[{"node":"Send Status: Web Post","type":"main","index":0},{"node":"Generate SEO Content","type":"main","index":0}]]},"Generate SEO Content":{"main":[[{"node":"Status: SEO Done","type":"main","index":0}]]},"Status: SEO Done":{"main":[[{"node":"Send Status: SEO","type":"main","index":0},{"node":"Generate Social Media","type":"main","index":0}]]},"Generate Social Media":{"main":[[{"node":"Status: Social Done","type":"main","index":0}]]},"Status: Social Done":{"main":[[{"node":"Send Status: Social","type":"main","index":0},{"node":"Final Output","type":"main","index":0}]]},"Final Output":{"main":[[{"node":"Send Status: Complete","type":"main","index":0}]]},"Send Status: Complete":{"main":[[{"node":"Final Response","type":"main","index":0}]]},"Final Response":{"main":[[{"node":"Respond to Webhook","type":"main","index":0}]]}},"settings":{},"staticData":{},"pinData":null}	[{"startData":"1","resultData":"2","executionData":"3"},{},{"runData":"4","lastNodeExecuted":"5","error":"6"},{"contextData":"7","nodeExecutionStack":"8","waitingExecution":"9"},{"Webhook Trigger":"10","Status: Started":"11","Generate Web Post":"12"},"Generate Web Post",{"level":"13","shouldReport":false,"tags":"14","message":"15","stack":"16"},{},["17","18"],{},["19"],["20"],["21"],"info",{},"Credential with ID \\"B2oF5F10osX9S0yy\\" does not exist for type \\"openAiApi\\".","Error: Credential with ID \\"B2oF5F10osX9S0yy\\" does not exist for type \\"openAiApi\\".\\n    at CredentialsHelper.getCredentials (/usr/local/lib/node_modules/n8n/src/credentials-helper.ts:273:11)\\n    at processTicksAndRejections (node:internal/process/task_queues:105:5)\\n    at CredentialsHelper.getDecrypted (/usr/local/lib/node_modules/n8n/src/credentials-helper.ts:339:23)\\n    at ExecuteContext._getCredentials (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/node-execution-context/node-execution-context.ts:360:31)\\n    at ExecuteContext.getCredentials (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/node-execution-context/base-execute-context.ts:100:10)\\n    at RoutingNode.prepareCredentials (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/routing-node.ts:1105:7)\\n    at RoutingNode.runNode (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/routing-node.ts:71:50)\\n    at ExecuteContext.versionedNodeType.execute (/usr/local/lib/node_modules/n8n/src/node-types.ts:60:18)\\n    at WorkflowExecute.executeNode (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:1265:8)\\n    at WorkflowExecute.runNode (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:1446:11)",{"node":"22","data":"23","source":"24"},{"node":"25","data":"26","source":"27"},{"startTime":1760103448204,"executionIndex":0,"source":"28","hints":"29","executionTime":0,"executionStatus":"30","data":"31"},{"startTime":1760103448204,"executionIndex":1,"source":"32","hints":"33","executionTime":14,"executionStatus":"30","data":"34"},{"startTime":1760103448218,"executionIndex":2,"source":"35","hints":"36","executionTime":24,"executionStatus":"37","error":"38"},{"parameters":"39","id":"40","name":"5","type":"41","typeVersion":1.1,"position":"42","credentials":"43"},{"main":"44"},{"main":"35"},{"parameters":"45","id":"46","name":"47","type":"48","typeVersion":4.2,"position":"49"},{"main":"50"},{"main":"51"},[],[],"success",{"main":"52"},["53"],[],{"main":"54"},["55"],[],"error",{"level":"13","shouldReport":false,"tags":"14","message":"15","stack":"16"},{"oldVersionNotice":"56","resource":"57","operation":"58","model":"59","prompt":"60","simplifyOutput":true,"options":"61","requestOptions":"62"},"webPost","n8n-nodes-base.openAi",[304,208],{"openAiApi":"63"},["64"],{"preBuiltAgentsCalloutHttpRequest":"56","curlImport":"56","method":"65","url":"66","authentication":"67","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"68","specifyBody":"68","jsonBody":"69","options":"70","infoMessage":"56"},"webhookStatusStart","Send Status: Started","n8n-nodes-base.httpRequest",[512,0],["71"],["72"],["73"],{"previousNode":"74"},["71"],{"previousNode":"74"},"","text","complete","gpt-3.5-turbo-instruct","=Write a compelling web post announcement for: {{ $json.announcement }}. Include headline, introduction, key features, and call-to-action. Format as HTML.",{"maxTokens":1000,"temperature":0.7},{},{"id":"75","name":"76"},["77"],"POST","={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","none","json","={{ JSON.stringify($json) }}",{},["78"],{"previousNode":"79"},["80"],"Webhook Trigger","B2oF5F10osX9S0yy","OpenAi account",{"json":"81","pairedItem":"82"},{"json":"83","pairedItem":"84"},"Status: Started",{"json":"81","pairedItem":"85"},{"headers":"86","params":"87","query":"88","body":"89","webhookUrl":"90","executionMode":"91"},{"item":0},{"status":"92","taskId":null,"executionId":"93","timestamp":"94","step":"95","conversationId":"96","userId":null,"sequence":1,"totalSteps":5},{"item":0},{"item":0},{"host":"97","user-agent":"98","accept":"99","content-type":"100","content-length":"101"},{},{},{"taskId":"102","conversationId":"96","announcement":"103","product":"104","target_audience":"105","tone":"106"},"http://localhost:5678/webhook/marketing-swarm","production","started","5","2025-10-10T08:37:28.211-05:00","initialization","test-conv-123","localhost:5678","curl/8.7.1","*/*","application/json","396","test-marketing-swarm-123","Create a marketing campaign for our new AI-powered project management tool targeting small business owners. Include blog post, SEO strategy, and social media content.","AI Project Management Tool","small business owners","professional"]
6	{"id":"Q08T7oMX2dZslqV4","name":"Marketing Swarm - Major Announcement","active":true,"isArchived":false,"createdAt":"2025-10-09T23:04:05.011Z","updatedAt":"2025-10-10T13:37:05.078Z","nodes":[{"parameters":{"multipleMethods":false,"httpMethod":"POST","path":"marketing-swarm","authentication":"none","responseMode":"responseNode","webhookNotice":"","options":{}},"id":"webhook","name":"Webhook Trigger","type":"n8n-nodes-base.webhook","typeVersion":2,"position":[112,112],"webhookId":"7f338c6b-a9bb-446b-9a1d-702739d89a51"},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"started"},{"name":"taskId","type":"string","value":"={{ $json.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"initialization"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":1},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusStart","name":"Status: Started","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[304,0]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusStart","name":"Send Status: Started","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[512,0]},{"parameters":{"oldVersionNotice":"","resource":"text","operation":"complete","model":"gpt-3.5-turbo-instruct","prompt":"=Write a compelling web post announcement for: {{ $json.announcement }}. Include headline, introduction, key features, and call-to-action. Format as HTML.","simplifyOutput":true,"options":{"maxTokens":1000,"temperature":0.7},"requestOptions":{}},"id":"webPost","name":"Generate Web Post","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[304,208],"credentials":{"openAiApi":{"id":"B2oF5F10osX9S0yy","name":"OpenAi account"}}},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"web_post_complete"},{"name":"webPost","type":"string","value":"={{ $json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":2},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusWebPost","name":"Status: Web Post Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[512,208]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusWebPost","name":"Send Status: Web Post","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[704,100]},{"parameters":{"oldVersionNotice":"","resource":"text","operation":"complete","model":"gpt-3.5-turbo-instruct","prompt":"=Create SEO-optimized content for: {{ $json.announcement }}. Include meta title, meta description, keywords, and structured data JSON-LD.","simplifyOutput":true,"options":{"maxTokens":800,"temperature":0.5},"requestOptions":{}},"id":"seoContent","name":"Generate SEO Content","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[704,300],"credentials":{"openAiApi":{"id":"B2oF5F10osX9S0yy","name":"OpenAi account"}}},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"seo_complete"},{"name":"seoContent","type":"string","value":"={{ $json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":3},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusSEO","name":"Status: SEO Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[912,300]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusSEO","name":"Send Status: SEO","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1104,200]},{"parameters":{"oldVersionNotice":"","resource":"text","operation":"complete","model":"gpt-3.5-turbo-instruct","prompt":"=Create social media posts for: {{ $json.announcement }}. Generate posts for Twitter/X (280 chars), LinkedIn (professional, 1300 chars), and Facebook (engaging, 500 chars). Include relevant hashtags.","simplifyOutput":true,"options":{"maxTokens":1200,"temperature":0.8},"requestOptions":{}},"id":"socialMedia","name":"Generate Social Media","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[1104,400],"credentials":{"openAiApi":{"id":"B2oF5F10osX9S0yy","name":"OpenAi account"}}},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"social_media_complete"},{"name":"socialMedia","type":"string","value":"={{ $('Generate Social Media').item.json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":4},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"statusSocial","name":"Status: Social Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1312,400]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusSocial","name":"Send Status: Social","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1504,300]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"completed"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"webPost","type":"string","value":"={{ $('Status: Web Post Done').item.json.webPost }}"},{"name":"seoContent","type":"string","value":"={{ $('Status: SEO Done').item.json.seoContent }}"},{"name":"socialMedia","type":"string","value":"={{ $('Status: Social Done').item.json.socialMedia }}"},{"name":"sequence","type":"number","value":5},{"name":"totalSteps","type":"number","value":5}]},"includeOtherFields":false,"options":{}},"id":"finalOutput","name":"Final Output","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1504,500]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{},"infoMessage":""},"id":"webhookStatusComplete","name":"Send Status: Complete","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1712,500]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"status","type":"string","value":"completed"},{"name":"taskId","type":"string","value":"={{ $('Final Output').item.json.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $('Final Output').item.json.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Final Output').item.json.userId }}"},{"name":"executionId","type":"string","value":"={{ $('Final Output').item.json.executionId }}"},{"name":"timestamp","type":"string","value":"={{ $('Final Output').item.json.timestamp }}"},{"name":"webPost","type":"string","value":"={{ $('Final Output').item.json.webPost }}"},{"name":"seoContent","type":"string","value":"={{ $('Final Output').item.json.seoContent }}"},{"name":"socialMedia","type":"string","value":"={{ $('Final Output').item.json.socialMedia }}"}]},"includeOtherFields":false,"options":{}},"id":"finalResponse","name":"Final Response","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1912,500]},{"parameters":{"generalNotice":"","respondWith":"json","webhookNotice":"","responseBody":"={{ $json }}","options":{}},"id":"respondWebhook","name":"Respond to Webhook","type":"n8n-nodes-base.respondToWebhook","typeVersion":1.1,"position":[2112,500]}],"connections":{"Webhook Trigger":{"main":[[{"node":"Status: Started","type":"main","index":0},{"node":"Generate Web Post","type":"main","index":0}]]},"Status: Started":{"main":[[{"node":"Send Status: Started","type":"main","index":0}]]},"Generate Web Post":{"main":[[{"node":"Status: Web Post Done","type":"main","index":0}]]},"Status: Web Post Done":{"main":[[{"node":"Send Status: Web Post","type":"main","index":0},{"node":"Generate SEO Content","type":"main","index":0}]]},"Generate SEO Content":{"main":[[{"node":"Status: SEO Done","type":"main","index":0}]]},"Status: SEO Done":{"main":[[{"node":"Send Status: SEO","type":"main","index":0},{"node":"Generate Social Media","type":"main","index":0}]]},"Generate Social Media":{"main":[[{"node":"Status: Social Done","type":"main","index":0}]]},"Status: Social Done":{"main":[[{"node":"Send Status: Social","type":"main","index":0},{"node":"Final Output","type":"main","index":0}]]},"Final Output":{"main":[[{"node":"Send Status: Complete","type":"main","index":0}]]},"Send Status: Complete":{"main":[[{"node":"Final Response","type":"main","index":0}]]},"Final Response":{"main":[[{"node":"Respond to Webhook","type":"main","index":0}]]}},"settings":{},"staticData":{},"pinData":null}	[{"startData":"1","resultData":"2","executionData":"3"},{},{"runData":"4","lastNodeExecuted":"5","error":"6"},{"contextData":"7","nodeExecutionStack":"8","waitingExecution":"9"},{"Webhook Trigger":"10","Status: Started":"11","Generate Web Post":"12"},"Generate Web Post",{"level":"13","shouldReport":false,"tags":"14","message":"15","stack":"16"},{},["17","18"],{},["19"],["20"],["21"],"info",{},"Credential with ID \\"B2oF5F10osX9S0yy\\" does not exist for type \\"openAiApi\\".","Error: Credential with ID \\"B2oF5F10osX9S0yy\\" does not exist for type \\"openAiApi\\".\\n    at CredentialsHelper.getCredentials (/usr/local/lib/node_modules/n8n/src/credentials-helper.ts:273:11)\\n    at processTicksAndRejections (node:internal/process/task_queues:105:5)\\n    at CredentialsHelper.getDecrypted (/usr/local/lib/node_modules/n8n/src/credentials-helper.ts:339:23)\\n    at ExecuteContext._getCredentials (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/node-execution-context/node-execution-context.ts:360:31)\\n    at ExecuteContext.getCredentials (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/node-execution-context/base-execute-context.ts:100:10)\\n    at RoutingNode.prepareCredentials (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/routing-node.ts:1105:7)\\n    at RoutingNode.runNode (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/routing-node.ts:71:50)\\n    at ExecuteContext.versionedNodeType.execute (/usr/local/lib/node_modules/n8n/src/node-types.ts:60:18)\\n    at WorkflowExecute.executeNode (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:1265:8)\\n    at WorkflowExecute.runNode (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:1446:11)",{"node":"22","data":"23","source":"24"},{"node":"25","data":"26","source":"27"},{"startTime":1760103455999,"executionIndex":0,"source":"28","hints":"29","executionTime":1,"executionStatus":"30","data":"31"},{"startTime":1760103456000,"executionIndex":1,"source":"32","hints":"33","executionTime":0,"executionStatus":"30","data":"34"},{"startTime":1760103456001,"executionIndex":2,"source":"35","hints":"36","executionTime":2,"executionStatus":"37","error":"38"},{"parameters":"39","id":"40","name":"5","type":"41","typeVersion":1.1,"position":"42","credentials":"43"},{"main":"44"},{"main":"35"},{"parameters":"45","id":"46","name":"47","type":"48","typeVersion":4.2,"position":"49"},{"main":"50"},{"main":"51"},[],[],"success",{"main":"52"},["53"],[],{"main":"54"},["55"],[],"error",{"level":"13","shouldReport":false,"tags":"14","message":"15","stack":"16"},{"oldVersionNotice":"56","resource":"57","operation":"58","model":"59","prompt":"60","simplifyOutput":true,"options":"61","requestOptions":"62"},"webPost","n8n-nodes-base.openAi",[304,208],{"openAiApi":"63"},["64"],{"preBuiltAgentsCalloutHttpRequest":"56","curlImport":"56","method":"65","url":"66","authentication":"67","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"68","specifyBody":"68","jsonBody":"69","options":"70","infoMessage":"56"},"webhookStatusStart","Send Status: Started","n8n-nodes-base.httpRequest",[512,0],["71"],["72"],["73"],{"previousNode":"74"},["71"],{"previousNode":"74"},"","text","complete","gpt-3.5-turbo-instruct","=Write a compelling web post announcement for: {{ $json.announcement }}. Include headline, introduction, key features, and call-to-action. Format as HTML.",{"maxTokens":1000,"temperature":0.7},{},{"id":"75","name":"76"},["77"],"POST","={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","none","json","={{ JSON.stringify($json) }}",{},["78"],{"previousNode":"79"},["80"],"Webhook Trigger","B2oF5F10osX9S0yy","OpenAi account",{"json":"81","pairedItem":"82"},{"json":"83","pairedItem":"84"},"Status: Started",{"json":"81","pairedItem":"85"},{"headers":"86","params":"87","query":"88","body":"89","webhookUrl":"90","executionMode":"91"},{"item":0},{"status":"92","taskId":null,"executionId":"93","timestamp":"94","step":"95","conversationId":null,"userId":null,"sequence":1,"totalSteps":5},{"item":0},{"item":0},{"host":"96","user-agent":"97","accept":"98","content-type":"99","content-length":"100"},{},{},{"announcement":"101"},"http://localhost:5678/webhook/marketing-swarm","production","started","6","2025-10-10T08:37:36.000-05:00","initialization","localhost:5678","curl/8.7.1","*/*","application/json","55","Test marketing campaign for AI tool"]
\.


--
-- TOC entry 4253 (class 0 OID 19329)
-- Dependencies: 334
-- Data for Name: execution_entity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.execution_entity (id, finished, mode, "retryOf", "retrySuccessId", "startedAt", "stoppedAt", "waitTill", status, "workflowId", "deletedAt", "createdAt") FROM stdin;
1	f	manual	\N	\N	2025-10-10 12:47:55.174+00	2025-10-10 12:47:55.205+00	\N	error	Q08T7oMX2dZslqV4	\N	2025-10-10 12:47:55.165+00
2	f	manual	\N	\N	2025-10-10 12:49:32.119+00	2025-10-10 12:49:32.461+00	\N	error	Q08T7oMX2dZslqV4	\N	2025-10-10 12:49:32.108+00
3	f	manual	\N	\N	2025-10-10 12:51:38.349+00	2025-10-10 12:51:41.307+00	\N	error	Q08T7oMX2dZslqV4	\N	2025-10-10 12:51:38.341+00
4	f	manual	\N	\N	2025-10-10 12:53:48.606+00	2025-10-10 12:53:48.617+00	\N	error	Q08T7oMX2dZslqV4	\N	2025-10-10 12:53:48.6+00
5	f	webhook	\N	\N	2025-10-10 13:37:28.196+00	2025-10-10 13:37:28.243+00	\N	error	Q08T7oMX2dZslqV4	\N	2025-10-10 13:37:28.175+00
6	f	webhook	\N	\N	2025-10-10 13:37:35.996+00	2025-10-10 13:37:36.004+00	\N	error	Q08T7oMX2dZslqV4	\N	2025-10-10 13:37:35.986+00
\.


--
-- TOC entry 4275 (class 0 OID 20035)
-- Dependencies: 356
-- Data for Name: execution_metadata; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.execution_metadata (id, "executionId", key, value) FROM stdin;
\.


--
-- TOC entry 4283 (class 0 OID 20228)
-- Dependencies: 364
-- Data for Name: folder; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.folder (id, name, "parentFolderId", "projectId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4284 (class 0 OID 20246)
-- Dependencies: 365
-- Data for Name: folder_tag; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.folder_tag ("folderId", "tagId") FROM stdin;
\.


--
-- TOC entry 4290 (class 0 OID 20342)
-- Dependencies: 371
-- Data for Name: insights_by_period; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.insights_by_period (id, "metaId", type, value, "periodUnit", "periodStart") FROM stdin;
1	1	1	49	0	2025-10-10 13:00:00+00
2	1	3	2	0	2025-10-10 13:00:00+00
\.


--
-- TOC entry 4286 (class 0 OID 20313)
-- Dependencies: 367
-- Data for Name: insights_metadata; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.insights_metadata ("metaId", "workflowId", "projectId", "workflowName", "projectName") FROM stdin;
1	Q08T7oMX2dZslqV4	i9Hx3voRXPvZMWtL	Marketing Swarm - Major Announcement	Golfer Geek <golfergeek@orchestratorai.io>
\.


--
-- TOC entry 4288 (class 0 OID 20330)
-- Dependencies: 369
-- Data for Name: insights_raw; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.insights_raw (id, "metaId", type, value, "timestamp") FROM stdin;
\.


--
-- TOC entry 4261 (class 0 OID 19521)
-- Dependencies: 342
-- Data for Name: installed_nodes; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.installed_nodes (name, type, "latestVersion", package) FROM stdin;
\.


--
-- TOC entry 4260 (class 0 OID 19514)
-- Dependencies: 341
-- Data for Name: installed_packages; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.installed_packages ("packageName", "installedVersion", "authorName", "authorEmail", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4276 (class 0 OID 20049)
-- Dependencies: 357
-- Data for Name: invalid_auth_token; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.invalid_auth_token (token, "expiresAt") FROM stdin;
\.


--
-- TOC entry 4248 (class 0 OID 19009)
-- Dependencies: 324
-- Data for Name: migration_metadata; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.migration_metadata (migration_file, source, workflow_id, created_at, synced_at, notes) FROM stdin;
\.


--
-- TOC entry 4250 (class 0 OID 19310)
-- Dependencies: 331
-- Data for Name: migrations; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.migrations (id, "timestamp", name) FROM stdin;
1	1587669153312	InitialMigration1587669153312
2	1589476000887	WebhookModel1589476000887
3	1594828256133	CreateIndexStoppedAt1594828256133
4	1607431743768	MakeStoppedAtNullable1607431743768
5	1611144599516	AddWebhookId1611144599516
6	1617270242566	CreateTagEntity1617270242566
7	1620824779533	UniqueWorkflowNames1620824779533
8	1626176912946	AddwaitTill1626176912946
9	1630419189837	UpdateWorkflowCredentials1630419189837
10	1644422880309	AddExecutionEntityIndexes1644422880309
11	1646834195327	IncreaseTypeVarcharLimit1646834195327
12	1646992772331	CreateUserManagement1646992772331
13	1648740597343	LowerCaseUserEmail1648740597343
14	1652254514002	CommunityNodes1652254514002
15	1652367743993	AddUserSettings1652367743993
16	1652905585850	AddAPIKeyColumn1652905585850
17	1654090467022	IntroducePinData1654090467022
18	1658932090381	AddNodeIds1658932090381
19	1659902242948	AddJsonKeyPinData1659902242948
20	1660062385367	CreateCredentialsUserRole1660062385367
21	1663755770893	CreateWorkflowsEditorRole1663755770893
22	1664196174001	WorkflowStatistics1664196174001
23	1665484192212	CreateCredentialUsageTable1665484192212
24	1665754637025	RemoveCredentialUsageTable1665754637025
25	1669739707126	AddWorkflowVersionIdColumn1669739707126
26	1669823906995	AddTriggerCountColumn1669823906995
27	1671535397530	MessageEventBusDestinations1671535397530
28	1671726148421	RemoveWorkflowDataLoadedFlag1671726148421
29	1673268682475	DeleteExecutionsWithWorkflows1673268682475
30	1674138566000	AddStatusToExecutions1674138566000
31	1674509946020	CreateLdapEntities1674509946020
32	1675940580449	PurgeInvalidWorkflowConnections1675940580449
33	1676996103000	MigrateExecutionStatus1676996103000
34	1677236854063	UpdateRunningExecutionStatus1677236854063
35	1677501636754	CreateVariables1677501636754
36	1679416281778	CreateExecutionMetadataTable1679416281778
37	1681134145996	AddUserActivatedProperty1681134145996
38	1681134145997	RemoveSkipOwnerSetup1681134145997
39	1690000000000	MigrateIntegerKeysToString1690000000000
40	1690000000020	SeparateExecutionData1690000000020
41	1690000000030	RemoveResetPasswordColumns1690000000030
42	1690000000030	AddMfaColumns1690000000030
43	1690787606731	AddMissingPrimaryKeyOnExecutionData1690787606731
44	1691088862123	CreateWorkflowNameIndex1691088862123
45	1692967111175	CreateWorkflowHistoryTable1692967111175
46	1693491613982	ExecutionSoftDelete1693491613982
47	1693554410387	DisallowOrphanExecutions1693554410387
48	1694091729095	MigrateToTimestampTz1694091729095
49	1695128658538	AddWorkflowMetadata1695128658538
50	1695829275184	ModifyWorkflowHistoryNodesAndConnections1695829275184
51	1700571993961	AddGlobalAdminRole1700571993961
52	1705429061930	DropRoleMapping1705429061930
53	1711018413374	RemoveFailedExecutionStatus1711018413374
54	1711390882123	MoveSshKeysToDatabase1711390882123
55	1712044305787	RemoveNodesAccess1712044305787
56	1714133768519	CreateProject1714133768519
57	1714133768521	MakeExecutionStatusNonNullable1714133768521
58	1717498465931	AddActivatedAtUserSetting1717498465931
59	1720101653148	AddConstraintToExecutionMetadata1720101653148
60	1721377157740	FixExecutionMetadataSequence1721377157740
61	1723627610222	CreateInvalidAuthTokenTable1723627610222
62	1723796243146	RefactorExecutionIndices1723796243146
63	1724753530828	CreateAnnotationTables1724753530828
64	1724951148974	AddApiKeysTable1724951148974
65	1726606152711	CreateProcessedDataTable1726606152711
66	1727427440136	SeparateExecutionCreationFromStart1727427440136
67	1728659839644	AddMissingPrimaryKeyOnAnnotationTagMapping1728659839644
68	1729607673464	UpdateProcessedDataValueColumnToText1729607673464
69	1729607673469	AddProjectIcons1729607673469
70	1730386903556	CreateTestDefinitionTable1730386903556
71	1731404028106	AddDescriptionToTestDefinition1731404028106
72	1731582748663	MigrateTestDefinitionKeyToString1731582748663
73	1732271325258	CreateTestMetricTable1732271325258
74	1732549866705	CreateTestRun1732549866705
75	1733133775640	AddMockedNodesColumnToTestDefinition1733133775640
76	1734479635324	AddManagedColumnToCredentialsTable1734479635324
77	1736172058779	AddStatsColumnsToTestRun1736172058779
78	1736947513045	CreateTestCaseExecutionTable1736947513045
79	1737715421462	AddErrorColumnsToTestRuns1737715421462
80	1738709609940	CreateFolderTable1738709609940
81	1739549398681	CreateAnalyticsTables1739549398681
82	1740445074052	UpdateParentFolderIdColumn1740445074052
83	1741167584277	RenameAnalyticsToInsights1741167584277
84	1742918400000	AddScopesColumnToApiKeys1742918400000
85	1745322634000	ClearEvaluation1745322634000
86	1745587087521	AddWorkflowStatisticsRootCount1745587087521
87	1745934666076	AddWorkflowArchivedColumn1745934666076
88	1745934666077	DropRoleTable1745934666077
89	1747824239000	AddProjectDescriptionColumn1747824239000
90	1750252139166	AddLastActiveAtColumnToUser1750252139166
91	1750252139166	AddScopeTables1750252139166
92	1750252139167	AddRolesTables1750252139167
93	1750252139168	LinkRoleToUserTable1750252139168
94	1750252139170	RemoveOldRoleColumn1750252139170
95	1752669793000	AddInputsOutputsToTestCaseExecution1752669793000
96	1753953244168	LinkRoleToProjectRelationTable1753953244168
97	1754475614601	CreateDataStoreTables1754475614601
98	1754475614602	ReplaceDataStoreTablesWithDataTables1754475614602
99	1756906557570	AddTimestampsToRoleAndRoleIndexes1756906557570
\.


--
-- TOC entry 4247 (class 0 OID 18993)
-- Dependencies: 323
-- Data for Name: n8n_workflows; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.n8n_workflows (id, name, active, nodes, connections, settings, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4282 (class 0 OID 20117)
-- Dependencies: 363
-- Data for Name: processed_data; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.processed_data ("workflowId", context, "createdAt", "updatedAt", value) FROM stdin;
\.


--
-- TOC entry 4270 (class 0 OID 19954)
-- Dependencies: 351
-- Data for Name: project; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.project (id, name, type, "createdAt", "updatedAt", icon, description) FROM stdin;
i9Hx3voRXPvZMWtL	Golfer Geek <golfergeek@orchestratorai.io>	personal	2025-10-09 20:29:48.678+00	2025-10-09 20:45:39.243+00	\N	\N
\.


--
-- TOC entry 4271 (class 0 OID 19961)
-- Dependencies: 352
-- Data for Name: project_relation; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.project_relation ("projectId", "userId", role, "createdAt", "updatedAt") FROM stdin;
i9Hx3voRXPvZMWtL	9f12b0ff-372b-4d46-b8ea-30c14a4a14a2	project:personalOwner	2025-10-09 20:29:48.678+00	2025-10-09 20:29:48.678+00
\.


--
-- TOC entry 4294 (class 0 OID 20398)
-- Dependencies: 375
-- Data for Name: role; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.role (slug, "displayName", description, "roleType", "systemRole", "createdAt", "updatedAt") FROM stdin;
global:owner	Owner	Owner	global	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.285+00
global:admin	Admin	Admin	global	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.285+00
global:member	Member	Member	global	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.285+00
project:admin	Project Admin	Project Admin	project	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.301+00
project:personalOwner	Project Owner	Project Owner	project	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.301+00
project:editor	Project Editor	Project Editor	project	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.301+00
project:viewer	Project Viewer	Project Viewer	project	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.301+00
credential:owner	Credential Owner	Credential Owner	credential	t	2025-10-09 20:29:49.31+00	2025-10-09 20:29:49.31+00
credential:user	Credential User	Credential User	credential	t	2025-10-09 20:29:49.31+00	2025-10-09 20:29:49.31+00
workflow:owner	Workflow Owner	Workflow Owner	workflow	t	2025-10-09 20:29:49.315+00	2025-10-09 20:29:49.315+00
workflow:editor	Workflow Editor	Workflow Editor	workflow	t	2025-10-09 20:29:49.315+00	2025-10-09 20:29:49.315+00
\.


--
-- TOC entry 4295 (class 0 OID 20406)
-- Dependencies: 376
-- Data for Name: role_scope; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.role_scope ("roleSlug", "scopeSlug") FROM stdin;
global:owner	annotationTag:create
global:owner	annotationTag:read
global:owner	annotationTag:update
global:owner	annotationTag:delete
global:owner	annotationTag:list
global:owner	auditLogs:manage
global:owner	banner:dismiss
global:owner	community:register
global:owner	communityPackage:install
global:owner	communityPackage:uninstall
global:owner	communityPackage:update
global:owner	communityPackage:list
global:owner	credential:share
global:owner	credential:move
global:owner	credential:create
global:owner	credential:read
global:owner	credential:update
global:owner	credential:delete
global:owner	credential:list
global:owner	externalSecretsProvider:sync
global:owner	externalSecretsProvider:create
global:owner	externalSecretsProvider:read
global:owner	externalSecretsProvider:update
global:owner	externalSecretsProvider:delete
global:owner	externalSecretsProvider:list
global:owner	externalSecret:list
global:owner	externalSecret:use
global:owner	eventBusDestination:test
global:owner	eventBusDestination:create
global:owner	eventBusDestination:read
global:owner	eventBusDestination:update
global:owner	eventBusDestination:delete
global:owner	eventBusDestination:list
global:owner	ldap:sync
global:owner	ldap:manage
global:owner	license:manage
global:owner	logStreaming:manage
global:owner	orchestration:read
global:owner	project:create
global:owner	project:read
global:owner	project:update
global:owner	project:delete
global:owner	project:list
global:owner	saml:manage
global:owner	securityAudit:generate
global:owner	sourceControl:pull
global:owner	sourceControl:push
global:owner	sourceControl:manage
global:owner	tag:create
global:owner	tag:read
global:owner	tag:update
global:owner	tag:delete
global:owner	tag:list
global:owner	user:resetPassword
global:owner	user:changeRole
global:owner	user:enforceMfa
global:owner	user:create
global:owner	user:read
global:owner	user:update
global:owner	user:delete
global:owner	user:list
global:owner	variable:create
global:owner	variable:read
global:owner	variable:update
global:owner	variable:delete
global:owner	variable:list
global:owner	workersView:manage
global:owner	workflow:share
global:owner	workflow:execute
global:owner	workflow:move
global:owner	workflow:create
global:owner	workflow:read
global:owner	workflow:update
global:owner	workflow:delete
global:owner	workflow:list
global:owner	folder:create
global:owner	folder:read
global:owner	folder:update
global:owner	folder:delete
global:owner	folder:list
global:owner	folder:move
global:owner	insights:list
global:owner	oidc:manage
global:owner	dataStore:list
global:owner	role:manage
global:admin	annotationTag:create
global:admin	annotationTag:read
global:admin	annotationTag:update
global:admin	annotationTag:delete
global:admin	annotationTag:list
global:admin	auditLogs:manage
global:admin	banner:dismiss
global:admin	community:register
global:admin	communityPackage:install
global:admin	communityPackage:uninstall
global:admin	communityPackage:update
global:admin	communityPackage:list
global:admin	credential:share
global:admin	credential:move
global:admin	credential:create
global:admin	credential:read
global:admin	credential:update
global:admin	credential:delete
global:admin	credential:list
global:admin	externalSecretsProvider:sync
global:admin	externalSecretsProvider:create
global:admin	externalSecretsProvider:read
global:admin	externalSecretsProvider:update
global:admin	externalSecretsProvider:delete
global:admin	externalSecretsProvider:list
global:admin	externalSecret:list
global:admin	externalSecret:use
global:admin	eventBusDestination:test
global:admin	eventBusDestination:create
global:admin	eventBusDestination:read
global:admin	eventBusDestination:update
global:admin	eventBusDestination:delete
global:admin	eventBusDestination:list
global:admin	ldap:sync
global:admin	ldap:manage
global:admin	license:manage
global:admin	logStreaming:manage
global:admin	orchestration:read
global:admin	project:create
global:admin	project:read
global:admin	project:update
global:admin	project:delete
global:admin	project:list
global:admin	saml:manage
global:admin	securityAudit:generate
global:admin	sourceControl:pull
global:admin	sourceControl:push
global:admin	sourceControl:manage
global:admin	tag:create
global:admin	tag:read
global:admin	tag:update
global:admin	tag:delete
global:admin	tag:list
global:admin	user:resetPassword
global:admin	user:changeRole
global:admin	user:enforceMfa
global:admin	user:create
global:admin	user:read
global:admin	user:update
global:admin	user:delete
global:admin	user:list
global:admin	variable:create
global:admin	variable:read
global:admin	variable:update
global:admin	variable:delete
global:admin	variable:list
global:admin	workersView:manage
global:admin	workflow:share
global:admin	workflow:execute
global:admin	workflow:move
global:admin	workflow:create
global:admin	workflow:read
global:admin	workflow:update
global:admin	workflow:delete
global:admin	workflow:list
global:admin	folder:create
global:admin	folder:read
global:admin	folder:update
global:admin	folder:delete
global:admin	folder:list
global:admin	folder:move
global:admin	insights:list
global:admin	oidc:manage
global:admin	dataStore:list
global:admin	role:manage
global:member	annotationTag:create
global:member	annotationTag:read
global:member	annotationTag:update
global:member	annotationTag:delete
global:member	annotationTag:list
global:member	eventBusDestination:test
global:member	eventBusDestination:list
global:member	tag:create
global:member	tag:read
global:member	tag:update
global:member	tag:list
global:member	user:list
global:member	variable:read
global:member	variable:list
global:member	dataStore:list
project:admin	credential:share
project:admin	credential:move
project:admin	credential:create
project:admin	credential:read
project:admin	credential:update
project:admin	credential:delete
project:admin	credential:list
project:admin	project:read
project:admin	project:update
project:admin	project:delete
project:admin	project:list
project:admin	sourceControl:push
project:admin	workflow:execute
project:admin	workflow:move
project:admin	workflow:create
project:admin	workflow:read
project:admin	workflow:update
project:admin	workflow:delete
project:admin	workflow:list
project:admin	folder:create
project:admin	folder:read
project:admin	folder:update
project:admin	folder:delete
project:admin	folder:list
project:admin	folder:move
project:admin	dataStore:create
project:admin	dataStore:read
project:admin	dataStore:update
project:admin	dataStore:delete
project:admin	dataStore:readRow
project:admin	dataStore:writeRow
project:admin	dataStore:listProject
project:personalOwner	credential:share
project:personalOwner	credential:move
project:personalOwner	credential:create
project:personalOwner	credential:read
project:personalOwner	credential:update
project:personalOwner	credential:delete
project:personalOwner	credential:list
project:personalOwner	project:read
project:personalOwner	project:list
project:personalOwner	workflow:share
project:personalOwner	workflow:execute
project:personalOwner	workflow:move
project:personalOwner	workflow:create
project:personalOwner	workflow:read
project:personalOwner	workflow:update
project:personalOwner	workflow:delete
project:personalOwner	workflow:list
project:personalOwner	folder:create
project:personalOwner	folder:read
project:personalOwner	folder:update
project:personalOwner	folder:delete
project:personalOwner	folder:list
project:personalOwner	folder:move
project:personalOwner	dataStore:create
project:personalOwner	dataStore:read
project:personalOwner	dataStore:update
project:personalOwner	dataStore:delete
project:personalOwner	dataStore:readRow
project:personalOwner	dataStore:writeRow
project:personalOwner	dataStore:listProject
project:editor	credential:create
project:editor	credential:read
project:editor	credential:update
project:editor	credential:delete
project:editor	credential:list
project:editor	project:read
project:editor	project:list
project:editor	workflow:execute
project:editor	workflow:create
project:editor	workflow:read
project:editor	workflow:update
project:editor	workflow:delete
project:editor	workflow:list
project:editor	folder:create
project:editor	folder:read
project:editor	folder:update
project:editor	folder:delete
project:editor	folder:list
project:editor	dataStore:create
project:editor	dataStore:read
project:editor	dataStore:update
project:editor	dataStore:delete
project:editor	dataStore:readRow
project:editor	dataStore:writeRow
project:editor	dataStore:listProject
project:viewer	credential:read
project:viewer	credential:list
project:viewer	project:read
project:viewer	project:list
project:viewer	workflow:read
project:viewer	workflow:list
project:viewer	folder:read
project:viewer	folder:list
project:viewer	dataStore:read
project:viewer	dataStore:readRow
project:viewer	dataStore:listProject
credential:owner	credential:share
credential:owner	credential:move
credential:owner	credential:read
credential:owner	credential:update
credential:owner	credential:delete
credential:user	credential:read
workflow:owner	workflow:share
workflow:owner	workflow:execute
workflow:owner	workflow:move
workflow:owner	workflow:read
workflow:owner	workflow:update
workflow:owner	workflow:delete
workflow:editor	workflow:execute
workflow:editor	workflow:read
workflow:editor	workflow:update
\.


--
-- TOC entry 4293 (class 0 OID 20391)
-- Dependencies: 374
-- Data for Name: scope; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.scope (slug, "displayName", description) FROM stdin;
annotationTag:create	Create Annotation Tag	Allows creating new annotation tags.
annotationTag:read	annotationTag:read	\N
annotationTag:update	annotationTag:update	\N
annotationTag:delete	annotationTag:delete	\N
annotationTag:list	annotationTag:list	\N
annotationTag:*	annotationTag:*	\N
auditLogs:manage	auditLogs:manage	\N
auditLogs:*	auditLogs:*	\N
banner:dismiss	banner:dismiss	\N
banner:*	banner:*	\N
community:register	community:register	\N
community:*	community:*	\N
communityPackage:install	communityPackage:install	\N
communityPackage:uninstall	communityPackage:uninstall	\N
communityPackage:update	communityPackage:update	\N
communityPackage:list	communityPackage:list	\N
communityPackage:manage	communityPackage:manage	\N
communityPackage:*	communityPackage:*	\N
credential:share	credential:share	\N
credential:move	credential:move	\N
credential:create	credential:create	\N
credential:read	credential:read	\N
credential:update	credential:update	\N
credential:delete	credential:delete	\N
credential:list	credential:list	\N
credential:*	credential:*	\N
externalSecretsProvider:sync	externalSecretsProvider:sync	\N
externalSecretsProvider:create	externalSecretsProvider:create	\N
externalSecretsProvider:read	externalSecretsProvider:read	\N
externalSecretsProvider:update	externalSecretsProvider:update	\N
externalSecretsProvider:delete	externalSecretsProvider:delete	\N
externalSecretsProvider:list	externalSecretsProvider:list	\N
externalSecretsProvider:*	externalSecretsProvider:*	\N
externalSecret:list	externalSecret:list	\N
externalSecret:use	externalSecret:use	\N
externalSecret:*	externalSecret:*	\N
eventBusDestination:test	eventBusDestination:test	\N
eventBusDestination:create	eventBusDestination:create	\N
eventBusDestination:read	eventBusDestination:read	\N
eventBusDestination:update	eventBusDestination:update	\N
eventBusDestination:delete	eventBusDestination:delete	\N
eventBusDestination:list	eventBusDestination:list	\N
eventBusDestination:*	eventBusDestination:*	\N
ldap:sync	ldap:sync	\N
ldap:manage	ldap:manage	\N
ldap:*	ldap:*	\N
license:manage	license:manage	\N
license:*	license:*	\N
logStreaming:manage	logStreaming:manage	\N
logStreaming:*	logStreaming:*	\N
orchestration:read	orchestration:read	\N
orchestration:list	orchestration:list	\N
orchestration:*	orchestration:*	\N
project:create	project:create	\N
project:read	project:read	\N
project:update	project:update	\N
project:delete	project:delete	\N
project:list	project:list	\N
project:*	project:*	\N
saml:manage	saml:manage	\N
saml:*	saml:*	\N
securityAudit:generate	securityAudit:generate	\N
securityAudit:*	securityAudit:*	\N
sourceControl:pull	sourceControl:pull	\N
sourceControl:push	sourceControl:push	\N
sourceControl:manage	sourceControl:manage	\N
sourceControl:*	sourceControl:*	\N
tag:create	tag:create	\N
tag:read	tag:read	\N
tag:update	tag:update	\N
tag:delete	tag:delete	\N
tag:list	tag:list	\N
tag:*	tag:*	\N
user:resetPassword	user:resetPassword	\N
user:changeRole	user:changeRole	\N
user:enforceMfa	user:enforceMfa	\N
user:create	user:create	\N
user:read	user:read	\N
user:update	user:update	\N
user:delete	user:delete	\N
user:list	user:list	\N
user:*	user:*	\N
variable:create	variable:create	\N
variable:read	variable:read	\N
variable:update	variable:update	\N
variable:delete	variable:delete	\N
variable:list	variable:list	\N
variable:*	variable:*	\N
workersView:manage	workersView:manage	\N
workersView:*	workersView:*	\N
workflow:share	workflow:share	\N
workflow:execute	workflow:execute	\N
workflow:move	workflow:move	\N
workflow:activate	workflow:activate	\N
workflow:deactivate	workflow:deactivate	\N
workflow:create	workflow:create	\N
workflow:read	workflow:read	\N
workflow:update	workflow:update	\N
workflow:delete	workflow:delete	\N
workflow:list	workflow:list	\N
workflow:*	workflow:*	\N
folder:create	folder:create	\N
folder:read	folder:read	\N
folder:update	folder:update	\N
folder:delete	folder:delete	\N
folder:list	folder:list	\N
folder:move	folder:move	\N
folder:*	folder:*	\N
insights:list	insights:list	\N
insights:*	insights:*	\N
oidc:manage	oidc:manage	\N
oidc:*	oidc:*	\N
dataStore:create	dataStore:create	\N
dataStore:read	dataStore:read	\N
dataStore:update	dataStore:update	\N
dataStore:delete	dataStore:delete	\N
dataStore:list	dataStore:list	\N
dataStore:readRow	dataStore:readRow	\N
dataStore:writeRow	dataStore:writeRow	\N
dataStore:listProject	dataStore:listProject	\N
dataStore:*	dataStore:*	\N
execution:delete	execution:delete	\N
execution:read	execution:read	\N
execution:retry	execution:retry	\N
execution:list	execution:list	\N
execution:get	execution:get	\N
execution:*	execution:*	\N
workflowTags:update	workflowTags:update	\N
workflowTags:list	workflowTags:list	\N
workflowTags:*	workflowTags:*	\N
role:manage	role:manage	\N
role:*	role:*	\N
*	*	\N
\.


--
-- TOC entry 4259 (class 0 OID 19506)
-- Dependencies: 340
-- Data for Name: settings; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.settings (key, value, "loadOnStartup") FROM stdin;
ui.banners.dismissed	["V1"]	t
features.ldap	{"loginEnabled":false,"loginLabel":"","connectionUrl":"","allowUnauthorizedCerts":false,"connectionSecurity":"none","connectionPort":389,"baseDn":"","bindingAdminDn":"","bindingAdminPassword":"","firstNameAttribute":"","lastNameAttribute":"","emailAttribute":"","loginIdAttribute":"","ldapIdAttribute":"","userFilter":"","synchronizationEnabled":false,"synchronizationInterval":60,"searchPageSize":0,"searchTimeout":60}	t
userManagement.authenticationMethod	email	t
features.sourceControl.sshKeys	{"encryptedPrivateKey":"U2FsdGVkX18uK1cYPYc2Qqvf+aKSdY6oHbf5l0BCwR6cf7koIhxfqGl+fjXlNo08E0mNGYTUYMEfXX1oTf0cri5avihshJrZjx4I4bkSM3G7jG38t/k257KVEnBTkzPYkHHgNMS2PuYEirq08jIo83eUjJzec55QRDMAAb0qrQz5qnvBcxAyXRjkWwbQIK6LM8BNBKOLhHNXuiN5fCqHmru+RMY36gzX1B/z3tfvU575nAvKItVy9C5AR9YqeuGuSyFbtvxHVyaOhnM7guVg8nm0pHZoTR548mbIcRX4yYHwAYBpC2RWa6KT0PqdRDufoEGcD6ODbbmJHCcN7673B5XCkoj6XbNLLKBAu1d+0YPAzZWQq7/Z2pk3iHrlNWMpmcYOnxa8IIjeXO2AsdNlhhsrPs8OUTnCVslRGh8Eugee9SQpeCYhkGauFl1Mich0NCWCFc8j6ZTve4RN4rLLVGk9XrKfq5qSC8DfNStQPbM32ZFZXB0MMWWusOtFEkFUjQncmgHQo+kHZTQqtQrS5nI/RzxGMi/t4XGN4WIwP/EwmC4VtxrWTn9E6oH0KKJr","publicKey":"ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIPOfUCG5hekveeuBOAeFv0t01F7srLLyVCFZA3gmZ2Gm n8n deploy key"}	t
features.sourceControl	{"branchName":"main","keyGeneratorType":"ed25519"}	t
userManagement.isInstanceOwnerSetUp	true	t
license.cert	eyJsaWNlbnNlS2V5IjoiLS0tLS1CRUdJTiBMSUNFTlNFIEtFWS0tLS0tXG5mS3pqSUppSGQrNWJlSFZINzRnLzdJQy9tZVFhdTlHQ1VrS0NyUUo5L2NhTXZyZkxDcy8xdUtUMzZwd3pLTGJPXG5hRXdXaXBiakw1L3ZnaGc1Wno1NnhQSC9iT0ZIV2g4RkcvaTA2Q3JwajJPbEVLZXNMQlEzZ3RETDNZek1HT01uXG53OUJHb1lQd3FLbHM2OEV6Q0NHVVFWYlQrVUxHZVpjbUdOMGszV2hwZ1JNUjIwMU1TcEJiNTNlRkZMYnpCNnY0XG4ybzArYzBNSk1SREZxOEREcm8rbjNGTzdkUk1FeG9uMWswM0xHa1hqWGhkY1E3cjY3T3ZOYVZnaS9MU1FJSFk0XG55elRhbUowYUIwNmJ5RE5BUkRBbitScElHN3RjYm5BdGRETU90RVpBWUt2NjIvZXZMbjAvTHRsdHN4WnQySUpnXG5xWW1TVzRiT1E3NjdEZDZicDJ0NHdRPT18fFUyRnNkR1ZrWDE5T3ZGWEpLb3dWdU5KU1VWNjE3SWR1ZWZ6T0YrXG44NHUybzFqN1FCNHVxcWFsTHIwQXFOSVhxeTFjVm9wY0U1cU9ueGNHUlBqOVI3NnNXTjY1RENKZEtXN3RaUFpVXG5mM3JoSHY2d0dXd0tYWWFicHNoQTl0OFpodERsMnh2MENZc1Y4Mmc5VTBhZCthSllMc2tEa2JLZ21RSFRrNjhUXG5BS0p3OU9MYUhhL05SaVBDTkdYeHl1NHRpVXdLZ1cxaDVwbkVZZUJmZjZCTTAxeG1wTVJGVFBxWFYrYXkyL29NXG5zU3FITFRldzNQRThCUWw4QVk1M0JHTDlQNGVGVnlCM2RUMXNENmdVR0E4bFJwOEtlY2gvRmtSa2djK2c5WGpXXG5XeEprbFcrWDJoSmtyUWphMzhwcFZKbWV3Z3hXMXdScFBldzNPdmJZZHFKVnVmeDZUZEhoRElBVWNQRU5SbFkxXG5NWUxUMi9CaDdvNzR3S09FT1BYMk5tbXBvZlpjYkl0bUFEdXduQjB2TDlycGE0QnpaVGhIangwdi9vbU0zSW1LXG5wR3JMVk9yVWpoZjdFalJLUUMxeWs0eFZGQTRwSlFSdFNPUWg1dm5BT0dUUXExRXhETnBCa0pQaGxzdHBnSTcrXG55ckEvNW9CaEYvcjFLRFlYNDkrY0ZYSEkzcDNSQnJFQkM3STRLT2JhczZDS3dIQXN0M3lLNmVJMkdaSFRCUXJEXG5qM0lseitjVlU5bUxmTjIraFUzZDB1UFZ6TEtjbmxEdVlhcnVOeFN6K2RKNHduN0tGU0pSLzZzcmJjak9ra1RrXG5MSnZwWnZhWGYvVDRnL3lJai9LeEJnaDdlMXhZeWRZNjN5ZUxmRWJteVNCZzZTQURkcTlMZnhDTVdYV1ZwTW9NXG54OU9ySEYrV1JCNWZrSFpwQnFtcVQ5QkIyV09YaXppOFBLVlJQcUo0T3l0OTNkZnpodzJEcGNWQmpRM1hLMmNUXG5nci9WMEFQRmdxd3lYRDNRVTFuZXNzYWt2YUlMQU5qblg5ZGM5Sm1sRm4xbXVHY3lxRy9wejZwMmM3NXk3ZjZYXG5jYU1ZYWd6eWRycUlFU2V4ZFlBVnZFODFTR0JGZjlxczQ3QUJCb1l3eXphRCtRMmxoTk40MkNucWdxTkcxWFZGXG5ENjVFV1gxR3ovTlpURTZsK3ZEbHViWDI3MHhUKytzYjJySG5jMGNGdlh3RDJidzFTSGRBUk1HMkJxMkVPaERuXG5IS0NWMlNmV0kzSDA1S2tZZlZEZDYwR0dNSVU5aVYzaXc5UGNjTUY5K3FJWkFXZ2p4S3djTkdKdjY4WllXOXRWXG5BMWxXSXBGMlp0SFFoenNNazNNWm9OK29HV3QwTWpwWlpaUW1kNlV6MmpXTEdzbFltd2RZK0t3MVhqYkhZcTlPXG4wVG9CYlJFUWVjN1VGRGhtRysyOWJsWGFUUS9HWUJYdXE0Q0p0dWsvQnB2aWtsbXNlMkFYNXl6QTgvTHlreFk4XG55UXBQOFVoTmJXMjl1U1BUeUI5UWVoNm1RWE94R3luK1dwYVpyU0FhSytXeGV0V0FqeVNsdjFWNW8vcGNUbSszXG5leU84a0xkcXFYeHdBTFRzZm5UQlV0Qko3N3dUY2MxNEZ4N0l4bnJWdXQxVlM4MUNrbjMzREt0Smk0UzBZY2Y1XG5TV3pZbDRZWUpXKzM4UDZzaCtFQ2E3eTg3dGorclJyK3lEZUloM2l4VUp4TUtPR3FaWGNXdVFMZnFwK1gzaytvXG40R3I0UkVSdTNVSEtwQkFDWHFhTVdldjI2ZVFjRFdJcEVsYUQxSFMwVDZUcDEwSEVaNWhwNmxxMDA5MmQwVU1JXG5YbDB4aEU2c3IxTWU4M095NE5ISnd2dUhCYzQ0cC84UlQwRWxhc2dLd3NQalJqTkMyMFBoUWxZOW14ZTRHTExOXG5NbDZaVXR2YnQ3aEpDS3FIdFJZYkVmbmxMTTgvaDBBRmtNS0MwRmdLbHYvT0F3L2xiZnFHSENhVlNsKzJQTTFtXG5EMnhlRHRHUVRHemY1THhreGtFalNEMllvQnZoSUtSTk13LzY4d2ZGSzhvOXNpc1BnOGpjN0NQZzlrNDJraThaXG53clZQZkdUQVYrTTROSDh0eUtGckp3QmVMYVJ6RlF2MmJmMiswUGs0clFtd1JJWGlMNHplY25PeUwvY3FIR2xjXG5tMU9GU255YjZnaDZKR0x0aFJEck5iMnpaYXRnS3hoNkNZSzBkbExXZWFSY3VXc1FuVWcxYkFLRENjVmRxdElSXG5yaGdLS3RWeXU5WkFKV2lrZ2d3MTJKL3hzakdYQmd0eHpuaWEzREYvWjNyd01oVUV0SGkzSXc2SWRCTlVjNmZQXG5ENGxLcHRxTElsQUpOT0pJN09FSFlTdjR2YUlEMFBBRE0zU1RuemgycTFlTzhJdzhWSTdxeGxISjBDN294RnNEXG5VUE9PSlFVcENPU0dxZ2svc3NncEJ2ek5SaW1VR0QzWTFncUdWK2Z0VVBlaTlXeENmYjR6RW1pMDZReFF6TlZmXG4rKzlLdks3aFpuQjdlMG15T0tQTDNUbnZITDN0MStXeFBITEtZVy9PSnRpRVJnMFE3OG9Rc3ZhaW91K1lXN0lYXG40cUNHeUlLeVI3L2JURHVyakRQMzRMdThKL3dQbTR1OUFBZ3d4WmpqRk82a0gzc2tnRktyN1JNQTJHWHJXWC9SXG5DZGNod3czM0haT3hJakxXeld1M0FGYzYvNVB0UTBNTGE1VVhVanNYYzVHNW9SaUlWV2VBMUo3LzQybXo0ZXRTXG50VEJhNXo0a0xZYTc5OUE4WDVkMUZES3lGemhGVlQ0c1F2bUsyUHJ2Z2tGQVFGSlE1WGpKQkxaUE1uYWs0UmM0XG5URkFteWJQUmtsaEVLK2RjYkpFbFIzMDJFNFI1SjAwNzdkRGtGdVlDeFRuYlh5L0F5U2ZsdysvdG96Z3U5SWRPXG5hVFdSYTJobGhNRmZjYjFpbGFvUzNUc1dKTUFBZ1RRTFBjOXM0dVVmQlpqbzNJWDdTR1FtQnNQc3QrdThnVUJxXG56L0dpUWRkVGx0SnIrendRQm1ZUzY1SFBCdTR5M3NHdWxyZGxGZGpCcTBraWdZbnc9PXx8WTJ6KzBEKzBiRDJsXG56U1JpbHRlSzNFTExuNGZsOHg1Sk1VbU5sQ3JrU0RRNUJBU2F2azJpeW9sS0xLRWVYZWVETUROenorMzNHVkNZXG40SlpSb1RhNXhIdlN4QlE5UHR4bFZEZ0N0eVNCZTJ6a3o5OUpyVjE4QWQrMklHTU40OEtCSjNxMkFQMG5reXNZXG5xZ2Zab3FDTVNDQnZLTjQzbHdVWXE0elZ3SEFOUDNGeGRvbjQyUXdUd2FGNHZ2L0pVOVRRcmZ4WUxPWTUwM09EXG4vWXVpa2ZTY0lKYy9zUG5lVk5GV2JJUjFJNStSQ1hmVlNnUm1lbUJmYmI2SFpvUnZPRzRpMk92RWJPL1VjQjNrXG54VS9wZHYzaUNjL1pldWJ6d2ZpQlE5dEUyMXUyMVd0aXh6QTc1eDJQZ25UR0VyUTFjOHp2RkxwdC9ZR2JmaUtaXG5UdUx0OFZ1VXJnPT1cbi0tLS0tRU5EIExJQ0VOU0UgS0VZLS0tLS0iLCJ4NTA5IjoiLS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tXG5NSUlFRERDQ0FmUUNDUUNxZzJvRFQ4MHh3akFOQmdrcWhraUc5dzBCQVFVRkFEQklNUXN3Q1FZRFZRUUdFd0pFXG5SVEVQTUEwR0ExVUVDQXdHUW1WeWJHbHVNUTh3RFFZRFZRUUhEQVpDWlhKc2FXNHhGekFWQmdOVkJBTU1EbXhwXG5ZMlZ1YzJVdWJqaHVMbWx2TUI0WERUSXlNRFl5TkRBME1UQTBNRm9YRFRJek1EWXlOREEwTVRBME1Gb3dTREVMXG5NQWtHQTFVRUJoTUNSRVV4RHpBTkJnTlZCQWdNQmtKbGNteHBiakVQTUEwR0ExVUVCd3dHUW1WeWJHbHVNUmN3XG5GUVlEVlFRRERBNXNhV05sYm5ObExtNDRiaTVwYnpDQ0FTSXdEUVlKS29aSWh2Y05BUUVCQlFBRGdnRVBBRENDXG5BUW9DZ2dFQkFNQk0wNVhCNDRnNXhmbUNMd2RwVVR3QVQ4K0NCa3lMS0ZzZXprRDVLLzZXaGFYL1hyc2QvUWQwXG4yMEo3d2w1V2RIVTRjVkJtRlJqVndWemtsQ0syeVlKaThtang4c1hzR3E5UTFsYlVlTUtmVjlkc2dmdWhubEFTXG50blFaZ2x1Z09uRjJGZ1JoWGIvakswdHhUb2FvK2JORTZyNGdJRXpwa3RITEJUWXZ2aXVKbXJlZjdXYlBSdDRJXG5uZDlEN2xoeWJlYnloVjdrdXpqUUEvcFBLSFRGczhNVEhaOGhZVXhSeXJwbTMrTVl6UUQrYmpBMlUxRkljdGFVXG53UVhZV2FON3QydVR3Q3Q5ekFLc21ZL1dlT2J2bDNUWk41T05MQXp5V0dDdWxtNWN3S1IzeGJsQlp6WG5CNmdzXG5Pbk4yT0FkU3RjelRWQ3ljbThwY0ZVcnl0S1NLa0dFQ0F3RUFBVEFOQmdrcWhraUc5dzBCQVFVRkFBT0NBZ0VBXG5sSjAxd2NuMXZqWFhDSHVvaTdSMERKMWxseDErZGFmcXlFcVBBMjdKdStMWG1WVkdYUW9yUzFiOHhqVXFVa2NaXG5UQndiV0ZPNXo1ZFptTnZuYnlqYXptKzZvT2cwUE1hWXhoNlRGd3NJMlBPYmM3YkZ2MmVheXdQdC8xQ3BuYzQwXG5xVU1oZnZSeC9HQ1pQQ1d6My8yUlBKV1g5alFEU0hYQ1hxOEJXK0kvM2N1TERaeVkzZkVZQkIwcDNEdlZtYWQ2XG42V0hRYVVyaU4wL0xxeVNPcC9MWmdsbC90MDI5Z1dWdDA1WmliR29LK2NWaFpFY3NMY1VJaHJqMnVGR0ZkM0ltXG5KTGcxSktKN2pLU0JVUU9kSU1EdnNGVUY3WWRNdk11ckNZQTJzT05OOENaK0k1eFFWMUtTOWV2R0hNNWZtd2dTXG5PUEZ2UHp0RENpMC8xdVc5dE9nSHBvcnVvZGFjdCtFWk5rQVRYQ3ZaaXUydy9xdEtSSkY0VTRJVEVtNWFXMGt3XG42enVDOHh5SWt0N3ZoZHM0OFV1UlNHSDlqSnJBZW1sRWl6dEdJTGhHRHF6UUdZYmxoVVFGR01iQmI3amhlTHlDXG5MSjFXT0c2MkYxc3B4Q0tCekVXNXg2cFIxelQxbWhFZ2Q0TWtMYTZ6UFRwYWNyZDk1QWd4YUdLRUxhMVJXU0ZwXG5NdmRoR2s0TnY3aG5iOHIrQnVNUkM2aWVkUE1DelhxL001MGNOOEFnOGJ3K0oxYUZvKzBFSzJoV0phN2tpRStzXG45R3ZGalNkekNGbFVQaEtra1Vaa1NvNWFPdGNRcTdKdTZrV0JoTG9GWUtncHJscDFRVkIwc0daQTZvNkR0cWphXG5HNy9SazZ2YmFZOHdzTllLMnpCWFRUOG5laDVab1JaL1BKTFV0RUV0YzdZPVxuLS0tLS1FTkQgQ0VSVElGSUNBVEUtLS0tLSJ9	f
\.


--
-- TOC entry 4272 (class 0 OID 19989)
-- Dependencies: 353
-- Data for Name: shared_credentials; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.shared_credentials ("credentialsId", "projectId", role, "createdAt", "updatedAt") FROM stdin;
7tuOlNCTiyjK0BzN	i9Hx3voRXPvZMWtL	credential:owner	2025-10-10 12:48:44.887+00	2025-10-10 12:48:44.887+00
\.


--
-- TOC entry 4273 (class 0 OID 20015)
-- Dependencies: 354
-- Data for Name: shared_workflow; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.shared_workflow ("workflowId", "projectId", role, "createdAt", "updatedAt") FROM stdin;
1LaQnwqSoTxmnw3Z	i9Hx3voRXPvZMWtL	workflow:owner	2025-10-09 23:01:45.917+00	2025-10-09 23:01:45.917+00
9jxl03jCcqg17oOy	i9Hx3voRXPvZMWtL	workflow:owner	2025-10-09 23:01:53.794+00	2025-10-09 23:01:53.794+00
Q08T7oMX2dZslqV4	i9Hx3voRXPvZMWtL	workflow:owner	2025-10-09 23:04:05.011+00	2025-10-09 23:04:05.011+00
\.


--
-- TOC entry 4256 (class 0 OID 19357)
-- Dependencies: 337
-- Data for Name: tag_entity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.tag_entity (name, "createdAt", "updatedAt", id) FROM stdin;
\.


--
-- TOC entry 4292 (class 0 OID 20369)
-- Dependencies: 373
-- Data for Name: test_case_execution; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.test_case_execution (id, "testRunId", "executionId", status, "runAt", "completedAt", "errorCode", "errorDetails", metrics, "createdAt", "updatedAt", inputs, outputs) FROM stdin;
\.


--
-- TOC entry 4291 (class 0 OID 20354)
-- Dependencies: 372
-- Data for Name: test_run; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.test_run (id, "workflowId", status, "errorCode", "errorDetails", "runAt", "completedAt", metrics, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4258 (class 0 OID 19443)
-- Dependencies: 339
-- Data for Name: user; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n."user" (id, email, "firstName", "lastName", password, "personalizationAnswers", "createdAt", "updatedAt", settings, disabled, "mfaEnabled", "mfaSecret", "mfaRecoveryCodes", "lastActiveAt", "roleSlug") FROM stdin;
9f12b0ff-372b-4d46-b8ea-30c14a4a14a2	golfergeek@orchestratorai.io	Golfer	Geek	$2a$10$5GQh3k/cRVa6iXMmTerh0uPGTsowKkMWHAcU/6QgXoVG3p5bOjx3u	{"version":"v4","personalization_survey_submitted_at":"2025-10-09T20:45:55.451Z","personalization_survey_n8n_version":"1.113.3","companySize":"<20","companyType":"saas","role":"business-owner","reportedSource":"youtube"}	2025-10-09 20:29:48.187+00	2025-10-10 13:50:29.848+00	{"userActivated": false}	f	f	\N	\N	2025-10-10	global:owner
\.


--
-- TOC entry 4281 (class 0 OID 20101)
-- Dependencies: 362
-- Data for Name: user_api_keys; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.user_api_keys (id, "userId", label, "apiKey", "createdAt", "updatedAt", scopes) FROM stdin;
zQTzYfs7ExLSDksn	9f12b0ff-372b-4d46-b8ea-30c14a4a14a2	OrchestratorAI	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI5ZjEyYjBmZi0zNzJiLTRkNDYtYjhlYS0zMGMxNGE0YTE0YTIiLCJpc3MiOiJuOG4iLCJhdWQiOiJwdWJsaWMtYXBpIiwiaWF0IjoxNzYwMDQyOTA4fQ.kGRjGIPvyOptWjzFAatIt0KZbG7leeRYoNhyifC73BM	2025-10-09 20:48:28.884+00	2025-10-09 20:48:28.884+00	["credential:create","credential:delete","credential:move","project:create","project:delete","project:list","project:update","securityAudit:generate","sourceControl:pull","tag:create","tag:delete","tag:list","tag:read","tag:update","user:changeRole","user:create","user:delete","user:enforceMfa","user:list","user:read","variable:create","variable:delete","variable:list","variable:update","workflow:create","workflow:delete","workflow:list","workflow:move","workflow:read","workflow:update","workflowTags:update","workflowTags:list","workflow:activate","workflow:deactivate","execution:delete","execution:read","execution:retry","execution:list"]
\.


--
-- TOC entry 4267 (class 0 OID 19627)
-- Dependencies: 348
-- Data for Name: variables; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.variables (key, type, value, id) FROM stdin;
\.


--
-- TOC entry 4255 (class 0 OID 19347)
-- Dependencies: 336
-- Data for Name: webhook_entity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.webhook_entity ("webhookPath", method, node, "webhookId", "pathLength", "workflowId") FROM stdin;
marketing-swarm	POST	Webhook Trigger	\N	\N	Q08T7oMX2dZslqV4
\.


--
-- TOC entry 4254 (class 0 OID 19339)
-- Dependencies: 335
-- Data for Name: workflow_entity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.workflow_entity (name, active, nodes, connections, "createdAt", "updatedAt", settings, "staticData", "pinData", "versionId", "triggerCount", id, meta, "parentFolderId", "isArchived") FROM stdin;
Helper: LLM Task	f	[{"parameters":{},"id":"execute-workflow-trigger","name":"Execute Workflow Trigger","type":"n8n-nodes-base.executeWorkflowTrigger","typeVersion":1,"position":[240,304]},{"parameters":{"conditions":{"boolean":[{"value1":"={{ $('Execute Workflow Trigger').item.json.sendStartStatus }}","value2":true}]},"options":{}},"id":"check-send-start","name":"Check Send Start Status","type":"n8n-nodes-base.if","typeVersion":2,"position":[464,304]},{"parameters":{"method":"POST","url":"={{ $('Execute Workflow Trigger').item.json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  taskId: $('Execute Workflow Trigger').item.json.taskId,\\\\n  status: 'running',\\\\n  timestamp: new Date().toISOString(),\\\\n  step: $('Execute Workflow Trigger').item.json.stepName,\\\\n  message: 'Starting ' + ($('Execute Workflow Trigger').item.json.stepName || 'task'),\\\\n  sequence: $('Execute Workflow Trigger').item.json.sequence,\\\\n  totalSteps: $('Execute Workflow Trigger').item.json.totalSteps,\\\\n  conversationId: $('Execute Workflow Trigger').item.json.conversationId,\\\\n  userId: $('Execute Workflow Trigger').item.json.userId\\\\n}) }}","options":{}},"id":"send-start-status","name":"Send Start Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[688,192],"continueOnFail":true},{"parameters":{"mode":"expression","output":null},"id":"select-provider","name":"Select Provider","type":"n8n-nodes-base.switch","typeVersion":3,"position":[688,432]},{"parameters":{"method":"POST","url":"https://api.openai.com/v1/chat/completions","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  model: $('Execute Workflow Trigger').item.json.model || 'gpt-4',\\\\n  messages: [{ role: 'user', content: $('Execute Workflow Trigger').item.json.prompt }],\\\\n  temperature: $('Execute Workflow Trigger').item.json.temperature || 0.7,\\\\n  max_tokens: $('Execute Workflow Trigger').item.json.maxTokens || 1000\\\\n}) }}","options":{}},"id":"openai-request","name":"OpenAI Request","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[912,304]},{"parameters":{"method":"POST","url":"={{ $('Execute Workflow Trigger').item.json.baseUrl || 'http://host.docker.internal:11434/api/generate' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  model: $('Execute Workflow Trigger').item.json.model || 'llama2',\\\\n  prompt: $('Execute Workflow Trigger').item.json.prompt,\\\\n  stream: false,\\\\n  options: {\\\\n    temperature: $('Execute Workflow Trigger').item.json.temperature || 0.7,\\\\n    num_predict: $('Execute Workflow Trigger').item.json.maxTokens || 1000\\\\n  }\\\\n}) }}","options":{}},"id":"ollama-request","name":"Ollama Request","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[912,432]},{"parameters":{"method":"POST","url":"https://api.anthropic.com/v1/messages","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  model: $('Execute Workflow Trigger').item.json.model || 'claude-3-sonnet-20240229',\\\\n  messages: [{ role: 'user', content: $('Execute Workflow Trigger').item.json.prompt }],\\\\n  temperature: $('Execute Workflow Trigger').item.json.temperature || 0.7,\\\\n  max_tokens: $('Execute Workflow Trigger').item.json.maxTokens || 1000\\\\n}) }}","options":{}},"id":"anthropic-request","name":"Anthropic Request","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[912,544]},{"parameters":{"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.choices[0].message.content }}"},{"name":"provider","type":"string","value":"openai"},{"name":"model","type":"string","value":"={{ $json.model }}"},{"name":"usage","type":"object","value":"={{ $json.usage }}"}]},"options":{}},"id":"normalize-openai","name":"Normalize OpenAI","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1120,304]},{"parameters":{"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.response }}"},{"name":"provider","type":"string","value":"ollama"},{"name":"model","type":"string","value":"={{ $json.model }}"},{"name":"usage","type":"object","value":"={{ { prompt_tokens: $json.prompt_eval_count, completion_tokens: $json.eval_count } }}"}]},"options":{}},"id":"normalize-ollama","name":"Normalize Ollama","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1120,432]},{"parameters":{"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.content[0].text }}"},{"name":"provider","type":"string","value":"anthropic"},{"name":"model","type":"string","value":"={{ $json.model }}"},{"name":"usage","type":"object","value":"={{ $json.usage }}"}]},"options":{}},"id":"normalize-anthropic","name":"Normalize Anthropic","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1120,544]},{"parameters":{"conditions":{"boolean":[{"value1":"={{ $('Execute Workflow Trigger').item.json.sendEndStatus }}","value2":true}]},"options":{}},"id":"check-send-end","name":"Check Send End Status","type":"n8n-nodes-base.if","typeVersion":2,"position":[1344,432]},{"parameters":{"method":"POST","url":"={{ $('Execute Workflow Trigger').item.json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  taskId: $('Execute Workflow Trigger').item.json.taskId,\\\\n  status: 'completed',\\\\n  timestamp: new Date().toISOString(),\\\\n  step: $('Execute Workflow Trigger').item.json.stepName,\\\\n  message: 'Completed ' + ($('Execute Workflow Trigger').item.json.stepName || 'task'),\\\\n  sequence: $('Execute Workflow Trigger').item.json.sequence,\\\\n  totalSteps: $('Execute Workflow Trigger').item.json.totalSteps,\\\\n  conversationId: $('Execute Workflow Trigger').item.json.conversationId,\\\\n  userId: $('Execute Workflow Trigger').item.json.userId\\\\n}) }}","options":{}},"id":"send-end-status","name":"Send End Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1568,304],"continueOnFail":true}]	{"Execute Workflow Trigger":{"main":[[{"node":"Check Send Start Status","type":"main","index":0}]]},"Check Send Start Status":{"main":[[{"node":"Send Start Status","type":"main","index":0}],[{"node":"Select Provider","type":"main","index":0}]]},"Send Start Status":{"main":[[{"node":"Select Provider","type":"main","index":0}]]},"Select Provider":{"main":[[{"node":"OpenAI Request","type":"main","index":0}],[{"node":"Ollama Request","type":"main","index":0}],[{"node":"Anthropic Request","type":"main","index":0}]]},"OpenAI Request":{"main":[[{"node":"Normalize OpenAI","type":"main","index":0}]]},"Ollama Request":{"main":[[{"node":"Normalize Ollama","type":"main","index":0}]]},"Anthropic Request":{"main":[[{"node":"Normalize Anthropic","type":"main","index":0}]]},"Normalize OpenAI":{"main":[[{"node":"Check Send End Status","type":"main","index":0}]]},"Normalize Ollama":{"main":[[{"node":"Check Send End Status","type":"main","index":0}]]},"Normalize Anthropic":{"main":[[{"node":"Check Send End Status","type":"main","index":0}]]},"Check Send End Status":{"main":[[{"node":"Send End Status","type":"main","index":0}],[]]}}	2025-10-08 18:29:22.544+00	2025-10-08 18:44:54.356+00	{}	\N	{}	2892ac76-9646-46f4-9e0d-5b65555d6ff8	0	9jxl03jCcqg17oOy	\N	\N	f
Marketing Swarm - Flexible LLM	f	[{"parameters":{"httpMethod":"POST","path":"marketing-swarm-flexible","options":{}},"id":"webhook","name":"Webhook","type":"n8n-nodes-base.webhook","typeVersion":2,"position":[240,304],"webhookId":"marketing-swarm-flex"},{"parameters":{"assignments":{"assignments":[{"name":"provider","type":"string","value":"={{ $json.body.provider || 'openai' }}"},{"name":"model","type":"string","value":"={{ $json.body.model || 'gpt-4' }}"},{"name":"announcement","type":"string","value":"={{ $json.body.announcement }}"},{"name":"taskId","type":"string","value":"={{ $json.body.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $json.body.userId }}"},{"name":"statusWebhook","type":"string","value":"={{ $json.body.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}"}]},"options":{}},"id":"extract-config","name":"Extract Config","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[464,304]},{"parameters":{"method":"POST","url":"={{ $('Extract Config').item.json.statusWebhook }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  taskId: $('Extract Config').item.json.taskId,\\\\n  status: 'running',\\\\n  timestamp: new Date().toISOString(),\\\\n  step: 'workflow_started',\\\\n  message: 'Marketing Swarm workflow started',\\\\n  sequence: 0,\\\\n  totalSteps: 4,\\\\n  conversationId: $('Extract Config').item.json.conversationId,\\\\n  userId: $('Extract Config').item.json.userId\\\\n}) }}","options":{}},"id":"send-workflow-start","name":"Send Workflow Start","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[688,304],"continueOnFail":true},{"parameters":{"workflowId":"={{ '9jxl03jCcqg17oOy' }}","options":{}},"id":"web-post-task","name":"Web Post Task","type":"n8n-nodes-base.executeWorkflow","typeVersion":1.1,"position":[912,144]},{"parameters":{"workflowId":"={{ '9jxl03jCcqg17oOy' }}","options":{}},"id":"seo-task","name":"SEO Task","type":"n8n-nodes-base.executeWorkflow","typeVersion":1.1,"position":[912,304]},{"parameters":{"workflowId":"={{ '9jxl03jCcqg17oOy' }}","options":{}},"id":"social-task","name":"Social Media Task","type":"n8n-nodes-base.executeWorkflow","typeVersion":1.1,"position":[912,480]},{"parameters":{"assignments":{"assignments":[{"name":"webPost","type":"string","value":"={{ $('Web Post Task').item.json.text }}"},{"name":"seoContent","type":"string","value":"={{ $('SEO Task').item.json.text }}"},{"name":"socialMedia","type":"string","value":"={{ $('Social Media Task').item.json.text }}"}]},"options":{}},"id":"combine-results","name":"Combine Results","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1120,304]},{"parameters":{"method":"POST","url":"={{ $('Extract Config').item.json.statusWebhook }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  taskId: $('Extract Config').item.json.taskId,\\\\n  status: 'completed',\\\\n  timestamp: new Date().toISOString(),\\\\n  step: 'workflow_completed',\\\\n  message: 'Marketing Swarm workflow completed',\\\\n  sequence: 4,\\\\n  totalSteps: 4,\\\\n  conversationId: $('Extract Config').item.json.conversationId,\\\\n  userId: $('Extract Config').item.json.userId,\\\\n  results: {\\\\n    webPost: $json.webPost,\\\\n    seoContent: $json.seoContent,\\\\n    socialMedia: $json.socialMedia\\\\n  }\\\\n}) }}","options":{}},"id":"send-final-status","name":"Send Final Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1344,304],"continueOnFail":true},{"parameters":{"respondWith":"json","responseBody":"={{ $json }}","options":{}},"id":"respond","name":"Respond to Webhook","type":"n8n-nodes-base.respondToWebhook","typeVersion":1.1,"position":[1568,304]}]	{"Webhook":{"main":[[{"node":"Extract Config","type":"main","index":0}]]},"Extract Config":{"main":[[{"node":"Send Workflow Start","type":"main","index":0}]]},"Send Workflow Start":{"main":[[{"node":"Web Post Task","type":"main","index":0},{"node":"SEO Task","type":"main","index":0},{"node":"Social Media Task","type":"main","index":0}]]},"Web Post Task":{"main":[[{"node":"Combine Results","type":"main","index":0}]]},"SEO Task":{"main":[[{"node":"Combine Results","type":"main","index":0}]]},"Social Media Task":{"main":[[{"node":"Combine Results","type":"main","index":0}]]},"Combine Results":{"main":[[{"node":"Send Final Status","type":"main","index":0}]]},"Send Final Status":{"main":[[{"node":"Respond to Webhook","type":"main","index":0}]]}}	2025-10-08 18:41:15.406+00	2025-10-10 13:12:20.101+00	{}	\N	{}	d817e98a-ea3c-4399-ae6d-b0259c8a8f31	0	1LaQnwqSoTxmnw3Z	\N	\N	f
Marketing Swarm - Major Announcement	t	[{"parameters":{"httpMethod":"POST","path":"marketing-swarm","options":{},"responseMode":"responseNode"},"id":"webhook","name":"Webhook Trigger","type":"n8n-nodes-base.webhook","typeVersion":2,"position":[112,112],"webhookId":"7f338c6b-a9bb-446b-9a1d-702739d89a51"},{"parameters":{"assignments":{"assignments":[{"name":"status","type":"string","value":"started"},{"name":"taskId","type":"string","value":"={{ $json.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"initialization"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":1},{"name":"totalSteps","type":"number","value":5}]}},"id":"statusStart","name":"Status: Started","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[304,0]},{"parameters":{"method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{}},"id":"webhookStatusStart","name":"Send Status: Started","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[512,0]},{"parameters":{"prompt":"=Write a compelling web post announcement for: {{ $json.announcement }}. Include headline, introduction, key features, and call-to-action. Format as HTML.","options":{"maxTokens":1000,"temperature":0.7},"requestOptions":{}},"id":"webPost","name":"Generate Web Post","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[304,208],"credentials":{"openAiApi":{"id":"B2oF5F10osX9S0yy","name":"OpenAi account"}}},{"parameters":{"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"web_post_complete"},{"name":"webPost","type":"string","value":"={{ $json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":2},{"name":"totalSteps","type":"number","value":5}]}},"id":"statusWebPost","name":"Status: Web Post Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[512,208]},{"parameters":{"method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{}},"id":"webhookStatusWebPost","name":"Send Status: Web Post","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[704,100]},{"parameters":{"prompt":"=Create SEO-optimized content for: {{ $json.announcement }}. Include meta title, meta description, keywords, and structured data JSON-LD.","options":{"maxTokens":800,"temperature":0.5},"requestOptions":{}},"id":"seoContent","name":"Generate SEO Content","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[704,300],"credentials":{"openAiApi":{"id":"B2oF5F10osX9S0yy","name":"OpenAi account"}}},{"parameters":{"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"seo_complete"},{"name":"seoContent","type":"string","value":"={{ $json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":3},{"name":"totalSteps","type":"number","value":5}]}},"id":"statusSEO","name":"Status: SEO Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[912,300]},{"parameters":{"method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{}},"id":"webhookStatusSEO","name":"Send Status: SEO","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1104,200]},{"parameters":{"prompt":"=Create social media posts for: {{ $json.announcement }}. Generate posts for Twitter/X (280 chars), LinkedIn (professional, 1300 chars), and Facebook (engaging, 500 chars). Include relevant hashtags.","options":{"maxTokens":1200,"temperature":0.8},"requestOptions":{}},"id":"socialMedia","name":"Generate Social Media","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[1104,400],"credentials":{"openAiApi":{"id":"B2oF5F10osX9S0yy","name":"OpenAi account"}}},{"parameters":{"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"social_media_complete"},{"name":"socialMedia","type":"string","value":"={{ $('Generate Social Media').item.json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":4},{"name":"totalSteps","type":"number","value":5}]}},"id":"statusSocial","name":"Status: Social Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1312,400]},{"parameters":{"method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{}},"id":"webhookStatusSocial","name":"Send Status: Social","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1504,300]},{"parameters":{"assignments":{"assignments":[{"name":"status","type":"string","value":"completed"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"webPost","type":"string","value":"={{ $('Status: Web Post Done').item.json.webPost }}"},{"name":"seoContent","type":"string","value":"={{ $('Status: SEO Done').item.json.seoContent }}"},{"name":"socialMedia","type":"string","value":"={{ $('Status: Social Done').item.json.socialMedia }}"},{"name":"sequence","type":"number","value":5},{"name":"totalSteps","type":"number","value":5}]}},"id":"finalOutput","name":"Final Output","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1504,500]},{"parameters":{"method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{}},"id":"webhookStatusComplete","name":"Send Status: Complete","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1712,500]},{"parameters":{"mode":"manual","assignments":{"assignments":[{"name":"status","type":"string","value":"completed"},{"name":"taskId","type":"string","value":"={{ $('Final Output').item.json.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $('Final Output').item.json.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Final Output').item.json.userId }}"},{"name":"executionId","type":"string","value":"={{ $('Final Output').item.json.executionId }}"},{"name":"timestamp","type":"string","value":"={{ $('Final Output').item.json.timestamp }}"},{"name":"webPost","type":"string","value":"={{ $('Final Output').item.json.webPost }}"},{"name":"seoContent","type":"string","value":"={{ $('Final Output').item.json.seoContent }}"},{"name":"socialMedia","type":"string","value":"={{ $('Final Output').item.json.socialMedia }}"}]}},"id":"finalResponse","name":"Final Response","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1912,500]},{"parameters":{"respondWith":"json","responseBody":"={{ $json }}"},"id":"respondWebhook","name":"Respond to Webhook","type":"n8n-nodes-base.respondToWebhook","typeVersion":1.1,"position":[2112,500]}]	{"Webhook Trigger":{"main":[[{"node":"Status: Started","type":"main","index":0},{"node":"Generate Web Post","type":"main","index":0}]]},"Status: Started":{"main":[[{"node":"Send Status: Started","type":"main","index":0}]]},"Generate Web Post":{"main":[[{"node":"Status: Web Post Done","type":"main","index":0}]]},"Status: Web Post Done":{"main":[[{"node":"Send Status: Web Post","type":"main","index":0},{"node":"Generate SEO Content","type":"main","index":0}]]},"Generate SEO Content":{"main":[[{"node":"Status: SEO Done","type":"main","index":0}]]},"Status: SEO Done":{"main":[[{"node":"Send Status: SEO","type":"main","index":0},{"node":"Generate Social Media","type":"main","index":0}]]},"Generate Social Media":{"main":[[{"node":"Status: Social Done","type":"main","index":0}]]},"Status: Social Done":{"main":[[{"node":"Send Status: Social","type":"main","index":0},{"node":"Final Output","type":"main","index":0}]]},"Final Output":{"main":[[{"node":"Send Status: Complete","type":"main","index":0}]]},"Send Status: Complete":{"main":[[{"node":"Final Response","type":"main","index":0}]]},"Final Response":{"main":[[{"node":"Respond to Webhook","type":"main","index":0}]]}}	2025-10-09 23:04:05.011+00	2025-10-10 13:37:05.078+00	{}	\N	\N	2685c6ed-6ea7-4323-aba5-aace4131d87a	1	Q08T7oMX2dZslqV4	\N	\N	f
\.


--
-- TOC entry 4269 (class 0 OID 19725)
-- Dependencies: 350
-- Data for Name: workflow_history; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.workflow_history ("versionId", "workflowId", authors, "createdAt", "updatedAt", nodes, connections) FROM stdin;
d817e98a-ea3c-4399-ae6d-b0259c8a8f31	1LaQnwqSoTxmnw3Z	Golfer Geek	2025-10-10 13:12:20.106+00	2025-10-10 13:12:20.106+00	[{"parameters":{"httpMethod":"POST","path":"marketing-swarm-flexible","options":{}},"id":"webhook","name":"Webhook","type":"n8n-nodes-base.webhook","typeVersion":2,"position":[240,304],"webhookId":"marketing-swarm-flex"},{"parameters":{"assignments":{"assignments":[{"name":"provider","type":"string","value":"={{ $json.body.provider || 'openai' }}"},{"name":"model","type":"string","value":"={{ $json.body.model || 'gpt-4' }}"},{"name":"announcement","type":"string","value":"={{ $json.body.announcement }}"},{"name":"taskId","type":"string","value":"={{ $json.body.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $json.body.userId }}"},{"name":"statusWebhook","type":"string","value":"={{ $json.body.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}"}]},"options":{}},"id":"extract-config","name":"Extract Config","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[464,304]},{"parameters":{"method":"POST","url":"={{ $('Extract Config').item.json.statusWebhook }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  taskId: $('Extract Config').item.json.taskId,\\\\n  status: 'running',\\\\n  timestamp: new Date().toISOString(),\\\\n  step: 'workflow_started',\\\\n  message: 'Marketing Swarm workflow started',\\\\n  sequence: 0,\\\\n  totalSteps: 4,\\\\n  conversationId: $('Extract Config').item.json.conversationId,\\\\n  userId: $('Extract Config').item.json.userId\\\\n}) }}","options":{}},"id":"send-workflow-start","name":"Send Workflow Start","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[688,304],"continueOnFail":true},{"parameters":{"workflowId":"={{ '9jxl03jCcqg17oOy' }}","options":{}},"id":"web-post-task","name":"Web Post Task","type":"n8n-nodes-base.executeWorkflow","typeVersion":1.1,"position":[912,144]},{"parameters":{"workflowId":"={{ '9jxl03jCcqg17oOy' }}","options":{}},"id":"seo-task","name":"SEO Task","type":"n8n-nodes-base.executeWorkflow","typeVersion":1.1,"position":[912,304]},{"parameters":{"workflowId":"={{ '9jxl03jCcqg17oOy' }}","options":{}},"id":"social-task","name":"Social Media Task","type":"n8n-nodes-base.executeWorkflow","typeVersion":1.1,"position":[912,480]},{"parameters":{"assignments":{"assignments":[{"name":"webPost","type":"string","value":"={{ $('Web Post Task').item.json.text }}"},{"name":"seoContent","type":"string","value":"={{ $('SEO Task').item.json.text }}"},{"name":"socialMedia","type":"string","value":"={{ $('Social Media Task').item.json.text }}"}]},"options":{}},"id":"combine-results","name":"Combine Results","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1120,304]},{"parameters":{"method":"POST","url":"={{ $('Extract Config').item.json.statusWebhook }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  taskId: $('Extract Config').item.json.taskId,\\\\n  status: 'completed',\\\\n  timestamp: new Date().toISOString(),\\\\n  step: 'workflow_completed',\\\\n  message: 'Marketing Swarm workflow completed',\\\\n  sequence: 4,\\\\n  totalSteps: 4,\\\\n  conversationId: $('Extract Config').item.json.conversationId,\\\\n  userId: $('Extract Config').item.json.userId,\\\\n  results: {\\\\n    webPost: $json.webPost,\\\\n    seoContent: $json.seoContent,\\\\n    socialMedia: $json.socialMedia\\\\n  }\\\\n}) }}","options":{}},"id":"send-final-status","name":"Send Final Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1344,304],"continueOnFail":true},{"parameters":{"respondWith":"json","responseBody":"={{ $json }}","options":{}},"id":"respond","name":"Respond to Webhook","type":"n8n-nodes-base.respondToWebhook","typeVersion":1.1,"position":[1568,304]}]	{"Webhook":{"main":[[{"node":"Extract Config","type":"main","index":0}]]},"Extract Config":{"main":[[{"node":"Send Workflow Start","type":"main","index":0}]]},"Send Workflow Start":{"main":[[{"node":"Web Post Task","type":"main","index":0},{"node":"SEO Task","type":"main","index":0},{"node":"Social Media Task","type":"main","index":0}]]},"Web Post Task":{"main":[[{"node":"Combine Results","type":"main","index":0}]]},"SEO Task":{"main":[[{"node":"Combine Results","type":"main","index":0}]]},"Social Media Task":{"main":[[{"node":"Combine Results","type":"main","index":0}]]},"Combine Results":{"main":[[{"node":"Send Final Status","type":"main","index":0}]]},"Send Final Status":{"main":[[{"node":"Respond to Webhook","type":"main","index":0}]]}}
\.


--
-- TOC entry 4262 (class 0 OID 19542)
-- Dependencies: 343
-- Data for Name: workflow_statistics; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.workflow_statistics (count, "latestEvent", name, "workflowId", "rootCount") FROM stdin;
1	2025-10-10 12:47:55.156+00	data_loaded	Q08T7oMX2dZslqV4	1
4	2025-10-10 12:53:48.632+00	manual_error	Q08T7oMX2dZslqV4	0
2	2025-10-10 13:37:36.011+00	production_error	Q08T7oMX2dZslqV4	2
\.


--
-- TOC entry 4257 (class 0 OID 19364)
-- Dependencies: 338
-- Data for Name: workflows_tags; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.workflows_tags ("workflowId", "tagId") FROM stdin;
\.


--
-- TOC entry 4330 (class 0 OID 0)
-- Dependencies: 346
-- Name: auth_provider_sync_history_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.auth_provider_sync_history_id_seq', 1, false);


--
-- TOC entry 4331 (class 0 OID 0)
-- Dependencies: 358
-- Name: execution_annotations_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.execution_annotations_id_seq', 1, false);


--
-- TOC entry 4332 (class 0 OID 0)
-- Dependencies: 333
-- Name: execution_entity_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.execution_entity_id_seq', 6, true);


--
-- TOC entry 4333 (class 0 OID 0)
-- Dependencies: 355
-- Name: execution_metadata_temp_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.execution_metadata_temp_id_seq', 1, false);


--
-- TOC entry 4334 (class 0 OID 0)
-- Dependencies: 370
-- Name: insights_by_period_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.insights_by_period_id_seq', 2, true);


--
-- TOC entry 4335 (class 0 OID 0)
-- Dependencies: 366
-- Name: insights_metadata_metaId_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n."insights_metadata_metaId_seq"', 1, true);


--
-- TOC entry 4336 (class 0 OID 0)
-- Dependencies: 368
-- Name: insights_raw_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.insights_raw_id_seq', 4, true);


--
-- TOC entry 4337 (class 0 OID 0)
-- Dependencies: 330
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.migrations_id_seq', 99, true);


--
-- TOC entry 4040 (class 2606 OID 20362)
-- Name: test_run PK_011c050f566e9db509a0fadb9b9; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.test_run
    ADD CONSTRAINT "PK_011c050f566e9db509a0fadb9b9" PRIMARY KEY (id);


--
-- TOC entry 3971 (class 2606 OID 19520)
-- Name: installed_packages PK_08cc9197c39b028c1e9beca225940576fd1a5804; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.installed_packages
    ADD CONSTRAINT "PK_08cc9197c39b028c1e9beca225940576fd1a5804" PRIMARY KEY ("packageName");


--
-- TOC entry 4006 (class 2606 OID 20042)
-- Name: execution_metadata PK_17a0b6284f8d626aae88e1c16e4; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_metadata
    ADD CONSTRAINT "PK_17a0b6284f8d626aae88e1c16e4" PRIMARY KEY (id);


--
-- TOC entry 3997 (class 2606 OID 19969)
-- Name: project_relation PK_1caaa312a5d7184a003be0f0cb6; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.project_relation
    ADD CONSTRAINT "PK_1caaa312a5d7184a003be0f0cb6" PRIMARY KEY ("projectId", "userId");


--
-- TOC entry 4029 (class 2606 OID 20250)
-- Name: folder_tag PK_27e4e00852f6b06a925a4d83a3e; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.folder_tag
    ADD CONSTRAINT "PK_27e4e00852f6b06a925a4d83a3e" PRIMARY KEY ("folderId", "tagId");


--
-- TOC entry 4047 (class 2606 OID 20405)
-- Name: role PK_35c9b140caaf6da09cfabb0d675; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.role
    ADD CONSTRAINT "PK_35c9b140caaf6da09cfabb0d675" PRIMARY KEY (slug);


--
-- TOC entry 3993 (class 2606 OID 19960)
-- Name: project PK_4d68b1358bb5b766d3e78f32f57; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.project
    ADD CONSTRAINT "PK_4d68b1358bb5b766d3e78f32f57" PRIMARY KEY (id);


--
-- TOC entry 4008 (class 2606 OID 20055)
-- Name: invalid_auth_token PK_5779069b7235b256d91f7af1a15; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.invalid_auth_token
    ADD CONSTRAINT "PK_5779069b7235b256d91f7af1a15" PRIMARY KEY (token);


--
-- TOC entry 4003 (class 2606 OID 20023)
-- Name: shared_workflow PK_5ba87620386b847201c9531c58f; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.shared_workflow
    ADD CONSTRAINT "PK_5ba87620386b847201c9531c58f" PRIMARY KEY ("workflowId", "projectId");


--
-- TOC entry 4027 (class 2606 OID 20234)
-- Name: folder PK_6278a41a706740c94c02e288df8; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.folder
    ADD CONSTRAINT "PK_6278a41a706740c94c02e288df8" PRIMARY KEY (id);


--
-- TOC entry 4056 (class 2606 OID 20482)
-- Name: data_table_column PK_673cb121ee4a8a5e27850c72c51; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.data_table_column
    ADD CONSTRAINT "PK_673cb121ee4a8a5e27850c72c51" PRIMARY KEY (id);


--
-- TOC entry 4014 (class 2606 OID 20082)
-- Name: annotation_tag_entity PK_69dfa041592c30bbc0d4b84aa00; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.annotation_tag_entity
    ADD CONSTRAINT "PK_69dfa041592c30bbc0d4b84aa00" PRIMARY KEY (id);


--
-- TOC entry 4011 (class 2606 OID 20069)
-- Name: execution_annotations PK_7afcf93ffa20c4252869a7c6a23; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_annotations
    ADD CONSTRAINT "PK_7afcf93ffa20c4252869a7c6a23" PRIMARY KEY (id);


--
-- TOC entry 3938 (class 2606 OID 19317)
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- TOC entry 3973 (class 2606 OID 19528)
-- Name: installed_nodes PK_8ebd28194e4f792f96b5933423fc439df97d9689; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.installed_nodes
    ADD CONSTRAINT "PK_8ebd28194e4f792f96b5933423fc439df97d9689" PRIMARY KEY (name);


--
-- TOC entry 4001 (class 2606 OID 19997)
-- Name: shared_credentials PK_8ef3a59796a228913f251779cff; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.shared_credentials
    ADD CONSTRAINT "PK_8ef3a59796a228913f251779cff" PRIMARY KEY ("credentialsId", "projectId");


--
-- TOC entry 4043 (class 2606 OID 20377)
-- Name: test_case_execution PK_90c121f77a78a6580e94b794bce; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.test_case_execution
    ADD CONSTRAINT "PK_90c121f77a78a6580e94b794bce" PRIMARY KEY (id);


--
-- TOC entry 4022 (class 2606 OID 20109)
-- Name: user_api_keys PK_978fa5caa3468f463dac9d92e69; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.user_api_keys
    ADD CONSTRAINT "PK_978fa5caa3468f463dac9d92e69" PRIMARY KEY (id);


--
-- TOC entry 4018 (class 2606 OID 20088)
-- Name: execution_annotation_tags PK_979ec03d31294cca484be65d11f; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_annotation_tags
    ADD CONSTRAINT "PK_979ec03d31294cca484be65d11f" PRIMARY KEY ("annotationId", "tagId");


--
-- TOC entry 3954 (class 2606 OID 19353)
-- Name: webhook_entity PK_b21ace2e13596ccd87dc9bf4ea6; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.webhook_entity
    ADD CONSTRAINT "PK_b21ace2e13596ccd87dc9bf4ea6" PRIMARY KEY ("webhookPath", method);


--
-- TOC entry 4037 (class 2606 OID 20347)
-- Name: insights_by_period PK_b606942249b90cc39b0265f0575; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_by_period
    ADD CONSTRAINT "PK_b606942249b90cc39b0265f0575" PRIMARY KEY (id);


--
-- TOC entry 3991 (class 2606 OID 19733)
-- Name: workflow_history PK_b6572dd6173e4cd06fe79937b58; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflow_history
    ADD CONSTRAINT "PK_b6572dd6173e4cd06fe79937b58" PRIMARY KEY ("versionId");


--
-- TOC entry 4045 (class 2606 OID 20397)
-- Name: scope PK_bfc45df0481abd7f355d6187da1; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.scope
    ADD CONSTRAINT "PK_bfc45df0481abd7f355d6187da1" PRIMARY KEY (slug);


--
-- TOC entry 4024 (class 2606 OID 20125)
-- Name: processed_data PK_ca04b9d8dc72de268fe07a65773; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.processed_data
    ADD CONSTRAINT "PK_ca04b9d8dc72de268fe07a65773" PRIMARY KEY ("workflowId", context);


--
-- TOC entry 3969 (class 2606 OID 19513)
-- Name: settings PK_dc0fe14e6d9943f268e7b119f69ab8bd; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.settings
    ADD CONSTRAINT "PK_dc0fe14e6d9943f268e7b119f69ab8bd" PRIMARY KEY (key);


--
-- TOC entry 4052 (class 2606 OID 20468)
-- Name: data_table PK_e226d0001b9e6097cbfe70617cb; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.data_table
    ADD CONSTRAINT "PK_e226d0001b9e6097cbfe70617cb" PRIMARY KEY (id);


--
-- TOC entry 3964 (class 2606 OID 19452)
-- Name: user PK_ea8f538c94b6e352418254ed6474a81f; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n."user"
    ADD CONSTRAINT "PK_ea8f538c94b6e352418254ed6474a81f" PRIMARY KEY (id);


--
-- TOC entry 4034 (class 2606 OID 20335)
-- Name: insights_raw PK_ec15125755151e3a7e00e00014f; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_raw
    ADD CONSTRAINT "PK_ec15125755151e3a7e00e00014f" PRIMARY KEY (id);


--
-- TOC entry 4032 (class 2606 OID 20317)
-- Name: insights_metadata PK_f448a94c35218b6208ce20cf5a1; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_metadata
    ADD CONSTRAINT "PK_f448a94c35218b6208ce20cf5a1" PRIMARY KEY ("metaId");


--
-- TOC entry 4050 (class 2606 OID 20410)
-- Name: role_scope PK_role_scope; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.role_scope
    ADD CONSTRAINT "PK_role_scope" PRIMARY KEY ("roleSlug", "scopeSlug");


--
-- TOC entry 4058 (class 2606 OID 20484)
-- Name: data_table_column UQ_8082ec4890f892f0bc77473a123; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.data_table_column
    ADD CONSTRAINT "UQ_8082ec4890f892f0bc77473a123" UNIQUE ("dataTableId", name);


--
-- TOC entry 4054 (class 2606 OID 20470)
-- Name: data_table UQ_b23096ef747281ac944d28e8b0d; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.data_table
    ADD CONSTRAINT "UQ_b23096ef747281ac944d28e8b0d" UNIQUE ("projectId", name);


--
-- TOC entry 3966 (class 2606 OID 19454)
-- Name: user UQ_e12875dfb3b1d92d7d7c5377e2; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n."user"
    ADD CONSTRAINT "UQ_e12875dfb3b1d92d7d7c5377e2" UNIQUE (email);


--
-- TOC entry 3979 (class 2606 OID 19609)
-- Name: auth_identity auth_identity_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.auth_identity
    ADD CONSTRAINT auth_identity_pkey PRIMARY KEY ("providerId", "providerType");


--
-- TOC entry 3981 (class 2606 OID 19625)
-- Name: auth_provider_sync_history auth_provider_sync_history_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.auth_provider_sync_history
    ADD CONSTRAINT auth_provider_sync_history_pkey PRIMARY KEY (id);


--
-- TOC entry 3940 (class 2606 OID 19707)
-- Name: credentials_entity credentials_entity_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.credentials_entity
    ADD CONSTRAINT credentials_entity_pkey PRIMARY KEY (id);


--
-- TOC entry 3977 (class 2606 OID 19580)
-- Name: event_destinations event_destinations_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.event_destinations
    ADD CONSTRAINT event_destinations_pkey PRIMARY KEY (id);


--
-- TOC entry 3988 (class 2606 OID 19723)
-- Name: execution_data execution_data_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_data
    ADD CONSTRAINT execution_data_pkey PRIMARY KEY ("executionId");


--
-- TOC entry 3936 (class 2606 OID 19018)
-- Name: migration_metadata migration_metadata_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.migration_metadata
    ADD CONSTRAINT migration_metadata_pkey PRIMARY KEY (migration_file);


--
-- TOC entry 3929 (class 2606 OID 19008)
-- Name: n8n_workflows n8n_workflows_name_key; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.n8n_workflows
    ADD CONSTRAINT n8n_workflows_name_key UNIQUE (name);


--
-- TOC entry 3931 (class 2606 OID 19006)
-- Name: n8n_workflows n8n_workflows_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.n8n_workflows
    ADD CONSTRAINT n8n_workflows_pkey PRIMARY KEY (id);


--
-- TOC entry 3948 (class 2606 OID 19336)
-- Name: execution_entity pk_e3e63bbf986767844bbe1166d4e; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_entity
    ADD CONSTRAINT pk_e3e63bbf986767844bbe1166d4e PRIMARY KEY (id);


--
-- TOC entry 3975 (class 2606 OID 19676)
-- Name: workflow_statistics pk_workflow_statistics; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflow_statistics
    ADD CONSTRAINT pk_workflow_statistics PRIMARY KEY ("workflowId", name);


--
-- TOC entry 3962 (class 2606 OID 19655)
-- Name: workflows_tags pk_workflows_tags; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflows_tags
    ADD CONSTRAINT pk_workflows_tags PRIMARY KEY ("workflowId", "tagId");


--
-- TOC entry 3959 (class 2606 OID 19696)
-- Name: tag_entity tag_entity_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.tag_entity
    ADD CONSTRAINT tag_entity_pkey PRIMARY KEY (id);


--
-- TOC entry 3984 (class 2606 OID 19635)
-- Name: variables variables_key_key; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.variables
    ADD CONSTRAINT variables_key_key UNIQUE (key);


--
-- TOC entry 3986 (class 2606 OID 19710)
-- Name: variables variables_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.variables
    ADD CONSTRAINT variables_pkey PRIMARY KEY (id);


--
-- TOC entry 3952 (class 2606 OID 19694)
-- Name: workflow_entity workflow_entity_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflow_entity
    ADD CONSTRAINT workflow_entity_pkey PRIMARY KEY (id);


--
-- TOC entry 4025 (class 1259 OID 20245)
-- Name: IDX_14f68deffaf858465715995508; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_14f68deffaf858465715995508" ON n8n.folder USING btree ("projectId", id);


--
-- TOC entry 4030 (class 1259 OID 20328)
-- Name: IDX_1d8ab99d5861c9388d2dc1cf73; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_1d8ab99d5861c9388d2dc1cf73" ON n8n.insights_metadata USING btree ("workflowId");


--
-- TOC entry 3989 (class 1259 OID 19739)
-- Name: IDX_1e31657f5fe46816c34be7c1b4; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_1e31657f5fe46816c34be7c1b4" ON n8n.workflow_history USING btree ("workflowId");


--
-- TOC entry 4019 (class 1259 OID 20116)
-- Name: IDX_1ef35bac35d20bdae979d917a3; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_1ef35bac35d20bdae979d917a3" ON n8n.user_api_keys USING btree ("apiKey");


--
-- TOC entry 3994 (class 1259 OID 19981)
-- Name: IDX_5f0643f6717905a05164090dde; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_5f0643f6717905a05164090dde" ON n8n.project_relation USING btree ("userId");


--
-- TOC entry 4035 (class 1259 OID 20353)
-- Name: IDX_60b6a84299eeb3f671dfec7693; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_60b6a84299eeb3f671dfec7693" ON n8n.insights_by_period USING btree ("periodStart", type, "periodUnit", "metaId");


--
-- TOC entry 3995 (class 1259 OID 19980)
-- Name: IDX_61448d56d61802b5dfde5cdb00; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_61448d56d61802b5dfde5cdb00" ON n8n.project_relation USING btree ("projectId");


--
-- TOC entry 4020 (class 1259 OID 20115)
-- Name: IDX_63d7bbae72c767cf162d459fcc; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_63d7bbae72c767cf162d459fcc" ON n8n.user_api_keys USING btree ("userId", label);


--
-- TOC entry 4041 (class 1259 OID 20388)
-- Name: IDX_8e4b4774db42f1e6dda3452b2a; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_8e4b4774db42f1e6dda3452b2a" ON n8n.test_case_execution USING btree ("testRunId");


--
-- TOC entry 4009 (class 1259 OID 20075)
-- Name: IDX_97f863fa83c4786f1956508496; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_97f863fa83c4786f1956508496" ON n8n.execution_annotations USING btree ("executionId");


--
-- TOC entry 4015 (class 1259 OID 20099)
-- Name: IDX_a3697779b366e131b2bbdae297; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_a3697779b366e131b2bbdae297" ON n8n.execution_annotation_tags USING btree ("tagId");


--
-- TOC entry 4012 (class 1259 OID 20083)
-- Name: IDX_ae51b54c4bb430cf92f48b623f; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_ae51b54c4bb430cf92f48b623f" ON n8n.annotation_tag_entity USING btree (name);


--
-- TOC entry 4016 (class 1259 OID 20100)
-- Name: IDX_c1519757391996eb06064f0e7c; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_c1519757391996eb06064f0e7c" ON n8n.execution_annotation_tags USING btree ("annotationId");


--
-- TOC entry 4004 (class 1259 OID 20048)
-- Name: IDX_cec8eea3bf49551482ccb4933e; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_cec8eea3bf49551482ccb4933e" ON n8n.execution_metadata USING btree ("executionId", key);


--
-- TOC entry 4038 (class 1259 OID 20368)
-- Name: IDX_d6870d3b6e4c185d33926f423c; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_d6870d3b6e4c185d33926f423c" ON n8n.test_run USING btree ("workflowId");


--
-- TOC entry 3943 (class 1259 OID 19740)
-- Name: IDX_execution_entity_deletedAt; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_execution_entity_deletedAt" ON n8n.execution_entity USING btree ("deletedAt");


--
-- TOC entry 4048 (class 1259 OID 20421)
-- Name: IDX_role_scope_scopeSlug; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_role_scope_scopeSlug" ON n8n.role_scope USING btree ("scopeSlug");


--
-- TOC entry 3949 (class 1259 OID 19724)
-- Name: IDX_workflow_entity_name; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_workflow_entity_name" ON n8n.workflow_entity USING btree (name);


--
-- TOC entry 3941 (class 1259 OID 19431)
-- Name: idx_07fde106c0b471d8cc80a64fc8; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_07fde106c0b471d8cc80a64fc8 ON n8n.credentials_entity USING btree (type);


--
-- TOC entry 3955 (class 1259 OID 19355)
-- Name: idx_16f4436789e804e3e1c9eeb240; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_16f4436789e804e3e1c9eeb240 ON n8n.webhook_entity USING btree ("webhookId", method, "pathLength");


--
-- TOC entry 3956 (class 1259 OID 19363)
-- Name: idx_812eb05f7451ca757fb98444ce; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX idx_812eb05f7451ca757fb98444ce ON n8n.tag_entity USING btree (name);


--
-- TOC entry 3944 (class 1259 OID 20058)
-- Name: idx_execution_entity_stopped_at_status_deleted_at; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_execution_entity_stopped_at_status_deleted_at ON n8n.execution_entity USING btree ("stoppedAt", status, "deletedAt") WHERE (("stoppedAt" IS NOT NULL) AND ("deletedAt" IS NULL));


--
-- TOC entry 3945 (class 1259 OID 20057)
-- Name: idx_execution_entity_wait_till_status_deleted_at; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_execution_entity_wait_till_status_deleted_at ON n8n.execution_entity USING btree ("waitTill", status, "deletedAt") WHERE (("waitTill" IS NOT NULL) AND ("deletedAt" IS NULL));


--
-- TOC entry 3946 (class 1259 OID 20056)
-- Name: idx_execution_entity_workflow_id_started_at; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_execution_entity_workflow_id_started_at ON n8n.execution_entity USING btree ("workflowId", "startedAt") WHERE (("startedAt" IS NOT NULL) AND ("deletedAt" IS NULL));


--
-- TOC entry 3932 (class 1259 OID 19027)
-- Name: idx_migration_metadata_source; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_migration_metadata_source ON n8n.migration_metadata USING btree (source);


--
-- TOC entry 3933 (class 1259 OID 19029)
-- Name: idx_migration_metadata_synced; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_migration_metadata_synced ON n8n.migration_metadata USING btree (synced_at);


--
-- TOC entry 3934 (class 1259 OID 19028)
-- Name: idx_migration_metadata_workflow; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_migration_metadata_workflow ON n8n.migration_metadata USING btree (workflow_id);


--
-- TOC entry 3925 (class 1259 OID 19025)
-- Name: idx_n8n_workflows_active; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_n8n_workflows_active ON n8n.n8n_workflows USING btree (active);


--
-- TOC entry 3926 (class 1259 OID 19024)
-- Name: idx_n8n_workflows_name; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_n8n_workflows_name ON n8n.n8n_workflows USING btree (name);


--
-- TOC entry 3927 (class 1259 OID 19026)
-- Name: idx_n8n_workflows_updated; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_n8n_workflows_updated ON n8n.n8n_workflows USING btree (updated_at);


--
-- TOC entry 3960 (class 1259 OID 19656)
-- Name: idx_workflows_tags_workflow_id; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_workflows_tags_workflow_id ON n8n.workflows_tags USING btree ("workflowId");


--
-- TOC entry 3942 (class 1259 OID 19697)
-- Name: pk_credentials_entity_id; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX pk_credentials_entity_id ON n8n.credentials_entity USING btree (id);


--
-- TOC entry 3957 (class 1259 OID 19653)
-- Name: pk_tag_entity_id; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX pk_tag_entity_id ON n8n.tag_entity USING btree (id);


--
-- TOC entry 3982 (class 1259 OID 19708)
-- Name: pk_variables_id; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX pk_variables_id ON n8n.variables USING btree (id);


--
-- TOC entry 3950 (class 1259 OID 19652)
-- Name: pk_workflow_entity_id; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX pk_workflow_entity_id ON n8n.workflow_entity USING btree (id);


--
-- TOC entry 3998 (class 1259 OID 20492)
-- Name: project_relation_role_idx; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX project_relation_role_idx ON n8n.project_relation USING btree (role);


--
-- TOC entry 3999 (class 1259 OID 20493)
-- Name: project_relation_role_project_idx; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX project_relation_role_project_idx ON n8n.project_relation USING btree ("projectId", role);


--
-- TOC entry 3967 (class 1259 OID 20494)
-- Name: user_role_idx; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX user_role_idx ON n8n."user" USING btree ("roleSlug");


--
-- TOC entry 4083 (class 2606 OID 20126)
-- Name: processed_data FK_06a69a7032c97a763c2c7599464; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.processed_data
    ADD CONSTRAINT "FK_06a69a7032c97a763c2c7599464" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4088 (class 2606 OID 20318)
-- Name: insights_metadata FK_1d8ab99d5861c9388d2dc1cf733; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_metadata
    ADD CONSTRAINT "FK_1d8ab99d5861c9388d2dc1cf733" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE SET NULL;


--
-- TOC entry 4070 (class 2606 OID 19734)
-- Name: workflow_history FK_1e31657f5fe46816c34be7c1b4b; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflow_history
    ADD CONSTRAINT "FK_1e31657f5fe46816c34be7c1b4b" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4089 (class 2606 OID 20323)
-- Name: insights_metadata FK_2375a1eda085adb16b24615b69c; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_metadata
    ADD CONSTRAINT "FK_2375a1eda085adb16b24615b69c" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE SET NULL;


--
-- TOC entry 4078 (class 2606 OID 20043)
-- Name: execution_metadata FK_31d0b4c93fb85ced26f6005cda3; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_metadata
    ADD CONSTRAINT "FK_31d0b4c93fb85ced26f6005cda3" FOREIGN KEY ("executionId") REFERENCES n8n.execution_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4074 (class 2606 OID 19998)
-- Name: shared_credentials FK_416f66fc846c7c442970c094ccf; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.shared_credentials
    ADD CONSTRAINT "FK_416f66fc846c7c442970c094ccf" FOREIGN KEY ("credentialsId") REFERENCES n8n.credentials_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4071 (class 2606 OID 19975)
-- Name: project_relation FK_5f0643f6717905a05164090dde7; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.project_relation
    ADD CONSTRAINT "FK_5f0643f6717905a05164090dde7" FOREIGN KEY ("userId") REFERENCES n8n."user"(id) ON DELETE CASCADE;


--
-- TOC entry 4072 (class 2606 OID 19970)
-- Name: project_relation FK_61448d56d61802b5dfde5cdb002; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.project_relation
    ADD CONSTRAINT "FK_61448d56d61802b5dfde5cdb002" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4091 (class 2606 OID 20348)
-- Name: insights_by_period FK_6414cfed98daabbfdd61a1cfbc0; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_by_period
    ADD CONSTRAINT "FK_6414cfed98daabbfdd61a1cfbc0" FOREIGN KEY ("metaId") REFERENCES n8n.insights_metadata("metaId") ON DELETE CASCADE;


--
-- TOC entry 4090 (class 2606 OID 20336)
-- Name: insights_raw FK_6e2e33741adef2a7c5d66befa4e; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_raw
    ADD CONSTRAINT "FK_6e2e33741adef2a7c5d66befa4e" FOREIGN KEY ("metaId") REFERENCES n8n.insights_metadata("metaId") ON DELETE CASCADE;


--
-- TOC entry 4066 (class 2606 OID 19529)
-- Name: installed_nodes FK_73f857fc5dce682cef8a99c11dbddbc969618951; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.installed_nodes
    ADD CONSTRAINT "FK_73f857fc5dce682cef8a99c11dbddbc969618951" FOREIGN KEY (package) REFERENCES n8n.installed_packages("packageName") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4084 (class 2606 OID 20240)
-- Name: folder FK_804ea52f6729e3940498bd54d78; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.folder
    ADD CONSTRAINT "FK_804ea52f6729e3940498bd54d78" FOREIGN KEY ("parentFolderId") REFERENCES n8n.folder(id) ON DELETE CASCADE;


--
-- TOC entry 4075 (class 2606 OID 20003)
-- Name: shared_credentials FK_812c2852270da1247756e77f5a4; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.shared_credentials
    ADD CONSTRAINT "FK_812c2852270da1247756e77f5a4" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4093 (class 2606 OID 20378)
-- Name: test_case_execution FK_8e4b4774db42f1e6dda3452b2af; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.test_case_execution
    ADD CONSTRAINT "FK_8e4b4774db42f1e6dda3452b2af" FOREIGN KEY ("testRunId") REFERENCES n8n.test_run(id) ON DELETE CASCADE;


--
-- TOC entry 4098 (class 2606 OID 20485)
-- Name: data_table_column FK_930b6e8faaf88294cef23484160; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.data_table_column
    ADD CONSTRAINT "FK_930b6e8faaf88294cef23484160" FOREIGN KEY ("dataTableId") REFERENCES n8n.data_table(id) ON DELETE CASCADE;


--
-- TOC entry 4086 (class 2606 OID 20251)
-- Name: folder_tag FK_94a60854e06f2897b2e0d39edba; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.folder_tag
    ADD CONSTRAINT "FK_94a60854e06f2897b2e0d39edba" FOREIGN KEY ("folderId") REFERENCES n8n.folder(id) ON DELETE CASCADE;


--
-- TOC entry 4079 (class 2606 OID 20070)
-- Name: execution_annotations FK_97f863fa83c4786f19565084960; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_annotations
    ADD CONSTRAINT "FK_97f863fa83c4786f19565084960" FOREIGN KEY ("executionId") REFERENCES n8n.execution_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4080 (class 2606 OID 20094)
-- Name: execution_annotation_tags FK_a3697779b366e131b2bbdae2976; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_annotation_tags
    ADD CONSTRAINT "FK_a3697779b366e131b2bbdae2976" FOREIGN KEY ("tagId") REFERENCES n8n.annotation_tag_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4076 (class 2606 OID 20029)
-- Name: shared_workflow FK_a45ea5f27bcfdc21af9b4188560; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.shared_workflow
    ADD CONSTRAINT "FK_a45ea5f27bcfdc21af9b4188560" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4085 (class 2606 OID 20235)
-- Name: folder FK_a8260b0b36939c6247f385b8221; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.folder
    ADD CONSTRAINT "FK_a8260b0b36939c6247f385b8221" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4081 (class 2606 OID 20089)
-- Name: execution_annotation_tags FK_c1519757391996eb06064f0e7c8; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_annotation_tags
    ADD CONSTRAINT "FK_c1519757391996eb06064f0e7c8" FOREIGN KEY ("annotationId") REFERENCES n8n.execution_annotations(id) ON DELETE CASCADE;


--
-- TOC entry 4097 (class 2606 OID 20471)
-- Name: data_table FK_c2a794257dee48af7c9abf681de; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.data_table
    ADD CONSTRAINT "FK_c2a794257dee48af7c9abf681de" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4073 (class 2606 OID 20428)
-- Name: project_relation FK_c6b99592dc96b0d836d7a21db91; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.project_relation
    ADD CONSTRAINT "FK_c6b99592dc96b0d836d7a21db91" FOREIGN KEY (role) REFERENCES n8n.role(slug);


--
-- TOC entry 4092 (class 2606 OID 20363)
-- Name: test_run FK_d6870d3b6e4c185d33926f423c8; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.test_run
    ADD CONSTRAINT "FK_d6870d3b6e4c185d33926f423c8" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4077 (class 2606 OID 20024)
-- Name: shared_workflow FK_daa206a04983d47d0a9c34649ce; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.shared_workflow
    ADD CONSTRAINT "FK_daa206a04983d47d0a9c34649ce" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4087 (class 2606 OID 20256)
-- Name: folder_tag FK_dc88164176283de80af47621746; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.folder_tag
    ADD CONSTRAINT "FK_dc88164176283de80af47621746" FOREIGN KEY ("tagId") REFERENCES n8n.tag_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4082 (class 2606 OID 20110)
-- Name: user_api_keys FK_e131705cbbc8fb589889b02d457; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.user_api_keys
    ADD CONSTRAINT "FK_e131705cbbc8fb589889b02d457" FOREIGN KEY ("userId") REFERENCES n8n."user"(id) ON DELETE CASCADE;


--
-- TOC entry 4094 (class 2606 OID 20383)
-- Name: test_case_execution FK_e48965fac35d0f5b9e7f51d8c44; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.test_case_execution
    ADD CONSTRAINT "FK_e48965fac35d0f5b9e7f51d8c44" FOREIGN KEY ("executionId") REFERENCES n8n.execution_entity(id) ON DELETE SET NULL;


--
-- TOC entry 4065 (class 2606 OID 20423)
-- Name: user FK_eaea92ee7bfb9c1b6cd01505d56; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n."user"
    ADD CONSTRAINT "FK_eaea92ee7bfb9c1b6cd01505d56" FOREIGN KEY ("roleSlug") REFERENCES n8n.role(slug);


--
-- TOC entry 4095 (class 2606 OID 20411)
-- Name: role_scope FK_role; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.role_scope
    ADD CONSTRAINT "FK_role" FOREIGN KEY ("roleSlug") REFERENCES n8n.role(slug) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4096 (class 2606 OID 20416)
-- Name: role_scope FK_scope; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.role_scope
    ADD CONSTRAINT "FK_scope" FOREIGN KEY ("scopeSlug") REFERENCES n8n.scope(slug) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4068 (class 2606 OID 19610)
-- Name: auth_identity auth_identity_userId_fkey; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.auth_identity
    ADD CONSTRAINT "auth_identity_userId_fkey" FOREIGN KEY ("userId") REFERENCES n8n."user"(id);


--
-- TOC entry 4069 (class 2606 OID 19716)
-- Name: execution_data execution_data_fk; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_data
    ADD CONSTRAINT execution_data_fk FOREIGN KEY ("executionId") REFERENCES n8n.execution_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4060 (class 2606 OID 19688)
-- Name: execution_entity fk_execution_entity_workflow_id; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_entity
    ADD CONSTRAINT fk_execution_entity_workflow_id FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4062 (class 2606 OID 19682)
-- Name: webhook_entity fk_webhook_entity_workflow_id; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.webhook_entity
    ADD CONSTRAINT fk_webhook_entity_workflow_id FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4061 (class 2606 OID 20307)
-- Name: workflow_entity fk_workflow_parent_folder; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflow_entity
    ADD CONSTRAINT fk_workflow_parent_folder FOREIGN KEY ("parentFolderId") REFERENCES n8n.folder(id) ON DELETE CASCADE;


--
-- TOC entry 4067 (class 2606 OID 19677)
-- Name: workflow_statistics fk_workflow_statistics_workflow_id; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflow_statistics
    ADD CONSTRAINT fk_workflow_statistics_workflow_id FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4063 (class 2606 OID 19662)
-- Name: workflows_tags fk_workflows_tags_tag_id; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflows_tags
    ADD CONSTRAINT fk_workflows_tags_tag_id FOREIGN KEY ("tagId") REFERENCES n8n.tag_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4064 (class 2606 OID 19657)
-- Name: workflows_tags fk_workflows_tags_workflow_id; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflows_tags
    ADD CONSTRAINT fk_workflows_tags_workflow_id FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4059 (class 2606 OID 19019)
-- Name: migration_metadata migration_metadata_workflow_id_fkey; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.migration_metadata
    ADD CONSTRAINT migration_metadata_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES n8n.n8n_workflows(id);


--
-- TOC entry 4305 (class 0 OID 0)
-- Dependencies: 4303
-- Name: DATABASE postgres; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE postgres TO dashboard_user;


--
-- TOC entry 2674 (class 826 OID 19031)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: n8n; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA n8n GRANT ALL ON SEQUENCES  TO postgres;


--
-- TOC entry 2673 (class 826 OID 19030)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: n8n; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA n8n GRANT ALL ON TABLES  TO postgres;


-- Completed on 2025-10-10 15:26:51 UTC

--
-- PostgreSQL database dump complete
--

