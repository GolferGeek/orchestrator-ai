--
-- PostgreSQL database dump
--

-- Dumped from database version 15.8
-- Dumped by pg_dump version 15.8

-- Started on 2025-10-09 21:28:14 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS postgres;
--
-- TOC entry 5083 (class 1262 OID 5)
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 5084 (class 0 OID 0)
-- Dependencies: 5083
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- TOC entry 5086 (class 0 OID 0)
-- Name: postgres; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE postgres SET "app.settings.jwt_secret" TO 'super-secret-jwt-token-with-at-least-32-characters-long';
ALTER DATABASE postgres SET "app.settings.jwt_exp" TO '3600';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 24 (class 2615 OID 16686)
-- Name: _realtime; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA _realtime;


ALTER SCHEMA _realtime OWNER TO postgres;

--
-- TOC entry 23 (class 2615 OID 16457)
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO supabase_admin;

--
-- TOC entry 16 (class 2615 OID 16391)
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA extensions;


ALTER SCHEMA extensions OWNER TO postgres;

--
-- TOC entry 21 (class 2615 OID 16618)
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql;


ALTER SCHEMA graphql OWNER TO supabase_admin;

--
-- TOC entry 20 (class 2615 OID 16607)
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql_public;


ALTER SCHEMA graphql_public OWNER TO supabase_admin;

--
-- TOC entry 18 (class 2615 OID 16758)
-- Name: n8n; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA n8n;


ALTER SCHEMA n8n OWNER TO postgres;

--
-- TOC entry 5089 (class 0 OID 0)
-- Dependencies: 18
-- Name: SCHEMA n8n; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA n8n IS 'Schema for n8n workflow automation tables and data';


--
-- TOC entry 8 (class 3079 OID 16687)
-- Name: pg_net; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;


--
-- TOC entry 5090 (class 0 OID 0)
-- Dependencies: 8
-- Name: EXTENSION pg_net; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_net IS 'Async HTTP';


--
-- TOC entry 13 (class 2615 OID 16386)
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA pgbouncer;


ALTER SCHEMA pgbouncer OWNER TO pgbouncer;

--
-- TOC entry 14 (class 2615 OID 16599)
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA realtime;


ALTER SCHEMA realtime OWNER TO supabase_admin;

--
-- TOC entry 22 (class 2615 OID 16505)
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA storage;


ALTER SCHEMA storage OWNER TO supabase_admin;

--
-- TOC entry 25 (class 2615 OID 16730)
-- Name: supabase_functions; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA supabase_functions;


ALTER SCHEMA supabase_functions OWNER TO supabase_admin;

--
-- TOC entry 15 (class 2615 OID 18145)
-- Name: supabase_migrations; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA supabase_migrations;


ALTER SCHEMA supabase_migrations OWNER TO postgres;

--
-- TOC entry 19 (class 2615 OID 16645)
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA vault;


ALTER SCHEMA vault OWNER TO supabase_admin;

--
-- TOC entry 7 (class 3079 OID 16673)
-- Name: pg_graphql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_graphql WITH SCHEMA graphql;


--
-- TOC entry 5097 (class 0 OID 0)
-- Dependencies: 7
-- Name: EXTENSION pg_graphql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_graphql IS 'pg_graphql: GraphQL support';


--
-- TOC entry 5 (class 3079 OID 16565)
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- TOC entry 5098 (class 0 OID 0)
-- Dependencies: 5
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- TOC entry 3 (class 3079 OID 16403)
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- TOC entry 5099 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- TOC entry 4 (class 3079 OID 16440)
-- Name: pgjwt; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgjwt WITH SCHEMA extensions;


--
-- TOC entry 5100 (class 0 OID 0)
-- Dependencies: 4
-- Name: EXTENSION pgjwt; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgjwt IS 'JSON Web Token API for Postgresql';


--
-- TOC entry 6 (class 3079 OID 16646)
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- TOC entry 5101 (class 0 OID 0)
-- Dependencies: 6
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- TOC entry 2 (class 3079 OID 16392)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- TOC entry 5102 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 1258 (class 1247 OID 17902)
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE auth.aal_level OWNER TO supabase_auth_admin;

--
-- TOC entry 1282 (class 1247 OID 18043)
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


ALTER TYPE auth.code_challenge_method OWNER TO supabase_auth_admin;

--
-- TOC entry 1255 (class 1247 OID 17896)
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE auth.factor_status OWNER TO supabase_auth_admin;

--
-- TOC entry 1252 (class 1247 OID 17890)
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE auth.factor_type OWNER TO supabase_auth_admin;

--
-- TOC entry 1294 (class 1247 OID 18124)
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE auth.oauth_registration_type OWNER TO supabase_auth_admin;

--
-- TOC entry 1288 (class 1247 OID 18085)
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE auth.one_time_token_type OWNER TO supabase_auth_admin;

--
-- TOC entry 1213 (class 1247 OID 17476)
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE realtime.action OWNER TO supabase_admin;

--
-- TOC entry 1204 (class 1247 OID 17436)
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


ALTER TYPE realtime.equality_op OWNER TO supabase_admin;

--
-- TOC entry 1207 (class 1247 OID 17451)
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text
);


ALTER TYPE realtime.user_defined_filter OWNER TO supabase_admin;

--
-- TOC entry 1219 (class 1247 OID 17518)
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


ALTER TYPE realtime.wal_column OWNER TO supabase_admin;

--
-- TOC entry 1216 (class 1247 OID 17489)
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


ALTER TYPE realtime.wal_rls OWNER TO supabase_admin;

--
-- TOC entry 1399 (class 1247 OID 19110)
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS'
);


ALTER TYPE storage.buckettype OWNER TO supabase_storage_admin;

--
-- TOC entry 392 (class 1255 OID 16503)
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION auth.email() OWNER TO supabase_auth_admin;

--
-- TOC entry 5103 (class 0 OID 0)
-- Dependencies: 392
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- TOC entry 499 (class 1255 OID 17872)
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION auth.jwt() OWNER TO supabase_auth_admin;

--
-- TOC entry 410 (class 1255 OID 16502)
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION auth.role() OWNER TO supabase_auth_admin;

--
-- TOC entry 5106 (class 0 OID 0)
-- Dependencies: 410
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- TOC entry 391 (class 1255 OID 16501)
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION auth.uid() OWNER TO supabase_auth_admin;

--
-- TOC entry 5108 (class 0 OID 0)
-- Dependencies: 391
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- TOC entry 462 (class 1255 OID 16560)
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_cron_access() OWNER TO supabase_admin;

--
-- TOC entry 5125 (class 0 OID 0)
-- Dependencies: 462
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- TOC entry 430 (class 1255 OID 16612)
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN
        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        DROP FUNCTION IF EXISTS graphql_public.graphql;
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

        -- This hook executes when `graphql.resolve` is created. That is not necessarily the last
        -- function in the extension so we need to grant permissions on existing entities AND
        -- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;

        -- Allow postgres role to allow granting usage on graphql and graphql_public schemas to custom roles
        grant usage on schema graphql_public to postgres with grant option;
        grant usage on schema graphql to postgres with grant option;
    END IF;

END;
$_$;


ALTER FUNCTION extensions.grant_pg_graphql_access() OWNER TO supabase_admin;

--
-- TOC entry 5127 (class 0 OID 0)
-- Dependencies: 430
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- TOC entry 474 (class 1255 OID 16562)
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
    ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

    ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
    ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

    REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
    REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

    GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_net_access() OWNER TO supabase_admin;

--
-- TOC entry 5129 (class 0 OID 0)
-- Dependencies: 474
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- TOC entry 429 (class 1255 OID 16603)
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_ddl_watch() OWNER TO supabase_admin;

--
-- TOC entry 457 (class 1255 OID 16604)
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_drop_watch() OWNER TO supabase_admin;

--
-- TOC entry 458 (class 1255 OID 16614)
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION extensions.set_graphql_placeholder() OWNER TO supabase_admin;

--
-- TOC entry 5158 (class 0 OID 0)
-- Dependencies: 458
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- TOC entry 463 (class 1255 OID 16387)
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $_$
begin
    raise debug 'PgBouncer auth request: %', p_usename;

    return query
    select 
        rolname::text, 
        case when rolvaliduntil < now() 
            then null 
            else rolpassword::text 
        end 
    from pg_authid 
    where rolname=$1 and rolcanlogin;
end;
$_$;


ALTER FUNCTION pgbouncer.get_auth(p_usename text) OWNER TO supabase_admin;

--
-- TOC entry 500 (class 1255 OID 18153)
-- Name: calculate_completion_percentage(jsonb); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.calculate_completion_percentage(requirements jsonb) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    total_fields INTEGER := 12;  -- Total required fields
    completed_fields INTEGER := 0;
    field_name TEXT;
BEGIN
    -- Count non-null, non-empty required fields
    FOR field_name IN SELECT * FROM jsonb_object_keys(requirements)
    LOOP
        IF requirements ->> field_name IS NOT NULL 
           AND LENGTH(TRIM(requirements ->> field_name)) > 0 THEN
            completed_fields := completed_fields + 1;
        END IF;
    END LOOP;
    
    RETURN (completed_fields * 100 / total_fields);
END;
$$;


ALTER FUNCTION public.calculate_completion_percentage(requirements jsonb) OWNER TO postgres;

--
-- TOC entry 484 (class 1255 OID 18154)
-- Name: cleanup_abandoned_conversations(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cleanup_abandoned_conversations() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    -- Delete conversations abandoned for more than 7 days
    DELETE FROM agent_creation_conversations
    WHERE completion_status = 'in_progress'
      AND last_activity_at < NOW() - INTERVAL '7 days';
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$;


ALTER FUNCTION public.cleanup_abandoned_conversations() OWNER TO postgres;

--
-- TOC entry 512 (class 1255 OID 18773)
-- Name: cleanup_old_jokes(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cleanup_old_jokes() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM jokes_agent 
    WHERE created_at < NOW() - INTERVAL '30 days';
END;
$$;


ALTER FUNCTION public.cleanup_old_jokes() OWNER TO postgres;

--
-- TOC entry 485 (class 1255 OID 18155)
-- Name: exec_sql(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.exec_sql(query text DEFAULT NULL::text, sql_query text DEFAULT NULL::text) RETURNS SETOF jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  q text := coalesce(query, sql_query);
  r record;
begin
  if q is null or length(trim(q)) = 0 then
    raise exception 'No SQL provided to exec_sql()';
  end if;

  -- Execute the query and stream rows as JSONB
  for r in execute q loop
    return next to_jsonb(r);
  end loop;
  return;

exception when others then
  -- Return a single JSON object describing the error (so callers get structured feedback)
  return query select jsonb_build_object(
    'error', true,
    'message', sqlerrm,
    'code', sqlstate
  );
end;
$$;


ALTER FUNCTION public.exec_sql(query text, sql_query text) OWNER TO postgres;

--
-- TOC entry 513 (class 1255 OID 18156)
-- Name: get_global_model_config(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_global_model_config() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  SELECT value FROM public.system_settings WHERE key = 'model_config_global';
$$;


ALTER FUNCTION public.get_global_model_config() OWNER TO postgres;

--
-- TOC entry 501 (class 1255 OID 18157)
-- Name: log_agent_action(character varying, uuid, jsonb, jsonb, jsonb, boolean, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.log_agent_action(p_action character varying, p_agent_id uuid, p_details jsonb DEFAULT '{}'::jsonb, p_previous_state jsonb DEFAULT NULL::jsonb, p_new_state jsonb DEFAULT NULL::jsonb, p_success boolean DEFAULT true, p_error_message text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    log_id UUID;
BEGIN
    INSERT INTO agent_creation_logs (
        action, agent_configuration_id, performed_by, details,
        previous_state, new_state, success, error_message
    ) VALUES (
        p_action, p_agent_id, auth.uid(), p_details,
        p_previous_state, p_new_state, p_success, p_error_message
    ) RETURNING id INTO log_id;
    
    RETURN log_id;
END;
$$;


ALTER FUNCTION public.log_agent_action(p_action character varying, p_agent_id uuid, p_details jsonb, p_previous_state jsonb, p_new_state jsonb, p_success boolean, p_error_message text) OWNER TO postgres;

--
-- TOC entry 5184 (class 0 OID 0)
-- Dependencies: 501
-- Name: FUNCTION log_agent_action(p_action character varying, p_agent_id uuid, p_details jsonb, p_previous_state jsonb, p_new_state jsonb, p_success boolean, p_error_message text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.log_agent_action(p_action character varying, p_agent_id uuid, p_details jsonb, p_previous_state jsonb, p_new_state jsonb, p_success boolean, p_error_message text) IS 'Helper function to create audit log entries';


--
-- TOC entry 489 (class 1255 OID 18886)
-- Name: set_timestamp_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_timestamp_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_timestamp_updated_at() OWNER TO postgres;

--
-- TOC entry 502 (class 1255 OID 18158)
-- Name: update_agent_configurations_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_agent_configurations_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_agent_configurations_updated_at() OWNER TO postgres;

--
-- TOC entry 503 (class 1255 OID 18159)
-- Name: update_agent_skills_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_agent_skills_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_agent_skills_updated_at() OWNER TO postgres;

--
-- TOC entry 504 (class 1255 OID 18160)
-- Name: update_agent_usage_analytics(uuid, integer, integer, integer, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_agent_usage_analytics(p_agent_id uuid, p_conversation_increment integer DEFAULT 0, p_message_increment integer DEFAULT 0, p_response_time_ms integer DEFAULT NULL::integer, p_error_increment integer DEFAULT 0, p_unique_user_increment integer DEFAULT 0) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO agent_usage_analytics (
        agent_configuration_id, agent_id, date_period,
        conversation_count, message_count, error_count, unique_users
    ) VALUES (
        p_agent_id, 
        (SELECT agent_id FROM agent_configurations WHERE id = p_agent_id),
        CURRENT_DATE,
        p_conversation_increment, p_message_increment, p_error_increment, p_unique_user_increment
    )
    ON CONFLICT (agent_configuration_id, date_period) 
    DO UPDATE SET
        conversation_count = agent_usage_analytics.conversation_count + p_conversation_increment,
        message_count = agent_usage_analytics.message_count + p_message_increment,
        error_count = agent_usage_analytics.error_count + p_error_increment,
        unique_users = agent_usage_analytics.unique_users + p_unique_user_increment,
        avg_response_time_ms = CASE 
            WHEN p_response_time_ms IS NOT NULL THEN
                COALESCE(
                    (agent_usage_analytics.avg_response_time_ms + p_response_time_ms) / 2,
                    p_response_time_ms
                )
            ELSE agent_usage_analytics.avg_response_time_ms
        END,
        last_updated = NOW();
END;
$$;


ALTER FUNCTION public.update_agent_usage_analytics(p_agent_id uuid, p_conversation_increment integer, p_message_increment integer, p_response_time_ms integer, p_error_increment integer, p_unique_user_increment integer) OWNER TO postgres;

--
-- TOC entry 5189 (class 0 OID 0)
-- Dependencies: 504
-- Name: FUNCTION update_agent_usage_analytics(p_agent_id uuid, p_conversation_increment integer, p_message_increment integer, p_response_time_ms integer, p_error_increment integer, p_unique_user_increment integer); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.update_agent_usage_analytics(p_agent_id uuid, p_conversation_increment integer, p_message_increment integer, p_response_time_ms integer, p_error_increment integer, p_unique_user_increment integer) IS 'Helper function to update daily usage stats';


--
-- TOC entry 505 (class 1255 OID 18161)
-- Name: update_completion_percentage(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_completion_percentage() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.completion_percentage = calculate_completion_percentage(NEW.requirements_gathered);
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_completion_percentage() OWNER TO postgres;

--
-- TOC entry 506 (class 1255 OID 18162)
-- Name: update_conversation_timestamps(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_conversation_timestamps() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    NEW.last_activity_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_conversation_timestamps() OWNER TO postgres;

--
-- TOC entry 509 (class 1255 OID 18163)
-- Name: update_creation_metrics(boolean, integer, integer, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_creation_metrics(p_success boolean, p_creation_time_seconds integer DEFAULT NULL::integer, p_questions_answered integer DEFAULT NULL::integer, p_department character varying DEFAULT NULL::character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    current_hour INTEGER;
    dept_breakdown JSONB;
BEGIN
    current_hour := EXTRACT(hour FROM NOW());
    
    -- Get current department breakdown or initialize
    SELECT department_breakdown INTO dept_breakdown
    FROM agent_creation_metrics
    WHERE date_period = CURRENT_DATE AND hour_period = current_hour;
    
    IF dept_breakdown IS NULL THEN
        dept_breakdown := '{}';
    END IF;
    
    -- Update department count
    IF p_department IS NOT NULL THEN
        dept_breakdown := jsonb_set(
            dept_breakdown,
            ARRAY[p_department],
            to_jsonb(COALESCE((dept_breakdown ->> p_department)::INTEGER, 0) + 1)
        );
    END IF;
    
    INSERT INTO agent_creation_metrics (
        date_period, hour_period, total_attempts,
        successful_creations, failed_creations,
        avg_creation_time_seconds, avg_questions_to_completion,
        department_breakdown
    ) VALUES (
        CURRENT_DATE, current_hour, 1,
        CASE WHEN p_success THEN 1 ELSE 0 END,
        CASE WHEN p_success THEN 0 ELSE 1 END,
        p_creation_time_seconds, p_questions_answered,
        dept_breakdown
    )
    ON CONFLICT (date_period, hour_period)
    DO UPDATE SET
        total_attempts = agent_creation_metrics.total_attempts + 1,
        successful_creations = agent_creation_metrics.successful_creations + 
            CASE WHEN p_success THEN 1 ELSE 0 END,
        failed_creations = agent_creation_metrics.failed_creations + 
            CASE WHEN p_success THEN 0 ELSE 1 END,
        avg_creation_time_seconds = CASE 
            WHEN p_creation_time_seconds IS NOT NULL THEN
                COALESCE(
                    (agent_creation_metrics.avg_creation_time_seconds + p_creation_time_seconds) / 2,
                    p_creation_time_seconds
                )
            ELSE agent_creation_metrics.avg_creation_time_seconds
        END,
        avg_questions_to_completion = CASE 
            WHEN p_questions_answered IS NOT NULL THEN
                COALESCE(
                    (agent_creation_metrics.avg_questions_to_completion + p_questions_answered) / 2.0,
                    p_questions_answered::DECIMAL
                )
            ELSE agent_creation_metrics.avg_questions_to_completion
        END,
        department_breakdown = dept_breakdown,
        last_updated = NOW();
END;
$$;


ALTER FUNCTION public.update_creation_metrics(p_success boolean, p_creation_time_seconds integer, p_questions_answered integer, p_department character varying) OWNER TO postgres;

--
-- TOC entry 5193 (class 0 OID 0)
-- Dependencies: 509
-- Name: FUNCTION update_creation_metrics(p_success boolean, p_creation_time_seconds integer, p_questions_answered integer, p_department character varying); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.update_creation_metrics(p_success boolean, p_creation_time_seconds integer, p_questions_answered integer, p_department character varying) IS 'Helper function to update system creation metrics';


--
-- TOC entry 490 (class 1255 OID 18973)
-- Name: update_plans_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_plans_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_plans_updated_at() OWNER TO postgres;

--
-- TOC entry 510 (class 1255 OID 18164)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

--
-- TOC entry 511 (class 1255 OID 18165)
-- Name: validate_skill_examples(jsonb); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.validate_skill_examples(examples jsonb) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    example_text TEXT;
    example_value JSONB;
BEGIN
    -- Check each example in the array
    FOR example_value IN SELECT jsonb_array_elements(examples)
    LOOP
        example_text := example_value #>> '{}';
        
        -- Ensure example is not empty or too short
        IF LENGTH(TRIM(example_text)) < 5 THEN
            RETURN FALSE;
        END IF;
        
        -- Ensure example is a reasonable length (not too long)
        IF LENGTH(example_text) > 500 THEN
            RETURN FALSE;
        END IF;
    END LOOP;
    
    RETURN TRUE;
END;
$$;


ALTER FUNCTION public.validate_skill_examples(examples jsonb) OWNER TO postgres;

--
-- TOC entry 481 (class 1255 OID 17511)
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_;

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or (
                          action = 'DELETE'
                          and realtime.is_visible_through_filters(old_columns, subs.filters)
                        )
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) OWNER TO supabase_admin;

--
-- TOC entry 491 (class 1255 OID 17589)
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) OWNER TO supabase_admin;

--
-- TOC entry 480 (class 1255 OID 17523)
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) OWNER TO supabase_admin;

--
-- TOC entry 478 (class 1255 OID 17473)
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
    declare
      res jsonb;
    begin
      execute format('select to_jsonb(%L::'|| type_::text || ')', val)  into res;
      return res;
    end
    $$;


ALTER FUNCTION realtime."cast"(val text, type_ regtype) OWNER TO supabase_admin;

--
-- TOC entry 486 (class 1255 OID 17468)
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


ALTER FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) OWNER TO supabase_admin;

--
-- TOC entry 483 (class 1255 OID 17519)
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


ALTER FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) OWNER TO supabase_admin;

--
-- TOC entry 482 (class 1255 OID 17530)
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS SETOF realtime.wal_rls
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
      with pub as (
        select
          concat_ws(
            ',',
            case when bool_or(pubinsert) then 'insert' else null end,
            case when bool_or(pubupdate) then 'update' else null end,
            case when bool_or(pubdelete) then 'delete' else null end
          ) as w2j_actions,
          coalesce(
            string_agg(
              realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
              ','
            ) filter (where ppt.tablename is not null and ppt.tablename not like '% %'),
            ''
          ) w2j_add_tables
        from
          pg_publication pp
          left join pg_publication_tables ppt
            on pp.pubname = ppt.pubname
        where
          pp.pubname = publication
        group by
          pp.pubname
        limit 1
      ),
      w2j as (
        select
          x.*, pub.w2j_add_tables
        from
          pub,
          pg_logical_slot_get_changes(
            slot_name, null, max_changes,
            'include-pk', 'true',
            'include-transaction', 'false',
            'include-timestamp', 'true',
            'include-type-oids', 'true',
            'format-version', '2',
            'actions', pub.w2j_actions,
            'add-tables', pub.w2j_add_tables
          ) x
      )
      select
        xyz.wal,
        xyz.is_rls_enabled,
        xyz.subscription_ids,
        xyz.errors
      from
        w2j,
        realtime.apply_rls(
          wal := w2j.data::jsonb,
          max_record_bytes := max_record_bytes
        ) xyz(wal, is_rls_enabled, subscription_ids, errors)
      where
        w2j.w2j_add_tables <> ''
        and xyz.subscription_ids[1] is not null
    $$;


ALTER FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) OWNER TO supabase_admin;

--
-- TOC entry 477 (class 1255 OID 17467)
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


ALTER FUNCTION realtime.quote_wal2json(entity regclass) OWNER TO supabase_admin;

--
-- TOC entry 475 (class 1255 OID 17588)
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  BEGIN
    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    -- Attempt to insert the message
    INSERT INTO realtime.messages (payload, event, topic, private, extension)
    VALUES (payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      -- Capture and notify the error
      RAISE WARNING 'ErrorSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) OWNER TO supabase_admin;

--
-- TOC entry 487 (class 1255 OID 17465)
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


ALTER FUNCTION realtime.subscription_check_filters() OWNER TO supabase_admin;

--
-- TOC entry 479 (class 1255 OID 17500)
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION realtime.to_regrole(role_name text) OWNER TO supabase_admin;

--
-- TOC entry 488 (class 1255 OID 17582)
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION realtime.topic() OWNER TO supabase_realtime_admin;

--
-- TOC entry 417 (class 1255 OID 19088)
-- Name: add_prefixes(text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.add_prefixes(_bucket_id text, _name text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    prefixes text[];
BEGIN
    prefixes := "storage"."get_prefixes"("_name");

    IF array_length(prefixes, 1) > 0 THEN
        INSERT INTO storage.prefixes (name, bucket_id)
        SELECT UNNEST(prefixes) as name, "_bucket_id" ON CONFLICT DO NOTHING;
    END IF;
END;
$$;


ALTER FUNCTION storage.add_prefixes(_bucket_id text, _name text) OWNER TO supabase_storage_admin;

--
-- TOC entry 495 (class 1255 OID 17769)
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) OWNER TO supabase_storage_admin;

--
-- TOC entry 423 (class 1255 OID 19089)
-- Name: delete_prefix(text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.delete_prefix(_bucket_id text, _name text) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    -- Check if we can delete the prefix
    IF EXISTS(
        SELECT FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name") + 1
          AND "prefixes"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    )
    OR EXISTS(
        SELECT FROM "storage"."objects"
        WHERE "objects"."bucket_id" = "_bucket_id"
          AND "storage"."get_level"("objects"."name") = "storage"."get_level"("_name") + 1
          AND "objects"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    ) THEN
    -- There are sub-objects, skip deletion
    RETURN false;
    ELSE
        DELETE FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name")
          AND "prefixes"."name" = "_name";
        RETURN true;
    END IF;
END;
$$;


ALTER FUNCTION storage.delete_prefix(_bucket_id text, _name text) OWNER TO supabase_storage_admin;

--
-- TOC entry 426 (class 1255 OID 19092)
-- Name: delete_prefix_hierarchy_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.delete_prefix_hierarchy_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    prefix text;
BEGIN
    prefix := "storage"."get_prefix"(OLD."name");

    IF coalesce(prefix, '') != '' THEN
        PERFORM "storage"."delete_prefix"(OLD."bucket_id", prefix);
    END IF;

    RETURN OLD;
END;
$$;


ALTER FUNCTION storage.delete_prefix_hierarchy_trigger() OWNER TO supabase_storage_admin;

--
-- TOC entry 520 (class 1255 OID 19107)
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION storage.enforce_bucket_name_length() OWNER TO supabase_storage_admin;

--
-- TOC entry 517 (class 1255 OID 17743)
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    SELECT _parts[array_length(_parts,1)] INTO _filename;
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION storage.extension(name text) OWNER TO supabase_storage_admin;

--
-- TOC entry 492 (class 1255 OID 17742)
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION storage.filename(name text) OWNER TO supabase_storage_admin;

--
-- TOC entry 516 (class 1255 OID 17741)
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION storage.foldername(name text) OWNER TO supabase_storage_admin;

--
-- TOC entry 493 (class 1255 OID 19070)
-- Name: get_level(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_level(name text) RETURNS integer
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
SELECT array_length(string_to_array("name", '/'), 1);
$$;


ALTER FUNCTION storage.get_level(name text) OWNER TO supabase_storage_admin;

--
-- TOC entry 507 (class 1255 OID 19086)
-- Name: get_prefix(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_prefix(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$
SELECT
    CASE WHEN strpos("name", '/') > 0 THEN
             regexp_replace("name", '[\/]{1}[^\/]+\/?$', '')
         ELSE
             ''
        END;
$_$;


ALTER FUNCTION storage.get_prefix(name text) OWNER TO supabase_storage_admin;

--
-- TOC entry 508 (class 1255 OID 19087)
-- Name: get_prefixes(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_prefixes(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $$
DECLARE
    parts text[];
    prefixes text[];
    prefix text;
BEGIN
    -- Split the name into parts by '/'
    parts := string_to_array("name", '/');
    prefixes := '{}';

    -- Construct the prefixes, stopping one level below the last part
    FOR i IN 1..array_length(parts, 1) - 1 LOOP
            prefix := array_to_string(parts[1:i], '/');
            prefixes := array_append(prefixes, prefix);
    END LOOP;

    RETURN prefixes;
END;
$$;


ALTER FUNCTION storage.get_prefixes(name text) OWNER TO supabase_storage_admin;

--
-- TOC entry 518 (class 1255 OID 19105)
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION storage.get_size_by_bucket() OWNER TO supabase_storage_admin;

--
-- TOC entry 497 (class 1255 OID 17808)
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, next_key_token text, next_upload_token text) OWNER TO supabase_storage_admin;

--
-- TOC entry 496 (class 1255 OID 17771)
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(name COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                        substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1)))
                    ELSE
                        name
                END AS name, id, metadata, updated_at
            FROM
                storage.objects
            WHERE
                bucket_id = $5 AND
                name ILIKE $1 || ''%'' AND
                CASE
                    WHEN $6 != '''' THEN
                    name COLLATE "C" > $6
                ELSE true END
                AND CASE
                    WHEN $4 != '''' THEN
                        CASE
                            WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                                substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                name COLLATE "C" > $4
                            END
                    ELSE
                        true
                END
            ORDER BY
                name COLLATE "C" ASC) as e order by name COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_token, bucket_id, start_after;
END;
$_$;


ALTER FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, start_after text, next_token text) OWNER TO supabase_storage_admin;

--
-- TOC entry 425 (class 1255 OID 19091)
-- Name: objects_insert_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.objects_insert_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    NEW.level := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.objects_insert_prefix_trigger() OWNER TO supabase_storage_admin;

--
-- TOC entry 519 (class 1255 OID 19106)
-- Name: objects_update_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.objects_update_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    old_prefixes TEXT[];
BEGIN
    -- Ensure this is an update operation and the name has changed
    IF TG_OP = 'UPDATE' AND (NEW."name" <> OLD."name" OR NEW."bucket_id" <> OLD."bucket_id") THEN
        -- Retrieve old prefixes
        old_prefixes := "storage"."get_prefixes"(OLD."name");

        -- Remove old prefixes that are only used by this object
        WITH all_prefixes as (
            SELECT unnest(old_prefixes) as prefix
        ),
        can_delete_prefixes as (
             SELECT prefix
             FROM all_prefixes
             WHERE NOT EXISTS (
                 SELECT 1 FROM "storage"."objects"
                 WHERE "bucket_id" = OLD."bucket_id"
                   AND "name" <> OLD."name"
                   AND "name" LIKE (prefix || '%')
             )
         )
        DELETE FROM "storage"."prefixes" WHERE name IN (SELECT prefix FROM can_delete_prefixes);

        -- Add new prefixes
        PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    END IF;
    -- Set the new level
    NEW."level" := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.objects_update_prefix_trigger() OWNER TO supabase_storage_admin;

--
-- TOC entry 498 (class 1255 OID 17824)
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION storage.operation() OWNER TO supabase_storage_admin;

--
-- TOC entry 424 (class 1255 OID 19090)
-- Name: prefixes_insert_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.prefixes_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.prefixes_insert_trigger() OWNER TO supabase_storage_admin;

--
-- TOC entry 515 (class 1255 OID 17758)
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql
    AS $$
declare
    can_bypass_rls BOOLEAN;
begin
    SELECT rolbypassrls
    INTO can_bypass_rls
    FROM pg_roles
    WHERE rolname = coalesce(nullif(current_setting('role', true), 'none'), current_user);

    IF can_bypass_rls THEN
        RETURN QUERY SELECT * FROM storage.search_v1_optimised(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    ELSE
        RETURN QUERY SELECT * FROM storage.search_legacy_v1(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    END IF;
end;
$$;


ALTER FUNCTION storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- TOC entry 514 (class 1255 OID 19103)
-- Name: search_legacy_v1(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_legacy_v1(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select path_tokens[$1] as folder
           from storage.objects
             where objects.name ilike $2 || $3 || ''%''
               and bucket_id = $4
               and array_length(objects.path_tokens, 1) <> $1
           group by folder
           order by folder ' || v_sort_order || '
     )
     (select folder as "name",
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[$1] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where objects.name ilike $2 || $3 || ''%''
       and bucket_id = $4
       and array_length(objects.path_tokens, 1) = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


ALTER FUNCTION storage.search_legacy_v1(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- TOC entry 428 (class 1255 OID 19102)
-- Name: search_v1_optimised(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_v1_optimised(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select (string_to_array(name, ''/''))[level] as name
           from storage.prefixes
             where lower(prefixes.name) like lower($2 || $3) || ''%''
               and bucket_id = $4
               and level = $1
           order by name ' || v_sort_order || '
     )
     (select name,
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[level] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where lower(objects.name) like lower($2 || $3) || ''%''
       and bucket_id = $4
       and level = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


ALTER FUNCTION storage.search_v1_optimised(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- TOC entry 427 (class 1255 OID 19097)
-- Name: search_v2(text, text, integer, integer, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
BEGIN
    RETURN query EXECUTE
        $sql$
        SELECT * FROM (
            (
                SELECT
                    split_part(name, '/', $4) AS key,
                    name || '/' AS name,
                    NULL::uuid AS id,
                    NULL::timestamptz AS updated_at,
                    NULL::timestamptz AS created_at,
                    NULL::jsonb AS metadata
                FROM storage.prefixes
                WHERE name COLLATE "C" LIKE $1 || '%'
                AND bucket_id = $2
                AND level = $4
                AND name COLLATE "C" > $5
                ORDER BY prefixes.name COLLATE "C" LIMIT $3
            )
            UNION ALL
            (SELECT split_part(name, '/', $4) AS key,
                name,
                id,
                updated_at,
                created_at,
                metadata
            FROM storage.objects
            WHERE name COLLATE "C" LIKE $1 || '%'
                AND bucket_id = $2
                AND level = $4
                AND name COLLATE "C" > $5
            ORDER BY name COLLATE "C" LIMIT $3)
        ) obj
        ORDER BY name COLLATE "C" LIMIT $3;
        $sql$
        USING prefix, bucket_name, limits, levels, start_after;
END;
$_$;


ALTER FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer, levels integer, start_after text) OWNER TO supabase_storage_admin;

--
-- TOC entry 494 (class 1255 OID 17759)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION storage.update_updated_at_column() OWNER TO supabase_storage_admin;

--
-- TOC entry 476 (class 1255 OID 16754)
-- Name: http_request(); Type: FUNCTION; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE FUNCTION supabase_functions.http_request() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'supabase_functions'
    AS $$
  DECLARE
    request_id bigint;
    payload jsonb;
    url text := TG_ARGV[0]::text;
    method text := TG_ARGV[1]::text;
    headers jsonb DEFAULT '{}'::jsonb;
    params jsonb DEFAULT '{}'::jsonb;
    timeout_ms integer DEFAULT 1000;
  BEGIN
    IF url IS NULL OR url = 'null' THEN
      RAISE EXCEPTION 'url argument is missing';
    END IF;

    IF method IS NULL OR method = 'null' THEN
      RAISE EXCEPTION 'method argument is missing';
    END IF;

    IF TG_ARGV[2] IS NULL OR TG_ARGV[2] = 'null' THEN
      headers = '{"Content-Type": "application/json"}'::jsonb;
    ELSE
      headers = TG_ARGV[2]::jsonb;
    END IF;

    IF TG_ARGV[3] IS NULL OR TG_ARGV[3] = 'null' THEN
      params = '{}'::jsonb;
    ELSE
      params = TG_ARGV[3]::jsonb;
    END IF;

    IF TG_ARGV[4] IS NULL OR TG_ARGV[4] = 'null' THEN
      timeout_ms = 1000;
    ELSE
      timeout_ms = TG_ARGV[4]::integer;
    END IF;

    CASE
      WHEN method = 'GET' THEN
        SELECT http_get INTO request_id FROM net.http_get(
          url,
          params,
          headers,
          timeout_ms
        );
      WHEN method = 'POST' THEN
        payload = jsonb_build_object(
          'old_record', OLD,
          'record', NEW,
          'type', TG_OP,
          'table', TG_TABLE_NAME,
          'schema', TG_TABLE_SCHEMA
        );

        SELECT http_post INTO request_id FROM net.http_post(
          url,
          payload,
          params,
          headers,
          timeout_ms
        );
      ELSE
        RAISE EXCEPTION 'method argument % is invalid', method;
    END CASE;

    INSERT INTO supabase_functions.hooks
      (hook_table_id, hook_name, request_id)
    VALUES
      (TG_RELID, TG_NAME, request_id);

    RETURN NEW;
  END
$$;


ALTER FUNCTION supabase_functions.http_request() OWNER TO supabase_functions_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 258 (class 1259 OID 17379)
-- Name: extensions; Type: TABLE; Schema: _realtime; Owner: supabase_admin
--

CREATE TABLE _realtime.extensions (
    id uuid NOT NULL,
    type text,
    settings jsonb,
    tenant_external_id text,
    inserted_at timestamp(0) without time zone NOT NULL,
    updated_at timestamp(0) without time zone NOT NULL
);


ALTER TABLE _realtime.extensions OWNER TO supabase_admin;

--
-- TOC entry 256 (class 1259 OID 17365)
-- Name: schema_migrations; Type: TABLE; Schema: _realtime; Owner: supabase_admin
--

CREATE TABLE _realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


ALTER TABLE _realtime.schema_migrations OWNER TO supabase_admin;

--
-- TOC entry 257 (class 1259 OID 17370)
-- Name: tenants; Type: TABLE; Schema: _realtime; Owner: supabase_admin
--

CREATE TABLE _realtime.tenants (
    id uuid NOT NULL,
    name text,
    external_id text,
    jwt_secret text,
    max_concurrent_users integer DEFAULT 200 NOT NULL,
    inserted_at timestamp(0) without time zone NOT NULL,
    updated_at timestamp(0) without time zone NOT NULL,
    max_events_per_second integer DEFAULT 100 NOT NULL,
    postgres_cdc_default text DEFAULT 'postgres_cdc_rls'::text,
    max_bytes_per_second integer DEFAULT 100000 NOT NULL,
    max_channels_per_client integer DEFAULT 100 NOT NULL,
    max_joins_per_second integer DEFAULT 500 NOT NULL,
    suspend boolean DEFAULT false,
    jwt_jwks jsonb,
    notify_private_alpha boolean DEFAULT false,
    private_only boolean DEFAULT false NOT NULL,
    migrations_ran integer DEFAULT 0,
    broadcast_adapter character varying(255) DEFAULT 'gen_rpc'::character varying,
    max_presence_events_per_second integer DEFAULT 10000,
    max_payload_size_in_kb integer DEFAULT 3000
);


ALTER TABLE _realtime.tenants OWNER TO supabase_admin;

--
-- TOC entry 238 (class 1259 OID 16488)
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE auth.audit_log_entries OWNER TO supabase_auth_admin;

--
-- TOC entry 5214 (class 0 OID 0)
-- Dependencies: 238
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- TOC entry 282 (class 1259 OID 18047)
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text NOT NULL,
    code_challenge_method auth.code_challenge_method NOT NULL,
    code_challenge text NOT NULL,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone
);


ALTER TABLE auth.flow_state OWNER TO supabase_auth_admin;

--
-- TOC entry 5216 (class 0 OID 0)
-- Dependencies: 282
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.flow_state IS 'stores metadata for pkce logins';


--
-- TOC entry 273 (class 1259 OID 17844)
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE auth.identities OWNER TO supabase_auth_admin;

--
-- TOC entry 5218 (class 0 OID 0)
-- Dependencies: 273
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- TOC entry 5219 (class 0 OID 0)
-- Dependencies: 273
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- TOC entry 237 (class 1259 OID 16481)
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE auth.instances OWNER TO supabase_auth_admin;

--
-- TOC entry 5221 (class 0 OID 0)
-- Dependencies: 237
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- TOC entry 277 (class 1259 OID 17934)
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE auth.mfa_amr_claims OWNER TO supabase_auth_admin;

--
-- TOC entry 5223 (class 0 OID 0)
-- Dependencies: 277
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- TOC entry 276 (class 1259 OID 17922)
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


ALTER TABLE auth.mfa_challenges OWNER TO supabase_auth_admin;

--
-- TOC entry 5225 (class 0 OID 0)
-- Dependencies: 276
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- TOC entry 275 (class 1259 OID 17909)
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid
);


ALTER TABLE auth.mfa_factors OWNER TO supabase_auth_admin;

--
-- TOC entry 5227 (class 0 OID 0)
-- Dependencies: 275
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- TOC entry 284 (class 1259 OID 18129)
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_id text NOT NULL,
    client_secret_hash text NOT NULL,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048))
);


ALTER TABLE auth.oauth_clients OWNER TO supabase_auth_admin;

--
-- TOC entry 283 (class 1259 OID 18097)
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


ALTER TABLE auth.one_time_tokens OWNER TO supabase_auth_admin;

--
-- TOC entry 236 (class 1259 OID 16470)
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


ALTER TABLE auth.refresh_tokens OWNER TO supabase_auth_admin;

--
-- TOC entry 5231 (class 0 OID 0)
-- Dependencies: 236
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- TOC entry 235 (class 1259 OID 16469)
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth.refresh_tokens_id_seq OWNER TO supabase_auth_admin;

--
-- TOC entry 5233 (class 0 OID 0)
-- Dependencies: 235
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- TOC entry 280 (class 1259 OID 17976)
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


ALTER TABLE auth.saml_providers OWNER TO supabase_auth_admin;

--
-- TOC entry 5235 (class 0 OID 0)
-- Dependencies: 280
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- TOC entry 281 (class 1259 OID 17994)
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


ALTER TABLE auth.saml_relay_states OWNER TO supabase_auth_admin;

--
-- TOC entry 5237 (class 0 OID 0)
-- Dependencies: 281
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- TOC entry 239 (class 1259 OID 16496)
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE auth.schema_migrations OWNER TO supabase_auth_admin;

--
-- TOC entry 5239 (class 0 OID 0)
-- Dependencies: 239
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- TOC entry 274 (class 1259 OID 17874)
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text
);


ALTER TABLE auth.sessions OWNER TO supabase_auth_admin;

--
-- TOC entry 5241 (class 0 OID 0)
-- Dependencies: 274
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- TOC entry 5242 (class 0 OID 0)
-- Dependencies: 274
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- TOC entry 279 (class 1259 OID 17961)
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


ALTER TABLE auth.sso_domains OWNER TO supabase_auth_admin;

--
-- TOC entry 5244 (class 0 OID 0)
-- Dependencies: 279
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- TOC entry 278 (class 1259 OID 17952)
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


ALTER TABLE auth.sso_providers OWNER TO supabase_auth_admin;

--
-- TOC entry 5246 (class 0 OID 0)
-- Dependencies: 278
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- TOC entry 5247 (class 0 OID 0)
-- Dependencies: 278
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- TOC entry 234 (class 1259 OID 16458)
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


ALTER TABLE auth.users OWNER TO supabase_auth_admin;

--
-- TOC entry 5249 (class 0 OID 0)
-- Dependencies: 234
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- TOC entry 5250 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- TOC entry 351 (class 1259 OID 20076)
-- Name: annotation_tag_entity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.annotation_tag_entity (
    id character varying(16) NOT NULL,
    name character varying(24) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.annotation_tag_entity OWNER TO postgres;

--
-- TOC entry 336 (class 1259 OID 19603)
-- Name: auth_identity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.auth_identity (
    "userId" uuid,
    "providerId" character varying(64) NOT NULL,
    "providerType" character varying(32) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.auth_identity OWNER TO postgres;

--
-- TOC entry 338 (class 1259 OID 19616)
-- Name: auth_provider_sync_history; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.auth_provider_sync_history (
    id integer NOT NULL,
    "providerType" character varying(32) NOT NULL,
    "runMode" text NOT NULL,
    status text NOT NULL,
    "startedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    scanned integer NOT NULL,
    created integer NOT NULL,
    updated integer NOT NULL,
    disabled integer NOT NULL,
    error text
);


ALTER TABLE n8n.auth_provider_sync_history OWNER TO postgres;

--
-- TOC entry 337 (class 1259 OID 19615)
-- Name: auth_provider_sync_history_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

CREATE SEQUENCE n8n.auth_provider_sync_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE n8n.auth_provider_sync_history_id_seq OWNER TO postgres;

--
-- TOC entry 5254 (class 0 OID 0)
-- Dependencies: 337
-- Name: auth_provider_sync_history_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: postgres
--

ALTER SEQUENCE n8n.auth_provider_sync_history_id_seq OWNED BY n8n.auth_provider_sync_history.id;


--
-- TOC entry 323 (class 1259 OID 19319)
-- Name: credentials_entity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.credentials_entity (
    name character varying(128) NOT NULL,
    data text NOT NULL,
    type character varying(128) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    id character varying(36) NOT NULL,
    "isManaged" boolean DEFAULT false NOT NULL
);


ALTER TABLE n8n.credentials_entity OWNER TO postgres;

--
-- TOC entry 368 (class 1259 OID 20462)
-- Name: data_table; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.data_table (
    id character varying(36) NOT NULL,
    name character varying(128) NOT NULL,
    "projectId" character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.data_table OWNER TO postgres;

--
-- TOC entry 369 (class 1259 OID 20476)
-- Name: data_table_column; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.data_table_column (
    id character varying(36) NOT NULL,
    name character varying(128) NOT NULL,
    type character varying(32) NOT NULL,
    index integer NOT NULL,
    "dataTableId" character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.data_table_column OWNER TO postgres;

--
-- TOC entry 5255 (class 0 OID 0)
-- Dependencies: 369
-- Name: COLUMN data_table_column.type; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.data_table_column.type IS 'Expected: string, number, boolean, or date (not enforced as a constraint)';


--
-- TOC entry 5256 (class 0 OID 0)
-- Dependencies: 369
-- Name: COLUMN data_table_column.index; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.data_table_column.index IS 'Column order, starting from 0 (0 = first column)';


--
-- TOC entry 335 (class 1259 OID 19572)
-- Name: event_destinations; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.event_destinations (
    id uuid NOT NULL,
    destination jsonb NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.event_destinations OWNER TO postgres;

--
-- TOC entry 352 (class 1259 OID 20084)
-- Name: execution_annotation_tags; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.execution_annotation_tags (
    "annotationId" integer NOT NULL,
    "tagId" character varying(24) NOT NULL
);


ALTER TABLE n8n.execution_annotation_tags OWNER TO postgres;

--
-- TOC entry 350 (class 1259 OID 20060)
-- Name: execution_annotations; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.execution_annotations (
    id integer NOT NULL,
    "executionId" integer NOT NULL,
    vote character varying(6),
    note text,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.execution_annotations OWNER TO postgres;

--
-- TOC entry 349 (class 1259 OID 20059)
-- Name: execution_annotations_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

CREATE SEQUENCE n8n.execution_annotations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE n8n.execution_annotations_id_seq OWNER TO postgres;

--
-- TOC entry 5257 (class 0 OID 0)
-- Dependencies: 349
-- Name: execution_annotations_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: postgres
--

ALTER SEQUENCE n8n.execution_annotations_id_seq OWNED BY n8n.execution_annotations.id;


--
-- TOC entry 340 (class 1259 OID 19711)
-- Name: execution_data; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.execution_data (
    "executionId" integer NOT NULL,
    "workflowData" json NOT NULL,
    data text NOT NULL
);


ALTER TABLE n8n.execution_data OWNER TO postgres;

--
-- TOC entry 325 (class 1259 OID 19329)
-- Name: execution_entity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.execution_entity (
    id integer NOT NULL,
    finished boolean NOT NULL,
    mode character varying NOT NULL,
    "retryOf" character varying,
    "retrySuccessId" character varying,
    "startedAt" timestamp(3) with time zone,
    "stoppedAt" timestamp(3) with time zone,
    "waitTill" timestamp(3) with time zone,
    status character varying NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    "deletedAt" timestamp(3) with time zone,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.execution_entity OWNER TO postgres;

--
-- TOC entry 324 (class 1259 OID 19328)
-- Name: execution_entity_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

CREATE SEQUENCE n8n.execution_entity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE n8n.execution_entity_id_seq OWNER TO postgres;

--
-- TOC entry 5258 (class 0 OID 0)
-- Dependencies: 324
-- Name: execution_entity_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: postgres
--

ALTER SEQUENCE n8n.execution_entity_id_seq OWNED BY n8n.execution_entity.id;


--
-- TOC entry 347 (class 1259 OID 20035)
-- Name: execution_metadata; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.execution_metadata (
    id integer NOT NULL,
    "executionId" integer NOT NULL,
    key character varying(255) NOT NULL,
    value text NOT NULL
);


ALTER TABLE n8n.execution_metadata OWNER TO postgres;

--
-- TOC entry 346 (class 1259 OID 20034)
-- Name: execution_metadata_temp_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

CREATE SEQUENCE n8n.execution_metadata_temp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE n8n.execution_metadata_temp_id_seq OWNER TO postgres;

--
-- TOC entry 5259 (class 0 OID 0)
-- Dependencies: 346
-- Name: execution_metadata_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: postgres
--

ALTER SEQUENCE n8n.execution_metadata_temp_id_seq OWNED BY n8n.execution_metadata.id;


--
-- TOC entry 355 (class 1259 OID 20228)
-- Name: folder; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.folder (
    id character varying(36) NOT NULL,
    name character varying(128) NOT NULL,
    "parentFolderId" character varying(36),
    "projectId" character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.folder OWNER TO postgres;

--
-- TOC entry 356 (class 1259 OID 20246)
-- Name: folder_tag; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.folder_tag (
    "folderId" character varying(36) NOT NULL,
    "tagId" character varying(36) NOT NULL
);


ALTER TABLE n8n.folder_tag OWNER TO postgres;

--
-- TOC entry 362 (class 1259 OID 20342)
-- Name: insights_by_period; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.insights_by_period (
    id integer NOT NULL,
    "metaId" integer NOT NULL,
    type integer NOT NULL,
    value integer NOT NULL,
    "periodUnit" integer NOT NULL,
    "periodStart" timestamp(0) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE n8n.insights_by_period OWNER TO postgres;

--
-- TOC entry 5260 (class 0 OID 0)
-- Dependencies: 362
-- Name: COLUMN insights_by_period.type; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.insights_by_period.type IS '0: time_saved_minutes, 1: runtime_milliseconds, 2: success, 3: failure';


--
-- TOC entry 5261 (class 0 OID 0)
-- Dependencies: 362
-- Name: COLUMN insights_by_period."periodUnit"; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.insights_by_period."periodUnit" IS '0: hour, 1: day, 2: week';


--
-- TOC entry 361 (class 1259 OID 20341)
-- Name: insights_by_period_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

ALTER TABLE n8n.insights_by_period ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME n8n.insights_by_period_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 358 (class 1259 OID 20313)
-- Name: insights_metadata; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.insights_metadata (
    "metaId" integer NOT NULL,
    "workflowId" character varying(16),
    "projectId" character varying(36),
    "workflowName" character varying(128) NOT NULL,
    "projectName" character varying(255) NOT NULL
);


ALTER TABLE n8n.insights_metadata OWNER TO postgres;

--
-- TOC entry 357 (class 1259 OID 20312)
-- Name: insights_metadata_metaId_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

ALTER TABLE n8n.insights_metadata ALTER COLUMN "metaId" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME n8n."insights_metadata_metaId_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 360 (class 1259 OID 20330)
-- Name: insights_raw; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.insights_raw (
    id integer NOT NULL,
    "metaId" integer NOT NULL,
    type integer NOT NULL,
    value integer NOT NULL,
    "timestamp" timestamp(0) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE n8n.insights_raw OWNER TO postgres;

--
-- TOC entry 5262 (class 0 OID 0)
-- Dependencies: 360
-- Name: COLUMN insights_raw.type; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.insights_raw.type IS '0: time_saved_minutes, 1: runtime_milliseconds, 2: success, 3: failure';


--
-- TOC entry 359 (class 1259 OID 20329)
-- Name: insights_raw_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

ALTER TABLE n8n.insights_raw ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME n8n.insights_raw_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 333 (class 1259 OID 19521)
-- Name: installed_nodes; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.installed_nodes (
    name character varying(200) NOT NULL,
    type character varying(200) NOT NULL,
    "latestVersion" integer DEFAULT 1 NOT NULL,
    package character varying(241) NOT NULL
);


ALTER TABLE n8n.installed_nodes OWNER TO postgres;

--
-- TOC entry 332 (class 1259 OID 19514)
-- Name: installed_packages; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.installed_packages (
    "packageName" character varying(214) NOT NULL,
    "installedVersion" character varying(50) NOT NULL,
    "authorName" character varying(70),
    "authorEmail" character varying(70),
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.installed_packages OWNER TO postgres;

--
-- TOC entry 348 (class 1259 OID 20049)
-- Name: invalid_auth_token; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.invalid_auth_token (
    token character varying(512) NOT NULL,
    "expiresAt" timestamp(3) with time zone NOT NULL
);


ALTER TABLE n8n.invalid_auth_token OWNER TO postgres;

--
-- TOC entry 315 (class 1259 OID 19009)
-- Name: migration_metadata; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.migration_metadata (
    migration_file text NOT NULL,
    source text NOT NULL,
    workflow_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    synced_at timestamp with time zone DEFAULT now(),
    notes text,
    CONSTRAINT migration_metadata_source_check CHECK ((source = ANY (ARRAY['dev'::text, 'prod'::text, 'staging'::text])))
);


ALTER TABLE n8n.migration_metadata OWNER TO postgres;

--
-- TOC entry 5263 (class 0 OID 0)
-- Dependencies: 315
-- Name: TABLE migration_metadata; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON TABLE n8n.migration_metadata IS 'Tracks n8n workflow migration sources and metadata (moved to n8n schema for better organization)';


--
-- TOC entry 5264 (class 0 OID 0)
-- Dependencies: 315
-- Name: COLUMN migration_metadata.source; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.migration_metadata.source IS 'Origin of the migration: dev, prod, or staging';


--
-- TOC entry 5265 (class 0 OID 0)
-- Dependencies: 315
-- Name: COLUMN migration_metadata.workflow_id; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.migration_metadata.workflow_id IS 'References the n8n workflow this migration manages';


--
-- TOC entry 322 (class 1259 OID 19310)
-- Name: migrations; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE n8n.migrations OWNER TO postgres;

--
-- TOC entry 321 (class 1259 OID 19309)
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

CREATE SEQUENCE n8n.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE n8n.migrations_id_seq OWNER TO postgres;

--
-- TOC entry 5266 (class 0 OID 0)
-- Dependencies: 321
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: postgres
--

ALTER SEQUENCE n8n.migrations_id_seq OWNED BY n8n.migrations.id;


--
-- TOC entry 314 (class 1259 OID 18993)
-- Name: n8n_workflows; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.n8n_workflows (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    active boolean DEFAULT true,
    nodes jsonb DEFAULT '[]'::jsonb NOT NULL,
    connections jsonb DEFAULT '{}'::jsonb NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE n8n.n8n_workflows OWNER TO postgres;

--
-- TOC entry 5267 (class 0 OID 0)
-- Dependencies: 314
-- Name: TABLE n8n_workflows; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON TABLE n8n.n8n_workflows IS 'Stores n8n workflow definitions for sync between environments (moved from public schema)';


--
-- TOC entry 354 (class 1259 OID 20117)
-- Name: processed_data; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.processed_data (
    "workflowId" character varying(36) NOT NULL,
    context character varying(255) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    value text NOT NULL
);


ALTER TABLE n8n.processed_data OWNER TO postgres;

--
-- TOC entry 342 (class 1259 OID 19954)
-- Name: project; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.project (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    icon json,
    description character varying(512)
);


ALTER TABLE n8n.project OWNER TO postgres;

--
-- TOC entry 343 (class 1259 OID 19961)
-- Name: project_relation; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.project_relation (
    "projectId" character varying(36) NOT NULL,
    "userId" uuid NOT NULL,
    role character varying NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.project_relation OWNER TO postgres;

--
-- TOC entry 366 (class 1259 OID 20398)
-- Name: role; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.role (
    slug character varying(128) NOT NULL,
    "displayName" text,
    description text,
    "roleType" text,
    "systemRole" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.role OWNER TO postgres;

--
-- TOC entry 5268 (class 0 OID 0)
-- Dependencies: 366
-- Name: COLUMN role.slug; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.role.slug IS 'Unique identifier of the role for example: "global:owner"';


--
-- TOC entry 5269 (class 0 OID 0)
-- Dependencies: 366
-- Name: COLUMN role."displayName"; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.role."displayName" IS 'Name used to display in the UI';


--
-- TOC entry 5270 (class 0 OID 0)
-- Dependencies: 366
-- Name: COLUMN role.description; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.role.description IS 'Text describing the scope in more detail of users';


--
-- TOC entry 5271 (class 0 OID 0)
-- Dependencies: 366
-- Name: COLUMN role."roleType"; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.role."roleType" IS 'Type of the role, e.g., global, project, or workflow';


--
-- TOC entry 5272 (class 0 OID 0)
-- Dependencies: 366
-- Name: COLUMN role."systemRole"; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.role."systemRole" IS 'Indicates if the role is managed by the system and cannot be edited';


--
-- TOC entry 367 (class 1259 OID 20406)
-- Name: role_scope; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.role_scope (
    "roleSlug" character varying(128) NOT NULL,
    "scopeSlug" character varying(128) NOT NULL
);


ALTER TABLE n8n.role_scope OWNER TO postgres;

--
-- TOC entry 365 (class 1259 OID 20391)
-- Name: scope; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.scope (
    slug character varying(128) NOT NULL,
    "displayName" text,
    description text
);


ALTER TABLE n8n.scope OWNER TO postgres;

--
-- TOC entry 5273 (class 0 OID 0)
-- Dependencies: 365
-- Name: COLUMN scope.slug; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.scope.slug IS 'Unique identifier of the scope for example: "project:create"';


--
-- TOC entry 5274 (class 0 OID 0)
-- Dependencies: 365
-- Name: COLUMN scope."displayName"; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.scope."displayName" IS 'Name used to display in the UI';


--
-- TOC entry 5275 (class 0 OID 0)
-- Dependencies: 365
-- Name: COLUMN scope.description; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.scope.description IS 'Text describing the scope in more detail of users';


--
-- TOC entry 331 (class 1259 OID 19506)
-- Name: settings; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.settings (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    "loadOnStartup" boolean DEFAULT false NOT NULL
);


ALTER TABLE n8n.settings OWNER TO postgres;

--
-- TOC entry 344 (class 1259 OID 19989)
-- Name: shared_credentials; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.shared_credentials (
    "credentialsId" character varying(36) NOT NULL,
    "projectId" character varying(36) NOT NULL,
    role text NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.shared_credentials OWNER TO postgres;

--
-- TOC entry 345 (class 1259 OID 20015)
-- Name: shared_workflow; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.shared_workflow (
    "workflowId" character varying(36) NOT NULL,
    "projectId" character varying(36) NOT NULL,
    role text NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.shared_workflow OWNER TO postgres;

--
-- TOC entry 328 (class 1259 OID 19357)
-- Name: tag_entity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.tag_entity (
    name character varying(24) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    id character varying(36) NOT NULL
);


ALTER TABLE n8n.tag_entity OWNER TO postgres;

--
-- TOC entry 364 (class 1259 OID 20369)
-- Name: test_case_execution; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.test_case_execution (
    id character varying(36) NOT NULL,
    "testRunId" character varying(36) NOT NULL,
    "executionId" integer,
    status character varying NOT NULL,
    "runAt" timestamp(3) with time zone,
    "completedAt" timestamp(3) with time zone,
    "errorCode" character varying,
    "errorDetails" json,
    metrics json,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    inputs json,
    outputs json
);


ALTER TABLE n8n.test_case_execution OWNER TO postgres;

--
-- TOC entry 363 (class 1259 OID 20354)
-- Name: test_run; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.test_run (
    id character varying(36) NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    status character varying NOT NULL,
    "errorCode" character varying,
    "errorDetails" json,
    "runAt" timestamp(3) with time zone,
    "completedAt" timestamp(3) with time zone,
    metrics json,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.test_run OWNER TO postgres;

--
-- TOC entry 330 (class 1259 OID 19443)
-- Name: user; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n."user" (
    id uuid DEFAULT uuid_in((OVERLAY(OVERLAY(md5((((random())::text || ':'::text) || (clock_timestamp())::text)) PLACING '4'::text FROM 13) PLACING to_hex((floor(((random() * (((11 - 8) + 1))::double precision) + (8)::double precision)))::integer) FROM 17))::cstring) NOT NULL,
    email character varying(255),
    "firstName" character varying(32),
    "lastName" character varying(32),
    password character varying(255),
    "personalizationAnswers" json,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    settings json,
    disabled boolean DEFAULT false NOT NULL,
    "mfaEnabled" boolean DEFAULT false NOT NULL,
    "mfaSecret" text,
    "mfaRecoveryCodes" text,
    "lastActiveAt" date,
    "roleSlug" character varying(128) DEFAULT 'global:member'::character varying NOT NULL
);


ALTER TABLE n8n."user" OWNER TO postgres;

--
-- TOC entry 353 (class 1259 OID 20101)
-- Name: user_api_keys; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.user_api_keys (
    id character varying(36) NOT NULL,
    "userId" uuid NOT NULL,
    label character varying(100) NOT NULL,
    "apiKey" character varying NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    scopes json
);


ALTER TABLE n8n.user_api_keys OWNER TO postgres;

--
-- TOC entry 339 (class 1259 OID 19627)
-- Name: variables; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.variables (
    key character varying(50) NOT NULL,
    type character varying(50) DEFAULT 'string'::character varying NOT NULL,
    value character varying(255),
    id character varying(36) NOT NULL
);


ALTER TABLE n8n.variables OWNER TO postgres;

--
-- TOC entry 327 (class 1259 OID 19347)
-- Name: webhook_entity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.webhook_entity (
    "webhookPath" character varying NOT NULL,
    method character varying NOT NULL,
    node character varying NOT NULL,
    "webhookId" character varying,
    "pathLength" integer,
    "workflowId" character varying(36) NOT NULL
);


ALTER TABLE n8n.webhook_entity OWNER TO postgres;

--
-- TOC entry 326 (class 1259 OID 19339)
-- Name: workflow_entity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.workflow_entity (
    name character varying(128) NOT NULL,
    active boolean NOT NULL,
    nodes json NOT NULL,
    connections json NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    settings json,
    "staticData" json,
    "pinData" json,
    "versionId" character(36),
    "triggerCount" integer DEFAULT 0 NOT NULL,
    id character varying(36) NOT NULL,
    meta json,
    "parentFolderId" character varying(36) DEFAULT NULL::character varying,
    "isArchived" boolean DEFAULT false NOT NULL
);


ALTER TABLE n8n.workflow_entity OWNER TO postgres;

--
-- TOC entry 341 (class 1259 OID 19725)
-- Name: workflow_history; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.workflow_history (
    "versionId" character varying(36) NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    authors character varying(255) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    nodes json NOT NULL,
    connections json NOT NULL
);


ALTER TABLE n8n.workflow_history OWNER TO postgres;

--
-- TOC entry 334 (class 1259 OID 19542)
-- Name: workflow_statistics; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.workflow_statistics (
    count integer DEFAULT 0,
    "latestEvent" timestamp(3) with time zone,
    name character varying(128) NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    "rootCount" integer DEFAULT 0
);


ALTER TABLE n8n.workflow_statistics OWNER TO postgres;

--
-- TOC entry 329 (class 1259 OID 19364)
-- Name: workflows_tags; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.workflows_tags (
    "workflowId" character varying(36) NOT NULL,
    "tagId" character varying(36) NOT NULL
);


ALTER TABLE n8n.workflows_tags OWNER TO postgres;

--
-- TOC entry 306 (class 1259 OID 18821)
-- Name: agent_orchestrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_orchestrations (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    organization_slug text,
    agent_slug text NOT NULL,
    slug text NOT NULL,
    display_name text NOT NULL,
    description text,
    status text DEFAULT 'active'::text,
    orchestration_json jsonb NOT NULL,
    prompt_templates jsonb DEFAULT '[]'::jsonb,
    tags text[] DEFAULT ARRAY[]::text[],
    version text,
    created_by uuid,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.agent_orchestrations OWNER TO postgres;

--
-- TOC entry 5276 (class 0 OID 0)
-- Dependencies: 306
-- Name: TABLE agent_orchestrations; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.agent_orchestrations IS 'Reusable orchestration recipes bound to a specific agent.';


--
-- TOC entry 5277 (class 0 OID 0)
-- Dependencies: 306
-- Name: COLUMN agent_orchestrations.orchestration_json; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.agent_orchestrations.orchestration_json IS 'Structured orchestration definition (phases, steps, dependencies).';


--
-- TOC entry 5278 (class 0 OID 0)
-- Dependencies: 306
-- Name: COLUMN agent_orchestrations.prompt_templates; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.agent_orchestrations.prompt_templates IS 'Prompt templates with parameter metadata required to launch orchestrations.';


--
-- TOC entry 304 (class 1259 OID 18778)
-- Name: agents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agents (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    organization_slug text,
    slug text NOT NULL,
    display_name text NOT NULL,
    description text,
    agent_type text NOT NULL,
    mode_profile text NOT NULL,
    version text,
    status text DEFAULT 'active'::text,
    yaml text NOT NULL,
    agent_card jsonb,
    context jsonb,
    config jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    function_code text
);


ALTER TABLE public.agents OWNER TO postgres;

--
-- TOC entry 5280 (class 0 OID 0)
-- Dependencies: 304
-- Name: TABLE agents; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.agents IS 'Database-backed agent descriptors for the new platform.';


--
-- TOC entry 5281 (class 0 OID 0)
-- Dependencies: 304
-- Name: COLUMN agents.organization_slug; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.agents.organization_slug IS 'Namespace / organization identifier (e.g., demo, my-org).';


--
-- TOC entry 5282 (class 0 OID 0)
-- Dependencies: 304
-- Name: COLUMN agents.yaml; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.agents.yaml IS 'Raw YAML/JSON descriptor for auditability.';


--
-- TOC entry 5283 (class 0 OID 0)
-- Dependencies: 304
-- Name: COLUMN agents.agent_card; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.agents.agent_card IS 'Cached agent card served to clients.';


--
-- TOC entry 5284 (class 0 OID 0)
-- Dependencies: 304
-- Name: COLUMN agents.context; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.agents.context IS 'System prompt, plan rubric, and reference data.';


--
-- TOC entry 5285 (class 0 OID 0)
-- Dependencies: 304
-- Name: COLUMN agents.config; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.agents.config IS 'Execution configuration (capabilities, supporting agents, checkpoints, etc.).';


--
-- TOC entry 5286 (class 0 OID 0)
-- Dependencies: 304
-- Name: COLUMN agents.function_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.agents.function_code IS 'JavaScript/TypeScript function code for function-type agents';


--
-- TOC entry 310 (class 1259 OID 18896)
-- Name: assets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    storage text NOT NULL,
    path text,
    bucket text,
    object_key text,
    mime text NOT NULL,
    size bigint,
    width integer,
    height integer,
    hash text,
    user_id uuid,
    conversation_id uuid,
    deliverable_version_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    source_url text,
    CONSTRAINT assets_storage_check CHECK ((storage = ANY (ARRAY['local'::text, 'supabase'::text, 'external'::text])))
);


ALTER TABLE public.assets OWNER TO postgres;

--
-- TOC entry 286 (class 1259 OID 18268)
-- Name: cidafm_commands; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cidafm_commands (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    type character varying(10) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    default_active boolean DEFAULT false,
    is_builtin boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT cidafm_commands_type_check CHECK (((type)::text = ANY (ARRAY[('^'::character varying)::text, ('&'::character varying)::text, ('!'::character varying)::text])))
);


ALTER TABLE public.cidafm_commands OWNER TO postgres;

--
-- TOC entry 287 (class 1259 OID 18279)
-- Name: companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.companies (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    industry character varying(100),
    founded_year integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.companies OWNER TO postgres;

--
-- TOC entry 288 (class 1259 OID 18285)
-- Name: conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversations (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    user_id uuid,
    agent_name character varying(255),
    agent_type character varying(100),
    started_at timestamp with time zone,
    last_active_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    organization_slug text,
    ended_at timestamp with time zone
);


ALTER TABLE public.conversations OWNER TO postgres;

--
-- TOC entry 5291 (class 0 OID 0)
-- Dependencies: 288
-- Name: COLUMN conversations.organization_slug; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.conversations.organization_slug IS 'Organization slug for database agents (e.g., my-org, acme-corp). NULL for file-based agents.';


--
-- TOC entry 289 (class 1259 OID 18294)
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    user_id uuid,
    conversation_id uuid,
    method character varying(255),
    params jsonb DEFAULT '{}'::jsonb,
    prompt text,
    response text,
    status character varying(50) DEFAULT 'pending'::character varying,
    progress integer DEFAULT 0,
    progress_message text,
    error_code text,
    error_message text,
    error_data jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    timeout_seconds integer DEFAULT 300,
    deliverable_type text,
    deliverable_metadata jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    llm_metadata jsonb DEFAULT '{}'::jsonb,
    response_metadata jsonb DEFAULT '{}'::jsonb,
    evaluation jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- TOC entry 313 (class 1259 OID 18988)
-- Name: conversations_with_stats; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.conversations_with_stats AS
 SELECT c.id,
    c.user_id,
    c.agent_name,
    c.agent_type,
    c.ended_at,
    c.started_at,
    c.last_active_at,
    c.metadata,
    c.created_at,
    c.updated_at,
    COALESCE(task_stats.task_count, (0)::bigint) AS task_count,
    COALESCE(task_stats.completed_tasks, (0)::bigint) AS completed_tasks,
    COALESCE(task_stats.failed_tasks, (0)::bigint) AS failed_tasks,
    COALESCE(task_stats.active_tasks, (0)::bigint) AS active_tasks,
    c.organization_slug
   FROM (public.conversations c
     LEFT JOIN ( SELECT t.conversation_id,
            count(*) AS task_count,
            count(
                CASE
                    WHEN ((t.status)::text = 'completed'::text) THEN 1
                    ELSE NULL::integer
                END) AS completed_tasks,
            count(
                CASE
                    WHEN ((t.status)::text = 'failed'::text) THEN 1
                    ELSE NULL::integer
                END) AS failed_tasks,
            count(
                CASE
                    WHEN ((t.status)::text = ANY (ARRAY['pending'::text, 'running'::text])) THEN 1
                    ELSE NULL::integer
                END) AS active_tasks
           FROM public.tasks t
          GROUP BY t.conversation_id) task_stats ON ((c.id = task_stats.conversation_id)));


ALTER TABLE public.conversations_with_stats OWNER TO postgres;

--
-- TOC entry 290 (class 1259 OID 18314)
-- Name: deliverable_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deliverable_versions (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    deliverable_id uuid NOT NULL,
    version_number integer NOT NULL,
    content text,
    format character varying(100),
    is_current_version boolean DEFAULT false,
    created_by_type character varying(50) DEFAULT 'ai_response'::character varying,
    task_id uuid,
    metadata jsonb DEFAULT '{}'::jsonb,
    file_attachments jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT deliverable_versions_created_by_type_check CHECK (((created_by_type)::text = ANY (ARRAY[('ai_response'::character varying)::text, ('manual_edit'::character varying)::text, ('ai_enhancement'::character varying)::text, ('user_request'::character varying)::text, ('conversation_task'::character varying)::text, ('conversation_merge'::character varying)::text, ('llm_rerun'::character varying)::text])))
);


ALTER TABLE public.deliverable_versions OWNER TO postgres;

--
-- TOC entry 291 (class 1259 OID 18327)
-- Name: deliverables; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deliverables (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    conversation_id uuid,
    project_step_id uuid,
    agent_name text,
    title text NOT NULL,
    type character varying(100),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.deliverables OWNER TO postgres;

--
-- TOC entry 292 (class 1259 OID 18335)
-- Name: departments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.departments (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    company_id uuid,
    name character varying(255) NOT NULL,
    head_of_department character varying(255),
    budget numeric(15,2),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.departments OWNER TO postgres;

--
-- TOC entry 308 (class 1259 OID 18872)
-- Name: human_approvals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.human_approvals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_slug text,
    agent_slug text NOT NULL,
    conversation_id uuid,
    task_id text,
    mode text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    approved_by text,
    decision_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.human_approvals OWNER TO postgres;

--
-- TOC entry 293 (class 1259 OID 18343)
-- Name: kpi_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kpi_data (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    department_id uuid,
    metric_id uuid,
    value numeric(15,4) NOT NULL,
    date_recorded date NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.kpi_data OWNER TO postgres;

--
-- TOC entry 294 (class 1259 OID 18349)
-- Name: kpi_goals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kpi_goals (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    department_id uuid,
    metric_id uuid,
    target_value numeric(15,4),
    period_start date,
    period_end date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.kpi_goals OWNER TO postgres;

--
-- TOC entry 295 (class 1259 OID 18355)
-- Name: kpi_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kpi_metrics (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    metric_type character varying(100),
    unit character varying(50),
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.kpi_metrics OWNER TO postgres;

--
-- TOC entry 296 (class 1259 OID 18363)
-- Name: llm_models; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llm_models (
    model_name text NOT NULL,
    provider_name text NOT NULL,
    display_name text,
    model_type text DEFAULT 'text-generation'::text,
    model_version text,
    context_window integer DEFAULT 4096,
    max_output_tokens integer DEFAULT 2048,
    model_parameters_json jsonb DEFAULT '{}'::jsonb,
    pricing_info_json jsonb DEFAULT '{}'::jsonb,
    capabilities jsonb DEFAULT '[]'::jsonb,
    model_tier text,
    speed_tier text DEFAULT 'medium'::text,
    loading_priority integer DEFAULT 5,
    is_local boolean DEFAULT false,
    is_currently_loaded boolean DEFAULT false,
    is_active boolean DEFAULT true,
    training_data_cutoff date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.llm_models OWNER TO postgres;

--
-- TOC entry 297 (class 1259 OID 18381)
-- Name: llm_providers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llm_providers (
    name text NOT NULL,
    display_name text NOT NULL,
    api_base_url text,
    configuration_json jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.llm_providers OWNER TO postgres;

--
-- TOC entry 298 (class 1259 OID 18390)
-- Name: llm_usage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llm_usage (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    run_id text NOT NULL,
    user_id uuid,
    conversation_id uuid,
    provider_name text,
    model_name text,
    input_tokens integer,
    output_tokens integer,
    input_cost numeric,
    output_cost numeric,
    duration_ms integer,
    status text DEFAULT 'completed'::text,
    caller_type text,
    agent_name text,
    is_local boolean DEFAULT false,
    model_tier text,
    fallback_used boolean DEFAULT false,
    routing_reason text,
    complexity_level text,
    complexity_score integer,
    data_classification text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_message text,
    data_sanitization_applied boolean DEFAULT false,
    sanitization_level text DEFAULT 'none'::text,
    pii_detected boolean DEFAULT false,
    pii_types jsonb DEFAULT '[]'::jsonb,
    pseudonyms_used integer DEFAULT 0,
    pseudonym_types jsonb DEFAULT '[]'::jsonb,
    redactions_applied integer DEFAULT 0,
    redaction_types jsonb DEFAULT '[]'::jsonb,
    source_blinding_applied boolean DEFAULT false,
    headers_stripped boolean DEFAULT false,
    custom_user_agent_used boolean DEFAULT false,
    proxy_used boolean DEFAULT false,
    no_train_header_sent boolean DEFAULT false,
    no_retain_header_sent boolean DEFAULT false,
    sanitization_time_ms integer DEFAULT 0,
    reversal_context_size integer DEFAULT 0,
    policy_profile text,
    sovereign_mode boolean DEFAULT false,
    compliance_flags jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    route text,
    total_cost numeric,
    pseudonym_mappings jsonb DEFAULT '[]'::jsonb,
    CONSTRAINT llm_usage_route_check CHECK (((route IS NULL) OR (route = ANY (ARRAY['local'::text, 'remote'::text]))))
);


ALTER TABLE public.llm_usage OWNER TO postgres;

--
-- TOC entry 5304 (class 0 OID 0)
-- Dependencies: 298
-- Name: COLUMN llm_usage.total_cost; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.llm_usage.total_cost IS 'Total cost for this LLM request (input_cost + output_cost)';


--
-- TOC entry 5305 (class 0 OID 0)
-- Dependencies: 298
-- Name: COLUMN llm_usage.pseudonym_mappings; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.llm_usage.pseudonym_mappings IS 'Array of {original, pseudonym, dataType} objects for this run';


--
-- TOC entry 309 (class 1259 OID 18889)
-- Name: llm_usage_analytics; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.llm_usage_analytics AS
 SELECT (date_trunc('day'::text, llm_usage.started_at))::date AS date,
    COALESCE(llm_usage.caller_type, 'unknown'::text) AS caller_type,
    count(*) AS total_requests,
    sum(
        CASE
            WHEN (llm_usage.status = 'completed'::text) THEN 1
            ELSE 0
        END) AS successful_requests,
    COALESCE(sum(llm_usage.total_cost), sum((COALESCE(llm_usage.input_cost, (0)::numeric) + COALESCE(llm_usage.output_cost, (0)::numeric)))) AS total_cost,
    avg(COALESCE(llm_usage.duration_ms, 0)) AS avg_duration_ms,
    sum(
        CASE
            WHEN (llm_usage.is_local IS TRUE) THEN 1
            ELSE 0
        END) AS local_requests,
    sum(
        CASE
            WHEN (llm_usage.is_local IS NOT TRUE) THEN 1
            ELSE 0
        END) AS external_requests
   FROM public.llm_usage
  GROUP BY ((date_trunc('day'::text, llm_usage.started_at))::date), COALESCE(llm_usage.caller_type, 'unknown'::text)
  ORDER BY ((date_trunc('day'::text, llm_usage.started_at))::date) DESC, COALESCE(llm_usage.caller_type, 'unknown'::text);


ALTER TABLE public.llm_usage_analytics OWNER TO postgres;

--
-- TOC entry 307 (class 1259 OID 18836)
-- Name: orchestration_runs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orchestration_runs (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    plan_id uuid,
    origin_type text DEFAULT 'plan'::text,
    origin_id uuid,
    orchestration_slug text,
    prompt_inputs jsonb DEFAULT '{}'::jsonb,
    organization_slug text,
    status text DEFAULT 'pending'::text,
    current_step_index integer,
    completed_steps jsonb DEFAULT '[]'::jsonb,
    step_state jsonb DEFAULT '{}'::jsonb,
    human_checkpoint_id text,
    metadata jsonb DEFAULT '{}'::jsonb,
    started_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone
);


ALTER TABLE public.orchestration_runs OWNER TO postgres;

--
-- TOC entry 5308 (class 0 OID 0)
-- Dependencies: 307
-- Name: TABLE orchestration_runs; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.orchestration_runs IS 'Live orchestration execution state derived from conversation plans or saved orchestrations.';


--
-- TOC entry 5309 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN orchestration_runs.origin_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.orchestration_runs.origin_type IS 'Execution source (plan, saved_orchestration, ad_hoc).';


--
-- TOC entry 5310 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN orchestration_runs.orchestration_slug; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.orchestration_runs.orchestration_slug IS 'Slug of the saved orchestration recipe when origin_type = saved_orchestration.';


--
-- TOC entry 5311 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN orchestration_runs.prompt_inputs; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.orchestration_runs.prompt_inputs IS 'Resolved prompt parameter payload provided at orchestration launch.';


--
-- TOC entry 5312 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN orchestration_runs.step_state; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.orchestration_runs.step_state IS 'Per-step status metadata including conversations, deliverables, assignments.';


--
-- TOC entry 305 (class 1259 OID 18791)
-- Name: organization_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_credentials (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    organization_slug text NOT NULL,
    alias text NOT NULL,
    credential_type text NOT NULL,
    encrypted_value bytea NOT NULL,
    encryption_metadata jsonb DEFAULT '{}'::jsonb,
    rotated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.organization_credentials OWNER TO postgres;

--
-- TOC entry 5314 (class 0 OID 0)
-- Dependencies: 305
-- Name: TABLE organization_credentials; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.organization_credentials IS 'Encrypted secrets per organization (API keys, service credentials).';


--
-- TOC entry 312 (class 1259 OID 18942)
-- Name: plan_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plan_id uuid NOT NULL,
    version_number integer NOT NULL,
    content text NOT NULL,
    format text DEFAULT 'markdown'::text NOT NULL,
    created_by_type text NOT NULL,
    created_by_id uuid,
    task_id uuid,
    metadata jsonb DEFAULT '{}'::jsonb,
    is_current_version boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT plan_versions_created_by_type_check CHECK ((created_by_type = ANY (ARRAY['agent'::text, 'user'::text]))),
    CONSTRAINT plan_versions_format_check CHECK ((format = ANY (ARRAY['markdown'::text, 'json'::text, 'text'::text])))
);


ALTER TABLE public.plan_versions OWNER TO postgres;

--
-- TOC entry 5316 (class 0 OID 0)
-- Dependencies: 312
-- Name: TABLE plan_versions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.plan_versions IS 'Stores immutable versions of plans. Each edit/refinement creates a new version.';


--
-- TOC entry 5317 (class 0 OID 0)
-- Dependencies: 312
-- Name: COLUMN plan_versions.created_by_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.plan_versions.created_by_type IS 'Whether this version was created by an agent or manually edited by a user';


--
-- TOC entry 5318 (class 0 OID 0)
-- Dependencies: 312
-- Name: COLUMN plan_versions.task_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.plan_versions.task_id IS 'Reference to the agent task that created this version (if applicable)';


--
-- TOC entry 5319 (class 0 OID 0)
-- Dependencies: 312
-- Name: COLUMN plan_versions.metadata; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.plan_versions.metadata IS 'Additional metadata like LLM model used, merge source versions, etc.';


--
-- TOC entry 311 (class 1259 OID 18920)
-- Name: plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    conversation_id uuid NOT NULL,
    user_id uuid NOT NULL,
    agent_name text NOT NULL,
    namespace text NOT NULL,
    title text NOT NULL,
    current_version_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    plan_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    organization_slug text
);


ALTER TABLE public.plans OWNER TO postgres;

--
-- TOC entry 5321 (class 0 OID 0)
-- Dependencies: 311
-- Name: TABLE plans; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.plans IS 'Structured execution plans, replacing conversation_plans.';


--
-- TOC entry 5322 (class 0 OID 0)
-- Dependencies: 311
-- Name: COLUMN plans.current_version_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.plans.current_version_id IS 'Points to the currently active version of this plan';


--
-- TOC entry 5323 (class 0 OID 0)
-- Dependencies: 311
-- Name: COLUMN plans.plan_json; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.plans.plan_json IS 'Plan structure with phases, steps, dependencies, checkpoints.';


--
-- TOC entry 299 (class 1259 OID 18444)
-- Name: pseudonym_dictionaries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pseudonym_dictionaries (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    original_value text NOT NULL,
    pseudonym text NOT NULL,
    data_type character varying(100) NOT NULL,
    category character varying(100),
    frequency_weight integer DEFAULT 1,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    organization_slug text,
    agent_slug text,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.pseudonym_dictionaries OWNER TO postgres;

--
-- TOC entry 300 (class 1259 OID 18453)
-- Name: redaction_patterns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.redaction_patterns (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    pattern_regex text NOT NULL,
    replacement text NOT NULL,
    description text,
    category character varying(100) DEFAULT 'pii_builtin'::character varying,
    priority integer DEFAULT 50,
    is_active boolean DEFAULT true,
    severity character varying(50),
    data_type character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.redaction_patterns OWNER TO postgres;

--
-- TOC entry 301 (class 1259 OID 18464)
-- Name: system_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_settings (
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.system_settings OWNER TO postgres;

--
-- TOC entry 5327 (class 0 OID 0)
-- Dependencies: 301
-- Name: TABLE system_settings; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.system_settings IS 'System-wide settings (key/value JSON). Used for global model configuration and feature flags.';


--
-- TOC entry 302 (class 1259 OID 18470)
-- Name: user_cidafm_commands; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_cidafm_commands (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    command_id uuid NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_cidafm_commands OWNER TO postgres;

--
-- TOC entry 303 (class 1259 OID 18477)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    display_name character varying(255),
    role character varying(50),
    roles jsonb DEFAULT '["user"]'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    namespace_access jsonb DEFAULT '["my-org"]'::jsonb NOT NULL,
    status text DEFAULT 'active'::text,
    organization_slug text
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 5330 (class 0 OID 0)
-- Dependencies: 303
-- Name: COLUMN users.namespace_access; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.namespace_access IS 'List of agent namespaces the user may access (e.g., ["demo","my-org"]).';


--
-- TOC entry 265 (class 1259 OID 17592)
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
)
PARTITION BY RANGE (inserted_at);


ALTER TABLE realtime.messages OWNER TO supabase_realtime_admin;

--
-- TOC entry 266 (class 1259 OID 17609)
-- Name: messages_2025_10_08; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_10_08 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_10_08 OWNER TO supabase_admin;

--
-- TOC entry 267 (class 1259 OID 17621)
-- Name: messages_2025_10_09; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_10_09 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_10_09 OWNER TO supabase_admin;

--
-- TOC entry 268 (class 1259 OID 17633)
-- Name: messages_2025_10_10; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_10_10 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_10_10 OWNER TO supabase_admin;

--
-- TOC entry 269 (class 1259 OID 17645)
-- Name: messages_2025_10_11; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_10_11 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_10_11 OWNER TO supabase_admin;

--
-- TOC entry 270 (class 1259 OID 17657)
-- Name: messages_2025_10_12; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_10_12 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_10_12 OWNER TO supabase_admin;

--
-- TOC entry 259 (class 1259 OID 17430)
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


ALTER TABLE realtime.schema_migrations OWNER TO supabase_admin;

--
-- TOC entry 262 (class 1259 OID 17453)
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);


ALTER TABLE realtime.subscription OWNER TO supabase_admin;

--
-- TOC entry 261 (class 1259 OID 17452)
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 240 (class 1259 OID 16509)
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


ALTER TABLE storage.buckets OWNER TO supabase_storage_admin;

--
-- TOC entry 5341 (class 0 OID 0)
-- Dependencies: 240
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- TOC entry 318 (class 1259 OID 19116)
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets_analytics (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.buckets_analytics OWNER TO supabase_storage_admin;

--
-- TOC entry 319 (class 1259 OID 19127)
-- Name: iceberg_namespaces; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.iceberg_namespaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.iceberg_namespaces OWNER TO supabase_storage_admin;

--
-- TOC entry 320 (class 1259 OID 19143)
-- Name: iceberg_tables; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.iceberg_tables (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    namespace_id uuid NOT NULL,
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    location text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.iceberg_tables OWNER TO supabase_storage_admin;

--
-- TOC entry 242 (class 1259 OID 16551)
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE storage.migrations OWNER TO supabase_storage_admin;

--
-- TOC entry 241 (class 1259 OID 16524)
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb,
    level integer
);


ALTER TABLE storage.objects OWNER TO supabase_storage_admin;

--
-- TOC entry 5346 (class 0 OID 0)
-- Dependencies: 241
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- TOC entry 317 (class 1259 OID 19071)
-- Name: prefixes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.prefixes (
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    level integer GENERATED ALWAYS AS (storage.get_level(name)) STORED NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE storage.prefixes OWNER TO supabase_storage_admin;

--
-- TOC entry 271 (class 1259 OID 17773)
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb
);


ALTER TABLE storage.s3_multipart_uploads OWNER TO supabase_storage_admin;

--
-- TOC entry 272 (class 1259 OID 17787)
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.s3_multipart_uploads_parts OWNER TO supabase_storage_admin;

--
-- TOC entry 255 (class 1259 OID 16743)
-- Name: hooks; Type: TABLE; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE TABLE supabase_functions.hooks (
    id bigint NOT NULL,
    hook_table_id integer NOT NULL,
    hook_name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    request_id bigint
);


ALTER TABLE supabase_functions.hooks OWNER TO supabase_functions_admin;

--
-- TOC entry 5351 (class 0 OID 0)
-- Dependencies: 255
-- Name: TABLE hooks; Type: COMMENT; Schema: supabase_functions; Owner: supabase_functions_admin
--

COMMENT ON TABLE supabase_functions.hooks IS 'Supabase Functions Hooks: Audit trail for triggered hooks.';


--
-- TOC entry 254 (class 1259 OID 16742)
-- Name: hooks_id_seq; Type: SEQUENCE; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE SEQUENCE supabase_functions.hooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE supabase_functions.hooks_id_seq OWNER TO supabase_functions_admin;

--
-- TOC entry 5353 (class 0 OID 0)
-- Dependencies: 254
-- Name: hooks_id_seq; Type: SEQUENCE OWNED BY; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER SEQUENCE supabase_functions.hooks_id_seq OWNED BY supabase_functions.hooks.id;


--
-- TOC entry 253 (class 1259 OID 16734)
-- Name: migrations; Type: TABLE; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE TABLE supabase_functions.migrations (
    version text NOT NULL,
    inserted_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE supabase_functions.migrations OWNER TO supabase_functions_admin;

--
-- TOC entry 285 (class 1259 OID 18146)
-- Name: schema_migrations; Type: TABLE; Schema: supabase_migrations; Owner: postgres
--

CREATE TABLE supabase_migrations.schema_migrations (
    version text NOT NULL,
    statements text[],
    name text
);


ALTER TABLE supabase_migrations.schema_migrations OWNER TO postgres;

--
-- TOC entry 316 (class 1259 OID 19057)
-- Name: seed_files; Type: TABLE; Schema: supabase_migrations; Owner: postgres
--

CREATE TABLE supabase_migrations.seed_files (
    path text NOT NULL,
    hash text NOT NULL
);


ALTER TABLE supabase_migrations.seed_files OWNER TO postgres;

--
-- TOC entry 3930 (class 0 OID 0)
-- Name: messages_2025_10_08; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_08 FOR VALUES FROM ('2025-10-08 00:00:00') TO ('2025-10-09 00:00:00');


--
-- TOC entry 3931 (class 0 OID 0)
-- Name: messages_2025_10_09; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_09 FOR VALUES FROM ('2025-10-09 00:00:00') TO ('2025-10-10 00:00:00');


--
-- TOC entry 3932 (class 0 OID 0)
-- Name: messages_2025_10_10; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_10 FOR VALUES FROM ('2025-10-10 00:00:00') TO ('2025-10-11 00:00:00');


--
-- TOC entry 3933 (class 0 OID 0)
-- Name: messages_2025_10_11; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_11 FOR VALUES FROM ('2025-10-11 00:00:00') TO ('2025-10-12 00:00:00');


--
-- TOC entry 3934 (class 0 OID 0)
-- Name: messages_2025_10_12; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_12 FOR VALUES FROM ('2025-10-12 00:00:00') TO ('2025-10-13 00:00:00');


--
-- TOC entry 3944 (class 2604 OID 16473)
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- TOC entry 4213 (class 2604 OID 19619)
-- Name: auth_provider_sync_history id; Type: DEFAULT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.auth_provider_sync_history ALTER COLUMN id SET DEFAULT nextval('n8n.auth_provider_sync_history_id_seq'::regclass);


--
-- TOC entry 4228 (class 2604 OID 20063)
-- Name: execution_annotations id; Type: DEFAULT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_annotations ALTER COLUMN id SET DEFAULT nextval('n8n.execution_annotations_id_seq'::regclass);


--
-- TOC entry 4188 (class 2604 OID 19332)
-- Name: execution_entity id; Type: DEFAULT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_entity ALTER COLUMN id SET DEFAULT nextval('n8n.execution_entity_id_seq'::regclass);


--
-- TOC entry 4227 (class 2604 OID 20038)
-- Name: execution_metadata id; Type: DEFAULT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_metadata ALTER COLUMN id SET DEFAULT nextval('n8n.execution_metadata_temp_id_seq'::regclass);


--
-- TOC entry 4184 (class 2604 OID 19313)
-- Name: migrations id; Type: DEFAULT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.migrations ALTER COLUMN id SET DEFAULT nextval('n8n.migrations_id_seq'::regclass);


--
-- TOC entry 3963 (class 2604 OID 16746)
-- Name: hooks id; Type: DEFAULT; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER TABLE ONLY supabase_functions.hooks ALTER COLUMN id SET DEFAULT nextval('supabase_functions.hooks_id_seq'::regclass);


--
-- TOC entry 4972 (class 0 OID 17379)
-- Dependencies: 258
-- Data for Name: extensions; Type: TABLE DATA; Schema: _realtime; Owner: supabase_admin
--

COPY _realtime.extensions (id, type, settings, tenant_external_id, inserted_at, updated_at) FROM stdin;
581a1937-af2d-4d45-9524-3626d30e3a01	postgres_cdc_rls	{"region": "us-east-1", "db_host": "tAy3GUAuUlGE0yG6KUUpk0/ZVyoeWKveyb9k1Nv4OwY=", "db_name": "sWBpZNdjggEPTQVlI52Zfw==", "db_port": "+enMDFi1J/3IrrquHHwUmA==", "db_user": "uxbEq/zz8DXVD53TOI1zmw==", "slot_name": "supabase_realtime_replication_slot", "db_password": "sWBpZNdjggEPTQVlI52Zfw==", "publication": "supabase_realtime", "ssl_enforced": false, "poll_interval_ms": 100, "poll_max_changes": 100, "poll_max_record_bytes": 1048576}	realtime-dev	2025-10-09 19:18:13	2025-10-09 19:18:13
\.


--
-- TOC entry 4970 (class 0 OID 17365)
-- Dependencies: 256
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: _realtime; Owner: supabase_admin
--

COPY _realtime.schema_migrations (version, inserted_at) FROM stdin;
20210706140551	2025-10-09 19:18:04
20220329161857	2025-10-09 19:18:04
20220410212326	2025-10-09 19:18:04
20220506102948	2025-10-09 19:18:04
20220527210857	2025-10-09 19:18:04
20220815211129	2025-10-09 19:18:04
20220815215024	2025-10-09 19:18:04
20220818141501	2025-10-09 19:18:04
20221018173709	2025-10-09 19:18:04
20221102172703	2025-10-09 19:18:04
20221223010058	2025-10-09 19:18:04
20230110180046	2025-10-09 19:18:04
20230810220907	2025-10-09 19:18:04
20230810220924	2025-10-09 19:18:04
20231024094642	2025-10-09 19:18:04
20240306114423	2025-10-09 19:18:04
20240418082835	2025-10-09 19:18:04
20240625211759	2025-10-09 19:18:04
20240704172020	2025-10-09 19:18:04
20240902173232	2025-10-09 19:18:04
20241106103258	2025-10-09 19:18:04
20250424203323	2025-10-09 19:18:04
20250613072131	2025-10-09 19:18:04
20250711044927	2025-10-09 19:18:05
20250811121559	2025-10-09 19:18:05
\.


--
-- TOC entry 4971 (class 0 OID 17370)
-- Dependencies: 257
-- Data for Name: tenants; Type: TABLE DATA; Schema: _realtime; Owner: supabase_admin
--

COPY _realtime.tenants (id, name, external_id, jwt_secret, max_concurrent_users, inserted_at, updated_at, max_events_per_second, postgres_cdc_default, max_bytes_per_second, max_channels_per_client, max_joins_per_second, suspend, jwt_jwks, notify_private_alpha, private_only, migrations_ran, broadcast_adapter, max_presence_events_per_second, max_payload_size_in_kb) FROM stdin;
d7051fd1-16ac-48f1-a120-fe5b1adb74bc	realtime-dev	realtime-dev	iNjicxc4+llvc9wovDvqymwfnj9teWMlyOIbJ8Fh6j2WNU8CIJ2ZgjR6MUIKqSmeDmvpsKLsZ9jgXJmQPpwL8w==	200	2025-10-09 19:18:13	2025-10-09 19:18:13	100	postgres_cdc_rls	100000	100	100	f	{"keys": [{"k": "c3VwZXItc2VjcmV0LWp3dC10b2tlbi13aXRoLWF0LWxlYXN0LTMyLWNoYXJhY3RlcnMtbG9uZw", "kty": "oct"}]}	f	f	63	gen_rpc	10000	3000
\.


--
-- TOC entry 4962 (class 0 OID 16488)
-- Dependencies: 238
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
00000000-0000-0000-0000-000000000000	bc26bebf-ce37-45ea-a2f2-f9690514126a	{"action":"login","actor_id":"a1b2c3d4-e5f6-7890-abcd-ef1234567890","actor_username":"admin@orchestratorai.io","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-09 19:36:14.189185+00	
00000000-0000-0000-0000-000000000000	5f93ebd9-ddb6-4980-87ef-7e8b0dcd253b	{"action":"token_refreshed","actor_id":"a1b2c3d4-e5f6-7890-abcd-ef1234567890","actor_username":"admin@orchestratorai.io","actor_via_sso":false,"log_type":"token"}	2025-10-09 20:31:33.761898+00	
00000000-0000-0000-0000-000000000000	73364d6c-4e31-4d25-bf0a-c76aed3a18c5	{"action":"token_revoked","actor_id":"a1b2c3d4-e5f6-7890-abcd-ef1234567890","actor_username":"admin@orchestratorai.io","actor_via_sso":false,"log_type":"token"}	2025-10-09 20:31:33.762581+00	
00000000-0000-0000-0000-000000000000	bbf6c892-db43-4df4-b44f-bd0e4a6ad095	{"action":"token_refreshed","actor_id":"a1b2c3d4-e5f6-7890-abcd-ef1234567890","actor_username":"admin@orchestratorai.io","actor_via_sso":false,"log_type":"token"}	2025-10-09 21:26:34.454822+00	
00000000-0000-0000-0000-000000000000	ae621542-ae14-452d-8d2d-893f8d20b907	{"action":"token_revoked","actor_id":"a1b2c3d4-e5f6-7890-abcd-ef1234567890","actor_username":"admin@orchestratorai.io","actor_via_sso":false,"log_type":"token"}	2025-10-09 21:26:34.456301+00	
\.


--
-- TOC entry 4992 (class 0 OID 18047)
-- Dependencies: 282
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at) FROM stdin;
\.


--
-- TOC entry 4983 (class 0 OID 17844)
-- Dependencies: 273
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
b29a590e-b07f-49df-a25b-574c956b5035	b29a590e-b07f-49df-a25b-574c956b5035	{"sub": "b29a590e-b07f-49df-a25b-574c956b5035", "email": "demo.user@playground.com", "email_verified": true, "phone_verified": false}	email	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00	2f1ee5e9-cae2-4f66-a1e0-bd2c02a11321
a1b2c3d4-e5f6-7890-abcd-ef1234567890	a1b2c3d4-e5f6-7890-abcd-ef1234567890	{"sub": "a1b2c3d4-e5f6-7890-abcd-ef1234567890", "email": "admin@orchestratorai.io", "email_verified": true, "phone_verified": false}	email	2025-10-09 19:28:38.366283+00	2025-10-09 19:28:38.366283+00	2025-10-09 19:28:38.366283+00	3f2ee5e9-cae2-4f66-a1e0-bd2c02a11322
c4d5e6f7-8901-2345-6789-abcdef012345	c4d5e6f7-8901-2345-6789-abcdef012345	{"sub": "c4d5e6f7-8901-2345-6789-abcdef012345", "email": "golfergeek@orchestratorai.io", "email_verified": true, "phone_verified": false}	email	2025-10-09 19:28:38.366283+00	2025-10-09 19:28:38.366283+00	2025-10-09 19:28:38.366283+00	4f3ee5e9-cae2-4f66-a1e0-bd2c02a11323
\.


--
-- TOC entry 4961 (class 0 OID 16481)
-- Dependencies: 237
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4987 (class 0 OID 17934)
-- Dependencies: 277
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
03cb42e0-4009-4a54-98e0-02d2a61bbcfa	2025-10-09 19:36:14.192191+00	2025-10-09 19:36:14.192191+00	password	f0b57f50-cf93-4181-a9da-f6aa9293a843
\.


--
-- TOC entry 4986 (class 0 OID 17922)
-- Dependencies: 276
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- TOC entry 4985 (class 0 OID 17909)
-- Dependencies: 275
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid) FROM stdin;
\.


--
-- TOC entry 4994 (class 0 OID 18129)
-- Dependencies: 284
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_clients (id, client_id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- TOC entry 4993 (class 0 OID 18097)
-- Dependencies: 283
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4960 (class 0 OID 16470)
-- Dependencies: 236
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
00000000-0000-0000-0000-000000000000	1	mai3ra5jhcek	a1b2c3d4-e5f6-7890-abcd-ef1234567890	t	2025-10-09 19:36:14.190917+00	2025-10-09 20:31:33.763206+00	\N	03cb42e0-4009-4a54-98e0-02d2a61bbcfa
00000000-0000-0000-0000-000000000000	2	uohsqcsins2v	a1b2c3d4-e5f6-7890-abcd-ef1234567890	t	2025-10-09 20:31:33.763741+00	2025-10-09 21:26:34.457035+00	mai3ra5jhcek	03cb42e0-4009-4a54-98e0-02d2a61bbcfa
00000000-0000-0000-0000-000000000000	3	zhjj2stbjt2e	a1b2c3d4-e5f6-7890-abcd-ef1234567890	f	2025-10-09 21:26:34.457622+00	2025-10-09 21:26:34.457622+00	uohsqcsins2v	03cb42e0-4009-4a54-98e0-02d2a61bbcfa
\.


--
-- TOC entry 4990 (class 0 OID 17976)
-- Dependencies: 280
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- TOC entry 4991 (class 0 OID 17994)
-- Dependencies: 281
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- TOC entry 4963 (class 0 OID 16496)
-- Dependencies: 239
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
\.


--
-- TOC entry 4984 (class 0 OID 17874)
-- Dependencies: 274
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag) FROM stdin;
03cb42e0-4009-4a54-98e0-02d2a61bbcfa	a1b2c3d4-e5f6-7890-abcd-ef1234567890	2025-10-09 19:36:14.190097+00	2025-10-09 21:26:34.459759+00	\N	aal1	\N	2025-10-09 21:26:34.459705	node	192.168.65.1	\N
\.


--
-- TOC entry 4989 (class 0 OID 17961)
-- Dependencies: 279
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4988 (class 0 OID 17952)
-- Dependencies: 278
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- TOC entry 4958 (class 0 OID 16458)
-- Dependencies: 234
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
00000000-0000-0000-0000-000000000000	b29a590e-b07f-49df-a25b-574c956b5035	authenticated	authenticated	demo.user@playground.com	$2a$06$KWFal7djFAv2drTJR1a3COiCpnRuC1fG/delGybibrECm.gETu8Cy	2025-10-09 19:18:09.981049+00	\N		\N		\N			\N	\N	\N	\N	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	c4d5e6f7-8901-2345-6789-abcdef012345	authenticated	authenticated	golfergeek@orchestratorai.io	$2a$06$NB.M8iX6siiAjTcCGdqevOqO6Xj1eicVIZ/I1cgwlGWDMUqTMxMNm	2025-10-09 19:28:38.352108+00	\N		\N		\N			\N	\N	\N	\N	\N	2025-10-09 19:28:38.352108+00	2025-10-09 19:28:38.352108+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a1b2c3d4-e5f6-7890-abcd-ef1234567890	authenticated	authenticated	admin@orchestratorai.io	$2a$06$M40tadYZqPNpdspfzoJef.VXKwZn2919vkslDzYGS3k8RqZSNmLoC	2025-10-09 19:28:38.352108+00	\N		\N		\N			\N	2025-10-09 19:36:14.190052+00	\N	\N	\N	2025-10-09 19:28:38.352108+00	2025-10-09 21:26:34.458839+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- TOC entry 5059 (class 0 OID 20076)
-- Dependencies: 351
-- Data for Name: annotation_tag_entity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.annotation_tag_entity (id, name, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 5044 (class 0 OID 19603)
-- Dependencies: 336
-- Data for Name: auth_identity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.auth_identity ("userId", "providerId", "providerType", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 5046 (class 0 OID 19616)
-- Dependencies: 338
-- Data for Name: auth_provider_sync_history; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.auth_provider_sync_history (id, "providerType", "runMode", status, "startedAt", "endedAt", scanned, created, updated, disabled, error) FROM stdin;
\.


--
-- TOC entry 5031 (class 0 OID 19319)
-- Dependencies: 323
-- Data for Name: credentials_entity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.credentials_entity (name, data, type, "createdAt", "updatedAt", id, "isManaged") FROM stdin;
\.


--
-- TOC entry 5076 (class 0 OID 20462)
-- Dependencies: 368
-- Data for Name: data_table; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.data_table (id, name, "projectId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 5077 (class 0 OID 20476)
-- Dependencies: 369
-- Data for Name: data_table_column; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.data_table_column (id, name, type, index, "dataTableId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 5043 (class 0 OID 19572)
-- Dependencies: 335
-- Data for Name: event_destinations; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.event_destinations (id, destination, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 5060 (class 0 OID 20084)
-- Dependencies: 352
-- Data for Name: execution_annotation_tags; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.execution_annotation_tags ("annotationId", "tagId") FROM stdin;
\.


--
-- TOC entry 5058 (class 0 OID 20060)
-- Dependencies: 350
-- Data for Name: execution_annotations; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.execution_annotations (id, "executionId", vote, note, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 5048 (class 0 OID 19711)
-- Dependencies: 340
-- Data for Name: execution_data; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.execution_data ("executionId", "workflowData", data) FROM stdin;
\.


--
-- TOC entry 5033 (class 0 OID 19329)
-- Dependencies: 325
-- Data for Name: execution_entity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.execution_entity (id, finished, mode, "retryOf", "retrySuccessId", "startedAt", "stoppedAt", "waitTill", status, "workflowId", "deletedAt", "createdAt") FROM stdin;
\.


--
-- TOC entry 5055 (class 0 OID 20035)
-- Dependencies: 347
-- Data for Name: execution_metadata; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.execution_metadata (id, "executionId", key, value) FROM stdin;
\.


--
-- TOC entry 5063 (class 0 OID 20228)
-- Dependencies: 355
-- Data for Name: folder; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.folder (id, name, "parentFolderId", "projectId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 5064 (class 0 OID 20246)
-- Dependencies: 356
-- Data for Name: folder_tag; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.folder_tag ("folderId", "tagId") FROM stdin;
\.


--
-- TOC entry 5070 (class 0 OID 20342)
-- Dependencies: 362
-- Data for Name: insights_by_period; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.insights_by_period (id, "metaId", type, value, "periodUnit", "periodStart") FROM stdin;
\.


--
-- TOC entry 5066 (class 0 OID 20313)
-- Dependencies: 358
-- Data for Name: insights_metadata; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.insights_metadata ("metaId", "workflowId", "projectId", "workflowName", "projectName") FROM stdin;
\.


--
-- TOC entry 5068 (class 0 OID 20330)
-- Dependencies: 360
-- Data for Name: insights_raw; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.insights_raw (id, "metaId", type, value, "timestamp") FROM stdin;
\.


--
-- TOC entry 5041 (class 0 OID 19521)
-- Dependencies: 333
-- Data for Name: installed_nodes; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.installed_nodes (name, type, "latestVersion", package) FROM stdin;
\.


--
-- TOC entry 5040 (class 0 OID 19514)
-- Dependencies: 332
-- Data for Name: installed_packages; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.installed_packages ("packageName", "installedVersion", "authorName", "authorEmail", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 5056 (class 0 OID 20049)
-- Dependencies: 348
-- Data for Name: invalid_auth_token; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.invalid_auth_token (token, "expiresAt") FROM stdin;
\.


--
-- TOC entry 5023 (class 0 OID 19009)
-- Dependencies: 315
-- Data for Name: migration_metadata; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.migration_metadata (migration_file, source, workflow_id, created_at, synced_at, notes) FROM stdin;
20251007190433_add_n8n_marketing_swarm_major_announcement.sql	dev	ee248b9d-f72d-40a0-8c26-6dbfaef5368a	2025-10-09 19:18:09.93636+00	2025-10-09 19:18:09.93636+00	Exported from n8n API
\.


--
-- TOC entry 5030 (class 0 OID 19310)
-- Dependencies: 322
-- Data for Name: migrations; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.migrations (id, "timestamp", name) FROM stdin;
1	1587669153312	InitialMigration1587669153312
2	1589476000887	WebhookModel1589476000887
3	1594828256133	CreateIndexStoppedAt1594828256133
4	1607431743768	MakeStoppedAtNullable1607431743768
5	1611144599516	AddWebhookId1611144599516
6	1617270242566	CreateTagEntity1617270242566
7	1620824779533	UniqueWorkflowNames1620824779533
8	1626176912946	AddwaitTill1626176912946
9	1630419189837	UpdateWorkflowCredentials1630419189837
10	1644422880309	AddExecutionEntityIndexes1644422880309
11	1646834195327	IncreaseTypeVarcharLimit1646834195327
12	1646992772331	CreateUserManagement1646992772331
13	1648740597343	LowerCaseUserEmail1648740597343
14	1652254514002	CommunityNodes1652254514002
15	1652367743993	AddUserSettings1652367743993
16	1652905585850	AddAPIKeyColumn1652905585850
17	1654090467022	IntroducePinData1654090467022
18	1658932090381	AddNodeIds1658932090381
19	1659902242948	AddJsonKeyPinData1659902242948
20	1660062385367	CreateCredentialsUserRole1660062385367
21	1663755770893	CreateWorkflowsEditorRole1663755770893
22	1664196174001	WorkflowStatistics1664196174001
23	1665484192212	CreateCredentialUsageTable1665484192212
24	1665754637025	RemoveCredentialUsageTable1665754637025
25	1669739707126	AddWorkflowVersionIdColumn1669739707126
26	1669823906995	AddTriggerCountColumn1669823906995
27	1671535397530	MessageEventBusDestinations1671535397530
28	1671726148421	RemoveWorkflowDataLoadedFlag1671726148421
29	1673268682475	DeleteExecutionsWithWorkflows1673268682475
30	1674138566000	AddStatusToExecutions1674138566000
31	1674509946020	CreateLdapEntities1674509946020
32	1675940580449	PurgeInvalidWorkflowConnections1675940580449
33	1676996103000	MigrateExecutionStatus1676996103000
34	1677236854063	UpdateRunningExecutionStatus1677236854063
35	1677501636754	CreateVariables1677501636754
36	1679416281778	CreateExecutionMetadataTable1679416281778
37	1681134145996	AddUserActivatedProperty1681134145996
38	1681134145997	RemoveSkipOwnerSetup1681134145997
39	1690000000000	MigrateIntegerKeysToString1690000000000
40	1690000000020	SeparateExecutionData1690000000020
41	1690000000030	RemoveResetPasswordColumns1690000000030
42	1690000000030	AddMfaColumns1690000000030
43	1690787606731	AddMissingPrimaryKeyOnExecutionData1690787606731
44	1691088862123	CreateWorkflowNameIndex1691088862123
45	1692967111175	CreateWorkflowHistoryTable1692967111175
46	1693491613982	ExecutionSoftDelete1693491613982
47	1693554410387	DisallowOrphanExecutions1693554410387
48	1694091729095	MigrateToTimestampTz1694091729095
49	1695128658538	AddWorkflowMetadata1695128658538
50	1695829275184	ModifyWorkflowHistoryNodesAndConnections1695829275184
51	1700571993961	AddGlobalAdminRole1700571993961
52	1705429061930	DropRoleMapping1705429061930
53	1711018413374	RemoveFailedExecutionStatus1711018413374
54	1711390882123	MoveSshKeysToDatabase1711390882123
55	1712044305787	RemoveNodesAccess1712044305787
56	1714133768519	CreateProject1714133768519
57	1714133768521	MakeExecutionStatusNonNullable1714133768521
58	1717498465931	AddActivatedAtUserSetting1717498465931
59	1720101653148	AddConstraintToExecutionMetadata1720101653148
60	1721377157740	FixExecutionMetadataSequence1721377157740
61	1723627610222	CreateInvalidAuthTokenTable1723627610222
62	1723796243146	RefactorExecutionIndices1723796243146
63	1724753530828	CreateAnnotationTables1724753530828
64	1724951148974	AddApiKeysTable1724951148974
65	1726606152711	CreateProcessedDataTable1726606152711
66	1727427440136	SeparateExecutionCreationFromStart1727427440136
67	1728659839644	AddMissingPrimaryKeyOnAnnotationTagMapping1728659839644
68	1729607673464	UpdateProcessedDataValueColumnToText1729607673464
69	1729607673469	AddProjectIcons1729607673469
70	1730386903556	CreateTestDefinitionTable1730386903556
71	1731404028106	AddDescriptionToTestDefinition1731404028106
72	1731582748663	MigrateTestDefinitionKeyToString1731582748663
73	1732271325258	CreateTestMetricTable1732271325258
74	1732549866705	CreateTestRun1732549866705
75	1733133775640	AddMockedNodesColumnToTestDefinition1733133775640
76	1734479635324	AddManagedColumnToCredentialsTable1734479635324
77	1736172058779	AddStatsColumnsToTestRun1736172058779
78	1736947513045	CreateTestCaseExecutionTable1736947513045
79	1737715421462	AddErrorColumnsToTestRuns1737715421462
80	1738709609940	CreateFolderTable1738709609940
81	1739549398681	CreateAnalyticsTables1739549398681
82	1740445074052	UpdateParentFolderIdColumn1740445074052
83	1741167584277	RenameAnalyticsToInsights1741167584277
84	1742918400000	AddScopesColumnToApiKeys1742918400000
85	1745322634000	ClearEvaluation1745322634000
86	1745587087521	AddWorkflowStatisticsRootCount1745587087521
87	1745934666076	AddWorkflowArchivedColumn1745934666076
88	1745934666077	DropRoleTable1745934666077
89	1747824239000	AddProjectDescriptionColumn1747824239000
90	1750252139166	AddLastActiveAtColumnToUser1750252139166
91	1750252139166	AddScopeTables1750252139166
92	1750252139167	AddRolesTables1750252139167
93	1750252139168	LinkRoleToUserTable1750252139168
94	1750252139170	RemoveOldRoleColumn1750252139170
95	1752669793000	AddInputsOutputsToTestCaseExecution1752669793000
96	1753953244168	LinkRoleToProjectRelationTable1753953244168
97	1754475614601	CreateDataStoreTables1754475614601
98	1754475614602	ReplaceDataStoreTablesWithDataTables1754475614602
99	1756906557570	AddTimestampsToRoleAndRoleIndexes1756906557570
\.


--
-- TOC entry 5022 (class 0 OID 18993)
-- Dependencies: 314
-- Data for Name: n8n_workflows; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.n8n_workflows (id, name, active, nodes, connections, settings, created_at, updated_at) FROM stdin;
ee248b9d-f72d-40a0-8c26-6dbfaef5368a	Marketing Swarm - Major Announcement	t	[{"id": "webhook", "name": "Webhook Trigger", "type": "n8n-nodes-base.webhook", "position": [112, 112], "webhookId": "7f338c6b-a9bb-446b-9a1d-702739d89a51", "parameters": {"path": "marketing-swarm", "options": {}, "httpMethod": "POST", "responseMode": "responseNode"}, "typeVersion": 2}]	{}	{}	2025-10-09 19:18:09.93636+00	2025-10-09 19:18:09.93636+00
\.


--
-- TOC entry 5062 (class 0 OID 20117)
-- Dependencies: 354
-- Data for Name: processed_data; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.processed_data ("workflowId", context, "createdAt", "updatedAt", value) FROM stdin;
\.


--
-- TOC entry 5050 (class 0 OID 19954)
-- Dependencies: 342
-- Data for Name: project; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.project (id, name, type, "createdAt", "updatedAt", icon, description) FROM stdin;
i9Hx3voRXPvZMWtL	Golfer Geek <golfergeek@orchestratorai.io>	personal	2025-10-09 20:29:48.678+00	2025-10-09 20:45:39.243+00	\N	\N
\.


--
-- TOC entry 5051 (class 0 OID 19961)
-- Dependencies: 343
-- Data for Name: project_relation; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.project_relation ("projectId", "userId", role, "createdAt", "updatedAt") FROM stdin;
i9Hx3voRXPvZMWtL	9f12b0ff-372b-4d46-b8ea-30c14a4a14a2	project:personalOwner	2025-10-09 20:29:48.678+00	2025-10-09 20:29:48.678+00
\.


--
-- TOC entry 5074 (class 0 OID 20398)
-- Dependencies: 366
-- Data for Name: role; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.role (slug, "displayName", description, "roleType", "systemRole", "createdAt", "updatedAt") FROM stdin;
global:owner	Owner	Owner	global	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.285+00
global:admin	Admin	Admin	global	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.285+00
global:member	Member	Member	global	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.285+00
project:admin	Project Admin	Project Admin	project	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.301+00
project:personalOwner	Project Owner	Project Owner	project	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.301+00
project:editor	Project Editor	Project Editor	project	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.301+00
project:viewer	Project Viewer	Project Viewer	project	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.301+00
credential:owner	Credential Owner	Credential Owner	credential	t	2025-10-09 20:29:49.31+00	2025-10-09 20:29:49.31+00
credential:user	Credential User	Credential User	credential	t	2025-10-09 20:29:49.31+00	2025-10-09 20:29:49.31+00
workflow:owner	Workflow Owner	Workflow Owner	workflow	t	2025-10-09 20:29:49.315+00	2025-10-09 20:29:49.315+00
workflow:editor	Workflow Editor	Workflow Editor	workflow	t	2025-10-09 20:29:49.315+00	2025-10-09 20:29:49.315+00
\.


--
-- TOC entry 5075 (class 0 OID 20406)
-- Dependencies: 367
-- Data for Name: role_scope; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.role_scope ("roleSlug", "scopeSlug") FROM stdin;
global:owner	annotationTag:create
global:owner	annotationTag:read
global:owner	annotationTag:update
global:owner	annotationTag:delete
global:owner	annotationTag:list
global:owner	auditLogs:manage
global:owner	banner:dismiss
global:owner	community:register
global:owner	communityPackage:install
global:owner	communityPackage:uninstall
global:owner	communityPackage:update
global:owner	communityPackage:list
global:owner	credential:share
global:owner	credential:move
global:owner	credential:create
global:owner	credential:read
global:owner	credential:update
global:owner	credential:delete
global:owner	credential:list
global:owner	externalSecretsProvider:sync
global:owner	externalSecretsProvider:create
global:owner	externalSecretsProvider:read
global:owner	externalSecretsProvider:update
global:owner	externalSecretsProvider:delete
global:owner	externalSecretsProvider:list
global:owner	externalSecret:list
global:owner	externalSecret:use
global:owner	eventBusDestination:test
global:owner	eventBusDestination:create
global:owner	eventBusDestination:read
global:owner	eventBusDestination:update
global:owner	eventBusDestination:delete
global:owner	eventBusDestination:list
global:owner	ldap:sync
global:owner	ldap:manage
global:owner	license:manage
global:owner	logStreaming:manage
global:owner	orchestration:read
global:owner	project:create
global:owner	project:read
global:owner	project:update
global:owner	project:delete
global:owner	project:list
global:owner	saml:manage
global:owner	securityAudit:generate
global:owner	sourceControl:pull
global:owner	sourceControl:push
global:owner	sourceControl:manage
global:owner	tag:create
global:owner	tag:read
global:owner	tag:update
global:owner	tag:delete
global:owner	tag:list
global:owner	user:resetPassword
global:owner	user:changeRole
global:owner	user:enforceMfa
global:owner	user:create
global:owner	user:read
global:owner	user:update
global:owner	user:delete
global:owner	user:list
global:owner	variable:create
global:owner	variable:read
global:owner	variable:update
global:owner	variable:delete
global:owner	variable:list
global:owner	workersView:manage
global:owner	workflow:share
global:owner	workflow:execute
global:owner	workflow:move
global:owner	workflow:create
global:owner	workflow:read
global:owner	workflow:update
global:owner	workflow:delete
global:owner	workflow:list
global:owner	folder:create
global:owner	folder:read
global:owner	folder:update
global:owner	folder:delete
global:owner	folder:list
global:owner	folder:move
global:owner	insights:list
global:owner	oidc:manage
global:owner	dataStore:list
global:owner	role:manage
global:admin	annotationTag:create
global:admin	annotationTag:read
global:admin	annotationTag:update
global:admin	annotationTag:delete
global:admin	annotationTag:list
global:admin	auditLogs:manage
global:admin	banner:dismiss
global:admin	community:register
global:admin	communityPackage:install
global:admin	communityPackage:uninstall
global:admin	communityPackage:update
global:admin	communityPackage:list
global:admin	credential:share
global:admin	credential:move
global:admin	credential:create
global:admin	credential:read
global:admin	credential:update
global:admin	credential:delete
global:admin	credential:list
global:admin	externalSecretsProvider:sync
global:admin	externalSecretsProvider:create
global:admin	externalSecretsProvider:read
global:admin	externalSecretsProvider:update
global:admin	externalSecretsProvider:delete
global:admin	externalSecretsProvider:list
global:admin	externalSecret:list
global:admin	externalSecret:use
global:admin	eventBusDestination:test
global:admin	eventBusDestination:create
global:admin	eventBusDestination:read
global:admin	eventBusDestination:update
global:admin	eventBusDestination:delete
global:admin	eventBusDestination:list
global:admin	ldap:sync
global:admin	ldap:manage
global:admin	license:manage
global:admin	logStreaming:manage
global:admin	orchestration:read
global:admin	project:create
global:admin	project:read
global:admin	project:update
global:admin	project:delete
global:admin	project:list
global:admin	saml:manage
global:admin	securityAudit:generate
global:admin	sourceControl:pull
global:admin	sourceControl:push
global:admin	sourceControl:manage
global:admin	tag:create
global:admin	tag:read
global:admin	tag:update
global:admin	tag:delete
global:admin	tag:list
global:admin	user:resetPassword
global:admin	user:changeRole
global:admin	user:enforceMfa
global:admin	user:create
global:admin	user:read
global:admin	user:update
global:admin	user:delete
global:admin	user:list
global:admin	variable:create
global:admin	variable:read
global:admin	variable:update
global:admin	variable:delete
global:admin	variable:list
global:admin	workersView:manage
global:admin	workflow:share
global:admin	workflow:execute
global:admin	workflow:move
global:admin	workflow:create
global:admin	workflow:read
global:admin	workflow:update
global:admin	workflow:delete
global:admin	workflow:list
global:admin	folder:create
global:admin	folder:read
global:admin	folder:update
global:admin	folder:delete
global:admin	folder:list
global:admin	folder:move
global:admin	insights:list
global:admin	oidc:manage
global:admin	dataStore:list
global:admin	role:manage
global:member	annotationTag:create
global:member	annotationTag:read
global:member	annotationTag:update
global:member	annotationTag:delete
global:member	annotationTag:list
global:member	eventBusDestination:test
global:member	eventBusDestination:list
global:member	tag:create
global:member	tag:read
global:member	tag:update
global:member	tag:list
global:member	user:list
global:member	variable:read
global:member	variable:list
global:member	dataStore:list
project:admin	credential:share
project:admin	credential:move
project:admin	credential:create
project:admin	credential:read
project:admin	credential:update
project:admin	credential:delete
project:admin	credential:list
project:admin	project:read
project:admin	project:update
project:admin	project:delete
project:admin	project:list
project:admin	sourceControl:push
project:admin	workflow:execute
project:admin	workflow:move
project:admin	workflow:create
project:admin	workflow:read
project:admin	workflow:update
project:admin	workflow:delete
project:admin	workflow:list
project:admin	folder:create
project:admin	folder:read
project:admin	folder:update
project:admin	folder:delete
project:admin	folder:list
project:admin	folder:move
project:admin	dataStore:create
project:admin	dataStore:read
project:admin	dataStore:update
project:admin	dataStore:delete
project:admin	dataStore:readRow
project:admin	dataStore:writeRow
project:admin	dataStore:listProject
project:personalOwner	credential:share
project:personalOwner	credential:move
project:personalOwner	credential:create
project:personalOwner	credential:read
project:personalOwner	credential:update
project:personalOwner	credential:delete
project:personalOwner	credential:list
project:personalOwner	project:read
project:personalOwner	project:list
project:personalOwner	workflow:share
project:personalOwner	workflow:execute
project:personalOwner	workflow:move
project:personalOwner	workflow:create
project:personalOwner	workflow:read
project:personalOwner	workflow:update
project:personalOwner	workflow:delete
project:personalOwner	workflow:list
project:personalOwner	folder:create
project:personalOwner	folder:read
project:personalOwner	folder:update
project:personalOwner	folder:delete
project:personalOwner	folder:list
project:personalOwner	folder:move
project:personalOwner	dataStore:create
project:personalOwner	dataStore:read
project:personalOwner	dataStore:update
project:personalOwner	dataStore:delete
project:personalOwner	dataStore:readRow
project:personalOwner	dataStore:writeRow
project:personalOwner	dataStore:listProject
project:editor	credential:create
project:editor	credential:read
project:editor	credential:update
project:editor	credential:delete
project:editor	credential:list
project:editor	project:read
project:editor	project:list
project:editor	workflow:execute
project:editor	workflow:create
project:editor	workflow:read
project:editor	workflow:update
project:editor	workflow:delete
project:editor	workflow:list
project:editor	folder:create
project:editor	folder:read
project:editor	folder:update
project:editor	folder:delete
project:editor	folder:list
project:editor	dataStore:create
project:editor	dataStore:read
project:editor	dataStore:update
project:editor	dataStore:delete
project:editor	dataStore:readRow
project:editor	dataStore:writeRow
project:editor	dataStore:listProject
project:viewer	credential:read
project:viewer	credential:list
project:viewer	project:read
project:viewer	project:list
project:viewer	workflow:read
project:viewer	workflow:list
project:viewer	folder:read
project:viewer	folder:list
project:viewer	dataStore:read
project:viewer	dataStore:readRow
project:viewer	dataStore:listProject
credential:owner	credential:share
credential:owner	credential:move
credential:owner	credential:read
credential:owner	credential:update
credential:owner	credential:delete
credential:user	credential:read
workflow:owner	workflow:share
workflow:owner	workflow:execute
workflow:owner	workflow:move
workflow:owner	workflow:read
workflow:owner	workflow:update
workflow:owner	workflow:delete
workflow:editor	workflow:execute
workflow:editor	workflow:read
workflow:editor	workflow:update
\.


--
-- TOC entry 5073 (class 0 OID 20391)
-- Dependencies: 365
-- Data for Name: scope; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.scope (slug, "displayName", description) FROM stdin;
annotationTag:create	Create Annotation Tag	Allows creating new annotation tags.
annotationTag:read	annotationTag:read	\N
annotationTag:update	annotationTag:update	\N
annotationTag:delete	annotationTag:delete	\N
annotationTag:list	annotationTag:list	\N
annotationTag:*	annotationTag:*	\N
auditLogs:manage	auditLogs:manage	\N
auditLogs:*	auditLogs:*	\N
banner:dismiss	banner:dismiss	\N
banner:*	banner:*	\N
community:register	community:register	\N
community:*	community:*	\N
communityPackage:install	communityPackage:install	\N
communityPackage:uninstall	communityPackage:uninstall	\N
communityPackage:update	communityPackage:update	\N
communityPackage:list	communityPackage:list	\N
communityPackage:manage	communityPackage:manage	\N
communityPackage:*	communityPackage:*	\N
credential:share	credential:share	\N
credential:move	credential:move	\N
credential:create	credential:create	\N
credential:read	credential:read	\N
credential:update	credential:update	\N
credential:delete	credential:delete	\N
credential:list	credential:list	\N
credential:*	credential:*	\N
externalSecretsProvider:sync	externalSecretsProvider:sync	\N
externalSecretsProvider:create	externalSecretsProvider:create	\N
externalSecretsProvider:read	externalSecretsProvider:read	\N
externalSecretsProvider:update	externalSecretsProvider:update	\N
externalSecretsProvider:delete	externalSecretsProvider:delete	\N
externalSecretsProvider:list	externalSecretsProvider:list	\N
externalSecretsProvider:*	externalSecretsProvider:*	\N
externalSecret:list	externalSecret:list	\N
externalSecret:use	externalSecret:use	\N
externalSecret:*	externalSecret:*	\N
eventBusDestination:test	eventBusDestination:test	\N
eventBusDestination:create	eventBusDestination:create	\N
eventBusDestination:read	eventBusDestination:read	\N
eventBusDestination:update	eventBusDestination:update	\N
eventBusDestination:delete	eventBusDestination:delete	\N
eventBusDestination:list	eventBusDestination:list	\N
eventBusDestination:*	eventBusDestination:*	\N
ldap:sync	ldap:sync	\N
ldap:manage	ldap:manage	\N
ldap:*	ldap:*	\N
license:manage	license:manage	\N
license:*	license:*	\N
logStreaming:manage	logStreaming:manage	\N
logStreaming:*	logStreaming:*	\N
orchestration:read	orchestration:read	\N
orchestration:list	orchestration:list	\N
orchestration:*	orchestration:*	\N
project:create	project:create	\N
project:read	project:read	\N
project:update	project:update	\N
project:delete	project:delete	\N
project:list	project:list	\N
project:*	project:*	\N
saml:manage	saml:manage	\N
saml:*	saml:*	\N
securityAudit:generate	securityAudit:generate	\N
securityAudit:*	securityAudit:*	\N
sourceControl:pull	sourceControl:pull	\N
sourceControl:push	sourceControl:push	\N
sourceControl:manage	sourceControl:manage	\N
sourceControl:*	sourceControl:*	\N
tag:create	tag:create	\N
tag:read	tag:read	\N
tag:update	tag:update	\N
tag:delete	tag:delete	\N
tag:list	tag:list	\N
tag:*	tag:*	\N
user:resetPassword	user:resetPassword	\N
user:changeRole	user:changeRole	\N
user:enforceMfa	user:enforceMfa	\N
user:create	user:create	\N
user:read	user:read	\N
user:update	user:update	\N
user:delete	user:delete	\N
user:list	user:list	\N
user:*	user:*	\N
variable:create	variable:create	\N
variable:read	variable:read	\N
variable:update	variable:update	\N
variable:delete	variable:delete	\N
variable:list	variable:list	\N
variable:*	variable:*	\N
workersView:manage	workersView:manage	\N
workersView:*	workersView:*	\N
workflow:share	workflow:share	\N
workflow:execute	workflow:execute	\N
workflow:move	workflow:move	\N
workflow:activate	workflow:activate	\N
workflow:deactivate	workflow:deactivate	\N
workflow:create	workflow:create	\N
workflow:read	workflow:read	\N
workflow:update	workflow:update	\N
workflow:delete	workflow:delete	\N
workflow:list	workflow:list	\N
workflow:*	workflow:*	\N
folder:create	folder:create	\N
folder:read	folder:read	\N
folder:update	folder:update	\N
folder:delete	folder:delete	\N
folder:list	folder:list	\N
folder:move	folder:move	\N
folder:*	folder:*	\N
insights:list	insights:list	\N
insights:*	insights:*	\N
oidc:manage	oidc:manage	\N
oidc:*	oidc:*	\N
dataStore:create	dataStore:create	\N
dataStore:read	dataStore:read	\N
dataStore:update	dataStore:update	\N
dataStore:delete	dataStore:delete	\N
dataStore:list	dataStore:list	\N
dataStore:readRow	dataStore:readRow	\N
dataStore:writeRow	dataStore:writeRow	\N
dataStore:listProject	dataStore:listProject	\N
dataStore:*	dataStore:*	\N
execution:delete	execution:delete	\N
execution:read	execution:read	\N
execution:retry	execution:retry	\N
execution:list	execution:list	\N
execution:get	execution:get	\N
execution:*	execution:*	\N
workflowTags:update	workflowTags:update	\N
workflowTags:list	workflowTags:list	\N
workflowTags:*	workflowTags:*	\N
role:manage	role:manage	\N
role:*	role:*	\N
*	*	\N
\.


--
-- TOC entry 5039 (class 0 OID 19506)
-- Dependencies: 331
-- Data for Name: settings; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.settings (key, value, "loadOnStartup") FROM stdin;
ui.banners.dismissed	["V1"]	t
features.ldap	{"loginEnabled":false,"loginLabel":"","connectionUrl":"","allowUnauthorizedCerts":false,"connectionSecurity":"none","connectionPort":389,"baseDn":"","bindingAdminDn":"","bindingAdminPassword":"","firstNameAttribute":"","lastNameAttribute":"","emailAttribute":"","loginIdAttribute":"","ldapIdAttribute":"","userFilter":"","synchronizationEnabled":false,"synchronizationInterval":60,"searchPageSize":0,"searchTimeout":60}	t
userManagement.authenticationMethod	email	t
features.sourceControl.sshKeys	{"encryptedPrivateKey":"U2FsdGVkX18uK1cYPYc2Qqvf+aKSdY6oHbf5l0BCwR6cf7koIhxfqGl+fjXlNo08E0mNGYTUYMEfXX1oTf0cri5avihshJrZjx4I4bkSM3G7jG38t/k257KVEnBTkzPYkHHgNMS2PuYEirq08jIo83eUjJzec55QRDMAAb0qrQz5qnvBcxAyXRjkWwbQIK6LM8BNBKOLhHNXuiN5fCqHmru+RMY36gzX1B/z3tfvU575nAvKItVy9C5AR9YqeuGuSyFbtvxHVyaOhnM7guVg8nm0pHZoTR548mbIcRX4yYHwAYBpC2RWa6KT0PqdRDufoEGcD6ODbbmJHCcN7673B5XCkoj6XbNLLKBAu1d+0YPAzZWQq7/Z2pk3iHrlNWMpmcYOnxa8IIjeXO2AsdNlhhsrPs8OUTnCVslRGh8Eugee9SQpeCYhkGauFl1Mich0NCWCFc8j6ZTve4RN4rLLVGk9XrKfq5qSC8DfNStQPbM32ZFZXB0MMWWusOtFEkFUjQncmgHQo+kHZTQqtQrS5nI/RzxGMi/t4XGN4WIwP/EwmC4VtxrWTn9E6oH0KKJr","publicKey":"ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIPOfUCG5hekveeuBOAeFv0t01F7srLLyVCFZA3gmZ2Gm n8n deploy key"}	t
features.sourceControl	{"branchName":"main","keyGeneratorType":"ed25519"}	t
userManagement.isInstanceOwnerSetUp	true	t
license.cert	eyJsaWNlbnNlS2V5IjoiLS0tLS1CRUdJTiBMSUNFTlNFIEtFWS0tLS0tXG5MVFJaSUUwaHVKUWl0VzNXRElEWUlxSmdCYXZNT0VtRjk2TVY4TFhrYm1zTTB0YWZQS1hNdGE2MEJWTk9VVTNzXG5NWWhSa21oZy9rOWFNYWtseS91aGVmS3hDaC9PSWhNNkYwTG9Ydm12cCtINHZHK0hYNWtnbHFIak1ERm9QUTZwXG5BUVlJajVwSnpGVnVSSTZTK1lUMHltcW5zeTJUaSt3NExpa2hTM2NPUG9DUFNKRnVqc2tBREl4emRrSDgxUWtRXG5ZRUMycHNOSkx5L05uckdpVks2MnRrNWZEdzZlSzhBZHRwU1RYeGoxTHJ2NDNWVGlPUmkxMG14UGkydjFIbUtzXG50RW9SMks0aVUwOGxXRFM4cUJqdUhINEw0UXFvamFaeDl5dW9idUNzTG1QY1FEOEJsck1KcU9MT0RGeXZBaURHXG5oTko4VkZvRmlpTkN5V3JwV2JyU0l3PT18fFUyRnNkR1ZrWDE4dTdDMTYwSkdScG42SHFaaUZyK28rdHFRMHdDXG55TEtTamF6Q251bk1EUWYwdU1SNFRnTTZqSTF2WUlWWUFtRlFyMXA4VGlzdGpqckMrMnBMZTArNG1nZjRxVnlvXG53TGFpbjJXSHB0ckdwdXUrbSszSGUrNE1EQ2NDZzNPa0JwMXlNSTZZR0VtbXhONnNHTEVyM2FNQ2F2NGF5aGRCXG5nRjN4ZlQwWVk4WmQ2Z3cxa3pUaXF3d2J4bWs5VHM5RGlsQy9uczVxd3NlQXYybWZlczhXSHpiUDBoejhTbVVUXG5EaVlVUjJyYkNMQnk0ZGl6RjFtMkgyY1o2SGtZeFpGUlZjU05NekF0aEc5emNOVThWRWZ3RXFSME9XR2w2Y0kwXG5pYWZLM2NrM2YrRXg2VzlCNmJPME9Xbi9scVFPZ3p1YTYxaXFwQVdtVXRWTDBHUWhPa01EMnpOY3VDWFVlSDQ5XG5JbkVMb3k5bDhzM0ZjTExUZW5LUDFXUjFTYTZScjg1UEhHY1BKTk4yT0Z6WTFsV0c2YVF3aEliQVZWRk8zdm5mXG50WHBvTkoyY3FOOW9BNWptRkRtdE1mQzNxSmpST0d2Q0ZnZkZ0STFDYXA4dllFR2JYb0V0T3hhckJ4WGtTeHBpXG5rTFhZQ2IvQW5hckwrN2FqMStvRDVXL0NvMHRKbzg4UHlEUzgrNXJQOWd5TVoyUFMzWkx6VTVFZjBrOTFzdjBuXG5wSG1iS1lTUWx3S0JSZUdONEV1cy81Q1MvVzJ5NE8rMkpETEZZRUtYbSt4bUVzK21xa2tTanNGbmlNZ1V2N2pOXG5mSjFpTy9tL1RDTDh1ODdlRitleExxZjg4a1dVZ3d1dmFHMzlmb215ZU9rUGRyTjArdUJHSHpWWVhwVDF4SzBkXG5sZUJERjJDckhTSmxPU2U5OGU1L3NLWEdQY0tNMGNXeTdGWXJpZjhkSzRqZkNFVG1BUVU5Wk9nRG94dlQ5RzUxXG4vTGxjbGtnQmxudzFKa0l6S1JFcGp4T3MxTVk3K2Z1WXhTV1E3dERFR0xPWUpJWkRlWVpFc2IyTXF3OHNjUHdLXG5TanZJYitPd1R1SmZGN0NZakdvTEJjQmdkaVFzcERmUzZNdUd4a0dsUHo2ZmgxSHFSZHhldkFJbWUwV0VJT0VCXG4reTRZMVg4WFZCb05FN1NmQnFtQnVOZ0dOU3RmOHFOL2VKdGpyOXdyZEVJbjFUcXFSOFhEcnNManFmdlUvZmxuXG5NQ1I0RS9LQXI5YXF1Q21ndDJJWHFlaEZ3ZDlxVlJ4Snh4RjA1eVhsV01wejJTS2hSRTVIZ2QwcjNUS0lHWDNqXG5xYUVhRCs3VGt1WnRuc01DMXFRZEdtYjY3bHNlUnF5RXlBc2lHdmZUY2RxeU1MMklmNGZic2xKS0hRTXlMR3ZxXG4yV0NKQWI3VEIxSnl5aEVxTTRGL01XU1A1NlR4NHRTbmVSZlVscm9tMmdCOGMzR0NCb09CVWgvMm4xTlBydVgzXG5zUS9pZUlqVE1qTEphOU1RZlJic1JiVkJpOUh3M0R3dEVteEVjeUlmelQzUmxvMHBrWjB3S1hhL3p5YjVIa0RvXG4waHBFOEE5NDREQVMvdWxiL3BoVWlrZGg3VHd2U2lFTmhMelhjeVhWY3NqcE13Y0pSY2FxakJCK0pLSGxlTGNoXG5UckdaaSs2Wmc5OEphWjVuTDQ5RERacEgxU3FxdTV3bWgyOEIwc0hJYnZENmJqcVJNdFRsSExPaXFEMkoxWFpLXG5EQmR2S0RPYmhZOG4vWElKTStQbmIzY2lQcUNoZUJNWCtvb1VaZEVNWmRLK3l4blNqT09WWDBFckUyUzdiOWJJXG5ZeUVBeG5qQmVaQjYxdi9oOGpVUmV6Q1huTnd5bjFLSWtrLy9IMWRFbDdqeHpZaXUrbjV0eTI3RTI2T3EzdnpDXG5FcVdRRmlGY0xyWWNLK2kzM2dMR2VwYkJmUStTdmhXZndvRHU0N3R4Y1VOQkprc2pROWlhUHlISSt3TXlXamVkXG5JRm1RdWlLcG1sdG9RZEhNT3NIQnJ1SkpnbVFSN09ZRXErQW1wd3VhRUdRT0JaTUdUcmlBNm9mYkMxR09UVzFNXG42aThWKzB5SmJQUWV3SzdVa2Vsc1R3U2hwZ1RSK01Ba21UaHlaaDBURWR1T1ZrNTI0SHZPR3pTc0ozMU9NeW80XG43WkxkU3JzSFl1UXAwNjEySEFzZTRDUmttUGdkemtSMGc1RVZaRXdBZys1cjNOVC9VenpUY0RteDNUeFRxWXM2XG5OYUxqZU5EZGNqeFlpN3Z6c0x3eHpOUzdNbDhQaEhhdEE0enFyOExIdEtLdkZaYlF6OGhzaytGRHBpUzU5dVNQXG5TNXRvNUdzYUkxdE5uVjZyVjV0aW5ER01LUzd4YTNqSmNOVHFxZG1ITFJpWmRteW92Wkc1ZzRjMzQzSUtVc1N6XG4xQjlSWExObkI4VlFNR1pIVVlVWEJaNTVreG1LeDNWSTRFeVUydys5cEU5TmlreHB1MjU5Wk5uLzFVbEFBbUpVXG56eldwdWN4a2N5Y0NCbWhnTGYzNHdhcm5vUlZRUGh0cmtWbFRkK004ZlhJdUorRjdoSE9YMllJRmZNalFPQ1J2XG5KS1dZOWptR2RINklrbmpTSEhWTkRuUm41WXJtT3gzTzdEN25VRmJleEl1dXpaeFJZazFtQUhxL2Vna3MwWnRQXG5DbkRLVGJxNjVRY1RxTHBCa3VSc1R4Q3YvK3RHRXdWTjQwSWlMOXdyVkM3TUtiSTlSS3h0SjNJZ0QySm5PQTR4XG4rRlJ2RDVMTGFiUVRjUXZoZ2REYkE4WXZ3aVVRRmppeDlFTVZHQ3VUcnkvai9sajVPSWlHc3lheGxZWU0xQlJLXG5SRU5oMGFxZXlFRFVBTFAwcW1QamtZKzRBdmhoOHExREpjWVZodkwyMkIyd0FMODJaZmpyZmxKZFVDQUZ4N3hkXG5aMzI0eG9XK3B2dytjTnpDdVJPdGhWaUZTU1pKQk1PVnBDRms3ZWxwV2dDc1ZMN2psY2kwMHdaQThrTEVhaTg1XG52cnFhdEl6bHo4YkMzQUpScHVtK1hWYnZ6Y2RWbWJTdFVUOFZGc204WmtaVDA0bkE9PXx8T0d3T1J6ZG5IK2xzXG5KUW43UERqZXAxTEt6R0tiQU5lL01lanNUYXZySWRNQzR0eENPYkRMZWJ5OWgvNXc0WTM4NEVOZWhuZW9zdEtwXG5hVW93cFdSSEwrc0R1TUpNN3FMNExoeTVacE10U1AycSt4ZkVSWkdScEhJQU50SmMwcU1wOXhLQW1yOXBlclJRXG55Y2dTenNUMEdqV2YwVDVoQlk0cUVhbitOQWRhaEtVT0t0NTZrYURGRHZ6OEJiTjRHOVlHejgvNmcrVkxjUis1XG5UVWt3alJ0T3BxYStyWFB0anRpaHhESFpVMDNvL3h0eCtsQ3lMMmFlV28veE1mQzBvTXE3MjVnVzJVY0xNM1R3XG4yU0p2akh1Qjl1OTRTTkhiajRORWhDU08yWVZVUjVaemVic254M0JpcHdSVm5ESVNUSU15S1lGU0cwZVlCM29MXG4xTTEyRmI5aE5BPT1cbi0tLS0tRU5EIExJQ0VOU0UgS0VZLS0tLS0iLCJ4NTA5IjoiLS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tXG5NSUlFRERDQ0FmUUNDUUNxZzJvRFQ4MHh3akFOQmdrcWhraUc5dzBCQVFVRkFEQklNUXN3Q1FZRFZRUUdFd0pFXG5SVEVQTUEwR0ExVUVDQXdHUW1WeWJHbHVNUTh3RFFZRFZRUUhEQVpDWlhKc2FXNHhGekFWQmdOVkJBTU1EbXhwXG5ZMlZ1YzJVdWJqaHVMbWx2TUI0WERUSXlNRFl5TkRBME1UQTBNRm9YRFRJek1EWXlOREEwTVRBME1Gb3dTREVMXG5NQWtHQTFVRUJoTUNSRVV4RHpBTkJnTlZCQWdNQmtKbGNteHBiakVQTUEwR0ExVUVCd3dHUW1WeWJHbHVNUmN3XG5GUVlEVlFRRERBNXNhV05sYm5ObExtNDRiaTVwYnpDQ0FTSXdEUVlKS29aSWh2Y05BUUVCQlFBRGdnRVBBRENDXG5BUW9DZ2dFQkFNQk0wNVhCNDRnNXhmbUNMd2RwVVR3QVQ4K0NCa3lMS0ZzZXprRDVLLzZXaGFYL1hyc2QvUWQwXG4yMEo3d2w1V2RIVTRjVkJtRlJqVndWemtsQ0syeVlKaThtang4c1hzR3E5UTFsYlVlTUtmVjlkc2dmdWhubEFTXG50blFaZ2x1Z09uRjJGZ1JoWGIvakswdHhUb2FvK2JORTZyNGdJRXpwa3RITEJUWXZ2aXVKbXJlZjdXYlBSdDRJXG5uZDlEN2xoeWJlYnloVjdrdXpqUUEvcFBLSFRGczhNVEhaOGhZVXhSeXJwbTMrTVl6UUQrYmpBMlUxRkljdGFVXG53UVhZV2FON3QydVR3Q3Q5ekFLc21ZL1dlT2J2bDNUWk41T05MQXp5V0dDdWxtNWN3S1IzeGJsQlp6WG5CNmdzXG5Pbk4yT0FkU3RjelRWQ3ljbThwY0ZVcnl0S1NLa0dFQ0F3RUFBVEFOQmdrcWhraUc5dzBCQVFVRkFBT0NBZ0VBXG5sSjAxd2NuMXZqWFhDSHVvaTdSMERKMWxseDErZGFmcXlFcVBBMjdKdStMWG1WVkdYUW9yUzFiOHhqVXFVa2NaXG5UQndiV0ZPNXo1ZFptTnZuYnlqYXptKzZvT2cwUE1hWXhoNlRGd3NJMlBPYmM3YkZ2MmVheXdQdC8xQ3BuYzQwXG5xVU1oZnZSeC9HQ1pQQ1d6My8yUlBKV1g5alFEU0hYQ1hxOEJXK0kvM2N1TERaeVkzZkVZQkIwcDNEdlZtYWQ2XG42V0hRYVVyaU4wL0xxeVNPcC9MWmdsbC90MDI5Z1dWdDA1WmliR29LK2NWaFpFY3NMY1VJaHJqMnVGR0ZkM0ltXG5KTGcxSktKN2pLU0JVUU9kSU1EdnNGVUY3WWRNdk11ckNZQTJzT05OOENaK0k1eFFWMUtTOWV2R0hNNWZtd2dTXG5PUEZ2UHp0RENpMC8xdVc5dE9nSHBvcnVvZGFjdCtFWk5rQVRYQ3ZaaXUydy9xdEtSSkY0VTRJVEVtNWFXMGt3XG42enVDOHh5SWt0N3ZoZHM0OFV1UlNHSDlqSnJBZW1sRWl6dEdJTGhHRHF6UUdZYmxoVVFGR01iQmI3amhlTHlDXG5MSjFXT0c2MkYxc3B4Q0tCekVXNXg2cFIxelQxbWhFZ2Q0TWtMYTZ6UFRwYWNyZDk1QWd4YUdLRUxhMVJXU0ZwXG5NdmRoR2s0TnY3aG5iOHIrQnVNUkM2aWVkUE1DelhxL001MGNOOEFnOGJ3K0oxYUZvKzBFSzJoV0phN2tpRStzXG45R3ZGalNkekNGbFVQaEtra1Vaa1NvNWFPdGNRcTdKdTZrV0JoTG9GWUtncHJscDFRVkIwc0daQTZvNkR0cWphXG5HNy9SazZ2YmFZOHdzTllLMnpCWFRUOG5laDVab1JaL1BKTFV0RUV0YzdZPVxuLS0tLS1FTkQgQ0VSVElGSUNBVEUtLS0tLSJ9	f
\.


--
-- TOC entry 5052 (class 0 OID 19989)
-- Dependencies: 344
-- Data for Name: shared_credentials; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.shared_credentials ("credentialsId", "projectId", role, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 5053 (class 0 OID 20015)
-- Dependencies: 345
-- Data for Name: shared_workflow; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.shared_workflow ("workflowId", "projectId", role, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 5036 (class 0 OID 19357)
-- Dependencies: 328
-- Data for Name: tag_entity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.tag_entity (name, "createdAt", "updatedAt", id) FROM stdin;
\.


--
-- TOC entry 5072 (class 0 OID 20369)
-- Dependencies: 364
-- Data for Name: test_case_execution; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.test_case_execution (id, "testRunId", "executionId", status, "runAt", "completedAt", "errorCode", "errorDetails", metrics, "createdAt", "updatedAt", inputs, outputs) FROM stdin;
\.


--
-- TOC entry 5071 (class 0 OID 20354)
-- Dependencies: 363
-- Data for Name: test_run; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.test_run (id, "workflowId", status, "errorCode", "errorDetails", "runAt", "completedAt", metrics, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 5038 (class 0 OID 19443)
-- Dependencies: 330
-- Data for Name: user; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n."user" (id, email, "firstName", "lastName", password, "personalizationAnswers", "createdAt", "updatedAt", settings, disabled, "mfaEnabled", "mfaSecret", "mfaRecoveryCodes", "lastActiveAt", "roleSlug") FROM stdin;
9f12b0ff-372b-4d46-b8ea-30c14a4a14a2	golfergeek@orchestratorai.io	Golfer	Geek	$2a$10$5GQh3k/cRVa6iXMmTerh0uPGTsowKkMWHAcU/6QgXoVG3p5bOjx3u	{"version":"v4","personalization_survey_submitted_at":"2025-10-09T20:45:55.451Z","personalization_survey_n8n_version":"1.113.3","companySize":"<20","companyType":"saas","role":"business-owner","reportedSource":"youtube"}	2025-10-09 20:29:48.187+00	2025-10-09 20:45:55.484+00	{"userActivated": false}	f	f	\N	\N	2025-10-09	global:owner
\.


--
-- TOC entry 5061 (class 0 OID 20101)
-- Dependencies: 353
-- Data for Name: user_api_keys; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.user_api_keys (id, "userId", label, "apiKey", "createdAt", "updatedAt", scopes) FROM stdin;
zQTzYfs7ExLSDksn	9f12b0ff-372b-4d46-b8ea-30c14a4a14a2	OrchestratorAI	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI5ZjEyYjBmZi0zNzJiLTRkNDYtYjhlYS0zMGMxNGE0YTE0YTIiLCJpc3MiOiJuOG4iLCJhdWQiOiJwdWJsaWMtYXBpIiwiaWF0IjoxNzYwMDQyOTA4fQ.kGRjGIPvyOptWjzFAatIt0KZbG7leeRYoNhyifC73BM	2025-10-09 20:48:28.884+00	2025-10-09 20:48:28.884+00	["credential:create","credential:delete","credential:move","project:create","project:delete","project:list","project:update","securityAudit:generate","sourceControl:pull","tag:create","tag:delete","tag:list","tag:read","tag:update","user:changeRole","user:create","user:delete","user:enforceMfa","user:list","user:read","variable:create","variable:delete","variable:list","variable:update","workflow:create","workflow:delete","workflow:list","workflow:move","workflow:read","workflow:update","workflowTags:update","workflowTags:list","workflow:activate","workflow:deactivate","execution:delete","execution:read","execution:retry","execution:list"]
\.


--
-- TOC entry 5047 (class 0 OID 19627)
-- Dependencies: 339
-- Data for Name: variables; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.variables (key, type, value, id) FROM stdin;
\.


--
-- TOC entry 5035 (class 0 OID 19347)
-- Dependencies: 327
-- Data for Name: webhook_entity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.webhook_entity ("webhookPath", method, node, "webhookId", "pathLength", "workflowId") FROM stdin;
\.


--
-- TOC entry 5034 (class 0 OID 19339)
-- Dependencies: 326
-- Data for Name: workflow_entity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.workflow_entity (name, active, nodes, connections, "createdAt", "updatedAt", settings, "staticData", "pinData", "versionId", "triggerCount", id, meta, "parentFolderId", "isArchived") FROM stdin;
\.


--
-- TOC entry 5049 (class 0 OID 19725)
-- Dependencies: 341
-- Data for Name: workflow_history; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.workflow_history ("versionId", "workflowId", authors, "createdAt", "updatedAt", nodes, connections) FROM stdin;
\.


--
-- TOC entry 5042 (class 0 OID 19542)
-- Dependencies: 334
-- Data for Name: workflow_statistics; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.workflow_statistics (count, "latestEvent", name, "workflowId", "rootCount") FROM stdin;
\.


--
-- TOC entry 5037 (class 0 OID 19364)
-- Dependencies: 329
-- Data for Name: workflows_tags; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.workflows_tags ("workflowId", "tagId") FROM stdin;
\.


--
-- TOC entry 5016 (class 0 OID 18821)
-- Dependencies: 306
-- Data for Name: agent_orchestrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_orchestrations (id, organization_slug, agent_slug, slug, display_name, description, status, orchestration_json, prompt_templates, tags, version, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5014 (class 0 OID 18778)
-- Dependencies: 304
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agents (id, organization_slug, slug, display_name, description, agent_type, mode_profile, version, status, yaml, agent_card, context, config, created_at, updated_at, function_code) FROM stdin;
894f8b22-5bcd-43fe-b900-ac9575933095	my-org	image_openai_generator	OpenAI Image Generator	Generates images via OpenAI function handler	function	full_cycle	1.0.0	active	{"metadata": {"type": "function", "category": "image", "description": "Generates images via OpenAI provider", "displayName": "OpenAI Image Generator"}, "hierarchy": {"department": "images", "reports_to": "image_orchestrator"}, "input_modes": ["text/plain"], "capabilities": ["image_generation"], "output_modes": ["image/png", "image/jpeg", "application/json"], "configuration": {"function": {"code": "async function handler(input, ctx) {\\n  const { prompt, size = '512x512', n = 1, deliverableId = null } = input || {};\\n  const out = await ctx.services.images.generate({ prompt, size, n, title: 'OpenAI Images', provider: 'openai', deliverableId });\\n  return out;\\n}", "version": "1", "language": "js", "timeout_ms": 20000}, "execution_profile": "full_cycle", "execution_capabilities": {"can_plan": false, "can_build": true, "requires_human_gate": false}}}	\N	{}	{"hierarchy": {"department": "images", "reports_to": "image_orchestrator"}, "input_modes": ["text/plain"], "capabilities": ["image_generation"], "output_modes": ["image/png", "image/jpeg", "application/json"], "configuration": {"function": {"code": "async function handler(input, ctx) {\\n  const { prompt, size = '512x512', n = 1, deliverableId = null } = input || {};\\n  const out = await ctx.services.images.generate({ prompt, size, n, title: 'OpenAI Images', provider: 'openai', deliverableId });\\n  return out;\\n}", "version": "1", "language": "js", "timeout_ms": 20000}, "execution_profile": "full_cycle", "execution_capabilities": {"can_plan": false, "can_build": true, "requires_human_gate": false}}}	2025-10-09 19:18:09.86463+00	2025-10-09 19:18:09.86463+00	\N
c2eff940-40ce-409c-b099-c449a3921f86	my-org	image_google_generator	Google Image Generator	Generates images via Google (Gemini/Imagen) function handler	function	full_cycle	1.0.0	active	{"metadata": {"type": "function", "category": "image", "description": "Generates images via Google (Gemini/Imagen) provider", "displayName": "Google Image Generator"}, "hierarchy": {"department": "images", "reports_to": "image_orchestrator"}, "input_modes": ["text/plain"], "capabilities": ["image_generation"], "output_modes": ["image/png", "image/jpeg", "application/json"], "configuration": {"function": {"code": "async function handler(input, ctx) {\\n  const { prompt, size = '512x512', n = 1, deliverableId = null } = input || {};\\n  const out = await ctx.services.images.generate({ prompt, size, n, title: 'Google Images', provider: 'gemini', deliverableId });\\n  return out;\\n}", "version": "1", "language": "js", "timeout_ms": 20000}, "execution_profile": "full_cycle", "execution_capabilities": {"can_plan": false, "can_build": true, "requires_human_gate": false}}}	\N	{}	{"hierarchy": {"department": "images", "reports_to": "image_orchestrator"}, "input_modes": ["text/plain"], "capabilities": ["image_generation"], "output_modes": ["image/png", "image/jpeg", "application/json"], "configuration": {"function": {"code": "async function handler(input, ctx) {\\n  const { prompt, size = '512x512', n = 1, deliverableId = null } = input || {};\\n  const out = await ctx.services.images.generate({ prompt, size, n, title: 'Google Images', provider: 'gemini', deliverableId });\\n  return out;\\n}", "version": "1", "language": "js", "timeout_ms": 20000}, "execution_profile": "full_cycle", "execution_capabilities": {"can_plan": false, "can_build": true, "requires_human_gate": false}}}	2025-10-09 19:18:09.86463+00	2025-10-09 19:18:09.86463+00	\N
68e1bfe7-df65-4dfa-b3bf-09bd283cb8fa	my-org	image_orchestrator	Image Orchestrator	Fan-out image generation to multiple providers	function	full_cycle	1.0.0	active	{"metadata": {"type": "function", "category": "image", "description": "Fans out image generation across multiple providers", "displayName": "Image Orchestrator"}, "hierarchy": {"team": ["image_openai_generator", "image_google_generator"], "department": "images"}, "input_modes": ["text/plain"], "capabilities": ["image_generation"], "output_modes": ["image/png", "image/jpeg", "application/json"], "configuration": {"function": {"code": "async function handler(input, ctx) {\\n  const { prompt, size = '512x512', n = 1, providers = ['openai','gemini'], deliverableId = null } = input || {};\\n  let last = null;\\n  for (const p of providers) {\\n    last = await ctx.services.images.generate({ prompt, size, n, title: 'Image Orchestrator', provider: p, deliverableId });\\n  }\\n  return last;\\n}", "version": "1", "language": "js", "timeout_ms": 20000}, "execution_profile": "full_cycle", "execution_capabilities": {"can_plan": false, "can_build": true, "requires_human_gate": false}}}	\N	{}	{"hierarchy": {"team": ["image_openai_generator", "image_google_generator"], "department": "images"}, "input_modes": ["text/plain"], "capabilities": ["image_generation"], "output_modes": ["image/png", "image/jpeg", "application/json"], "configuration": {"function": {"code": "async function handler(input, ctx) {\\n  const { prompt, size = '512x512', n = 1, providers = ['openai','gemini'], deliverableId = null } = input || {};\\n  let last = null;\\n  for (const p of providers) {\\n    last = await ctx.services.images.generate({ prompt, size, n, title: 'Image Orchestrator', provider: p, deliverableId });\\n  }\\n  return last;\\n}", "version": "1", "language": "js", "timeout_ms": 20000}, "execution_profile": "full_cycle", "execution_capabilities": {"can_plan": false, "can_build": true, "requires_human_gate": false}}}	2025-10-09 19:18:09.866585+00	2025-10-09 19:18:09.866585+00	\N
48271c6f-5de4-410f-ac04-6ca194415b47	demo	orchestrator	Demo Orchestrator	Coordinates multi-agent workflows for the demo namespace and delegates follow-up to specialists.	orchestrator	orchestrator_full	\N	active	\n{\n    "metadata": {\n        "name": "demo-orchestrator",\n        "displayName": "Demo Orchestrator",\n        "description": "Coordinates multi-step workflows for the demo namespace and delegates tasks to specialists.",\n        "version": "0.1.0",\n        "type": "orchestrator",\n        "tags": [\n            "demo",\n            "orchestrator",\n            "multi-agent"\n        ]\n    },\n    "capabilities": [\n        "converse",\n        "plan",\n        "build",\n        "delegate"\n    ],\n    "communication": {\n        "input_modes": [\n            "text/plain"\n        ],\n        "output_modes": [\n            "text/markdown",\n            "application/json"\n        ]\n    },\n    "configuration": {\n        "execution_capabilities": {\n            "supports_converse": true,\n            "supports_plan": true,\n            "supports_build": true,\n            "supports_orchestration": true\n        },\n        "prompt_prefix": "You are the primary orchestrator for the demo organization. Coordinate specialists, capture assumptions, and keep stakeholders informed."\n    },\n    "skills": [\n        {\n            "id": "orchestration-plan",\n            "name": "Produce orchestration plans",\n            "description": "Drafts multi-phase execution plans with owners, expected outputs, and checkpoints.",\n            "tags": [\n                "planning",\n                "coordination"\n            ],\n            "input_modes": [\n                "text/plain"\n            ],\n            "output_modes": [\n                "text/markdown"\n            ]\n        },\n        {\n            "id": "delegation-bridge",\n            "name": "Delegate supporting agents",\n            "description": "Identifies supporting agents, crafts delegation prompts, and tracks follow-ups.",\n            "tags": [\n                "delegation"\n            ],\n            "input_modes": [\n                "text/plain"\n            ],\n            "output_modes": [\n                "application/json"\n            ]\n        }\n    ],\n    "prompts": {\n        "system": "You are the Demo Orchestrator agent. Plan complex multi-step efforts, call out risks, and prepare the team to execute. Always provide a structured response with sections for context, execution plan, risks, and next steps.",\n        "plan": "Create an orchestration plan broken into numbered phases. Each phase must include an objective, concrete tasks, supporting agents/tools, and a readiness checklist.",\n        "build": "Summarize the execution status for all phases, including completed work, outstanding items, and human checkpoints that need attention.",\n        "human": "Clearly describe what decision or input the human stakeholder must provide to continue the orchestration."\n    },\n    "context": {\n        "plan_rubric": {\n            "required_sections": [\n                "Context",\n                "Objectives",\n                "Phases",\n                "Risks",\n                "Next Steps"\n            ],\n            "default_phase_labels": [\n                "Discovery",\n                "Design",\n                "Implementation",\n                "Validation"\n            ],\n            "risk_checks": [\n                "Call out missing approvals",\n                "Highlight resource gaps",\n                "Track dependencies across teams"\n            ]\n        },\n        "input_modes": [\n            "text/plain"\n        ],\n        "output_modes": [\n            "text/markdown",\n            "application/json"\n        ]\n    }\n}\n	\N	{"input_modes": ["text/plain"], "output_modes": ["text/markdown", "application/json"], "supported_modes": ["converse", "plan", "build"]}	{"streaming": {"enabled": true}, "extensions": ["orchestration:v1"], "default_llm": "gpt-4o-mini", "capabilities": ["delegate", "orchestrate"], "deliverables": {"enabled": true}, "notifications": {"push": true}, "stateTracking": {"enabled": true}, "supported_modes": ["converse", "plan", "build"]}	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00	\N
d7652e39-79c2-45d5-825e-cbef0e70efe5	my-org	requirements-specialist	Requirements Specialist	Transforms stakeholder requests into structured product requirements and acceptance criteria for my-org.	specialist	specialist_full	\N	active	\n{\n    "metadata": {\n        "name": "my-org-requirements-specialist",\n        "displayName": "Requirements Specialist",\n        "description": "Transforms stakeholder requests into structured product requirements and acceptance criteria for the my-org namespace.",\n        "version": "0.1.0",\n        "type": "specialist",\n        "tags": [\n            "my-org",\n            "requirements",\n            "analysis"\n        ]\n    },\n    "capabilities": [\n        "converse",\n        "plan",\n        "build"\n    ],\n    "communication": {\n        "input_modes": [\n            "text/plain"\n        ],\n        "output_modes": [\n            "text/markdown",\n            "application/json"\n        ]\n    },\n    "configuration": {\n        "execution_capabilities": {\n            "supports_converse": true,\n            "supports_plan": true,\n            "supports_build": true,\n            "supports_orchestration": false\n        },\n        "prompt_prefix": "You are a senior requirements analyst. Clarify ambiguous stakeholder input, capture explicit assumptions, and produce structured requirements packages."\n    },\n    "skills": [\n        {\n            "id": "clarify-context",\n            "name": "Clarify context",\n            "description": "Asks targeted follow-up questions to remove ambiguity and document assumptions.",\n            "tags": [\n                "analysis",\n                "discovery"\n            ],\n            "input_modes": [\n                "text/plain"\n            ],\n            "output_modes": [\n                "text/markdown"\n            ]\n        },\n        {\n            "id": "craft-requirements",\n            "name": "Craft structured requirements",\n            "description": "Produces user stories, acceptance criteria, and traceability matrices.",\n            "tags": [\n                "requirements",\n                "documentation"\n            ],\n            "input_modes": [\n                "text/plain"\n            ],\n            "output_modes": [\n                "text/markdown",\n                "application/json"\n            ]\n        }\n    ],\n    "prompts": {\n        "system": "You are the Requirements Specialist agent. Create precise, testable requirements packages and flag missing information.",\n        "plan": "Summarize the discovery plan you will follow, including questions to ask and artifacts to gather.",\n        "build": "Produce a requirements package with sections for problem statement, user stories, acceptance criteria, open questions, and implementation considerations.",\n        "human": "List any clarifications or approvals still required from stakeholders."\n    },\n    "context": {\n        "templates": {\n            "requirements_package": {\n                "sections": [\n                    "Problem Statement",\n                    "User Stories",\n                    "Acceptance Criteria",\n                    "Open Questions",\n                    "Implementation Considerations"\n                ]\n            }\n        },\n        "input_modes": [\n            "text/plain"\n        ],\n        "output_modes": [\n            "text/markdown",\n            "application/json"\n        ]\n    }\n}\n	\N	{"input_modes": ["text/plain"], "output_modes": ["text/markdown", "application/json"], "supported_modes": ["converse", "plan", "build"]}	{"streaming": {"enabled": true}, "default_llm": "gpt-4o-mini", "capabilities": ["requirements", "analysis"], "supported_modes": ["converse", "plan", "build"]}	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00	\N
61ed59b0-ebb1-4f87-98d1-2df4c21d9509	my-org	blog_post_writer	Blog Post Writer	Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.	specialist	specialist_full	\N	active	\nname: blog_post_writer\ndisplay_name: Blog Post Writer\ndescription: Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\nagent_type: context\nmode_profile: plan-build-converse\nversion: "1.0"\nstatus: active\n\nsystem_prompt: |\n  Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\n\n  When creating a plan for a blog post, structure it with the following sections:\n\n  # Blog Post Plan\n\n  ## Title & Topic\n  - Working title\n  - Target topic/theme\n  - Angle or unique perspective\n\n  ## Audience & Purpose\n  - Target audience description\n  - Primary goal (inform, persuade, entertain, etc.)\n  - Reader takeaway\n\n  ## Content Strategy\n  - Word count target\n  - SEO keywords\n  - Key points to cover\n\n  When building a deliverable, create:\n  - Engaging introduction\n  - Clear section headings\n  - Actionable content\n  - Strong conclusion with CTA\n\n  When conversing, provide helpful suggestions for improving blog content.\n\nmodes:\n  plan:\n    enabled: true\n    actions:\n      - create\n      - read\n      - list\n      - edit\n      - set_current\n      - delete_version\n      - merge_versions\n      - copy_version\n      - delete\n\n  build:\n    enabled: true\n    actions:\n      - create\n      - read\n      - list\n      - edit\n      - rerun\n      - set_current\n      - delete_version\n      - merge_versions\n      - copy_version\n      - delete\n\n  converse:\n    enabled: true\n\nllm_defaults:\n  provider: ollama\n  model: llama3.2:1b\n  temperature: 0.7\n	{"system_prompt": "Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\\n\\nWhen creating a plan for a blog post, structure it with the following sections:\\n\\n# Blog Post Plan\\n\\n## Title & Topic\\n- Working title\\n- Target topic/theme\\n- Angle or unique perspective\\n\\n## Audience & Purpose\\n- Target audience description\\n- Primary goal (inform, persuade, entertain, etc.)\\n- Reader takeaway\\n\\n## Content Strategy\\n- Word count target\\n- SEO keywords\\n- Key points to cover\\n\\nWhen building a deliverable, create:\\n- Engaging introduction\\n- Clear section headings\\n- Actionable content\\n- Strong conclusion with CTA\\n\\nWhen conversing, provide helpful suggestions for improving blog content."}	{"plan": {"template": "Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\\n\\nWhen creating a plan for a blog post, structure it with the following sections:\\n\\n# Blog Post Plan\\n\\n## Title & Topic\\n- Working title\\n- Target topic/theme\\n- Angle or unique perspective\\n\\n## Audience & Purpose\\n- Target audience description\\n- Primary goal (inform, persuade, entertain, etc.)\\n- Reader takeaway\\n\\n## Content Strategy\\n- Word count target\\n- SEO keywords\\n- Key points to cover\\n\\nWhen building a deliverable, create:\\n- Engaging introduction\\n- Clear section headings\\n- Actionable content\\n- Strong conclusion with CTA\\n\\nWhen conversing, provide helpful suggestions for improving blog content."}, "build": {"template": "Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\\n\\nWhen creating a plan for a blog post, structure it with the following sections:\\n\\n# Blog Post Plan\\n\\n## Title & Topic\\n- Working title\\n- Target topic/theme\\n- Angle or unique perspective\\n\\n## Audience & Purpose\\n- Target audience description\\n- Primary goal (inform, persuade, entertain, etc.)\\n- Reader takeaway\\n\\n## Content Strategy\\n- Word count target\\n- SEO keywords\\n- Key points to cover\\n\\nWhen building a deliverable, create:\\n- Engaging introduction\\n- Clear section headings\\n- Actionable content\\n- Strong conclusion with CTA\\n\\nWhen conversing, provide helpful suggestions for improving blog content."}, "converse": {"template": "Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\\n\\nWhen creating a plan for a blog post, structure it with the following sections:\\n\\n# Blog Post Plan\\n\\n## Title & Topic\\n- Working title\\n- Target topic/theme\\n- Angle or unique perspective\\n\\n## Audience & Purpose\\n- Target audience description\\n- Primary goal (inform, persuade, entertain, etc.)\\n- Reader takeaway\\n\\n## Content Strategy\\n- Word count target\\n- SEO keywords\\n- Key points to cover\\n\\nWhen building a deliverable, create:\\n- Engaging introduction\\n- Clear section headings\\n- Actionable content\\n- Strong conclusion with CTA\\n\\nWhen conversing, provide helpful suggestions for improving blog content."}}	{"llm_defaults": {"model": "llama3.2:1b", "provider": "ollama", "temperature": 0.7}}	2025-10-09 19:18:09.907966+00	2025-10-09 19:41:45.978701+00	\N
\.


--
-- TOC entry 5019 (class 0 OID 18896)
-- Dependencies: 310
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.assets (id, storage, path, bucket, object_key, mime, size, width, height, hash, user_id, conversation_id, deliverable_version_id, created_at, updated_at, source_url) FROM stdin;
\.


--
-- TOC entry 4996 (class 0 OID 18268)
-- Dependencies: 286
-- Data for Name: cidafm_commands; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cidafm_commands (id, type, name, description, default_active, is_builtin, created_at, updated_at) FROM stdin;
550e8400-e29b-41d4-a716-446655440001	^	format_markdown	Format response as Markdown with proper headers and structure	f	t	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
550e8400-e29b-41d4-a716-446655440002	^	format_json	Format response as JSON with proper structure	f	t	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
550e8400-e29b-41d4-a716-446655440003	&	include_examples	Include practical examples in the response	f	t	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
550e8400-e29b-41d4-a716-446655440004	&	include_code	Include code snippets and implementation details	f	t	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
550e8400-e29b-41d4-a716-446655440005	!	exclude_theory	Focus on practical implementation, avoid theoretical explanations	f	t	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
550e8400-e29b-41d4-a716-446655440006	!	exclude_warnings	Skip safety warnings and disclaimers	f	t	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
\.


--
-- TOC entry 4997 (class 0 OID 18279)
-- Dependencies: 287
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.companies (id, name, industry, founded_year, created_at, updated_at) FROM stdin;
5ea464e8-9a64-453d-9c46-a6908b7e01ad	Acme Analytics Inc.	Software	2018	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
\.


--
-- TOC entry 4998 (class 0 OID 18285)
-- Dependencies: 288
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conversations (id, user_id, agent_name, agent_type, started_at, last_active_at, metadata, created_at, updated_at, organization_slug, ended_at) FROM stdin;
66f858b9-0d63-4afa-9052-10b661543c05	b29a590e-b07f-49df-a25b-574c956b5035	Dashboard Builder Agent	conversation_agent	2025-09-30 19:18:09.981049+00	2025-09-30 21:18:09.981049+00	{"title": "Build React Dashboard Component", "priority": "normal", "complexity": "medium", "project_type": "mobile_app"}	2025-09-30 19:18:09.981049+00	2025-09-30 21:18:09.981049+00	\N	\N
5931a44f-506e-4377-b637-bf5bdfe79e8b	b29a590e-b07f-49df-a25b-574c956b5035	Authentication Agent	conversation_agent	2025-10-01 19:18:09.981049+00	2025-10-01 21:18:09.981049+00	{"title": "Implement User Authentication System", "priority": "low", "complexity": "low", "project_type": "api"}	2025-10-01 19:18:09.981049+00	2025-10-01 21:18:09.981049+00	\N	\N
91642195-1f88-4f3d-a88d-bc5d05440f80	b29a590e-b07f-49df-a25b-574c956b5035	Database Designer Agent	conversation_agent	2025-10-02 19:18:09.981049+00	2025-10-02 21:18:09.981049+00	{"title": "Design Database Schema", "priority": "urgent", "complexity": "high", "project_type": "web_app"}	2025-10-02 19:18:09.981049+00	2025-10-02 21:18:09.981049+00	\N	\N
2e536d84-d5c8-4c2e-bf58-436b5d7dd493	b29a590e-b07f-49df-a25b-574c956b5035	API Security Agent	conversation_agent	2025-10-03 19:18:09.981049+00	2025-10-03 21:18:09.981049+00	{"title": "Create API Rate Limiting Strategy", "priority": "normal", "complexity": "medium", "project_type": "mobile_app"}	2025-10-03 19:18:09.981049+00	2025-10-03 21:18:09.981049+00	\N	\N
bff9ce60-05b5-42fb-b508-8bf3b973aadd	b29a590e-b07f-49df-a25b-574c956b5035	Mobile UX Agent	conversation_agent	2025-10-04 19:18:09.981049+00	2025-10-04 21:18:09.981049+00	{"title": "Develop Mobile App Navigation", "priority": "low", "complexity": "low", "project_type": "api"}	2025-10-04 19:18:09.981049+00	2025-10-04 21:18:09.981049+00	\N	\N
c6741ed7-9003-4921-8dda-9aa6729f2916	b29a590e-b07f-49df-a25b-574c956b5035	Payment Integration Agent	conversation_agent	2025-10-05 19:18:09.981049+00	2025-10-05 21:18:09.981049+00	{"title": "Setup Payment Integration", "priority": "urgent", "complexity": "high", "project_type": "web_app"}	2025-10-05 19:18:09.981049+00	2025-10-05 21:18:09.981049+00	\N	\N
70afc481-1bbd-4c2f-9bf7-68dfbc2dc3ee	b29a590e-b07f-49df-a25b-574c956b5035	Email Template Agent	conversation_agent	2025-10-06 19:18:09.981049+00	2025-10-06 21:18:09.981049+00	{"title": "Build Email Template System", "priority": "normal", "complexity": "medium", "project_type": "mobile_app"}	2025-10-06 19:18:09.981049+00	2025-10-06 21:18:09.981049+00	\N	\N
d6671925-606e-462b-ae7c-66f46bf3f1b4	b29a590e-b07f-49df-a25b-574c956b5035	Search Optimization Agent	conversation_agent	2025-10-07 19:18:09.981049+00	2025-10-07 21:18:09.981049+00	{"title": "Implement Search Functionality", "priority": "low", "complexity": "low", "project_type": "api"}	2025-10-07 19:18:09.981049+00	2025-10-07 21:18:09.981049+00	\N	\N
9e6f502b-ba20-4e24-88a7-0ce85149c18b	b29a590e-b07f-49df-a25b-574c956b5035	Performance Agent	conversation_agent	2025-10-08 19:18:09.981049+00	2025-10-08 21:18:09.981049+00	{"title": "Optimize Application Performance", "priority": "urgent", "complexity": "high", "project_type": "web_app"}	2025-10-08 19:18:09.981049+00	2025-10-08 21:18:09.981049+00	\N	\N
9cfb3f53-02c6-4951-8e04-0fb624fad0e7	b29a590e-b07f-49df-a25b-574c956b5035	Security Audit Agent	conversation_agent	2025-10-09 19:18:09.981049+00	2025-10-09 21:18:09.981049+00	{"title": "Conduct Security Audit", "priority": "normal", "complexity": "medium", "project_type": "mobile_app"}	2025-10-09 19:18:09.981049+00	2025-10-09 21:18:09.981049+00	\N	\N
38ef70b5-1a48-4024-81f3-8c937f3dcea6	a1b2c3d4-e5f6-7890-abcd-ef1234567890	blog_post_writer	specialist	2025-10-09 19:54:42.572+00	2025-10-09 19:54:42.572+00	{"source": "frontend"}	2025-10-09 19:54:42.573716+00	2025-10-09 19:54:42.573716+00	my-org	\N
c01c1680-25a0-4bde-a648-e367a4a480d7	a1b2c3d4-e5f6-7890-abcd-ef1234567890	image_google_generator	function	2025-10-09 20:20:53.193+00	2025-10-09 20:20:53.193+00	{"source": "frontend"}	2025-10-09 20:20:53.203362+00	2025-10-09 20:20:53.203362+00	my-org	\N
\.


--
-- TOC entry 5000 (class 0 OID 18314)
-- Dependencies: 290
-- Data for Name: deliverable_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deliverable_versions (id, deliverable_id, version_number, content, format, is_current_version, created_by_type, task_id, metadata, file_attachments, created_at, updated_at) FROM stdin;
11d199d2-6575-470a-87df-0866faceaab0	1432230a-6eab-4001-8487-9d27809f37f6	1	# Building a Modern React Dashboard Component\n\nCreating an effective dashboard component is crucial for any modern web application. In this comprehensive guide, we'll explore the essential elements that make a dashboard both functional and visually appealing.\n\n## Key Design Principles\n\nWhen building a dashboard component, consider these fundamental principles:\n\n- **Clarity**: Information should be immediately understandable\n- **Hierarchy**: Most important metrics should be prominently displayed\n- **Responsiveness**: Works seamlessly across all device sizes\n- **Performance**: Loads quickly even with large datasets\n\n## Implementation Strategy\n\nStart with a clean component structure:\n\n```jsx\nconst Dashboard = () => {\n  const [metrics, setMetrics] = useState([]);\n  const [loading, setLoading] = useState(true);\n  \n  return (\n    <div className="dashboard-container">\n      {/* Your dashboard content */}\n    </div>\n  );\n};\n```\n\n## Best Practices\n\n1. Use React hooks for state management\n2. Implement proper error boundaries\n3. Add loading states for better UX\n4. Consider using a charting library like Chart.js or D3\n\nBy following these guidelines, you'll create a dashboard that users love to interact with and that scales with your application's growth.	markdown	t	ai_response	\N	{"topics": ["react", "dashboard", "components", "frontend"], "word_count": 850, "content_type": "blog_post", "generated_by": "ai_agent", "reading_time_minutes": 4}	{}	2025-09-30 21:18:09.981049+00	2025-09-30 21:18:09.981049+00
eb4ba4c4-669d-4c60-9372-42d890b5f4c9	4816b176-aba8-4f82-a9cc-3929430e897a	1	# Implementing Secure User Authentication: A Complete Guide\n\nUser authentication is the cornerstone of any secure web application. This guide walks you through implementing a robust authentication system that protects your users and your data.\n\n## Authentication Fundamentals\n\nModern authentication systems should include:\n\n- **Multi-factor authentication (MFA)**\n- **Secure password policies**\n- **Session management**\n- **Rate limiting**\n- **Account lockout protection**\n\n## JWT vs Session-Based Auth\n\n### JSON Web Tokens (JWT)\n\nJWTs offer stateless authentication with these advantages:\n- No server-side session storage required\n- Easy to scale across multiple servers\n- Built-in expiration handling\n\n### Session-Based Authentication\n\nTraditional sessions provide:\n- Immediate revocation capability\n- Server-side control over user sessions\n- Smaller client-side footprint\n\n## Implementation Steps\n\n1. **Choose your authentication strategy**\n2. **Set up secure password hashing** (use bcrypt or similar)\n3. **Implement login/logout endpoints**\n4. **Add middleware for route protection**\n5. **Create user registration flow**\n6. **Add password reset functionality**\n\n## Security Considerations\n\nAlways remember:\n- Hash passwords with salt\n- Use HTTPS in production\n- Implement proper CORS policies\n- Add request rate limiting\n- Log authentication attempts\n\nA well-implemented authentication system is invisible to legitimate users but impenetrable to attackers.	markdown	t	ai_response	\N	{"topics": ["authentication", "security", "jwt", "backend"], "word_count": 1200, "content_type": "blog_post", "generated_by": "ai_agent", "reading_time_minutes": 5}	{}	2025-10-01 21:18:09.981049+00	2025-10-01 21:18:09.981049+00
36f7d5a8-819a-41e0-b7c1-b1f0beafb390	60a1aefa-5dae-43b2-9682-3fae275da290	1	# Database Schema Design: Building Scalable Data Architecture\n\nA well-designed database schema is the foundation of any successful application. This guide covers essential principles and practical strategies for creating databases that scale.\n\n## Schema Design Principles\n\n### Normalization vs Denormalization\n\n**Normalization** reduces data redundancy:\n- Eliminates duplicate data\n- Ensures data consistency\n- Reduces storage requirements\n- Simplifies data updates\n\n**Denormalization** optimizes for read performance:\n- Faster query execution\n- Reduced join complexity\n- Better suited for analytics\n- May increase storage needs\n\n## Essential Design Patterns\n\n### 1. Primary Keys\nAlways use meaningful primary keys:\n```sql\nCREATE TABLE users (\n    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),\n    email VARCHAR(255) UNIQUE NOT NULL,\n    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);\n```\n\n### 2. Foreign Key Relationships\nMaintain referential integrity:\n```sql\nCREATE TABLE orders (\n    id UUID PRIMARY KEY,\n    user_id UUID REFERENCES users(id),\n    total_amount DECIMAL(10,2)\n);\n```\n\n### 3. Indexing Strategy\nCreate indexes for frequently queried columns:\n```sql\nCREATE INDEX idx_users_email ON users(email);\nCREATE INDEX idx_orders_user_id ON orders(user_id);\n```\n\n## Performance Optimization\n\n- Use appropriate data types\n- Implement proper indexing\n- Consider partitioning for large tables\n- Monitor query performance regularly\n\nRemember: a good schema design today saves countless hours of refactoring tomorrow.	markdown	t	ai_response	\N	{"topics": ["database", "schema", "design", "sql"], "word_count": 950, "content_type": "blog_post", "generated_by": "ai_agent", "reading_time_minutes": 4}	{}	2025-10-02 21:18:09.981049+00	2025-10-02 21:18:09.981049+00
15d985e3-e61c-4289-914e-497bd7fc2423	9f6ccb77-9b74-4531-8800-5dca05662230	1	# API Rate Limiting: Protecting Your Services from Abuse\n\nRate limiting is essential for maintaining API performance and preventing abuse. Learn how to implement effective rate limiting strategies that protect your infrastructure while providing a smooth experience for legitimate users.\n\n## Why Rate Limiting Matters\n\nWithout proper rate limiting, your API faces several risks:\n- **DDoS attacks** can overwhelm your servers\n- **Resource exhaustion** from excessive requests\n- **Cost escalation** in cloud environments\n- **Poor user experience** due to system slowdowns\n\n## Common Rate Limiting Algorithms\n\n### 1. Token Bucket\n\nThe token bucket algorithm allows bursts while maintaining average limits:\n\n```javascript\nclass TokenBucket {\n  constructor(capacity, refillRate) {\n    this.capacity = capacity;\n    this.tokens = capacity;\n    this.refillRate = refillRate;\n    this.lastRefill = Date.now();\n  }\n  \n  consume(tokens = 1) {\n    this.refill();\n    if (this.tokens >= tokens) {\n      this.tokens -= tokens;\n      return true;\n    }\n    return false;\n  }\n}\n```\n\n### 2. Fixed Window\n\nSimple but effective for most use cases:\n- Reset counters at fixed intervals\n- Easy to implement and understand\n- May allow bursts at window boundaries\n\n### 3. Sliding Window\n\nMore accurate but computationally expensive:\n- Smooth rate limiting\n- No boundary burst issues\n- Requires more memory and processing\n\n## Implementation Best Practices\n\n1. **Choose appropriate limits** based on your infrastructure\n2. **Implement different tiers** for different user types\n3. **Provide clear error messages** when limits are exceeded\n4. **Monitor and adjust** limits based on usage patterns\n5. **Consider geographic distribution** for global applications\n\n## HTTP Status Codes\n\nUse proper status codes:\n- `429 Too Many Requests` for rate limit exceeded\n- Include `Retry-After` header\n- Provide remaining quota in response headers\n\nEffective rate limiting protects your API while maintaining excellent user experience.	markdown	t	ai_response	\N	{"topics": ["api", "rate-limiting", "performance", "security"], "word_count": 1100, "content_type": "blog_post", "generated_by": "ai_agent", "reading_time_minutes": 5}	{}	2025-10-03 21:18:09.981049+00	2025-10-03 21:18:09.981049+00
83c6bf6c-7174-40d4-addb-fd6a69b37a7b	0d2913b0-9775-4b0a-82a2-e69090e99555	1	# Mobile App Navigation: Creating Intuitive User Journeys\n\nGreat mobile navigation is invisible – users should effortlessly move through your app without thinking about how to get where they want to go. This guide explores proven patterns and emerging trends in mobile navigation design.\n\n## Navigation Fundamentals\n\n### The 3-Tap Rule\n\nUsers should reach any feature within three taps:\n- **Tap 1**: Open the app\n- **Tap 2**: Navigate to section\n- **Tap 3**: Access specific feature\n\n### Visual Hierarchy\n\nEstablish clear information architecture:\n- Primary navigation (bottom tabs)\n- Secondary navigation (top tabs or lists)\n- Tertiary navigation (action sheets, modals)\n\n## Popular Navigation Patterns\n\n### 1. Bottom Tab Navigation\n\nBest for 3-5 primary sections:\n\n```jsx\n<Tab.Navigator>\n  <Tab.Screen name="Home" component={HomeScreen} />\n  <Tab.Screen name="Search" component={SearchScreen} />\n  <Tab.Screen name="Profile" component={ProfileScreen} />\n</Tab.Navigator>\n```\n\n**Pros:**\n- Thumb-friendly on mobile devices\n- Always visible\n- Clear section separation\n\n**Cons:**\n- Limited to 5 items maximum\n- Takes up screen space\n\n### 2. Drawer Navigation\n\nIdeal for apps with many sections:\n\n```jsx\n<Drawer.Navigator>\n  <Drawer.Screen name="Dashboard" component={DashboardScreen} />\n  <Drawer.Screen name="Settings" component={SettingsScreen} />\n  <Drawer.Screen name="Help" component={HelpScreen} />\n</Drawer.Navigator>\n```\n\n**Pros:**\n- Accommodates many navigation items\n- Saves screen space\n- Can include user information\n\n**Cons:**\n- Hidden by default\n- Requires gesture or button tap\n\n## Accessibility Considerations\n\n- Use semantic labels for screen readers\n- Ensure sufficient touch target sizes (44pt minimum)\n- Provide clear focus indicators\n- Test with voice control features\n\n## Performance Tips\n\n- Implement lazy loading for screens\n- Use native navigation libraries\n- Optimize animations for 60fps\n- Preload critical screens\n\nGreat navigation feels natural and gets users to their destination quickly and efficiently.	markdown	t	ai_response	\N	{"topics": ["mobile", "navigation", "ux", "design"], "word_count": 1050, "content_type": "blog_post", "generated_by": "ai_agent", "reading_time_minutes": 5}	{}	2025-10-04 21:18:09.981049+00	2025-10-04 21:18:09.981049+00
2c340a02-707f-40ac-be83-ebd8f496fa78	c7aa1741-7264-4daf-8ac8-4913f3364267	1	# Payment Integration Made Simple: Stripe Setup Guide\n\nIntegrating payments into your application doesn't have to be complicated. This comprehensive guide walks you through setting up Stripe payments with security best practices and optimal user experience.\n\n## Why Choose Stripe?\n\nStripe has become the gold standard for online payments:\n- **Security**: PCI DSS compliant out of the box\n- **Global reach**: Supports 135+ currencies\n- **Developer experience**: Excellent APIs and documentation\n- **Features**: Subscriptions, invoicing, marketplaces, and more\n\n## Setup Process\n\n### 1. Account Creation\n\n1. Sign up at stripe.com\n2. Complete business verification\n3. Get your API keys (test and live)\n4. Configure webhook endpoints\n\n### 2. Frontend Integration\n\nInstall Stripe Elements:\n\n```bash\nnpm install @stripe/stripe-js @stripe/react-stripe-js\n```\n\nBasic payment form:\n\n```jsx\nimport { loadStripe } from "@stripe/stripe-js";\nimport { Elements, CardElement, useStripe, useElements } from "@stripe/react-stripe-js";\n\nconst PaymentForm = () => {\n  const stripe = useStripe();\n  const elements = useElements();\n  \n  const handleSubmit = async (event) => {\n    event.preventDefault();\n    \n    const { error, paymentMethod } = await stripe.createPaymentMethod({\n      type: "card",\n      card: elements.getElement(CardElement),\n    });\n    \n    if (!error) {\n      // Send paymentMethod.id to your server\n    }\n  };\n  \n  return (\n    <form onSubmit={handleSubmit}>\n      <CardElement />\n      <button type="submit" disabled={!stripe}>\n        Pay Now\n      </button>\n    </form>\n  );\n};\n```\n\n### 3. Backend Integration\n\nServer-side payment processing:\n\n```javascript\nconst stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);\n\napp.post("/create-payment-intent", async (req, res) => {\n  const { amount, currency } = req.body;\n  \n  try {\n    const paymentIntent = await stripe.paymentIntents.create({\n      amount: amount * 100, // Convert to cents\n      currency: currency,\n      metadata: {\n        order_id: req.body.order_id\n      }\n    });\n    \n    res.send({\n      client_secret: paymentIntent.client_secret\n    });\n  } catch (error) {\n    res.status(400).send({ error: error.message });\n  }\n});\n```\n\n## Security Best Practices\n\n1. **Never store card data** on your servers\n2. **Use HTTPS** for all payment pages\n3. **Validate on server-side** before processing\n4. **Implement webhook verification**\n5. **Log payment attempts** for monitoring\n\n## Testing\n\nStripe provides test card numbers:\n- `4242424242424242` - Successful payment\n- `4000000000000002` - Card declined\n- `4000000000009995` - Insufficient funds\n\n## Going Live\n\n1. Complete Stripe account verification\n2. Switch to live API keys\n3. Update webhook endpoints\n4. Test with real payment methods\n5. Monitor payment success rates\n\nWith Stripe, you can focus on your product while trusting that payments are handled securely and reliably.	markdown	t	ai_response	\N	{"topics": ["payments", "stripe", "integration", "security"], "word_count": 1300, "content_type": "blog_post", "generated_by": "ai_agent", "reading_time_minutes": 6}	{}	2025-10-05 21:18:09.981049+00	2025-10-05 21:18:09.981049+00
3c281192-53a8-49bf-83ea-d6c3571c2c12	6ef02b65-cf27-4b78-a791-5f2e1b4e7065	1	# Email Template Systems: Building Responsive Communications\n\nEmail templates are crucial for maintaining consistent brand communication. This guide covers building a flexible, maintainable email template system that works across all email clients.\n\n## Email Template Challenges\n\nEmail rendering is notoriously difficult:\n- **Inconsistent CSS support** across email clients\n- **Limited HTML capabilities**\n- **Responsive design complexity**\n- **Dark mode considerations**\n- **Accessibility requirements**\n\n## Template Architecture\n\n### 1. Base Template Structure\n\n```html\n<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>{{subject}}</title>\n  <style>\n    /* Inline CSS for maximum compatibility */\n    .container { max-width: 600px; margin: 0 auto; }\n    .header { background-color: #f8f9fa; padding: 20px; }\n    .content { padding: 30px 20px; }\n    .footer { background-color: #6c757d; color: white; padding: 15px; }\n  </style>\n</head>\n<body>\n  <div class="container">\n    <div class="header">\n      <img src="{{logo_url}}" alt="{{company_name}}" height="40">\n    </div>\n    <div class="content">\n      {{content}}\n    </div>\n    <div class="footer">\n      <p>{{company_name}} | {{company_address}}</p>\n      <a href="{{unsubscribe_url}}">Unsubscribe</a>\n    </div>\n  </div>\n</body>\n</html>\n```\n\n### 2. Template Components\n\nCreate reusable components:\n\n```javascript\nconst EmailComponents = {\n  button: (text, url, color = "#007bff") => `\n    <table cellpadding="0" cellspacing="0" style="margin: 20px 0;">\n      <tr>\n        <td style="background-color: ${color}; border-radius: 4px; padding: 12px 24px;">\n          <a href="${url}" style="color: white; text-decoration: none; font-weight: bold;">\n            ${text}\n          </a>\n        </td>\n      </tr>\n    </table>\n  `,\n  \n  alert: (message, type = "info") => `\n    <div style="padding: 15px; margin: 20px 0; border-left: 4px solid ${getAlertColor(type)}; background-color: #f8f9fa;">\n      ${message}\n    </div>\n  `\n};\n```\n\n## Template Types\n\n### 1. Transactional Emails\n\n- Welcome messages\n- Password resets\n- Order confirmations\n- Account notifications\n\n### 2. Marketing Emails\n\n- Newsletters\n- Product announcements\n- Promotional campaigns\n- Event invitations\n\n### 3. System Notifications\n\n- Error alerts\n- System maintenance\n- Security notifications\n- Performance reports\n\n## Responsive Design\n\n```css\n@media screen and (max-width: 600px) {\n  .container {\n    width: 100% !important;\n    margin: 0 !important;\n  }\n  \n  .content {\n    padding: 20px 15px !important;\n  }\n  \n  .button {\n    width: 100% !important;\n    text-align: center !important;\n  }\n}\n```\n\n## Testing Strategy\n\n1. **Email client testing**: Gmail, Outlook, Apple Mail\n2. **Device testing**: Desktop, mobile, tablet\n3. **Dark mode testing**: iOS, Android, desktop clients\n4. **Accessibility testing**: Screen readers, keyboard navigation\n\n## Automation and Personalization\n\n```javascript\nconst personalizeEmail = (template, userData) => {\n  return template\n    .replace("{{user_name}}", userData.name)\n    .replace("{{user_email}}", userData.email)\n    .replace("{{custom_content}}", generateCustomContent(userData));\n};\n```\n\n## Performance Optimization\n\n- Optimize images for email\n- Use web-safe fonts\n- Minimize HTML size\n- Implement proper caching\n- Monitor delivery rates\n\nA well-designed email template system ensures consistent, professional communication that engages your audience across all devices and email clients.	markdown	t	ai_response	\N	{"topics": ["email", "templates", "communication", "html"], "word_count": 1150, "content_type": "blog_post", "generated_by": "ai_agent", "reading_time_minutes": 5}	{}	2025-10-06 21:18:09.981049+00	2025-10-06 21:18:09.981049+00
7198727f-e854-4363-b52d-9a7dd479f3a7	9735c935-af21-4d36-a568-a1e8f21d228d	1	# Search Functionality: Building Fast and Relevant Results\n\nImplementing effective search functionality can make or break user experience. This guide explores different search approaches, from simple text matching to advanced full-text search with ranking algorithms.\n\n## Search Implementation Strategies\n\n### 1. Database Full-Text Search\n\nMost databases offer built-in full-text search:\n\n**PostgreSQL:**\n```sql\n-- Create a text search vector\nALTER TABLE articles ADD COLUMN search_vector tsvector;\n\n-- Update search vector\nUPDATE articles SET search_vector = \n  to_tsvector('english', title || ' ' || content);\n\n-- Create index for performance\nCREATE INDEX articles_search_idx ON articles USING gin(search_vector);\n\n-- Search query\nSELECT title, \n       ts_rank(search_vector, query) as rank\nFROM articles, \n     to_tsquery('english', 'javascript & tutorial') query\nWHERE search_vector @@ query\nORDER BY rank DESC;\n```\n\n**MySQL:**\n```sql\n-- Create full-text index\nALTER TABLE articles ADD FULLTEXT(title, content);\n\n-- Search with relevance scoring\nSELECT title,\n       MATCH(title, content) AGAINST('javascript tutorial') as relevance\nFROM articles\nWHERE MATCH(title, content) AGAINST('javascript tutorial')\nORDER BY relevance DESC;\n```\n\n### 2. Elasticsearch Integration\n\nFor advanced search capabilities:\n\n```javascript\nconst { Client } = require('@elastic/elasticsearch');\nconst client = new Client({ node: 'http://localhost:9200' });\n\n// Index a document\nawait client.index({\n  index: 'articles',\n  id: 1,\n  body: {\n    title: 'JavaScript Tutorial',\n    content: 'Learn JavaScript fundamentals...',\n    tags: ['javascript', 'tutorial', 'programming'],\n    published_date: '2024-01-15'\n  }\n});\n\n// Search with multiple criteria\nconst searchResult = await client.search({\n  index: 'articles',\n  body: {\n    query: {\n      bool: {\n        must: [\n          {\n            multi_match: {\n              query: 'javascript tutorial',\n              fields: ['title^2', 'content', 'tags']\n            }\n          }\n        ],\n        filter: [\n          {\n            range: {\n              published_date: {\n                gte: '2024-01-01'\n              }\n            }\n          }\n        ]\n      }\n    },\n    highlight: {\n      fields: {\n        title: {},\n        content: {}\n      }\n    }\n  }\n});\n```\n\n## Search UX Best Practices\n\n### 1. Auto-complete and Suggestions\n\n```javascript\nconst searchSuggestions = async (query) => {\n  if (query.length < 2) return [];\n  \n  const suggestions = await client.search({\n    index: 'articles',\n    body: {\n      suggest: {\n        article_suggest: {\n          prefix: query,\n          completion: {\n            field: 'suggest',\n            size: 5\n          }\n        }\n      }\n    }\n  });\n  \n  return suggestions.body.suggest.article_suggest[0].options;\n};\n```\n\n### 2. Search Filters and Facets\n\n```javascript\nconst searchWithFilters = async (query, filters = {}) => {\n  const must = [{\n    multi_match: {\n      query: query,\n      fields: ['title^2', 'content']\n    }\n  }];\n  \n  const filter = [];\n  \n  if (filters.category) {\n    filter.push({ term: { category: filters.category } });\n  }\n  \n  if (filters.dateRange) {\n    filter.push({\n      range: {\n        published_date: {\n          gte: filters.dateRange.start,\n          lte: filters.dateRange.end\n        }\n      }\n    });\n  }\n  \n  return await client.search({\n    index: 'articles',\n    body: {\n      query: { bool: { must, filter } },\n      aggs: {\n        categories: {\n          terms: { field: 'category' }\n        },\n        date_histogram: {\n          date_histogram: {\n            field: 'published_date',\n            calendar_interval: 'month'\n          }\n        }\n      }\n    }\n  });\n};\n```\n\n## Performance Optimization\n\n### 1. Caching Strategies\n\n```javascript\nconst Redis = require('redis');\nconst redis = Redis.createClient();\n\nconst searchWithCache = async (query) => {\n  const cacheKey = `search:${query}`;\n  const cached = await redis.get(cacheKey);\n  \n  if (cached) {\n    return JSON.parse(cached);\n  }\n  \n  const results = await performSearch(query);\n  await redis.setex(cacheKey, 300, JSON.stringify(results)); // Cache for 5 minutes\n  \n  return results;\n};\n```\n\n### 2. Search Analytics\n\n```javascript\nconst trackSearch = async (query, results, userId) => {\n  await analytics.track({\n    event: 'Search Performed',\n    userId: userId,\n    properties: {\n      query: query,\n      results_count: results.length,\n      timestamp: new Date().toISOString()\n    }\n  });\n};\n```\n\n## Search Quality Metrics\n\n- **Click-through rate**: How often users click search results\n- **Zero-result searches**: Queries that return no results\n- **Search abandonment**: Users who search but don't interact with results\n- **Query reformulation**: Users who modify their search terms\n\nGreat search functionality anticipates user needs and delivers relevant results quickly, making your application more discoverable and user-friendly.	markdown	t	ai_response	\N	{"topics": ["search", "elasticsearch", "performance", "ux"], "word_count": 1250, "content_type": "blog_post", "generated_by": "ai_agent", "reading_time_minutes": 6}	{}	2025-10-07 21:18:09.981049+00	2025-10-07 21:18:09.981049+00
4b5e0ea9-6e44-4430-a603-c9d601e3d010	546aba1a-02a2-4d31-82ba-1518cec015f0	1	# Application Performance Optimization: Speed at Scale\n\nPerformance optimization is an ongoing process that directly impacts user experience and business metrics. This comprehensive guide covers frontend, backend, and infrastructure optimizations that deliver measurable improvements.\n\n## Performance Metrics That Matter\n\n### Core Web Vitals\n\n- **Largest Contentful Paint (LCP)**: < 2.5 seconds\n- **First Input Delay (FID)**: < 100 milliseconds\n- **Cumulative Layout Shift (CLS)**: < 0.1\n\n### Additional Metrics\n\n- **First Contentful Paint (FCP)**: < 1.8 seconds\n- **Time to Interactive (TTI)**: < 3.8 seconds\n- **Total Blocking Time (TBT)**: < 200 milliseconds\n\n## Frontend Optimization\n\n### 1. Code Splitting and Lazy Loading\n\n```javascript\n// Route-based code splitting\nconst Dashboard = lazy(() => import('./Dashboard'));\nconst Settings = lazy(() => import('./Settings'));\n\nfunction App() {\n  return (\n    <Router>\n      <Suspense fallback={<div>Loading...</div>}>\n        <Routes>\n          <Route path="/dashboard" element={<Dashboard />} />\n          <Route path="/settings" element={<Settings />} />\n        </Routes>\n      </Suspense>\n    </Router>\n  );\n}\n\n// Component-level lazy loading\nconst HeavyChart = lazy(() => \n  import('./HeavyChart').then(module => ({\n    default: module.HeavyChart\n  }))\n);\n```\n\n### 2. Image Optimization\n\n```javascript\n// Modern image formats with fallbacks\nconst OptimizedImage = ({ src, alt, width, height }) => {\n  return (\n    <picture>\n      <source srcSet={`${src}.webp`} type="image/webp" />\n      <source srcSet={`${src}.avif`} type="image/avif" />\n      <img \n        src={`${src}.jpg`}\n        alt={alt}\n        width={width}\n        height={height}\n        loading="lazy"\n        decoding="async"\n      />\n    </picture>\n  );\n};\n\n// Responsive images\nconst ResponsiveImage = ({ src, alt }) => {\n  const srcSet = [\n    `${src}-400w.jpg 400w`,\n    `${src}-800w.jpg 800w`,\n    `${src}-1200w.jpg 1200w`\n  ].join(', ');\n  \n  return (\n    <img \n      src={`${src}-800w.jpg`}\n      srcSet={srcSet}\n      sizes="(max-width: 400px) 400px, (max-width: 800px) 800px, 1200px"\n      alt={alt}\n      loading="lazy"\n    />\n  );\n};\n```\n\n### 3. Memory Management\n\n```javascript\n// Proper cleanup in React\nuseEffect(() => {\n  const subscription = api.subscribe(data => {\n    setData(data);\n  });\n  \n  const timeoutId = setTimeout(() => {\n    // Some delayed operation\n  }, 5000);\n  \n  // Cleanup function\n  return () => {\n    subscription.unsubscribe();\n    clearTimeout(timeoutId);\n  };\n}, []);\n\n// Memoization for expensive calculations\nconst expensiveValue = useMemo(() => {\n  return heavyCalculation(data);\n}, [data]);\n\nconst memoizedComponent = memo(({ items }) => {\n  return (\n    <ul>\n      {items.map(item => <li key={item.id}>{item.name}</li>)}\n    </ul>\n  );\n});\n```\n\n## Backend Optimization\n\n### 1. Database Query Optimization\n\n```sql\n-- Add appropriate indexes\nCREATE INDEX idx_orders_user_id_created_at ON orders(user_id, created_at DESC);\nCREATE INDEX idx_products_category_price ON products(category, price);\n\n-- Optimize queries with EXPLAIN\nEXPLAIN ANALYZE\nSELECT p.name, p.price, c.name as category_name\nFROM products p\nJOIN categories c ON p.category_id = c.id\nWHERE p.price BETWEEN 10 AND 100\nAND c.active = true\nORDER BY p.created_at DESC\nLIMIT 20;\n\n-- Use query result caching\nSELECT /*+ USE_QUERY_CACHE */ \n       product_id, name, price\nFROM products\nWHERE category = 'electronics'\nAND price < 500;\n```\n\n### 2. API Response Optimization\n\n```javascript\n// Implement response compression\nconst compression = require('compression');\napp.use(compression());\n\n// Add response caching headers\napp.get('/api/products', (req, res) => {\n  res.set({\n    'Cache-Control': 'public, max-age=3600', // 1 hour\n    'ETag': generateETag(products),\n    'Last-Modified': lastModifiedDate\n  });\n  \n  res.json(products);\n});\n\n// Implement pagination\napp.get('/api/products', async (req, res) => {\n  const page = parseInt(req.query.page) || 1;\n  const limit = parseInt(req.query.limit) || 20;\n  const offset = (page - 1) * limit;\n  \n  const products = await Product.findAll({\n    limit,\n    offset,\n    order: [['created_at', 'DESC']]\n  });\n  \n  const total = await Product.count();\n  \n  res.json({\n    data: products,\n    pagination: {\n      page,\n      limit,\n      total,\n      pages: Math.ceil(total / limit)\n    }\n  });\n});\n```\n\n## Infrastructure Optimization\n\n### 1. CDN Configuration\n\n```javascript\n// CloudFront distribution settings\nconst distributionConfig = {\n  Origins: [{\n    DomainName: 'api.example.com',\n    CustomOriginConfig: {\n      HTTPPort: 443,\n      OriginProtocolPolicy: 'https-only'\n    }\n  }],\n  DefaultCacheBehavior: {\n    TargetOriginId: 'api-origin',\n    ViewerProtocolPolicy: 'redirect-to-https',\n    CachePolicyId: 'custom-cache-policy',\n    Compress: true\n  },\n  CacheBehaviors: [{\n    PathPattern: '/static/*',\n    CachePolicyId: 'static-assets-policy',\n    TTL: 31536000 // 1 year\n  }]\n};\n```\n\n### 2. Load Balancing\n\n```yaml\n# nginx.conf\nupstream app_servers {\n    least_conn;\n    server app1:3000 weight=3;\n    server app2:3000 weight=3;\n    server app3:3000 weight=2;\n}\n\nserver {\n    listen 80;\n    server_name example.com;\n    \n    location / {\n        proxy_pass http://app_servers;\n        proxy_set_header Host $host;\n        proxy_set_header X-Real-IP $remote_addr;\n        proxy_cache_bypass $http_upgrade;\n    }\n    \n    location /static/ {\n        expires 1y;\n        add_header Cache-Control "public, immutable";\n        root /var/www;\n    }\n}\n```\n\n## Monitoring and Alerting\n\n```javascript\n// Performance monitoring\nconst performanceObserver = new PerformanceObserver((list) => {\n  for (const entry of list.getEntries()) {\n    if (entry.entryType === 'navigation') {\n      analytics.track('Page Load Performance', {\n        loadTime: entry.loadEventEnd - entry.loadEventStart,\n        domContentLoaded: entry.domContentLoadedEventEnd - entry.domContentLoadedEventStart,\n        firstPaint: entry.responseEnd - entry.requestStart\n      });\n    }\n  }\n});\n\nperformanceObserver.observe({ entryTypes: ['navigation', 'paint'] });\n```\n\nRemember: measure first, optimize second. Use real user monitoring to identify bottlenecks, then apply targeted optimizations that provide the biggest impact for your specific use case.	markdown	t	ai_response	\N	{"topics": ["performance", "optimization", "frontend", "backend"], "word_count": 1400, "content_type": "blog_post", "generated_by": "ai_agent", "reading_time_minutes": 6}	{}	2025-10-08 21:18:09.981049+00	2025-10-08 21:18:09.981049+00
ded4e8e5-1bfd-4515-9894-a272e93a1f35	5dfb6f49-6497-4882-939e-1c12efb9ffc3	1	# Security Audit Checklist: Protecting Your Application\n\nA comprehensive security audit is essential for protecting your application and user data. This checklist covers the most critical security areas that every application should address.\n\n## Authentication and Authorization\n\n### ✅ Authentication Security\n\n- [ ] **Strong password policies** enforced (minimum 8 characters, complexity requirements)\n- [ ] **Multi-factor authentication** available for sensitive accounts\n- [ ] **Account lockout** after failed login attempts (5-10 attempts)\n- [ ] **Password reset** tokens expire within reasonable time (15-30 minutes)\n- [ ] **Session management** with secure cookies and proper expiration\n- [ ] **Brute force protection** implemented (rate limiting, CAPTCHA)\n\n### ✅ Authorization Controls\n\n- [ ] **Principle of least privilege** applied to all user roles\n- [ ] **Role-based access control** properly implemented\n- [ ] **API endpoints** protected with proper authentication\n- [ ] **Direct object references** validated (prevent IDOR attacks)\n- [ ] **Admin functions** require additional verification\n\n## Data Protection\n\n### ✅ Data Encryption\n\n```javascript\n// Encrypt sensitive data at rest\nconst crypto = require('crypto');\n\nconst encryptData = (text, key) => {\n  const algorithm = 'aes-256-gcm';\n  const iv = crypto.randomBytes(16);\n  const cipher = crypto.createCipher(algorithm, key, iv);\n  \n  let encrypted = cipher.update(text, 'utf8', 'hex');\n  encrypted += cipher.final('hex');\n  \n  const authTag = cipher.getAuthTag();\n  \n  return {\n    encrypted,\n    iv: iv.toString('hex'),\n    authTag: authTag.toString('hex')\n  };\n};\n```\n\n### ✅ Data Handling\n\n- [ ] **PII data** properly classified and protected\n- [ ] **Data retention** policies implemented\n- [ ] **Secure data deletion** when no longer needed\n- [ ] **Database encryption** enabled for sensitive tables\n- [ ] **Backup encryption** for all data backups\n- [ ] **Data masking** in non-production environments\n\n## Input Validation and Sanitization\n\n### ✅ SQL Injection Prevention\n\n```javascript\n// Use parameterized queries\nconst getUserById = async (userId) => {\n  // ✅ SECURE: Parameterized query\n  const query = 'SELECT * FROM users WHERE id = $1';\n  const result = await db.query(query, [userId]);\n  return result.rows[0];\n};\n\n// ❌ VULNERABLE: String concatenation\n// const query = `SELECT * FROM users WHERE id = ${userId}`;\n```\n\n### ✅ XSS Prevention\n\n```javascript\n// Sanitize user input\nconst DOMPurify = require('dompurify');\n\nconst sanitizeInput = (userInput) => {\n  return DOMPurify.sanitize(userInput, {\n    ALLOWED_TAGS: ['b', 'i', 'em', 'strong'],\n    ALLOWED_ATTR: []\n  });\n};\n\n// Content Security Policy headers\napp.use((req, res, next) => {\n  res.setHeader(\n    'Content-Security-Policy',\n    "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'"\n  );\n  next();\n});\n```\n\n### ✅ Input Validation Checklist\n\n- [ ] **All user inputs** validated on both client and server\n- [ ] **File uploads** restricted by type, size, and content\n- [ ] **Email addresses** properly validated\n- [ ] **URLs** validated before processing\n- [ ] **JSON payloads** size-limited and schema-validated\n\n## Network Security\n\n### ✅ HTTPS and Transport Security\n\n```javascript\n// Force HTTPS in production\napp.use((req, res, next) => {\n  if (process.env.NODE_ENV === 'production' && !req.secure) {\n    return res.redirect(301, `https://${req.headers.host}${req.url}`);\n  }\n  next();\n});\n\n// Security headers\nconst helmet = require('helmet');\napp.use(helmet({\n  hsts: {\n    maxAge: 31536000,\n    includeSubDomains: true,\n    preload: true\n  },\n  contentSecurityPolicy: {\n    directives: {\n      defaultSrc: ["'self'"],\n      styleSrc: ["'self'", "'unsafe-inline'"],\n      scriptSrc: ["'self'"],\n      imgSrc: ["'self'", "data:", "https:"],\n    },\n  },\n}));\n```\n\n### ✅ Network Security Checklist\n\n- [ ] **TLS 1.2+** enforced for all connections\n- [ ] **Certificate pinning** implemented for mobile apps\n- [ ] **CORS policies** properly configured\n- [ ] **Rate limiting** on all public endpoints\n- [ ] **DDoS protection** in place\n- [ ] **Firewall rules** restricting unnecessary ports\n\n## Infrastructure Security\n\n### ✅ Server Hardening\n\n```bash\n# Update system packages\nsudo apt update && sudo apt upgrade -y\n\n# Configure firewall\nsudo ufw default deny incoming\nsudo ufw default allow outgoing\nsudo ufw allow ssh\nsudo ufw allow 80\nsudo ufw allow 443\nsudo ufw enable\n\n# Disable unnecessary services\nsudo systemctl disable apache2\nsudo systemctl stop apache2\n\n# Set up fail2ban for SSH protection\nsudo apt install fail2ban\nsudo systemctl enable fail2ban\n```\n\n### ✅ Infrastructure Checklist\n\n- [ ] **Operating systems** kept up to date\n- [ ] **Unnecessary services** disabled\n- [ ] **SSH keys** used instead of passwords\n- [ ] **Regular security patches** applied\n- [ ] **Monitoring and logging** enabled\n- [ ] **Backup and recovery** procedures tested\n\n## Application Security\n\n### ✅ Dependency Management\n\n```bash\n# Audit npm dependencies\nnpm audit\nnpm audit fix\n\n# Use Snyk for continuous monitoring\nnpx snyk test\nnpx snyk monitor\n\n# Keep dependencies updated\nnpm outdated\nnpm update\n```\n\n### ✅ Error Handling\n\n```javascript\n// Secure error handling\napp.use((err, req, res, next) => {\n  // Log full error details internally\n  console.error(err.stack);\n  \n  // Return generic error to client\n  if (process.env.NODE_ENV === 'production') {\n    res.status(500).json({\n      error: 'Internal server error',\n      message: 'Something went wrong'\n    });\n  } else {\n    res.status(500).json({\n      error: err.message,\n      stack: err.stack\n    });\n  }\n});\n```\n\n## Compliance and Documentation\n\n### ✅ Compliance Checklist\n\n- [ ] **GDPR compliance** for EU users\n- [ ] **CCPA compliance** for California users\n- [ ] **Privacy policy** updated and accessible\n- [ ] **Terms of service** current\n- [ ] **Data processing agreements** with third parties\n- [ ] **Incident response plan** documented and tested\n\n## Security Testing\n\n### ✅ Regular Security Testing\n\n- [ ] **Automated security scanning** integrated into CI/CD\n- [ ] **Penetration testing** performed annually\n- [ ] **Code reviews** include security considerations\n- [ ] **Vulnerability assessments** conducted quarterly\n- [ ] **Security training** provided to development team\n\nRemember: security is not a one-time task but an ongoing process. Regular audits, updates, and monitoring are essential for maintaining a secure application.	markdown	t	ai_response	\N	{"topics": ["security", "audit", "checklist", "compliance"], "word_count": 1350, "content_type": "blog_post", "generated_by": "ai_agent", "reading_time_minutes": 6}	{}	2025-10-09 21:18:09.981049+00	2025-10-09 21:18:09.981049+00
\.


--
-- TOC entry 5001 (class 0 OID 18327)
-- Dependencies: 291
-- Data for Name: deliverables; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deliverables (id, user_id, conversation_id, project_step_id, agent_name, title, type, created_at, updated_at) FROM stdin;
1432230a-6eab-4001-8487-9d27809f37f6	b29a590e-b07f-49df-a25b-574c956b5035	66f858b9-0d63-4afa-9052-10b661543c05	\N	Dashboard Builder Agent	Dashboard Component Specification	specification	2025-09-30 19:48:09.981049+00	2025-09-30 20:48:09.981049+00
4816b176-aba8-4f82-a9cc-3929430e897a	b29a590e-b07f-49df-a25b-574c956b5035	5931a44f-506e-4377-b637-bf5bdfe79e8b	\N	Authentication Agent	Authentication Implementation Guide	guide	2025-10-01 19:48:09.981049+00	2025-10-01 20:48:09.981049+00
60a1aefa-5dae-43b2-9682-3fae275da290	b29a590e-b07f-49df-a25b-574c956b5035	91642195-1f88-4f3d-a88d-bc5d05440f80	\N	Database Designer Agent	Database Schema Documentation	documentation	2025-10-02 19:48:09.981049+00	2025-10-02 20:48:09.981049+00
9f6ccb77-9b74-4531-8800-5dca05662230	b29a590e-b07f-49df-a25b-574c956b5035	2e536d84-d5c8-4c2e-bf58-436b5d7dd493	\N	API Security Agent	Rate Limiting Strategy Document	strategy	2025-10-03 19:48:09.981049+00	2025-10-03 20:48:09.981049+00
0d2913b0-9775-4b0a-82a2-e69090e99555	b29a590e-b07f-49df-a25b-574c956b5035	bff9ce60-05b5-42fb-b508-8bf3b973aadd	\N	Mobile UX Agent	Mobile Navigation Wireframes	wireframes	2025-10-04 19:48:09.981049+00	2025-10-04 20:48:09.981049+00
c7aa1741-7264-4daf-8ac8-4913f3364267	b29a590e-b07f-49df-a25b-574c956b5035	c6741ed7-9003-4921-8dda-9aa6729f2916	\N	Payment Integration Agent	Payment Integration Setup Guide	guide	2025-10-05 19:48:09.981049+00	2025-10-05 20:48:09.981049+00
6ef02b65-cf27-4b78-a791-5f2e1b4e7065	b29a590e-b07f-49df-a25b-574c956b5035	70afc481-1bbd-4c2f-9bf7-68dfbc2dc3ee	\N	Email Template Agent	Email Template Design System	design_system	2025-10-06 19:48:09.981049+00	2025-10-06 20:48:09.981049+00
9735c935-af21-4d36-a568-a1e8f21d228d	b29a590e-b07f-49df-a25b-574c956b5035	d6671925-606e-462b-ae7c-66f46bf3f1b4	\N	Search Optimization Agent	Search Algorithm Documentation	documentation	2025-10-07 19:48:09.981049+00	2025-10-07 20:48:09.981049+00
546aba1a-02a2-4d31-82ba-1518cec015f0	b29a590e-b07f-49df-a25b-574c956b5035	9e6f502b-ba20-4e24-88a7-0ce85149c18b	\N	Performance Agent	Performance Optimization Report	report	2025-10-08 19:48:09.981049+00	2025-10-08 20:48:09.981049+00
5dfb6f49-6497-4882-939e-1c12efb9ffc3	b29a590e-b07f-49df-a25b-574c956b5035	9cfb3f53-02c6-4951-8e04-0fb624fad0e7	\N	Security Audit Agent	Security Audit Checklist	checklist	2025-10-09 19:48:09.981049+00	2025-10-09 20:48:09.981049+00
\.


--
-- TOC entry 5002 (class 0 OID 18335)
-- Dependencies: 292
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.departments (id, company_id, name, head_of_department, budget, created_at, updated_at) FROM stdin;
f74fdc4e-6a3b-4880-9558-8716b9671d01	5ea464e8-9a64-453d-9c46-a6908b7e01ad	Sales	\N	1000000.00	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
ce7d2204-b6cd-494c-9adf-8ebae0aa8262	5ea464e8-9a64-453d-9c46-a6908b7e01ad	Professional Services	\N	1000000.00	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
f0c47c0c-5944-492e-b604-59469f1633bb	5ea464e8-9a64-453d-9c46-a6908b7e01ad	Enterprise Accounts	\N	1000000.00	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
\.


--
-- TOC entry 5018 (class 0 OID 18872)
-- Dependencies: 308
-- Data for Name: human_approvals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.human_approvals (id, organization_slug, agent_slug, conversation_id, task_id, mode, status, approved_by, decision_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5003 (class 0 OID 18343)
-- Dependencies: 293
-- Data for Name: kpi_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kpi_data (id, department_id, metric_id, value, date_recorded, created_at, updated_at) FROM stdin;
a350251a-0865-43bf-812b-64040d144208	f74fdc4e-6a3b-4880-9558-8716b9671d01	d12bd211-7c3f-4434-baa2-46b89aa7f2d4	14597.0000	2025-10-08	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
c7a48dd5-7e0e-4453-b410-0eddb78ef1d5	f74fdc4e-6a3b-4880-9558-8716b9671d01	cca4d9f2-271f-4c1d-bf84-09c3daf980bf	7597.0000	2025-10-08	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
6ecae517-83ef-4571-ba9d-9d52185bbe06	f74fdc4e-6a3b-4880-9558-8716b9671d01	6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	4597.0000	2025-10-08	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
53fd1f61-ba13-4bed-ace3-af9e180bf833	f74fdc4e-6a3b-4880-9558-8716b9671d01	310398dc-1f31-4d5c-b172-7da2ecfd00c8	1097.0000	2025-10-08	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
3af43532-da72-4a5a-877f-9f436613914f	f74fdc4e-6a3b-4880-9558-8716b9671d01	708be761-243b-4970-bffc-0f46a20b188d	2097.0000	2025-10-08	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
2c619a53-a725-4b63-bd6d-435a9713df2d	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	d12bd211-7c3f-4434-baa2-46b89aa7f2d4	14597.0000	2025-10-08	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
9eb96801-d56f-46fd-aa1b-f2bc2456e157	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	cca4d9f2-271f-4c1d-bf84-09c3daf980bf	7597.0000	2025-10-08	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
fa60372b-aba9-42de-88b1-bc5bc0db4d48	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	4597.0000	2025-10-08	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
43fe8134-fba8-42ba-8d21-4d4131124059	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	310398dc-1f31-4d5c-b172-7da2ecfd00c8	1097.0000	2025-10-08	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
2c66854d-ec9d-46b1-b44a-578e12ca85d9	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	708be761-243b-4970-bffc-0f46a20b188d	2097.0000	2025-10-08	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
735c3210-6189-4ee0-8f4f-4dd12f007246	f0c47c0c-5944-492e-b604-59469f1633bb	d12bd211-7c3f-4434-baa2-46b89aa7f2d4	14597.0000	2025-10-08	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
4f36f59d-c846-4ede-bd03-5e7ee27848a9	f0c47c0c-5944-492e-b604-59469f1633bb	cca4d9f2-271f-4c1d-bf84-09c3daf980bf	7597.0000	2025-10-08	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
43c0df09-da59-41b4-9673-a6f2d2c06147	f0c47c0c-5944-492e-b604-59469f1633bb	6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	4597.0000	2025-10-08	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
057e5384-5e1a-4368-ba2f-4c6f7983f4fa	f0c47c0c-5944-492e-b604-59469f1633bb	310398dc-1f31-4d5c-b172-7da2ecfd00c8	1097.0000	2025-10-08	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
1293e22f-fdc7-4935-a83e-a25c34db8470	f0c47c0c-5944-492e-b604-59469f1633bb	708be761-243b-4970-bffc-0f46a20b188d	2097.0000	2025-10-08	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
d91d49c7-b6d7-458c-98cb-e880a87a45ba	f74fdc4e-6a3b-4880-9558-8716b9671d01	d12bd211-7c3f-4434-baa2-46b89aa7f2d4	14694.0000	2025-10-07	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
09676ae4-b1cf-42d3-8a4b-96ea501c97ba	f74fdc4e-6a3b-4880-9558-8716b9671d01	cca4d9f2-271f-4c1d-bf84-09c3daf980bf	7694.0000	2025-10-07	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
f89963db-962b-4b99-af3d-196953286c64	f74fdc4e-6a3b-4880-9558-8716b9671d01	6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	4694.0000	2025-10-07	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
453b314d-cc98-4cdd-b806-017184e29b3e	f74fdc4e-6a3b-4880-9558-8716b9671d01	310398dc-1f31-4d5c-b172-7da2ecfd00c8	1194.0000	2025-10-07	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
77071353-cbad-4654-9ab4-ce067ee644bd	f74fdc4e-6a3b-4880-9558-8716b9671d01	708be761-243b-4970-bffc-0f46a20b188d	2194.0000	2025-10-07	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
f34fac78-358f-465a-aa70-7bc5132ca5b7	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	d12bd211-7c3f-4434-baa2-46b89aa7f2d4	14694.0000	2025-10-07	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
bbda0033-6741-4b5a-8f26-a1fed6bb6e14	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	cca4d9f2-271f-4c1d-bf84-09c3daf980bf	7694.0000	2025-10-07	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
d2e4ade3-500d-45e7-9ebb-4d8c5563a55b	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	4694.0000	2025-10-07	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
b4755561-00fb-4708-9495-7f01dbe5a022	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	310398dc-1f31-4d5c-b172-7da2ecfd00c8	1194.0000	2025-10-07	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
2daea62b-af54-483f-a6c8-5030a2b9fa54	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	708be761-243b-4970-bffc-0f46a20b188d	2194.0000	2025-10-07	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
02b2681d-35ab-4b98-9a65-cf93d89ef9c3	f0c47c0c-5944-492e-b604-59469f1633bb	d12bd211-7c3f-4434-baa2-46b89aa7f2d4	14694.0000	2025-10-07	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
8ab37b3b-8ea7-4d81-97dc-dfc3e6e05eac	f0c47c0c-5944-492e-b604-59469f1633bb	cca4d9f2-271f-4c1d-bf84-09c3daf980bf	7694.0000	2025-10-07	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
1c57a66a-7998-4547-8e52-bf951e3a0c6b	f0c47c0c-5944-492e-b604-59469f1633bb	6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	4694.0000	2025-10-07	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
332785af-a054-413f-8d7e-107d424604e3	f0c47c0c-5944-492e-b604-59469f1633bb	310398dc-1f31-4d5c-b172-7da2ecfd00c8	1194.0000	2025-10-07	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
0563d784-982f-45ae-8325-3bbd535386b7	f0c47c0c-5944-492e-b604-59469f1633bb	708be761-243b-4970-bffc-0f46a20b188d	2194.0000	2025-10-07	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
d07a5ab4-fcb4-4921-ab39-385ab09c93cb	f74fdc4e-6a3b-4880-9558-8716b9671d01	d12bd211-7c3f-4434-baa2-46b89aa7f2d4	14791.0000	2025-10-06	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
57a457a4-4c50-4f95-bef9-139a1603a994	f74fdc4e-6a3b-4880-9558-8716b9671d01	cca4d9f2-271f-4c1d-bf84-09c3daf980bf	7791.0000	2025-10-06	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
e1dfab09-8b87-44de-86e6-c35b3ba21c6c	f74fdc4e-6a3b-4880-9558-8716b9671d01	6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	4791.0000	2025-10-06	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
617179c7-1641-4d0c-93c9-7c44bbe35515	f74fdc4e-6a3b-4880-9558-8716b9671d01	310398dc-1f31-4d5c-b172-7da2ecfd00c8	1291.0000	2025-10-06	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
51a75758-f0b7-4c6c-a17e-bf0f91a384ae	f74fdc4e-6a3b-4880-9558-8716b9671d01	708be761-243b-4970-bffc-0f46a20b188d	2291.0000	2025-10-06	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
77d0f215-6a7d-4c7d-96b1-a2e830c1481b	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	d12bd211-7c3f-4434-baa2-46b89aa7f2d4	14791.0000	2025-10-06	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
9f42c48b-26fc-4abe-bea7-546df9b6322f	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	cca4d9f2-271f-4c1d-bf84-09c3daf980bf	7791.0000	2025-10-06	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
0ffebb0a-ea7e-4dd7-bbee-103ec8f4af83	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	4791.0000	2025-10-06	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
036f8c46-dff2-45db-9ef3-d87d32fbbe83	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	310398dc-1f31-4d5c-b172-7da2ecfd00c8	1291.0000	2025-10-06	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
18475936-2ab3-4ab2-9c88-ca8393cbde64	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	708be761-243b-4970-bffc-0f46a20b188d	2291.0000	2025-10-06	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
0002f562-9385-484e-9b99-a3cc90b7781b	f0c47c0c-5944-492e-b604-59469f1633bb	d12bd211-7c3f-4434-baa2-46b89aa7f2d4	14791.0000	2025-10-06	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
52101ccf-d274-4445-9464-0debbb0094a8	f0c47c0c-5944-492e-b604-59469f1633bb	cca4d9f2-271f-4c1d-bf84-09c3daf980bf	7791.0000	2025-10-06	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
fc3785f4-2b4f-4f21-8677-c4fba61fad82	f0c47c0c-5944-492e-b604-59469f1633bb	6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	4791.0000	2025-10-06	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
a4fd7a98-2989-4952-853e-92689ce04153	f0c47c0c-5944-492e-b604-59469f1633bb	310398dc-1f31-4d5c-b172-7da2ecfd00c8	1291.0000	2025-10-06	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
2e40070e-4d9a-45ee-9161-adbe70e16165	f0c47c0c-5944-492e-b604-59469f1633bb	708be761-243b-4970-bffc-0f46a20b188d	2291.0000	2025-10-06	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
3c17d546-e1c0-4c4f-8173-9dab5f1c88c4	f74fdc4e-6a3b-4880-9558-8716b9671d01	d12bd211-7c3f-4434-baa2-46b89aa7f2d4	14888.0000	2025-10-05	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
6719cd9b-8ab3-457c-820e-8b9fec78b2f1	f74fdc4e-6a3b-4880-9558-8716b9671d01	cca4d9f2-271f-4c1d-bf84-09c3daf980bf	7888.0000	2025-10-05	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
07ae6178-188f-48e5-b974-3d1b3018b13a	f74fdc4e-6a3b-4880-9558-8716b9671d01	6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	4888.0000	2025-10-05	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
21506812-ca3a-40b2-8b90-d21878dc7cd6	f74fdc4e-6a3b-4880-9558-8716b9671d01	310398dc-1f31-4d5c-b172-7da2ecfd00c8	1388.0000	2025-10-05	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
fcd78237-5615-4689-9052-cefa301bb31d	f74fdc4e-6a3b-4880-9558-8716b9671d01	708be761-243b-4970-bffc-0f46a20b188d	2388.0000	2025-10-05	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
8d81b0b5-43c8-422a-9d9f-0b2fa4d13814	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	d12bd211-7c3f-4434-baa2-46b89aa7f2d4	14888.0000	2025-10-05	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
e72467f1-faf8-4540-9323-29bf16a05fd1	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	cca4d9f2-271f-4c1d-bf84-09c3daf980bf	7888.0000	2025-10-05	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
f1d938db-ac23-46d3-a5b4-f2206e214e98	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	4888.0000	2025-10-05	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
d2cb82f4-d2a1-45a0-9fbf-91890f953841	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	310398dc-1f31-4d5c-b172-7da2ecfd00c8	1388.0000	2025-10-05	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
87f7e449-aeef-450b-a841-ac5e52a5ea02	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	708be761-243b-4970-bffc-0f46a20b188d	2388.0000	2025-10-05	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
436fab49-57b0-424b-bb48-1877efccfe7b	f0c47c0c-5944-492e-b604-59469f1633bb	d12bd211-7c3f-4434-baa2-46b89aa7f2d4	14888.0000	2025-10-05	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
b50d1d6c-74c7-486b-80ba-4096de245706	f0c47c0c-5944-492e-b604-59469f1633bb	cca4d9f2-271f-4c1d-bf84-09c3daf980bf	7888.0000	2025-10-05	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
35c97ba1-86f6-4399-8e19-bc620900625b	f0c47c0c-5944-492e-b604-59469f1633bb	6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	4888.0000	2025-10-05	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
7eaabb43-5ca9-40e3-8718-6db68b4fa486	f0c47c0c-5944-492e-b604-59469f1633bb	310398dc-1f31-4d5c-b172-7da2ecfd00c8	1388.0000	2025-10-05	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
54dee397-4a4f-4d91-8cee-056d5921cb23	f0c47c0c-5944-492e-b604-59469f1633bb	708be761-243b-4970-bffc-0f46a20b188d	2388.0000	2025-10-05	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
7dac0ddf-6088-48f0-a0ef-8ae54785a1cd	f74fdc4e-6a3b-4880-9558-8716b9671d01	d12bd211-7c3f-4434-baa2-46b89aa7f2d4	14985.0000	2025-10-04	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
e6a5da7f-771b-4e43-9300-7e3781945d28	f74fdc4e-6a3b-4880-9558-8716b9671d01	cca4d9f2-271f-4c1d-bf84-09c3daf980bf	7985.0000	2025-10-04	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
2a30d86c-5a98-4c96-a27d-31780cbc6b0d	f74fdc4e-6a3b-4880-9558-8716b9671d01	6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	4985.0000	2025-10-04	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
075a757e-dedc-4a1a-b021-c53b89cd746a	f74fdc4e-6a3b-4880-9558-8716b9671d01	310398dc-1f31-4d5c-b172-7da2ecfd00c8	1485.0000	2025-10-04	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
c439e432-51cc-4589-ac0e-f83b7ac38fbb	f74fdc4e-6a3b-4880-9558-8716b9671d01	708be761-243b-4970-bffc-0f46a20b188d	2485.0000	2025-10-04	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
bf55c304-8900-4440-857f-0d64dd777891	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	d12bd211-7c3f-4434-baa2-46b89aa7f2d4	14985.0000	2025-10-04	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
55829b74-8567-48a5-87b9-c1ac61fb798b	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	cca4d9f2-271f-4c1d-bf84-09c3daf980bf	7985.0000	2025-10-04	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
760355a2-91b8-41d7-8ef4-2c1b595f3952	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	4985.0000	2025-10-04	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
1e7faf7a-3634-4b02-a890-4bfda206a7d4	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	310398dc-1f31-4d5c-b172-7da2ecfd00c8	1485.0000	2025-10-04	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
307c0457-68ce-466e-a3c1-216247b84d6f	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	708be761-243b-4970-bffc-0f46a20b188d	2485.0000	2025-10-04	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
61dcbc1d-f2a2-4909-9697-57141bf35f03	f0c47c0c-5944-492e-b604-59469f1633bb	d12bd211-7c3f-4434-baa2-46b89aa7f2d4	14985.0000	2025-10-04	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
d08a0620-c562-40ba-bd46-05ab16a8cd9e	f0c47c0c-5944-492e-b604-59469f1633bb	cca4d9f2-271f-4c1d-bf84-09c3daf980bf	7985.0000	2025-10-04	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
b4ac4126-8d38-42be-b7ec-107e51e168dd	f0c47c0c-5944-492e-b604-59469f1633bb	6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	4985.0000	2025-10-04	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
277d9e09-4d35-4d4d-bf92-71db582ba6f6	f0c47c0c-5944-492e-b604-59469f1633bb	310398dc-1f31-4d5c-b172-7da2ecfd00c8	1485.0000	2025-10-04	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
df1dfe5b-7f6f-4944-8008-39a2c12d6f4a	f0c47c0c-5944-492e-b604-59469f1633bb	708be761-243b-4970-bffc-0f46a20b188d	2485.0000	2025-10-04	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
323455b5-19b9-4b58-a3de-a198a96a5d7b	f74fdc4e-6a3b-4880-9558-8716b9671d01	d12bd211-7c3f-4434-baa2-46b89aa7f2d4	15082.0000	2025-10-03	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
27b69907-ab31-4881-8dff-037fff7d0b94	f74fdc4e-6a3b-4880-9558-8716b9671d01	cca4d9f2-271f-4c1d-bf84-09c3daf980bf	8082.0000	2025-10-03	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
7660ba11-69d7-4a5b-8073-db8162d9147c	f74fdc4e-6a3b-4880-9558-8716b9671d01	6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	5082.0000	2025-10-03	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
1919c7d7-1650-4934-9597-f07d8a1eb88c	f74fdc4e-6a3b-4880-9558-8716b9671d01	310398dc-1f31-4d5c-b172-7da2ecfd00c8	1582.0000	2025-10-03	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
372e5023-1141-4470-9e85-ef452c9b98e8	f74fdc4e-6a3b-4880-9558-8716b9671d01	708be761-243b-4970-bffc-0f46a20b188d	2582.0000	2025-10-03	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
\.


--
-- TOC entry 5004 (class 0 OID 18349)
-- Dependencies: 294
-- Data for Name: kpi_goals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kpi_goals (id, department_id, metric_id, target_value, period_start, period_end, created_at, updated_at) FROM stdin;
52f5d36b-2243-499a-a93f-f0e7b2966941	f74fdc4e-6a3b-4880-9558-8716b9671d01	d12bd211-7c3f-4434-baa2-46b89aa7f2d4	500000.0000	2025-10-01	2025-12-31	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
ee1f210a-a376-4094-9596-ccd788e0be91	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	d12bd211-7c3f-4434-baa2-46b89aa7f2d4	500000.0000	2025-10-01	2025-12-31	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
bb68034e-3af0-4b73-96f4-5eda69abed4a	f0c47c0c-5944-492e-b604-59469f1633bb	d12bd211-7c3f-4434-baa2-46b89aa7f2d4	500000.0000	2025-10-01	2025-12-31	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
6cdbb058-7e84-4ce6-9847-45b6f9116cfe	f74fdc4e-6a3b-4880-9558-8716b9671d01	cca4d9f2-271f-4c1d-bf84-09c3daf980bf	250000.0000	2025-10-01	2025-12-31	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
d2d09f1f-8082-4e09-929b-499aa3a90d8e	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	cca4d9f2-271f-4c1d-bf84-09c3daf980bf	250000.0000	2025-10-01	2025-12-31	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
fa13e4b6-aa45-4006-87cc-51dc69135b72	f0c47c0c-5944-492e-b604-59469f1633bb	cca4d9f2-271f-4c1d-bf84-09c3daf980bf	250000.0000	2025-10-01	2025-12-31	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
d37e4e4d-d7bb-4473-8bd5-c90e619e7346	f74fdc4e-6a3b-4880-9558-8716b9671d01	6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	150000.0000	2025-10-01	2025-12-31	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
e805ef0a-8b43-410b-9b44-0be2435edfd8	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	150000.0000	2025-10-01	2025-12-31	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
d3dbe723-1ce6-49df-a964-466ad3b81e4d	f0c47c0c-5944-492e-b604-59469f1633bb	6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	150000.0000	2025-10-01	2025-12-31	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
6198c700-603f-474a-b4bb-72dfeba1c813	f74fdc4e-6a3b-4880-9558-8716b9671d01	310398dc-1f31-4d5c-b172-7da2ecfd00c8	50000.0000	2025-10-01	2025-12-31	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
2ab74b6d-4f5b-4bf4-ae57-01849092697e	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	310398dc-1f31-4d5c-b172-7da2ecfd00c8	50000.0000	2025-10-01	2025-12-31	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
9e87a0b8-21ef-4187-862c-04f950984cd0	f0c47c0c-5944-492e-b604-59469f1633bb	310398dc-1f31-4d5c-b172-7da2ecfd00c8	50000.0000	2025-10-01	2025-12-31	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
38f3f08e-fffd-480b-be22-a5e728c4d96b	f74fdc4e-6a3b-4880-9558-8716b9671d01	708be761-243b-4970-bffc-0f46a20b188d	75000.0000	2025-10-01	2025-12-31	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
118fa70d-6c3d-4894-bf1d-a31553541bfb	ce7d2204-b6cd-494c-9adf-8ebae0aa8262	708be761-243b-4970-bffc-0f46a20b188d	75000.0000	2025-10-01	2025-12-31	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
8b9e0562-5815-4601-9846-7ce44f7bc68e	f0c47c0c-5944-492e-b604-59469f1633bb	708be761-243b-4970-bffc-0f46a20b188d	75000.0000	2025-10-01	2025-12-31	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
\.


--
-- TOC entry 5005 (class 0 OID 18355)
-- Dependencies: 295
-- Data for Name: kpi_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kpi_metrics (id, name, metric_type, unit, description, created_at, updated_at) FROM stdin;
d12bd211-7c3f-4434-baa2-46b89aa7f2d4	Revenue_Total	revenue	USD	Total revenue	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
cca4d9f2-271f-4c1d-bf84-09c3daf980bf	Revenue_Subscription	revenue	USD	Recurring subscription revenue	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
6e8e5d7d-0fab-4ce2-9f49-a5f451fbdb8b	Revenue_Services	revenue	USD	Professional services revenue	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
310398dc-1f31-4d5c-b172-7da2ecfd00c8	Revenue_Usage	revenue	USD	Usage-based revenue	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
708be761-243b-4970-bffc-0f46a20b188d	Revenue_Enterprise	revenue	USD	Enterprise contract revenue	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
\.


--
-- TOC entry 5006 (class 0 OID 18363)
-- Dependencies: 296
-- Data for Name: llm_models; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llm_models (model_name, provider_name, display_name, model_type, model_version, context_window, max_output_tokens, model_parameters_json, pricing_info_json, capabilities, model_tier, speed_tier, loading_priority, is_local, is_currently_loaded, is_active, training_data_cutoff, created_at, updated_at) FROM stdin;
gpt-5	openai	GPT-5	text-generation	\N	128000	8192	{}	{}	[]	fast-thinking	medium	5	f	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
o4-mini	openai	o4-mini	text-generation	\N	32000	8192	{}	{}	[]	general	medium	5	f	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
o1-preview	openai	o1-preview	text-generation	\N	16000	4096	{}	{}	[]	general	medium	5	f	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
o1-mini	openai	o1-mini	text-generation	\N	8000	2048	{}	{}	[]	ultra-fast	medium	5	f	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
gemini-2.5-pro	google	Gemini 2.5 Pro	text-generation	\N	1000000	8192	{}	{}	[]	fast-thinking	medium	5	f	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
gemini-2.5-flash	google	Gemini 2.5 Flash	text-generation	\N	1000000	8192	{}	{}	[]	ultra-fast	medium	5	f	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
gemini-2.0-pro	google	Gemini 2.0 Pro	text-generation	\N	1000000	8192	{}	{}	[]	general	medium	5	f	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
gemini-2.0-flash	google	Gemini 2.0 Flash	text-generation	\N	1048576	8192	{}	{}	[]	general	medium	5	f	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
claude-opus-4-1-20250805	anthropic	Claude Opus 4.1	text-generation	\N	200000	8192	{}	{"input_cost_per_token": 0.000015, "output_cost_per_token": 0.000075}	["function_calling", "streaming", "vision", "coding", "reasoning", "agentic"]	fast-thinking	medium	5	f	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
claude-sonnet-4-20250514	anthropic	Claude Sonnet 4	text-generation	\N	200000	64000	{}	{"input_cost_per_token": 0.000003, "output_cost_per_token": 0.000015}	["function_calling", "streaming", "vision", "balanced", "high_output"]	general	medium	5	f	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
claude-3-5-haiku-20241022	anthropic	Claude 3.5 Haiku	text-generation	\N	200000	8192	{}	{"input_cost_per_token": 0.0008, "output_cost_per_token": 0.004}	["streaming", "fast", "low_latency", "cost_effective"]	ultra-fast	medium	5	f	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
claude-3-5-sonnet-20241022	anthropic	Claude 3.5 Sonnet	text-generation	\N	200000	8192	{}	{"input_cost_per_token": 0.000003, "output_cost_per_token": 0.000015}	["function_calling", "streaming", "balanced", "reasoning"]	general	medium	5	f	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
grok-4	grok	Grok 4	text-generation	\N	128000	8192	{}	{"api_pricing": "custom", "monthly_cost": 40, "subscription_tier": "SuperGrok"}	["function_calling", "streaming", "tool_use", "real_time_search", "multimodal"]	fast-thinking	medium	5	f	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
grok-4-heavy	grok	Grok 4 Heavy	text-generation	\N	256000	8192	{}	{"api_pricing": "custom", "monthly_cost": 120, "subscription_tier": "SuperGrok Heavy"}	["function_calling", "streaming", "tool_use", "max_accuracy", "enterprise"]	fast-thinking	medium	5	f	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
grok-3	grok	Grok 3	text-generation	\N	128000	8192	{}	{"api_pricing": "custom", "monthly_cost": 20, "subscription_tier": "Standard Grok"}	["streaming", "reasoning", "think_mode"]	general	medium	5	f	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
grok-3-mini	grok	Grok 3 mini	text-generation	\N	64000	4096	{}	{"api_pricing": "low_cost", "subscription_tier": "included"}	["streaming", "fast", "lower_accuracy"]	ultra-fast	medium	5	f	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
grok-code-fast-1	grok	Grok Code Fast 1	text-generation	\N	256000	8192	{}	{"pricing": "custom", "api_only": true, "specialized": "coding"}	["function_calling", "tool_use", "coding", "ide_integration", "agentic"]	general	medium	5	f	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
llama3.2:latest	ollama	Llama 3.2 Latest	text-generation	\N	128000	4096	{}	{"cost": 0, "local": true}	["streaming", "local", "open_source"]	general	medium	8	t	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
qwen3:8b	ollama	Qwen 3 8B	text-generation	\N	32000	4096	{}	{"cost": 0, "local": true}	["streaming", "local", "multilingual", "efficient"]	general	medium	7	t	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
deepseek-r1:latest	ollama	DeepSeek R1 Latest	text-generation	\N	64000	4096	{}	{"cost": 0, "local": true}	["streaming", "local", "reasoning", "coding"]	fast-thinking	medium	9	t	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
qwq:latest	ollama	QwQ Latest	text-generation	\N	32000	4096	{}	{"cost": 0, "local": true}	["streaming", "local", "reasoning"]	general	medium	5	t	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
gpt-oss:20b	ollama	GPT-OSS 20B	text-generation	\N	32000	4096	{}	{"cost": 0, "local": true}	["streaming", "local", "open_source", "efficient"]	ultra-fast	medium	8	t	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
phi3.5:latest	ollama	Phi 3.5 Latest	text-generation	\N	32000	4096	{}	{"cost": 0, "local": true}	["streaming", "local", "efficient"]	ultra-fast	medium	6	t	f	t	\N	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
\.


--
-- TOC entry 5007 (class 0 OID 18381)
-- Dependencies: 297
-- Data for Name: llm_providers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llm_providers (name, display_name, api_base_url, configuration_json, is_active, created_at, updated_at) FROM stdin;
openai	OpenAI	https://api.openai.com/v1	{"timeout": 30, "max_retries": 3}	t	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
google	Google Gemini	https://generativelanguage.googleapis.com/v1	{"timeout": 30, "max_retries": 3}	t	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
anthropic	Anthropic Claude	https://api.anthropic.com/v1	{"timeout": 30, "max_retries": 3}	t	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
grok	Grok (xAI)	https://api.xai.com	{"timeout": 30, "max_retries": 3}	t	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
ollama	Ollama	http://localhost:11434	{"local": true, "timeout": 30, "max_retries": 3}	t	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00
\.


--
-- TOC entry 5008 (class 0 OID 18390)
-- Dependencies: 298
-- Data for Name: llm_usage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llm_usage (id, run_id, user_id, conversation_id, provider_name, model_name, input_tokens, output_tokens, input_cost, output_cost, duration_ms, status, caller_type, agent_name, is_local, model_tier, fallback_used, routing_reason, complexity_level, complexity_score, data_classification, started_at, completed_at, error_message, data_sanitization_applied, sanitization_level, pii_detected, pii_types, pseudonyms_used, pseudonym_types, redactions_applied, redaction_types, source_blinding_applied, headers_stripped, custom_user_agent_used, proxy_used, no_train_header_sent, no_retain_header_sent, sanitization_time_ms, reversal_context_size, policy_profile, sovereign_mode, compliance_flags, created_at, route, total_cost, pseudonym_mappings) FROM stdin;
86812008-108b-48bc-a1ae-baefb6f68035	051577ee-fa1c-4c44-b902-739d226c804b	b29a590e-b07f-49df-a25b-574c956b5035	66f858b9-0d63-4afa-9052-10b661543c05	ollama	llama3.2:latest	175	305	0.002625	0.018300	1800	completed	api_call	task_agent	f	\N	f	\N	\N	\N	internal	2025-09-30 20:18:09.981049+00	2025-09-30 20:48:09.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-09-30 20:20:09.981049+00	\N	\N	[]
a278b674-ba9b-485e-b5cc-eb9e7b76c4ad	7d6e2760-2825-49f1-9922-0992ca843069	b29a590e-b07f-49df-a25b-574c956b5035	66f858b9-0d63-4afa-9052-10b661543c05	ollama	llama3.2:latest	200	335	0.003000	0.020100	1900	completed	background_task	analysis_agent	f	\N	f	\N	\N	\N	internal	2025-09-30 21:18:09.981049+00	2025-09-30 21:49:49.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-09-30 21:20:09.981049+00	\N	\N	[]
ff5a3d94-da37-4e5c-bf3a-eec9ed9f0639	81bd3a46-8cb5-4a7b-aeed-d4e8f0dff32b	b29a590e-b07f-49df-a25b-574c956b5035	66f858b9-0d63-4afa-9052-10b661543c05	ollama	llama3.2:latest	225	365	0.003375	0.021900	2000	completed	web_interface	summary_agent	f	\N	f	\N	\N	\N	internal	2025-09-30 22:18:09.981049+00	2025-09-30 22:51:29.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-09-30 22:20:09.981049+00	\N	\N	[]
9c22c6b2-d3b7-4d96-8d73-2f21cd91228f	ff6a8b19-d276-4974-a016-f196e8a128b9	b29a590e-b07f-49df-a25b-574c956b5035	66f858b9-0d63-4afa-9052-10b661543c05	ollama	llama3.2:latest	250	395	0.003750	0.023700	2100	completed	api_call	conversation_agent	f	\N	f	\N	\N	\N	internal	2025-09-30 23:18:09.981049+00	2025-09-30 23:53:09.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-09-30 23:20:09.981049+00	\N	\N	[]
1d360a2f-c5ba-4184-abaa-874df6bca2f4	7849239a-8647-48d7-8e51-88ad0b5296d7	b29a590e-b07f-49df-a25b-574c956b5035	5931a44f-506e-4377-b637-bf5bdfe79e8b	ollama	llama3.2:latest	225	380	0.003375	0.022800	2000	completed	api_call	task_agent	f	\N	f	\N	\N	\N	confidential	2025-10-01 20:18:09.981049+00	2025-10-01 20:51:29.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-01 20:20:09.981049+00	\N	\N	[]
4b93e64f-2db0-4209-a66c-6c004e2b14ff	97ec3785-a97f-4ac7-89cc-c4c453db7934	b29a590e-b07f-49df-a25b-574c956b5035	5931a44f-506e-4377-b637-bf5bdfe79e8b	ollama	llama3.2:latest	250	410	0.003750	0.024600	2100	completed	background_task	analysis_agent	f	\N	f	\N	\N	\N	confidential	2025-10-01 21:18:09.981049+00	2025-10-01 21:53:09.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-01 21:20:09.981049+00	\N	\N	[]
1c389a91-33ff-4ad5-a658-ed2eda7eff9b	12276bd6-be9a-43b1-8a94-a15f0f020ab1	b29a590e-b07f-49df-a25b-574c956b5035	5931a44f-506e-4377-b637-bf5bdfe79e8b	ollama	llama3.2:latest	275	440	0.004125	0.026400	2200	completed	web_interface	summary_agent	f	\N	f	\N	\N	\N	confidential	2025-10-01 22:18:09.981049+00	2025-10-01 22:54:49.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-01 22:20:09.981049+00	\N	\N	[]
90fd3a1b-b8c4-47b6-8bd5-7f7690f56d87	d512bdbe-58cc-4f1a-b66b-b2152ede1436	b29a590e-b07f-49df-a25b-574c956b5035	5931a44f-506e-4377-b637-bf5bdfe79e8b	ollama	llama3.2:latest	300	470	0.004500	0.028200	2300	completed	api_call	conversation_agent	f	\N	f	\N	\N	\N	confidential	2025-10-01 23:18:09.981049+00	2025-10-01 23:56:29.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-01 23:20:09.981049+00	\N	\N	[]
e706c313-beb4-4ee9-8abf-ce6dd4b9dc46	d96733e2-fa67-462a-83e8-062c3a8938bb	b29a590e-b07f-49df-a25b-574c956b5035	5931a44f-506e-4377-b637-bf5bdfe79e8b	ollama	llama3.2:latest	325	500	0.004875	0.030000	2400	completed	background_task	task_agent	f	\N	f	\N	\N	\N	confidential	2025-10-02 00:18:09.981049+00	2025-10-02 00:58:09.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-02 00:20:09.981049+00	\N	\N	[]
10313e39-b2a4-4f1f-b078-515a65b27314	4a5fbbb3-0198-4fd3-b8c0-56c936729118	b29a590e-b07f-49df-a25b-574c956b5035	91642195-1f88-4f3d-a88d-bc5d05440f80	ollama	llama3.2:latest	275	455	0.004125	0.027300	2200	completed	api_call	task_agent	f	\N	f	\N	\N	\N	public	2025-10-02 20:18:09.981049+00	2025-10-02 20:54:49.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-02 20:20:09.981049+00	\N	\N	[]
bb78d26a-c4e9-4acb-b79f-78eab845c5e1	ee2df670-2cd0-4358-b8fa-d2fe27c100b2	b29a590e-b07f-49df-a25b-574c956b5035	91642195-1f88-4f3d-a88d-bc5d05440f80	ollama	llama3.2:latest	300	485	0.004500	0.029100	2300	completed	background_task	analysis_agent	f	\N	f	\N	\N	\N	public	2025-10-02 21:18:09.981049+00	2025-10-02 21:56:29.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-02 21:20:09.981049+00	\N	\N	[]
65c020e6-6583-42d1-8671-616d6d847803	3b0e18fa-3bb8-421a-8909-53d76a0fa2a8	b29a590e-b07f-49df-a25b-574c956b5035	91642195-1f88-4f3d-a88d-bc5d05440f80	ollama	llama3.2:latest	325	515	0.004875	0.030900	2400	completed	web_interface	summary_agent	f	\N	f	\N	\N	\N	public	2025-10-02 22:18:09.981049+00	2025-10-02 22:58:09.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-02 22:20:09.981049+00	\N	\N	[]
00715c6d-ec94-498b-a749-6b82b665096a	16e538d5-fad1-4220-89e1-120395e37fa2	b29a590e-b07f-49df-a25b-574c956b5035	2e536d84-d5c8-4c2e-bf58-436b5d7dd493	ollama	llama3.2:latest	325	530	0.004875	0.031800	2400	completed	api_call	task_agent	f	\N	f	\N	\N	\N	internal	2025-10-03 20:18:09.981049+00	2025-10-03 20:58:09.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-03 20:20:09.981049+00	\N	\N	[]
ce233c46-f0a9-411f-a8ec-39f3fe4ac165	155c10c8-1ed7-49d3-b6fa-6b61f4048f26	b29a590e-b07f-49df-a25b-574c956b5035	2e536d84-d5c8-4c2e-bf58-436b5d7dd493	ollama	llama3.2:latest	350	560	0.005250	0.033600	2500	completed	background_task	analysis_agent	f	\N	f	\N	\N	\N	internal	2025-10-03 21:18:09.981049+00	2025-10-03 21:59:49.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-03 21:20:09.981049+00	\N	\N	[]
9f4faedb-acea-402d-867b-03265eea8ea1	b44b6f96-f12f-4241-a058-9ae4347ce3b9	b29a590e-b07f-49df-a25b-574c956b5035	2e536d84-d5c8-4c2e-bf58-436b5d7dd493	ollama	llama3.2:latest	375	590	0.005625	0.035400	2600	completed	web_interface	summary_agent	f	\N	f	\N	\N	\N	internal	2025-10-03 22:18:09.981049+00	2025-10-03 23:01:29.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-03 22:20:09.981049+00	\N	\N	[]
315f8ec8-fe49-49f8-b1ac-641a329eeb44	9334bc30-e07f-4879-9481-fe23eb63c5c0	b29a590e-b07f-49df-a25b-574c956b5035	2e536d84-d5c8-4c2e-bf58-436b5d7dd493	ollama	llama3.2:latest	400	620	0.006000	0.037200	2700	completed	api_call	conversation_agent	f	\N	f	\N	\N	\N	internal	2025-10-03 23:18:09.981049+00	2025-10-04 00:03:09.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-03 23:20:09.981049+00	\N	\N	[]
c61662df-c591-4070-a1e0-9ed02612911f	91a824f6-3732-436f-b811-c99e9bb85886	b29a590e-b07f-49df-a25b-574c956b5035	bff9ce60-05b5-42fb-b508-8bf3b973aadd	ollama	llama3.2:latest	375	605	0.005625	0.036300	2600	completed	api_call	task_agent	f	\N	f	\N	\N	\N	confidential	2025-10-04 20:18:09.981049+00	2025-10-04 21:01:29.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-04 20:20:09.981049+00	\N	\N	[]
b62f7646-47eb-49ca-8932-dbf713730c4b	6e77df7f-887f-42ed-83b9-fc5dcad5cd3e	b29a590e-b07f-49df-a25b-574c956b5035	bff9ce60-05b5-42fb-b508-8bf3b973aadd	ollama	llama3.2:latest	400	635	0.006000	0.038100	2700	completed	background_task	analysis_agent	f	\N	f	\N	\N	\N	confidential	2025-10-04 21:18:09.981049+00	2025-10-04 22:03:09.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-04 21:20:09.981049+00	\N	\N	[]
1e457f23-9dec-4d19-8226-a95bde222333	1e7b20d1-8e9d-46d7-93d2-d1d92821484b	b29a590e-b07f-49df-a25b-574c956b5035	bff9ce60-05b5-42fb-b508-8bf3b973aadd	ollama	llama3.2:latest	425	665	0.006375	0.039900	2800	completed	web_interface	summary_agent	f	\N	f	\N	\N	\N	confidential	2025-10-04 22:18:09.981049+00	2025-10-04 23:04:49.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-04 22:20:09.981049+00	\N	\N	[]
21b71975-d509-4fd9-9a9b-3a47ec0d4842	f5c6ce2a-c12b-4403-80ff-4a64cfcb8cb3	b29a590e-b07f-49df-a25b-574c956b5035	bff9ce60-05b5-42fb-b508-8bf3b973aadd	ollama	llama3.2:latest	450	695	0.006750	0.041700	2900	completed	api_call	conversation_agent	f	\N	f	\N	\N	\N	confidential	2025-10-04 23:18:09.981049+00	2025-10-05 00:06:29.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-04 23:20:09.981049+00	\N	\N	[]
bb3e54e7-d60d-4d1c-a2ae-a424dea16164	1adc2a7e-4b45-48b5-abfa-d463a38ff17d	b29a590e-b07f-49df-a25b-574c956b5035	bff9ce60-05b5-42fb-b508-8bf3b973aadd	ollama	llama3.2:latest	475	725	0.007125	0.043500	3000	completed	background_task	task_agent	f	\N	f	\N	\N	\N	confidential	2025-10-05 00:18:09.981049+00	2025-10-05 01:08:09.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-05 00:20:09.981049+00	\N	\N	[]
040ab109-b41d-4a5d-a11f-27434f73be58	66bded80-91f5-468b-a866-a389f6cdabd3	b29a590e-b07f-49df-a25b-574c956b5035	c6741ed7-9003-4921-8dda-9aa6729f2916	ollama	llama3.2:latest	425	680	0.006375	0.040800	2800	completed	api_call	task_agent	f	\N	f	\N	\N	\N	public	2025-10-05 20:18:09.981049+00	2025-10-05 21:04:49.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-05 20:20:09.981049+00	\N	\N	[]
297f0d54-66a0-404c-90c2-3b1313a363c6	f2b9520a-38c8-4b8f-934b-fc80da8a84b3	b29a590e-b07f-49df-a25b-574c956b5035	c6741ed7-9003-4921-8dda-9aa6729f2916	ollama	llama3.2:latest	450	710	0.006750	0.042600	2900	completed	background_task	analysis_agent	f	\N	f	\N	\N	\N	public	2025-10-05 21:18:09.981049+00	2025-10-05 22:06:29.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-05 21:20:09.981049+00	\N	\N	[]
752d3fa5-c806-48df-8122-1d0ae594edc1	12cf8a2c-8317-4bed-a1da-3a8a2f93846b	b29a590e-b07f-49df-a25b-574c956b5035	c6741ed7-9003-4921-8dda-9aa6729f2916	ollama	llama3.2:latest	475	740	0.007125	0.044400	3000	completed	web_interface	summary_agent	f	\N	f	\N	\N	\N	public	2025-10-05 22:18:09.981049+00	2025-10-05 23:08:09.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-05 22:20:09.981049+00	\N	\N	[]
a943202b-c889-4340-be96-e31e65b0226e	28d0534a-ed0d-413c-8828-b48e4a8854bc	b29a590e-b07f-49df-a25b-574c956b5035	70afc481-1bbd-4c2f-9bf7-68dfbc2dc3ee	ollama	llama3.2:latest	475	755	0.007125	0.045300	3000	completed	api_call	task_agent	f	\N	f	\N	\N	\N	internal	2025-10-06 20:18:09.981049+00	2025-10-06 21:08:09.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-06 20:20:09.981049+00	\N	\N	[]
b325315b-0ae8-4e1d-8e2c-2ee16474365e	51a3019f-45fb-4b2f-b583-6f60e98274c7	b29a590e-b07f-49df-a25b-574c956b5035	70afc481-1bbd-4c2f-9bf7-68dfbc2dc3ee	ollama	llama3.2:latest	500	785	0.007500	0.047100	3100	completed	background_task	analysis_agent	f	\N	f	\N	\N	\N	internal	2025-10-06 21:18:09.981049+00	2025-10-06 22:09:49.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-06 21:20:09.981049+00	\N	\N	[]
f71824be-74db-4540-a8c8-dbc859135486	8a41038e-d7d7-43cb-81a1-31b6360a69f6	b29a590e-b07f-49df-a25b-574c956b5035	70afc481-1bbd-4c2f-9bf7-68dfbc2dc3ee	ollama	llama3.2:latest	525	815	0.007875	0.048900	3200	completed	web_interface	summary_agent	f	\N	f	\N	\N	\N	internal	2025-10-06 22:18:09.981049+00	2025-10-06 23:11:29.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-06 22:20:09.981049+00	\N	\N	[]
0ba389a7-9b73-448a-a2f3-d2df3c1f3f83	ed8046d9-ba95-4d82-b419-258214d7c292	b29a590e-b07f-49df-a25b-574c956b5035	70afc481-1bbd-4c2f-9bf7-68dfbc2dc3ee	ollama	llama3.2:latest	550	845	0.008250	0.050700	3300	completed	api_call	conversation_agent	f	\N	f	\N	\N	\N	internal	2025-10-06 23:18:09.981049+00	2025-10-07 00:13:09.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-06 23:20:09.981049+00	\N	\N	[]
fb2cc108-b4ee-4651-95db-651f1cf7e316	2dd7eaf6-97cd-4b10-b04a-b891b4b7e462	b29a590e-b07f-49df-a25b-574c956b5035	d6671925-606e-462b-ae7c-66f46bf3f1b4	ollama	llama3.2:latest	525	830	0.007875	0.049800	3200	completed	api_call	task_agent	f	\N	f	\N	\N	\N	confidential	2025-10-07 20:18:09.981049+00	2025-10-07 21:11:29.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-07 20:20:09.981049+00	\N	\N	[]
df7505ab-0e63-4dfd-83bc-d6d977a0e1fe	cbb6f706-32c0-4e88-a4e5-bef81dc29d8a	b29a590e-b07f-49df-a25b-574c956b5035	d6671925-606e-462b-ae7c-66f46bf3f1b4	ollama	llama3.2:latest	550	860	0.008250	0.051600	3300	completed	background_task	analysis_agent	f	\N	f	\N	\N	\N	confidential	2025-10-07 21:18:09.981049+00	2025-10-07 22:13:09.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-07 21:20:09.981049+00	\N	\N	[]
4463dbf6-14a2-4023-887a-d3fd2031969c	cb16a897-06c7-4e9e-8a28-8be8811af35e	b29a590e-b07f-49df-a25b-574c956b5035	d6671925-606e-462b-ae7c-66f46bf3f1b4	ollama	llama3.2:latest	575	890	0.008625	0.053400	3400	completed	web_interface	summary_agent	f	\N	f	\N	\N	\N	confidential	2025-10-07 22:18:09.981049+00	2025-10-07 23:14:49.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-07 22:20:09.981049+00	\N	\N	[]
b0cb8865-46e1-498b-a51d-e14e942f5de9	10eb3fef-94e8-4c3d-a48d-d2642d5216a2	b29a590e-b07f-49df-a25b-574c956b5035	d6671925-606e-462b-ae7c-66f46bf3f1b4	ollama	llama3.2:latest	600	920	0.009000	0.055200	3500	completed	api_call	conversation_agent	f	\N	f	\N	\N	\N	confidential	2025-10-07 23:18:09.981049+00	2025-10-08 00:16:29.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-07 23:20:09.981049+00	\N	\N	[]
c52bbdf9-b5eb-48d5-b98b-9bc36198ef82	2d6e12f7-6463-4aed-9aae-a443136db8ab	b29a590e-b07f-49df-a25b-574c956b5035	d6671925-606e-462b-ae7c-66f46bf3f1b4	ollama	llama3.2:latest	625	950	0.009375	0.057000	3600	completed	background_task	task_agent	f	\N	f	\N	\N	\N	confidential	2025-10-08 00:18:09.981049+00	2025-10-08 01:18:09.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-08 00:20:09.981049+00	\N	\N	[]
0d311ad3-12b7-4c89-ada1-699a66fedd2d	c82e7fd7-ab47-4b25-b142-f8e9f5283ce9	b29a590e-b07f-49df-a25b-574c956b5035	9e6f502b-ba20-4e24-88a7-0ce85149c18b	ollama	llama3.2:latest	575	905	0.008625	0.054300	3400	completed	api_call	task_agent	f	\N	f	\N	\N	\N	public	2025-10-08 20:18:09.981049+00	2025-10-08 21:14:49.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-08 20:20:09.981049+00	\N	\N	[]
8910ee82-0092-46af-950d-80e7cfa76863	1e78a9f4-5982-4485-8eeb-9f587cb25ed9	b29a590e-b07f-49df-a25b-574c956b5035	9e6f502b-ba20-4e24-88a7-0ce85149c18b	ollama	llama3.2:latest	600	935	0.009000	0.056100	3500	completed	background_task	analysis_agent	f	\N	f	\N	\N	\N	public	2025-10-08 21:18:09.981049+00	2025-10-08 22:16:29.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-08 21:20:09.981049+00	\N	\N	[]
e18e1990-2495-4d1d-ae62-903f2dd2db51	8ffc2f08-8027-4552-91a0-76f6baccc6ab	b29a590e-b07f-49df-a25b-574c956b5035	9e6f502b-ba20-4e24-88a7-0ce85149c18b	ollama	llama3.2:latest	625	965	0.009375	0.057900	3600	completed	web_interface	summary_agent	f	\N	f	\N	\N	\N	public	2025-10-08 22:18:09.981049+00	2025-10-08 23:18:09.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-08 22:20:09.981049+00	\N	\N	[]
6ce003ab-211b-49bf-bb00-58aaef0541b5	6e2ceb37-5d28-4967-af48-bd4fe9267707	b29a590e-b07f-49df-a25b-574c956b5035	9cfb3f53-02c6-4951-8e04-0fb624fad0e7	ollama	llama3.2:latest	625	980	0.009375	0.058800	3600	completed	api_call	task_agent	f	\N	f	\N	\N	\N	internal	2025-10-09 20:18:09.981049+00	2025-10-09 21:18:09.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-09 20:20:09.981049+00	\N	\N	[]
62137f06-6534-4aca-b2bf-a4b5b3eb9802	422a9e8d-7aef-4834-aaf6-288d14c52008	b29a590e-b07f-49df-a25b-574c956b5035	9cfb3f53-02c6-4951-8e04-0fb624fad0e7	ollama	llama3.2:latest	650	1010	0.009750	0.060600	3700	completed	background_task	analysis_agent	f	\N	f	\N	\N	\N	internal	2025-10-09 21:18:09.981049+00	2025-10-09 22:19:49.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-09 21:20:09.981049+00	\N	\N	[]
998b1d66-6ce5-48c0-8396-428a4d24a9b5	860ff6bd-237f-4968-ac33-5b7e4814fb7d	b29a590e-b07f-49df-a25b-574c956b5035	9cfb3f53-02c6-4951-8e04-0fb624fad0e7	ollama	llama3.2:latest	675	1040	0.010125	0.062400	3800	completed	web_interface	summary_agent	f	\N	f	\N	\N	\N	internal	2025-10-09 22:18:09.981049+00	2025-10-09 23:21:29.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-09 22:20:09.981049+00	\N	\N	[]
74511440-1396-46e4-9a84-e7849c0b2a33	eb2504ed-78ad-4b8b-8f43-7edd84c1c7c2	b29a590e-b07f-49df-a25b-574c956b5035	9cfb3f53-02c6-4951-8e04-0fb624fad0e7	ollama	llama3.2:latest	700	1070	0.010500	0.064200	3900	completed	api_call	conversation_agent	f	\N	f	\N	\N	\N	internal	2025-10-09 23:18:09.981049+00	2025-10-10 00:23:09.981049+00	\N	f	none	f	[]	0	[]	0	[]	f	f	f	f	f	f	0	0	\N	f	[]	2025-10-09 23:20:09.981049+00	\N	\N	[]
aec5a8e4-dd8e-4426-98ac-83db85bd1042	ollama-1760039733926-i151s70t7	a1b2c3d4-e5f6-7890-abcd-ef1234567890	38ef70b5-1a48-4024-81f3-8c937f3dcea6	ollama	llama3.2:latest	103	524	\N	\N	5632	completed	agent	Blog Post Writer	t	local	f	\N	\N	\N	\N	2025-10-09 19:55:33.926+00	2025-10-09 19:55:39.558+00	\N	f	local-bypass	f	{}	0	[]	0	[]	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-09 19:55:39.564349+00	local	0	[]
c8cf1d16-77ec-4a19-a2f5-2992640ec87b	ollama-1760039752153-fr4bfnoks	a1b2c3d4-e5f6-7890-abcd-ef1234567890	38ef70b5-1a48-4024-81f3-8c937f3dcea6	ollama	gpt-oss:20b	115	1833	\N	\N	29545	completed	agent	Blog Post Writer	t	local	f	\N	\N	\N	\N	2025-10-09 19:55:52.153+00	2025-10-09 19:56:21.698+00	\N	f	local-bypass	f	{}	0	[]	0	[]	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-09 19:56:21.704581+00	local	0	[]
\.


--
-- TOC entry 5017 (class 0 OID 18836)
-- Dependencies: 307
-- Data for Name: orchestration_runs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orchestration_runs (id, plan_id, origin_type, origin_id, orchestration_slug, prompt_inputs, organization_slug, status, current_step_index, completed_steps, step_state, human_checkpoint_id, metadata, started_at, completed_at) FROM stdin;
\.


--
-- TOC entry 5015 (class 0 OID 18791)
-- Dependencies: 305
-- Data for Name: organization_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_credentials (id, organization_slug, alias, credential_type, encrypted_value, encryption_metadata, rotated_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5021 (class 0 OID 18942)
-- Dependencies: 312
-- Data for Name: plan_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_versions (id, plan_id, version_number, content, format, created_by_type, created_by_id, task_id, metadata, is_current_version, created_at) FROM stdin;
d8ecd3b4-8481-4564-a383-b46f5f18cd51	0459adf5-4c9f-4c1b-af2a-897d72fca33d	1	# How to Play Golf in the Rain: Tips, Gear, and Tricks for a Successful Wet Day\n\n*Meta description: Playing golf in the rain can be challenging, but with the right gear, strategy, and mindset, you can still enjoy a great round. Learn practical tips, gear recommendations, and mental hacks to keep your game on track when the skies open up.*\n\n---\n\n## Table of Contents\n\n1. [Why Golfing in the Rain Matters](#why-golfing-in-the-rain-matters)\n2. [Common Challenges of a Wet Round](#common-challenges-of-a-wet-round)\n3. [Essential Gear for Rainy Golf](#essential-gear-for-rainy-golf)\n4. [Pre‑Round Preparation](#pre-round-preparation)\n5. **Playing the Course in the Rain**  \n   5.1. [Club Selection & Ball Choice](#club-selection--ball-choice)  \n   5.2. [Swing Adjustments](#swing-adjustments)  \n   5.3. [Course Management](#course-management)  \n6. [Mental & Physical Tips](#mental--physical-tips)\n7. [After‑Game Recovery](#after-game-recovery)\n8. [Frequently Asked Questions](#frequently-asked-questions)\n9. [Conclusion](#conclusion)\n\n---\n\n## Why Golfing in the Rain Matters\n\nGolf is a sport that thrives on precision, consistency, and a calm mindset. Rain can disrupt all three, but it also offers unique opportunities:\n\n- **Improved Course Conditions** – Soft greens can reduce spin and help the ball stay on the fairway.\n- **Mental Challenge** – Adapting to wet conditions sharpens focus and resilience.\n- **Less Crowd** – Fewer players on the course can mean more space and less pressure.\n\nIf you’re a golfer who loves a challenge, mastering the rain can elevate your game.\n\n---\n\n## Common Challenges of a Wet Round\n\n| Challenge | Impact on Play | Why It Happens |\n|-----------|----------------|----------------|\n| **Wet Balls** | Reduced carry, more spin | Water increases ball spin and reduces launch |\n| **Slippery Clubs** | Poor grip, inconsistent swing | Moisture on hands and clubface |\n| **Soft Greens** | Slower roll, less reaction time | Turf becomes mushy and water‑logged |\n| **Wind & Visibility** | Unpredictable ball flight | Rain can amplify wind gusts and lower visibility |\n\nUnderstanding these hurdles is the first step toward overcoming them.\n\n---\n\n## Essential Gear for Rainy Golf\n\n| Item | Why It Matters | Tips |\n|------|----------------|------|\n| **Water‑Resistant Jacket & Pants** | Keeps you dry and comfortable | Look for breathable, quick‑dry fabrics |\n| **Windbreaker** | Protects against wind chill | Lightweight, packable |\n| **Golf Gloves (Water‑Proof)** | Maintains grip | Consider latex‑free or nitrile gloves with a textured palm |\n| **Rain‑Proof Golf Bag** | Protects clubs & electronics | Waterproof or water‑repellent material |\n| **Golf Ball with Low Spin** | Better performance in wet | Opt for “low spin” or “soft feel” models |\n| **Cap or Visor** | Shields eyes from rain | A brim that directs water away from your face |\n\n**Pro Tip:** Carry a spare glove and a small towel for quick dry‑downs between shots.\n\n---\n\n## Pre‑Round Preparation\n\n1. **Check the Forecast** – Use reliable weather apps or the course’s website for up‑to‑date rain predictions.\n2. **Inspect the Course** – Look for standing water, slushy greens, and potential hazards.\n3. **Warm‑Up Thoroughly** – A longer warm‑up helps loosen muscles and adjust to a slower swing tempo.\n4. **Plan Your Tee Shots** – Shorter, more accurate drives are safer when the ball doesn’t travel as far.\n\n---\n\n## Playing the Course in the Rain\n\n### 5.1 Club Selection & Ball Choice\n\n- **Shorter Clubs**: Use a club you’re comfortable with; the ball will carry less distance.\n- **Low‑Spin Balls**: Choose a ball that reduces backspin, giving you more control on the green.\n- **Avoid High‑Launch Shots**: The ball will tend to drop early; keep it low and controlled.\n\n### 5.2 Swing Adjustments\n\n| Adjustment | Effect | How to Execute |\n|------------|--------|----------------|\n| **Lower the Ball Position** | Reduces lift | Place the ball slightly forward in your stance |\n| **Shorter Tempo** | Prevents over‑swing | Focus on a smooth, controlled swing |\n| **Avoid Over‑Rotating the Clubface** | Limits spin | Keep the clubface square at impact |\n\n### 5.3 Course Management\n\n- **Play to the Wind**: In rain, wind can be more pronounced. Adjust your line accordingly.\n- **Choose the Safest Route**: Opt for the center of the fairway; avoid the edges where water can pool.\n- **Use the Greens Wisely**: Greens are slower; aim for a softer approach shot.\n\n---\n\n## Mental & Physical Tips\n\n| Tip | Why It Helps |\n|-----|--------------|\n| **Stay Positive** | A confident mindset improves focus and swing consistency. |\n| **Take Breaks** | Short pauses keep your body from getting too cold or stiff. |\n| **Stay Warm** | A warm body swings more efficiently; use hand warmers if needed. |\n| **Visualize the Shot** | Mentally picturing a smooth swing can help maintain rhythm. |\n\n---\n\n## After‑Game Recovery\n\n- **Dry Off**: Change into dry clothing as soon as possible to avoid chill.\n- **Hydrate**: Even if it’s raining, you’re still sweating. Drink water or a sports drink.\n- **Stretch**: Loosen the muscles you used, especially the back and shoulders.\n- **Reflect**: Note what worked and what didn’t. Use these insights for next time.\n\n---\n\n## Frequently Asked Questions\n\n| Question | Answer |\n|----------|--------|\n| **Can I play golf in heavy rain?** | It’s possible, but be cautious of water hazards and reduced visibility. |\n| **Do I need a golf umbrella?** | A golf umbrella is handy for shielding from rain, but many golfers prefer staying dry with proper gear. |\n| **How does rain affect putting?** | Greens are slower; use shorter, more controlled putts. |\n| **Is it safe to play in a downpour?** | Only if the course is open and there are no flooding hazards. |\n\n---\n\n## Conclusion\n\nPlaying golf in the rain isn’t just about enduring wet conditions—it’s an opportunity to sharpen your skills, adapt your strategy, and enjoy the game in a new light. With the right gear, thoughtful preparation, and a resilient mindset, you can turn a rainy round into a memorable one. So next time the clouds roll in, grab your waterproof jacket, adjust your swing, and let the rain add an extra layer of excitement to your game!\n\n---\n\n**Ready to tackle the rain?** Download our free *Rainy Golf Checklist* and stay prepared for every wet round.	markdown	agent	\N	e03d95f2-780b-4bcc-9e8c-337e43e4e994	{"usage": {"cost": 0, "inputTokens": 115, "totalTokens": 1948, "outputTokens": 1833}, "llmModel": "gpt-oss:20b", "llmProvider": "ollama"}	t	2025-10-09 19:56:21.727516+00
\.


--
-- TOC entry 5020 (class 0 OID 18920)
-- Dependencies: 311
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plans (id, conversation_id, user_id, agent_name, namespace, title, current_version_id, created_at, updated_at, plan_json, organization_slug) FROM stdin;
0459adf5-4c9f-4c1b-af2a-897d72fca33d	38ef70b5-1a48-4024-81f3-8c937f3dcea6	a1b2c3d4-e5f6-7890-abcd-ef1234567890	blog_post_writer	my-org	Plan from blog_post_writer	d8ecd3b4-8481-4564-a383-b46f5f18cd51	2025-10-09 19:56:21.715793+00	2025-10-09 19:56:21.731403+00	{}	\N
\.


--
-- TOC entry 5009 (class 0 OID 18444)
-- Dependencies: 299
-- Data for Name: pseudonym_dictionaries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pseudonym_dictionaries (id, original_value, pseudonym, data_type, category, frequency_weight, is_active, created_at, organization_slug, agent_slug, updated_at) FROM stdin;
71a5a8b4-b4b8-450c-bf39-563868c485df	Matt Weber	@person_matt	name	person	1	t	2025-10-09 19:18:09.981049+00	\N	\N	2025-10-09 19:18:09.981049+00
ef159156-1fdb-4b23-91d7-881295637d85	GolferGeek	@user_golfer	username	person	1	t	2025-10-09 19:18:09.981049+00	\N	\N	2025-10-09 19:18:09.981049+00
f2973a02-a6c3-4f66-a5c8-8936132d7423	Orchestrator AI	@company_orchestrator	custom	business	1	t	2025-10-09 19:18:09.981049+00	\N	\N	2025-10-09 19:18:09.981049+00
\.


--
-- TOC entry 5010 (class 0 OID 18453)
-- Dependencies: 300
-- Data for Name: redaction_patterns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.redaction_patterns (id, name, pattern_regex, replacement, description, category, priority, is_active, severity, data_type, created_at, updated_at) FROM stdin;
341ef90b-9d43-4e62-9101-a27326426c53	email_standard	\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}\\b	[EMAIL_REDACTED]	Standard email addresses	pii_builtin	10	t	pseudonymizer	email	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
3d9398a4-57f0-417f-b922-f1f5c67beed0	email_obfuscated	\\b[A-Za-z0-9._%+-]+\\s+(?:at|AT)\\s+[A-Za-z0-9.-]+\\s+(?:dot|DOT)\\s+[A-Za-z]{2,}\\b	[EMAIL_REDACTED]	Obfuscated email addresses (john at company dot com)	pii_builtin	20	t	pseudonymizer	email	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
33132eef-ea6a-4d1d-9d5e-48ffec414876	phone_us_standard	\\b(?:\\+?1[-.\\s]?)?\\(?([0-9]{3})\\)?[-.\\s]?([0-9]{3})[-.\\s]?([0-9]{4})\\b	[PHONE_REDACTED]	US phone numbers (various formats)	pii_builtin	10	t	pseudonymizer	phone	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
abe851d2-3787-425e-9083-2aa104062504	phone_international	\\+(?:[0-9] ?){6,14}[0-9]	[PHONE_REDACTED]	International phone numbers	pii_builtin	15	t	pseudonymizer	phone	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
bae7fe12-65b0-4260-bfed-f01a1c2f3141	name_first_last	\\b[A-Z][a-z]{1,}(?: [A-Z][a-z]{1,}){1,3}\\b	[NAME_REDACTED]	First and last names (Title case)	pii_builtin	30	t	flagger	name	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
cf2e1877-0a75-47ae-89e2-effa17adbf84	ip_address_v4	\\b(?:[0-9]{1,3}\\.){3}[0-9]{1,3}\\b	[IP_REDACTED]	IPv4 addresses	pii_builtin	10	t	flagger	ip_address	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
b71cd833-50d1-47fe-adde-97f586cb53e9	ip_address_v6	\\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\\b	[IP_REDACTED]	IPv6 addresses (full format)	pii_builtin	15	t	flagger	ip_address	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
d7d4061a-663a-4e0e-a9e2-948076b84a64	ssn_standard	\\b\\d{3}-\\d{2}-\\d{4}\\b	[SSN_REDACTED]	Social Security Numbers (XXX-XX-XXXX)	pii_builtin	5	t	showstopper	ssn	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
65f0bef1-8e51-4676-98ed-9d7dba107f74	ssn_no_dashes	\\b\\d{9}\\b	[SSN_REDACTED]	Social Security Numbers (no dashes)	pii_builtin	5	t	showstopper	ssn	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
c3eb0ef9-1327-4f12-9e89-87bf160ad330	credit_card_visa	\\b4[0-9]{12}(?:[0-9]{3})?\\b	[CREDIT_CARD_REDACTED]	Visa credit card numbers	pii_builtin	5	t	showstopper	credit_card	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
50c0194f-8e98-4088-9df4-e81acd3257fd	credit_card_mastercard	\\b5[1-5][0-9]{14}\\b	[CREDIT_CARD_REDACTED]	Mastercard credit card numbers	pii_builtin	5	t	showstopper	credit_card	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
107de532-eb6d-497b-ab48-f93acb3a5a57	credit_card_amex	\\b3[47][0-9]{13}\\b	[CREDIT_CARD_REDACTED]	American Express credit card numbers	pii_builtin	5	t	showstopper	credit_card	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
1ab30adc-1bea-4218-bdcf-7dbe190c3bcf	credit_card_discover	\\b6(?:011|5[0-9]{2})[0-9]{12}\\b	[CREDIT_CARD_REDACTED]	Discover credit card numbers	pii_builtin	5	t	showstopper	credit_card	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
b12753b0-2576-4d66-b2dc-eef95d3585c2	username_handle	\\b@[a-zA-Z0-9_]{3,15}\\b	[USERNAME_REDACTED]	Social media usernames/handles	pii_builtin	40	t	flagger	username	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
a5fe587d-92b3-4e3c-b0dd-1350343e3071	address_us_street	\\b\\d{1,5}\\s+[A-Za-z0-9\\s]{3,}\\s+(?:St|Street|Ave|Avenue|Rd|Road|Blvd|Boulevard|Dr|Drive|Ln|Lane|Ct|Court)\\b	[ADDRESS_REDACTED]	US street addresses	pii_builtin	25	t	pseudonymizer	address	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
96d31f42-dbdd-47d4-a3f0-ffde9186bec4	github_token	\\bgh[pousr]_[A-Za-z0-9]{36}\\b	[GITHUB_TOKEN_REDACTED]	GitHub personal access tokens	pii_builtin	1	t	showstopper	custom	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
df60793f-38ae-43bf-ad95-78e335e9853f	aws_access_key	\\bAKIA[0-9A-Z]{16}\\b	[AWS_ACCESS_KEY_REDACTED]	AWS access key IDs	pii_builtin	1	t	showstopper	custom	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
4dd46b68-2e67-4622-87a6-1dd37b1a094b	jwt_token	\\beyJ[A-Za-z0-9+/=]+\\.[A-Za-z0-9+/=]+\\.[A-Za-z0-9+/=]+\\b	[JWT_TOKEN_REDACTED]	JSON Web Tokens	pii_builtin	1	t	showstopper	custom	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
acfee6fd-ab89-4e14-9d5a-a28505c6f070	bearer_token	\\b[Bb]earer\\s+[A-Za-z0-9+/]{20,}	[BEARER_TOKEN_REDACTED]	Bearer tokens	pii_builtin	1	t	showstopper	custom	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
ace352ca-febf-4a98-bde6-6dbaf1553ba2	openai_api_key	\\bsk-[A-Za-z0-9]{48,}\\b	[OPENAI_API_KEY_REDACTED]	OpenAI API keys	pii_builtin	1	t	showstopper	custom	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
b26fefa9-e760-4ec8-b557-fff8ad0b9401	stripe_key	\\bsk_(?:test|live)_[A-Za-z0-9]{24,}\\b	[STRIPE_KEY_REDACTED]	Stripe API keys	pii_builtin	1	t	showstopper	custom	2025-10-09 19:18:09.981049+00	2025-10-09 19:30:53.889306+00
\.


--
-- TOC entry 5011 (class 0 OID 18464)
-- Dependencies: 301
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_settings (key, value, updated_at) FROM stdin;
model_config_global	{"model": "gpt-4o", "provider": "openai", "parameters": {"maxTokens": 800, "temperature": 0.2}}	2025-10-09 19:30:53.888433+00
\.


--
-- TOC entry 4999 (class 0 OID 18294)
-- Dependencies: 289
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (id, user_id, conversation_id, method, params, prompt, response, status, progress, progress_message, error_code, error_message, error_data, started_at, completed_at, timeout_seconds, deliverable_type, deliverable_metadata, metadata, llm_metadata, response_metadata, evaluation, created_at, updated_at) FROM stdin;
61640b8a-caba-43ab-bdec-98453ad5314d	b29a590e-b07f-49df-a25b-574c956b5035	66f858b9-0d63-4afa-9052-10b661543c05	setup_project_structure	{}	Initialize project with proper folder structure, dependencies, and configuration files	Project structure initialized successfully with all required dependencies and configuration files.	completed	0	\N	\N	\N	\N	2025-09-30 20:18:09.981049+00	2025-09-30 20:48:09.981049+00	300	\N	\N	{"tags": ["development", "implementation"], "title": "Setup project structure", "priority": "high", "complexity": "low", "estimated_hours": 5}	{}	{}	\N	2025-09-30 20:18:09.981049+00	2025-09-30 20:23:09.981049+00
f4566b4a-943a-46fd-a185-d157889b37a0	b29a590e-b07f-49df-a25b-574c956b5035	66f858b9-0d63-4afa-9052-10b661543c05	implement_core_functionality	{}	Develop the main features and business logic according to specifications	Implementation in progress...	in_progress	0	\N	\N	\N	\N	2025-09-30 21:18:09.981049+00	\N	300	\N	\N	{"tags": ["development", "implementation"], "title": "Implement core functionality", "priority": "high", "complexity": "high", "estimated_hours": 9}	{}	{}	\N	2025-09-30 21:18:09.981049+00	2025-09-30 21:23:09.981049+00
d6af0651-e748-4ee5-ac78-f1a76eec7961	b29a590e-b07f-49df-a25b-574c956b5035	66f858b9-0d63-4afa-9052-10b661543c05	add_testing_validation	{}	Create comprehensive test suite and implement validation rules	Writing tests...	in_progress	0	\N	\N	\N	\N	2025-09-30 22:18:09.981049+00	\N	300	\N	\N	{"tags": ["development", "testing"], "title": "Add testing and validation", "priority": "medium", "complexity": "medium", "estimated_hours": 13}	{}	{}	\N	2025-09-30 22:18:09.981049+00	2025-09-30 22:23:09.981049+00
c6c5b821-0be0-45a0-b141-85cead82895b	b29a590e-b07f-49df-a25b-574c956b5035	5931a44f-506e-4377-b637-bf5bdfe79e8b	setup_project_structure	{}	Initialize project with proper folder structure, dependencies, and configuration files	Project structure initialized successfully with all required dependencies and configuration files.	completed	0	\N	\N	\N	\N	2025-10-01 20:18:09.981049+00	2025-10-01 20:48:09.981049+00	300	\N	\N	{"tags": ["development", "implementation"], "title": "Setup project structure", "priority": "high", "complexity": "low", "estimated_hours": 6}	{}	{}	\N	2025-10-01 20:18:09.981049+00	2025-10-01 20:23:09.981049+00
0c74fe67-8e66-48de-a4de-a75655c3f660	b29a590e-b07f-49df-a25b-574c956b5035	5931a44f-506e-4377-b637-bf5bdfe79e8b	implement_core_functionality	{}	Develop the main features and business logic according to specifications		pending	0	\N	\N	\N	\N	2025-10-01 21:18:09.981049+00	\N	300	\N	\N	{"tags": ["development", "implementation"], "title": "Implement core functionality", "priority": "high", "complexity": "high", "estimated_hours": 10}	{}	{}	\N	2025-10-01 21:18:09.981049+00	2025-10-01 21:23:09.981049+00
e0722690-81c5-48ba-bc4c-6e57012e9379	b29a590e-b07f-49df-a25b-574c956b5035	5931a44f-506e-4377-b637-bf5bdfe79e8b	add_testing_validation	{}	Create comprehensive test suite and implement validation rules		pending	0	\N	\N	\N	\N	2025-10-01 22:18:09.981049+00	\N	300	\N	\N	{"tags": ["development", "testing"], "title": "Add testing and validation", "priority": "medium", "complexity": "medium", "estimated_hours": 14}	{}	{}	\N	2025-10-01 22:18:09.981049+00	2025-10-01 22:23:09.981049+00
59465d43-6a15-4049-b9d2-fcfabcc73184	b29a590e-b07f-49df-a25b-574c956b5035	5931a44f-506e-4377-b637-bf5bdfe79e8b	deploy_and_monitor	{}	Deploy to production environment and set up monitoring systems		pending	0	\N	\N	\N	\N	2025-10-01 23:18:09.981049+00	\N	300	\N	\N	{"tags": ["development", "deployment"], "title": "Deploy and monitor", "priority": "low", "complexity": "medium", "estimated_hours": 18}	{}	{}	\N	2025-10-01 23:18:09.981049+00	2025-10-01 23:23:09.981049+00
27868440-e9eb-4fc6-a034-a608bbdb3cdd	b29a590e-b07f-49df-a25b-574c956b5035	91642195-1f88-4f3d-a88d-bc5d05440f80	setup_project_structure	{}	Initialize project with proper folder structure, dependencies, and configuration files	Project structure initialized successfully with all required dependencies and configuration files.	completed	0	\N	\N	\N	\N	2025-10-02 20:18:09.981049+00	2025-10-02 20:48:09.981049+00	300	\N	\N	{"tags": ["development", "implementation"], "title": "Setup project structure", "priority": "high", "complexity": "low", "estimated_hours": 4}	{}	{}	\N	2025-10-02 20:18:09.981049+00	2025-10-02 20:23:09.981049+00
4c167f29-5068-49ba-b47c-acd6b2b948fb	b29a590e-b07f-49df-a25b-574c956b5035	91642195-1f88-4f3d-a88d-bc5d05440f80	implement_core_functionality	{}	Develop the main features and business logic according to specifications	Core functionality implemented and tested.	completed	0	\N	\N	\N	\N	2025-10-02 21:18:09.981049+00	2025-10-02 22:03:09.981049+00	300	\N	\N	{"tags": ["development", "implementation"], "title": "Implement core functionality", "priority": "high", "complexity": "high", "estimated_hours": 8}	{}	{}	\N	2025-10-02 21:18:09.981049+00	2025-10-02 21:23:09.981049+00
d45f04ec-cffa-45a9-a09d-4b359dd573c4	b29a590e-b07f-49df-a25b-574c956b5035	2e536d84-d5c8-4c2e-bf58-436b5d7dd493	setup_project_structure	{}	Initialize project with proper folder structure, dependencies, and configuration files	Project structure initialized successfully with all required dependencies and configuration files.	completed	0	\N	\N	\N	\N	2025-10-03 20:18:09.981049+00	2025-10-03 20:48:09.981049+00	300	\N	\N	{"tags": ["development", "implementation"], "title": "Setup project structure", "priority": "high", "complexity": "low", "estimated_hours": 5}	{}	{}	\N	2025-10-03 20:18:09.981049+00	2025-10-03 20:23:09.981049+00
d6cebc12-a83a-436a-98b4-47284dfb7232	b29a590e-b07f-49df-a25b-574c956b5035	2e536d84-d5c8-4c2e-bf58-436b5d7dd493	implement_core_functionality	{}	Develop the main features and business logic according to specifications	Implementation in progress...	in_progress	0	\N	\N	\N	\N	2025-10-03 21:18:09.981049+00	\N	300	\N	\N	{"tags": ["development", "implementation"], "title": "Implement core functionality", "priority": "high", "complexity": "high", "estimated_hours": 9}	{}	{}	\N	2025-10-03 21:18:09.981049+00	2025-10-03 21:23:09.981049+00
f79aa939-e466-4ab4-8e88-2173a7de6c13	b29a590e-b07f-49df-a25b-574c956b5035	2e536d84-d5c8-4c2e-bf58-436b5d7dd493	add_testing_validation	{}	Create comprehensive test suite and implement validation rules	Testing suite completed with 95% coverage.	completed	0	\N	\N	\N	\N	2025-10-03 22:18:09.981049+00	2025-10-03 23:18:09.981049+00	300	\N	\N	{"tags": ["development", "testing"], "title": "Add testing and validation", "priority": "medium", "complexity": "medium", "estimated_hours": 13}	{}	{}	\N	2025-10-03 22:18:09.981049+00	2025-10-03 22:23:09.981049+00
b8d1877c-731b-4376-a2cd-bee8d315b05a	b29a590e-b07f-49df-a25b-574c956b5035	bff9ce60-05b5-42fb-b508-8bf3b973aadd	setup_project_structure	{}	Initialize project with proper folder structure, dependencies, and configuration files	Project structure initialized successfully with all required dependencies and configuration files.	completed	0	\N	\N	\N	\N	2025-10-04 20:18:09.981049+00	2025-10-04 20:48:09.981049+00	300	\N	\N	{"tags": ["development", "implementation"], "title": "Setup project structure", "priority": "high", "complexity": "low", "estimated_hours": 6}	{}	{}	\N	2025-10-04 20:18:09.981049+00	2025-10-04 20:23:09.981049+00
63127da0-6085-49ba-a637-076ebb208057	b29a590e-b07f-49df-a25b-574c956b5035	bff9ce60-05b5-42fb-b508-8bf3b973aadd	implement_core_functionality	{}	Develop the main features and business logic according to specifications		pending	0	\N	\N	\N	\N	2025-10-04 21:18:09.981049+00	\N	300	\N	\N	{"tags": ["development", "implementation"], "title": "Implement core functionality", "priority": "high", "complexity": "high", "estimated_hours": 10}	{}	{}	\N	2025-10-04 21:18:09.981049+00	2025-10-04 21:23:09.981049+00
219ebe7f-1c98-406f-abb2-92d471b63ad9	b29a590e-b07f-49df-a25b-574c956b5035	bff9ce60-05b5-42fb-b508-8bf3b973aadd	add_testing_validation	{}	Create comprehensive test suite and implement validation rules	Writing tests...	in_progress	0	\N	\N	\N	\N	2025-10-04 22:18:09.981049+00	\N	300	\N	\N	{"tags": ["development", "testing"], "title": "Add testing and validation", "priority": "medium", "complexity": "medium", "estimated_hours": 14}	{}	{}	\N	2025-10-04 22:18:09.981049+00	2025-10-04 22:23:09.981049+00
b794ea77-e824-41f7-a2a2-6d997487cbbd	b29a590e-b07f-49df-a25b-574c956b5035	bff9ce60-05b5-42fb-b508-8bf3b973aadd	deploy_and_monitor	{}	Deploy to production environment and set up monitoring systems		pending	0	\N	\N	\N	\N	2025-10-04 23:18:09.981049+00	\N	300	\N	\N	{"tags": ["development", "deployment"], "title": "Deploy and monitor", "priority": "low", "complexity": "medium", "estimated_hours": 18}	{}	{}	\N	2025-10-04 23:18:09.981049+00	2025-10-04 23:23:09.981049+00
c7043128-b431-4ea1-855c-0cf8068fce6e	b29a590e-b07f-49df-a25b-574c956b5035	c6741ed7-9003-4921-8dda-9aa6729f2916	setup_project_structure	{}	Initialize project with proper folder structure, dependencies, and configuration files	Project structure initialized successfully with all required dependencies and configuration files.	completed	0	\N	\N	\N	\N	2025-10-05 20:18:09.981049+00	2025-10-05 20:48:09.981049+00	300	\N	\N	{"tags": ["development", "implementation"], "title": "Setup project structure", "priority": "high", "complexity": "low", "estimated_hours": 4}	{}	{}	\N	2025-10-05 20:18:09.981049+00	2025-10-05 20:23:09.981049+00
231baab1-9e85-4bc3-8255-3603ddfaa160	b29a590e-b07f-49df-a25b-574c956b5035	c6741ed7-9003-4921-8dda-9aa6729f2916	implement_core_functionality	{}	Develop the main features and business logic according to specifications	Core functionality implemented and tested.	completed	0	\N	\N	\N	\N	2025-10-05 21:18:09.981049+00	2025-10-05 22:03:09.981049+00	300	\N	\N	{"tags": ["development", "implementation"], "title": "Implement core functionality", "priority": "high", "complexity": "high", "estimated_hours": 8}	{}	{}	\N	2025-10-05 21:18:09.981049+00	2025-10-05 21:23:09.981049+00
889f7526-8536-44df-a2df-9fdef6ae779a	b29a590e-b07f-49df-a25b-574c956b5035	70afc481-1bbd-4c2f-9bf7-68dfbc2dc3ee	setup_project_structure	{}	Initialize project with proper folder structure, dependencies, and configuration files	Project structure initialized successfully with all required dependencies and configuration files.	completed	0	\N	\N	\N	\N	2025-10-06 20:18:09.981049+00	2025-10-06 20:48:09.981049+00	300	\N	\N	{"tags": ["development", "implementation"], "title": "Setup project structure", "priority": "high", "complexity": "low", "estimated_hours": 5}	{}	{}	\N	2025-10-06 20:18:09.981049+00	2025-10-06 20:23:09.981049+00
da454747-12f6-4bc7-be20-47a8d80f930d	b29a590e-b07f-49df-a25b-574c956b5035	70afc481-1bbd-4c2f-9bf7-68dfbc2dc3ee	implement_core_functionality	{}	Develop the main features and business logic according to specifications	Implementation in progress...	in_progress	0	\N	\N	\N	\N	2025-10-06 21:18:09.981049+00	\N	300	\N	\N	{"tags": ["development", "implementation"], "title": "Implement core functionality", "priority": "high", "complexity": "high", "estimated_hours": 9}	{}	{}	\N	2025-10-06 21:18:09.981049+00	2025-10-06 21:23:09.981049+00
7d803fce-554b-4327-a16a-605367afcc7c	b29a590e-b07f-49df-a25b-574c956b5035	70afc481-1bbd-4c2f-9bf7-68dfbc2dc3ee	add_testing_validation	{}	Create comprehensive test suite and implement validation rules		pending	0	\N	\N	\N	\N	2025-10-06 22:18:09.981049+00	\N	300	\N	\N	{"tags": ["development", "testing"], "title": "Add testing and validation", "priority": "medium", "complexity": "medium", "estimated_hours": 13}	{}	{}	\N	2025-10-06 22:18:09.981049+00	2025-10-06 22:23:09.981049+00
4bbc6a43-51b6-4310-9228-78f0d7191d4b	b29a590e-b07f-49df-a25b-574c956b5035	d6671925-606e-462b-ae7c-66f46bf3f1b4	setup_project_structure	{}	Initialize project with proper folder structure, dependencies, and configuration files	Project structure initialized successfully with all required dependencies and configuration files.	completed	0	\N	\N	\N	\N	2025-10-07 20:18:09.981049+00	2025-10-07 20:48:09.981049+00	300	\N	\N	{"tags": ["development", "implementation"], "title": "Setup project structure", "priority": "high", "complexity": "low", "estimated_hours": 6}	{}	{}	\N	2025-10-07 20:18:09.981049+00	2025-10-07 20:23:09.981049+00
3dd0bf9e-1e2e-404e-9842-91d879812a0c	b29a590e-b07f-49df-a25b-574c956b5035	d6671925-606e-462b-ae7c-66f46bf3f1b4	implement_core_functionality	{}	Develop the main features and business logic according to specifications		pending	0	\N	\N	\N	\N	2025-10-07 21:18:09.981049+00	\N	300	\N	\N	{"tags": ["development", "implementation"], "title": "Implement core functionality", "priority": "high", "complexity": "high", "estimated_hours": 10}	{}	{}	\N	2025-10-07 21:18:09.981049+00	2025-10-07 21:23:09.981049+00
a811897e-fa12-44c4-9075-d6eda229229d	b29a590e-b07f-49df-a25b-574c956b5035	d6671925-606e-462b-ae7c-66f46bf3f1b4	add_testing_validation	{}	Create comprehensive test suite and implement validation rules	Testing suite completed with 95% coverage.	completed	0	\N	\N	\N	\N	2025-10-07 22:18:09.981049+00	2025-10-07 23:18:09.981049+00	300	\N	\N	{"tags": ["development", "testing"], "title": "Add testing and validation", "priority": "medium", "complexity": "medium", "estimated_hours": 14}	{}	{}	\N	2025-10-07 22:18:09.981049+00	2025-10-07 22:23:09.981049+00
87283827-959e-4d5f-a343-5f59deac2214	b29a590e-b07f-49df-a25b-574c956b5035	d6671925-606e-462b-ae7c-66f46bf3f1b4	deploy_and_monitor	{}	Deploy to production environment and set up monitoring systems		pending	0	\N	\N	\N	\N	2025-10-07 23:18:09.981049+00	\N	300	\N	\N	{"tags": ["development", "deployment"], "title": "Deploy and monitor", "priority": "low", "complexity": "medium", "estimated_hours": 18}	{}	{}	\N	2025-10-07 23:18:09.981049+00	2025-10-07 23:23:09.981049+00
32878a73-2dfd-4020-987b-6c8279897f57	b29a590e-b07f-49df-a25b-574c956b5035	9e6f502b-ba20-4e24-88a7-0ce85149c18b	setup_project_structure	{}	Initialize project with proper folder structure, dependencies, and configuration files	Project structure initialized successfully with all required dependencies and configuration files.	completed	0	\N	\N	\N	\N	2025-10-08 20:18:09.981049+00	2025-10-08 20:48:09.981049+00	300	\N	\N	{"tags": ["development", "implementation"], "title": "Setup project structure", "priority": "high", "complexity": "low", "estimated_hours": 4}	{}	{}	\N	2025-10-08 20:18:09.981049+00	2025-10-08 20:23:09.981049+00
bb343d22-89fa-4169-beb9-4c19e26bb024	b29a590e-b07f-49df-a25b-574c956b5035	9e6f502b-ba20-4e24-88a7-0ce85149c18b	implement_core_functionality	{}	Develop the main features and business logic according to specifications	Core functionality implemented and tested.	completed	0	\N	\N	\N	\N	2025-10-08 21:18:09.981049+00	2025-10-08 22:03:09.981049+00	300	\N	\N	{"tags": ["development", "implementation"], "title": "Implement core functionality", "priority": "high", "complexity": "high", "estimated_hours": 8}	{}	{}	\N	2025-10-08 21:18:09.981049+00	2025-10-08 21:23:09.981049+00
07a0ff32-f04d-4318-a343-b00600a499c7	b29a590e-b07f-49df-a25b-574c956b5035	9cfb3f53-02c6-4951-8e04-0fb624fad0e7	setup_project_structure	{}	Initialize project with proper folder structure, dependencies, and configuration files	Project structure initialized successfully with all required dependencies and configuration files.	completed	0	\N	\N	\N	\N	2025-10-09 20:18:09.981049+00	2025-10-09 20:48:09.981049+00	300	\N	\N	{"tags": ["development", "implementation"], "title": "Setup project structure", "priority": "high", "complexity": "low", "estimated_hours": 5}	{}	{}	\N	2025-10-09 20:18:09.981049+00	2025-10-09 20:23:09.981049+00
5bb531c7-9c93-4ec3-a30a-0976cfc4b802	b29a590e-b07f-49df-a25b-574c956b5035	9cfb3f53-02c6-4951-8e04-0fb624fad0e7	implement_core_functionality	{}	Develop the main features and business logic according to specifications	Implementation in progress...	in_progress	0	\N	\N	\N	\N	2025-10-09 21:18:09.981049+00	\N	300	\N	\N	{"tags": ["development", "implementation"], "title": "Implement core functionality", "priority": "high", "complexity": "high", "estimated_hours": 9}	{}	{}	\N	2025-10-09 21:18:09.981049+00	2025-10-09 21:23:09.981049+00
55ad747b-2e53-472b-9d02-17e388d27d41	b29a590e-b07f-49df-a25b-574c956b5035	9cfb3f53-02c6-4951-8e04-0fb624fad0e7	add_testing_validation	{}	Create comprehensive test suite and implement validation rules		pending	0	\N	\N	\N	\N	2025-10-09 22:18:09.981049+00	\N	300	\N	\N	{"tags": ["development", "testing"], "title": "Add testing and validation", "priority": "medium", "complexity": "medium", "estimated_hours": 13}	{}	{}	\N	2025-10-09 22:18:09.981049+00	2025-10-09 22:23:09.981049+00
7e13cb15-80a5-4380-bb7a-2660ba6a733f	a1b2c3d4-e5f6-7890-abcd-ef1234567890	38ef70b5-1a48-4024-81f3-8c937f3dcea6	converse	{"method": "converse", "prompt": "can you write a blog post about playing golf in the rain?", "metadata": {"jsonrpc": {"id": "7e13cb15-80a5-4380-bb7a-2660ba6a733f", "method": "converse"}, "protocol": "a2a-google", "llmSelection": {"maxTokens": 800, "modelName": "gpt-4o", "temperature": 0.2, "providerName": "openai"}, "conversationHistory": [{"role": "assistant", "content": "Hello! I'm the Blog Post Writer. How can I help you today?", "timestamp": "2025-10-09T19:55:19.016Z"}, {"role": "user", "content": "can you write a blog post about playing golf in the rain?", "timestamp": "2025-10-09T19:55:19.016Z"}]}, "conversationId": "38ef70b5-1a48-4024-81f3-8c937f3dcea6"}	can you write a blog post about playing golf in the rain?	{"success":true,"mode":"converse","payload":{"content":{"message":"**Playing Golf in the Rain: A Guide for Wet Weather Enthusiasts**\\n=================================================================\\n\\nAs the sun beats down on the course, many of us look forward to a refreshing round of golf on a rainy day. But is it really possible to enjoy this sport in the midst of a downpour? With the right mindset and techniques, playing golf in the rain can be just as enjoyable as on a sunny day.\\n\\n**The Benefits of Playing Golf in the Rain**\\n------------------------------------------\\n\\nWhile some might view rain-soaked courses as a hindrance to golfing, we believe that there's something special about playing in the wet. For one, the reduced crowds mean less competition for tee times and more opportunities to practice your game. Additionally, the misty veil that shrouds the course creates an eerie yet serene atmosphere that can be quite invigorating.\\n\\n**Preparing Your Gear for Rainy Golf**\\n-----------------------------------------\\n\\nBefore you step onto the course, make sure your gear is up to the task:\\n\\n*   **Golf shoes with good traction**: You'll want footwear that can grip the wet grass, reducing the risk of slipping and falling.\\n*   **Waterproof pants or a rain jacket**: Keeping dry and comfortable is key when playing in the rain. Look for clothing with breathable membranes to prevent overheating.\\n*   **A waterproof ball marker and divot tool**: These small accessories will help you mark your ball's position on the green, even when it's submerged.\\n\\n**Tips for Playing Golf in the Rain**\\n--------------------------------------\\n\\nNow that you're equipped with the right gear, here are some expert tips for navigating the course in wet conditions:\\n\\n*   **Take slower swings**: A rain-soaked clubhead will have less grip and momentum than a dry one. Take your time to ensure accuracy and control.\\n*   **Choose the right clubs**: Select clubs that can handle the moisture, such as fairway woods or hybrids, which tend to be less affected by wet conditions.\\n*   **Pay attention to drainage**: Make sure you're playing on parts of the course with good drainage. Avoid low-lying areas where water may collect.\\n\\n**Conclusion**\\n----------\\n\\nPlaying golf in the rain requires a bit more finesse and patience than playing on dry days, but it can also be incredibly rewarding. With the right mindset and techniques, you'll find that this wet weather sport has its unique charm. So next time the skies grow dark, grab your gear and hit the course – the misty veil is waiting for you!\\n\\n---\\n\\nHow was that? Would you like me to make any changes or create a new post?"},"metadata":{"provider":"ollama","model":"llama3.2:latest","usage":{"inputTokens":103,"outputTokens":524,"totalTokens":627,"cost":0},"routingDecision":{"provider":"ollama","model":"llama3.2:latest","isLocal":true,"modelTier":"general","fallbackUsed":false,"complexityScore":6,"reasoningPath":["Sovereign routing feature flag: DISABLED - using legacy routing","PII Detection: COMPLETED","Found 1 PII matches","External provider - creating pseudonym instructions","Complexity analysis: medium (score: 6)","Selected tier: general","Attempting local-first routing","Selected local model: llama3.2:latest"],"sovereignModeEnforced":false,"sovereignModeViolation":false,"piiMetadata":{"piiDetected":true,"showstopperDetected":false,"detectionResults":{"totalMatches":1,"flaggedMatches":[{"value":"Blog Post Writer","dataType":"name","severity":"info","confidence":1,"startIndex":120,"endIndex":136,"pattern":"name_first_last"}],"dataTypesSummary":{"name":{"count":1,"severity":"info","examples":["Blo..."]}},"severityBreakdown":{"showstopper":0,"warning":0,"info":1}},"policyDecision":{"allowed":true,"blocked":false,"violations":[],"reasoningPath":["PII Detection: COMPLETED","Found 1 PII matches","External provider - creating pseudonym instructions"],"appliedFor":"external"},"pseudonymInstructions":{"shouldPseudonymize":false,"targetMatches":[],"requestId":"38ef70b5-1a48-4024-81f3-8c937f3dcea6","context":"llm-boundary"},"userMessage":{"summary":"1 piece of personal information detected","details":["Detected: Name","Information flagged for monitoring but not modified"],"actionsTaken":["Request sent to AI model with monitoring","No modifications made to your content"],"isBlocked":false},"processingFlow":"pseudonymized","processingSteps":["pii-detection","external-provider-check","pseudonym-instructions-created"],"timestamps":{"detectionStart":1760039719026,"policyCheck":1760039719030}},"originalPrompt":"User message: can you write a blog post about playing golf in the rain?\\n\\nRecent transcript:\\n[assistant] \\"Hello! I'm the Blog Post Writer. How can I help you today?\\"\\n[user] \\"can you write a blog post about playing golf in the rain?\\"","routeToAgent":true},"metadata":{"agentId":"61ed59b0-ebb1-4f87-98d1-2df4c21d9509","agentSlug":"blog_post_writer","agentType":"context","modeProfile":"specialist_full","organizationSlug":"my-org","jsonrpc":{"id":"7e13cb15-80a5-4380-bb7a-2660ba6a733f","method":"converse"},"userId":"a1b2c3d4-e5f6-7890-abcd-ef1234567890","createdBy":"a1b2c3d4-e5f6-7890-abcd-ef1234567890","taskId":"7e13cb15-80a5-4380-bb7a-2660ba6a733f"}}}}	completed	0	\N	\N	\N	\N	\N	2025-10-09 19:55:39.571+00	300	\N	\N	{}	{}	{}	\N	2025-10-09 19:55:19.01902+00	2025-10-09 19:55:39.571+00
e03d95f2-780b-4bcc-9e8c-337e43e4e994	a1b2c3d4-e5f6-7890-abcd-ef1234567890	38ef70b5-1a48-4024-81f3-8c937f3dcea6	plan	{"method": "plan", "prompt": "can you write a blog post about playing golf in the rain?", "metadata": {"jsonrpc": {"id": "e03d95f2-780b-4bcc-9e8c-337e43e4e994", "method": "plan.create"}, "protocol": "a2a-google", "conversationHistory": []}, "conversationId": "38ef70b5-1a48-4024-81f3-8c937f3dcea6"}	can you write a blog post about playing golf in the rain?	{"success":true,"mode":"plan","payload":{"content":{"plan":{"id":"0459adf5-4c9f-4c1b-af2a-897d72fca33d","conversationId":"38ef70b5-1a48-4024-81f3-8c937f3dcea6","userId":"a1b2c3d4-e5f6-7890-abcd-ef1234567890","agentName":"blog_post_writer","namespace":"my-org","title":"Plan from blog_post_writer","currentVersionId":"d8ecd3b4-8481-4564-a383-b46f5f18cd51","createdAt":"2025-10-09T19:56:21.715Z","updatedAt":"2025-10-09T19:56:21.731Z","currentVersion":{"id":"d8ecd3b4-8481-4564-a383-b46f5f18cd51","planId":"0459adf5-4c9f-4c1b-af2a-897d72fca33d","versionNumber":1,"content":"# How to Play Golf in the Rain: Tips, Gear, and Tricks for a Successful Wet Day\\n\\n*Meta description: Playing golf in the rain can be challenging, but with the right gear, strategy, and mindset, you can still enjoy a great round. Learn practical tips, gear recommendations, and mental hacks to keep your game on track when the skies open up.*\\n\\n---\\n\\n## Table of Contents\\n\\n1. [Why Golfing in the Rain Matters](#why-golfing-in-the-rain-matters)\\n2. [Common Challenges of a Wet Round](#common-challenges-of-a-wet-round)\\n3. [Essential Gear for Rainy Golf](#essential-gear-for-rainy-golf)\\n4. [Pre‑Round Preparation](#pre-round-preparation)\\n5. **Playing the Course in the Rain**  \\n   5.1. [Club Selection & Ball Choice](#club-selection--ball-choice)  \\n   5.2. [Swing Adjustments](#swing-adjustments)  \\n   5.3. [Course Management](#course-management)  \\n6. [Mental & Physical Tips](#mental--physical-tips)\\n7. [After‑Game Recovery](#after-game-recovery)\\n8. [Frequently Asked Questions](#frequently-asked-questions)\\n9. [Conclusion](#conclusion)\\n\\n---\\n\\n## Why Golfing in the Rain Matters\\n\\nGolf is a sport that thrives on precision, consistency, and a calm mindset. Rain can disrupt all three, but it also offers unique opportunities:\\n\\n- **Improved Course Conditions** – Soft greens can reduce spin and help the ball stay on the fairway.\\n- **Mental Challenge** – Adapting to wet conditions sharpens focus and resilience.\\n- **Less Crowd** – Fewer players on the course can mean more space and less pressure.\\n\\nIf you’re a golfer who loves a challenge, mastering the rain can elevate your game.\\n\\n---\\n\\n## Common Challenges of a Wet Round\\n\\n| Challenge | Impact on Play | Why It Happens |\\n|-----------|----------------|----------------|\\n| **Wet Balls** | Reduced carry, more spin | Water increases ball spin and reduces launch |\\n| **Slippery Clubs** | Poor grip, inconsistent swing | Moisture on hands and clubface |\\n| **Soft Greens** | Slower roll, less reaction time | Turf becomes mushy and water‑logged |\\n| **Wind & Visibility** | Unpredictable ball flight | Rain can amplify wind gusts and lower visibility |\\n\\nUnderstanding these hurdles is the first step toward overcoming them.\\n\\n---\\n\\n## Essential Gear for Rainy Golf\\n\\n| Item | Why It Matters | Tips |\\n|------|----------------|------|\\n| **Water‑Resistant Jacket & Pants** | Keeps you dry and comfortable | Look for breathable, quick‑dry fabrics |\\n| **Windbreaker** | Protects against wind chill | Lightweight, packable |\\n| **Golf Gloves (Water‑Proof)** | Maintains grip | Consider latex‑free or nitrile gloves with a textured palm |\\n| **Rain‑Proof Golf Bag** | Protects clubs & electronics | Waterproof or water‑repellent material |\\n| **Golf Ball with Low Spin** | Better performance in wet | Opt for “low spin” or “soft feel” models |\\n| **Cap or Visor** | Shields eyes from rain | A brim that directs water away from your face |\\n\\n**Pro Tip:** Carry a spare glove and a small towel for quick dry‑downs between shots.\\n\\n---\\n\\n## Pre‑Round Preparation\\n\\n1. **Check the Forecast** – Use reliable weather apps or the course’s website for up‑to‑date rain predictions.\\n2. **Inspect the Course** – Look for standing water, slushy greens, and potential hazards.\\n3. **Warm‑Up Thoroughly** – A longer warm‑up helps loosen muscles and adjust to a slower swing tempo.\\n4. **Plan Your Tee Shots** – Shorter, more accurate drives are safer when the ball doesn’t travel as far.\\n\\n---\\n\\n## Playing the Course in the Rain\\n\\n### 5.1 Club Selection & Ball Choice\\n\\n- **Shorter Clubs**: Use a club you’re comfortable with; the ball will carry less distance.\\n- **Low‑Spin Balls**: Choose a ball that reduces backspin, giving you more control on the green.\\n- **Avoid High‑Launch Shots**: The ball will tend to drop early; keep it low and controlled.\\n\\n### 5.2 Swing Adjustments\\n\\n| Adjustment | Effect | How to Execute |\\n|------------|--------|----------------|\\n| **Lower the Ball Position** | Reduces lift | Place the ball slightly forward in your stance |\\n| **Shorter Tempo** | Prevents over‑swing | Focus on a smooth, controlled swing |\\n| **Avoid Over‑Rotating the Clubface** | Limits spin | Keep the clubface square at impact |\\n\\n### 5.3 Course Management\\n\\n- **Play to the Wind**: In rain, wind can be more pronounced. Adjust your line accordingly.\\n- **Choose the Safest Route**: Opt for the center of the fairway; avoid the edges where water can pool.\\n- **Use the Greens Wisely**: Greens are slower; aim for a softer approach shot.\\n\\n---\\n\\n## Mental & Physical Tips\\n\\n| Tip | Why It Helps |\\n|-----|--------------|\\n| **Stay Positive** | A confident mindset improves focus and swing consistency. |\\n| **Take Breaks** | Short pauses keep your body from getting too cold or stiff. |\\n| **Stay Warm** | A warm body swings more efficiently; use hand warmers if needed. |\\n| **Visualize the Shot** | Mentally picturing a smooth swing can help maintain rhythm. |\\n\\n---\\n\\n## After‑Game Recovery\\n\\n- **Dry Off**: Change into dry clothing as soon as possible to avoid chill.\\n- **Hydrate**: Even if it’s raining, you’re still sweating. Drink water or a sports drink.\\n- **Stretch**: Loosen the muscles you used, especially the back and shoulders.\\n- **Reflect**: Note what worked and what didn’t. Use these insights for next time.\\n\\n---\\n\\n## Frequently Asked Questions\\n\\n| Question | Answer |\\n|----------|--------|\\n| **Can I play golf in heavy rain?** | It’s possible, but be cautious of water hazards and reduced visibility. |\\n| **Do I need a golf umbrella?** | A golf umbrella is handy for shielding from rain, but many golfers prefer staying dry with proper gear. |\\n| **How does rain affect putting?** | Greens are slower; use shorter, more controlled putts. |\\n| **Is it safe to play in a downpour?** | Only if the course is open and there are no flooding hazards. |\\n\\n---\\n\\n## Conclusion\\n\\nPlaying golf in the rain isn’t just about enduring wet conditions—it’s an opportunity to sharpen your skills, adapt your strategy, and enjoy the game in a new light. With the right gear, thoughtful preparation, and a resilient mindset, you can turn a rainy round into a memorable one. So next time the clouds roll in, grab your waterproof jacket, adjust your swing, and let the rain add an extra layer of excitement to your game!\\n\\n---\\n\\n**Ready to tackle the rain?** Download our free *Rainy Golf Checklist* and stay prepared for every wet round.","format":"markdown","createdByType":"agent","createdById":null,"taskId":"e03d95f2-780b-4bcc-9e8c-337e43e4e994","metadata":{"usage":{"cost":0,"inputTokens":115,"totalTokens":1948,"outputTokens":1833},"llmModel":"gpt-oss:20b","llmProvider":"ollama"},"isCurrentVersion":true,"createdAt":"2025-10-09T19:56:21.727Z"}},"version":{"id":"d8ecd3b4-8481-4564-a383-b46f5f18cd51","planId":"0459adf5-4c9f-4c1b-af2a-897d72fca33d","versionNumber":1,"content":"# How to Play Golf in the Rain: Tips, Gear, and Tricks for a Successful Wet Day\\n\\n*Meta description: Playing golf in the rain can be challenging, but with the right gear, strategy, and mindset, you can still enjoy a great round. Learn practical tips, gear recommendations, and mental hacks to keep your game on track when the skies open up.*\\n\\n---\\n\\n## Table of Contents\\n\\n1. [Why Golfing in the Rain Matters](#why-golfing-in-the-rain-matters)\\n2. [Common Challenges of a Wet Round](#common-challenges-of-a-wet-round)\\n3. [Essential Gear for Rainy Golf](#essential-gear-for-rainy-golf)\\n4. [Pre‑Round Preparation](#pre-round-preparation)\\n5. **Playing the Course in the Rain**  \\n   5.1. [Club Selection & Ball Choice](#club-selection--ball-choice)  \\n   5.2. [Swing Adjustments](#swing-adjustments)  \\n   5.3. [Course Management](#course-management)  \\n6. [Mental & Physical Tips](#mental--physical-tips)\\n7. [After‑Game Recovery](#after-game-recovery)\\n8. [Frequently Asked Questions](#frequently-asked-questions)\\n9. [Conclusion](#conclusion)\\n\\n---\\n\\n## Why Golfing in the Rain Matters\\n\\nGolf is a sport that thrives on precision, consistency, and a calm mindset. Rain can disrupt all three, but it also offers unique opportunities:\\n\\n- **Improved Course Conditions** – Soft greens can reduce spin and help the ball stay on the fairway.\\n- **Mental Challenge** – Adapting to wet conditions sharpens focus and resilience.\\n- **Less Crowd** – Fewer players on the course can mean more space and less pressure.\\n\\nIf you’re a golfer who loves a challenge, mastering the rain can elevate your game.\\n\\n---\\n\\n## Common Challenges of a Wet Round\\n\\n| Challenge | Impact on Play | Why It Happens |\\n|-----------|----------------|----------------|\\n| **Wet Balls** | Reduced carry, more spin | Water increases ball spin and reduces launch |\\n| **Slippery Clubs** | Poor grip, inconsistent swing | Moisture on hands and clubface |\\n| **Soft Greens** | Slower roll, less reaction time | Turf becomes mushy and water‑logged |\\n| **Wind & Visibility** | Unpredictable ball flight | Rain can amplify wind gusts and lower visibility |\\n\\nUnderstanding these hurdles is the first step toward overcoming them.\\n\\n---\\n\\n## Essential Gear for Rainy Golf\\n\\n| Item | Why It Matters | Tips |\\n|------|----------------|------|\\n| **Water‑Resistant Jacket & Pants** | Keeps you dry and comfortable | Look for breathable, quick‑dry fabrics |\\n| **Windbreaker** | Protects against wind chill | Lightweight, packable |\\n| **Golf Gloves (Water‑Proof)** | Maintains grip | Consider latex‑free or nitrile gloves with a textured palm |\\n| **Rain‑Proof Golf Bag** | Protects clubs & electronics | Waterproof or water‑repellent material |\\n| **Golf Ball with Low Spin** | Better performance in wet | Opt for “low spin” or “soft feel” models |\\n| **Cap or Visor** | Shields eyes from rain | A brim that directs water away from your face |\\n\\n**Pro Tip:** Carry a spare glove and a small towel for quick dry‑downs between shots.\\n\\n---\\n\\n## Pre‑Round Preparation\\n\\n1. **Check the Forecast** – Use reliable weather apps or the course’s website for up‑to‑date rain predictions.\\n2. **Inspect the Course** – Look for standing water, slushy greens, and potential hazards.\\n3. **Warm‑Up Thoroughly** – A longer warm‑up helps loosen muscles and adjust to a slower swing tempo.\\n4. **Plan Your Tee Shots** – Shorter, more accurate drives are safer when the ball doesn’t travel as far.\\n\\n---\\n\\n## Playing the Course in the Rain\\n\\n### 5.1 Club Selection & Ball Choice\\n\\n- **Shorter Clubs**: Use a club you’re comfortable with; the ball will carry less distance.\\n- **Low‑Spin Balls**: Choose a ball that reduces backspin, giving you more control on the green.\\n- **Avoid High‑Launch Shots**: The ball will tend to drop early; keep it low and controlled.\\n\\n### 5.2 Swing Adjustments\\n\\n| Adjustment | Effect | How to Execute |\\n|------------|--------|----------------|\\n| **Lower the Ball Position** | Reduces lift | Place the ball slightly forward in your stance |\\n| **Shorter Tempo** | Prevents over‑swing | Focus on a smooth, controlled swing |\\n| **Avoid Over‑Rotating the Clubface** | Limits spin | Keep the clubface square at impact |\\n\\n### 5.3 Course Management\\n\\n- **Play to the Wind**: In rain, wind can be more pronounced. Adjust your line accordingly.\\n- **Choose the Safest Route**: Opt for the center of the fairway; avoid the edges where water can pool.\\n- **Use the Greens Wisely**: Greens are slower; aim for a softer approach shot.\\n\\n---\\n\\n## Mental & Physical Tips\\n\\n| Tip | Why It Helps |\\n|-----|--------------|\\n| **Stay Positive** | A confident mindset improves focus and swing consistency. |\\n| **Take Breaks** | Short pauses keep your body from getting too cold or stiff. |\\n| **Stay Warm** | A warm body swings more efficiently; use hand warmers if needed. |\\n| **Visualize the Shot** | Mentally picturing a smooth swing can help maintain rhythm. |\\n\\n---\\n\\n## After‑Game Recovery\\n\\n- **Dry Off**: Change into dry clothing as soon as possible to avoid chill.\\n- **Hydrate**: Even if it’s raining, you’re still sweating. Drink water or a sports drink.\\n- **Stretch**: Loosen the muscles you used, especially the back and shoulders.\\n- **Reflect**: Note what worked and what didn’t. Use these insights for next time.\\n\\n---\\n\\n## Frequently Asked Questions\\n\\n| Question | Answer |\\n|----------|--------|\\n| **Can I play golf in heavy rain?** | It’s possible, but be cautious of water hazards and reduced visibility. |\\n| **Do I need a golf umbrella?** | A golf umbrella is handy for shielding from rain, but many golfers prefer staying dry with proper gear. |\\n| **How does rain affect putting?** | Greens are slower; use shorter, more controlled putts. |\\n| **Is it safe to play in a downpour?** | Only if the course is open and there are no flooding hazards. |\\n\\n---\\n\\n## Conclusion\\n\\nPlaying golf in the rain isn’t just about enduring wet conditions—it’s an opportunity to sharpen your skills, adapt your strategy, and enjoy the game in a new light. With the right gear, thoughtful preparation, and a resilient mindset, you can turn a rainy round into a memorable one. So next time the clouds roll in, grab your waterproof jacket, adjust your swing, and let the rain add an extra layer of excitement to your game!\\n\\n---\\n\\n**Ready to tackle the rain?** Download our free *Rainy Golf Checklist* and stay prepared for every wet round.","format":"markdown","createdByType":"agent","createdById":null,"taskId":"e03d95f2-780b-4bcc-9e8c-337e43e4e994","metadata":{"usage":{"cost":0,"inputTokens":115,"totalTokens":1948,"outputTokens":1833},"llmModel":"gpt-oss:20b","llmProvider":"ollama"},"isCurrentVersion":true,"createdAt":"2025-10-09T19:56:21.727Z"},"isNew":true},"metadata":{"provider":"ollama","model":"gpt-oss:20b","usage":{"inputTokens":115,"outputTokens":1833,"totalTokens":1948,"cost":0},"routingDecision":{"provider":"ollama","model":"gpt-oss:20b","isLocal":true,"modelTier":"ultra-fast","fallbackUsed":false,"complexityScore":3,"reasoningPath":["Sovereign routing feature flag: DISABLED - using legacy routing","PII Detection: COMPLETED","Found 0 PII matches","External provider - creating pseudonym instructions","Complexity analysis: simple (score: 3)","Selected tier: ultra-fast","Attempting local-first routing","Selected local model: gpt-oss:20b"],"sovereignModeEnforced":false,"sovereignModeViolation":false,"piiMetadata":{"piiDetected":false,"showstopperDetected":false,"detectionResults":{"totalMatches":0,"flaggedMatches":[],"dataTypesSummary":{},"severityBreakdown":{"showstopper":0,"warning":0,"info":0}},"policyDecision":{"allowed":true,"blocked":false,"violations":[],"reasoningPath":["PII Detection: COMPLETED","Found 0 PII matches","External provider - creating pseudonym instructions"],"appliedFor":"external"},"pseudonymInstructions":{"shouldPseudonymize":false,"targetMatches":[],"requestId":"38ef70b5-1a48-4024-81f3-8c937f3dcea6","context":"llm-boundary"},"userMessage":{"summary":"No personal information detected","details":[],"actionsTaken":["Request sent to AI model without modifications"],"isBlocked":false},"processingFlow":"pseudonymized","processingSteps":["pii-detection","external-provider-check","pseudonym-instructions-created"],"timestamps":{"detectionStart":1760039747052,"policyCheck":1760039747052}},"originalPrompt":"User message: can you write a blog post about playing golf in the rain?","routeToAgent":true}}}}	completed	0	\N	\N	\N	\N	\N	2025-10-09 19:56:21.739+00	300	\N	\N	{}	{}	{}	\N	2025-10-09 19:55:47.049813+00	2025-10-09 19:56:21.739+00
5c588e10-433a-4cbc-a130-499a70918670	a1b2c3d4-e5f6-7890-abcd-ef1234567890	c01c1680-25a0-4bde-a648-e367a4a480d7	build	{"method": "build", "prompt": "need an image of a golfer", "metadata": {"jsonrpc": {"id": "5c588e10-433a-4cbc-a130-499a70918670", "method": "build"}, "protocol": "a2a-google", "llmSelection": {"modelName": "gpt-oss:20b", "temperature": 0.7, "providerName": "ollama", "cidafmOptions": {"customOptions": {"customModifiers": []}, "executedCommands": [], "responseModifiers": [], "activeStateModifiers": []}}, "conversationHistory": [{"role": "assistant", "content": "Hello! I'm the Image Google Generator. How can I help you today?", "timestamp": "2025-10-09T20:21:22.072Z"}, {"role": "user", "content": "need an image of a golfer", "timestamp": "2025-10-09T20:21:22.072Z"}]}, "conversationId": "c01c1680-25a0-4bde-a648-e367a4a480d7"}	need an image of a golfer	{"success":false,"mode":"build","payload":{"content":{},"metadata":{"reason":"function_execution_failed"}}}	completed	0	\N	\N	\N	\N	\N	2025-10-09 20:21:27.262+00	300	\N	\N	{}	{}	{}	\N	2025-10-09 20:21:22.077346+00	2025-10-09 20:21:27.262+00
9d42f8bf-4847-463f-ab54-44d27dd8c1fd	a1b2c3d4-e5f6-7890-abcd-ef1234567890	c01c1680-25a0-4bde-a648-e367a4a480d7	build	{"method": "build", "prompt": "try again", "metadata": {"jsonrpc": {"id": "9d42f8bf-4847-463f-ab54-44d27dd8c1fd", "method": "build"}, "protocol": "a2a-google", "llmSelection": {"modelName": "gemini-2.5-flash", "temperature": 0.7, "providerName": "google", "cidafmOptions": {"customOptions": {"customModifiers": []}, "executedCommands": [], "responseModifiers": [], "activeStateModifiers": []}}, "conversationHistory": [{"role": "assistant", "content": "Hello! I'm the Image Google Generator. How can I help you today?", "timestamp": "2025-10-09T20:22:04.536Z"}, {"role": "user", "content": "need an image of a golfer", "timestamp": "2025-10-09T20:22:04.536Z"}, {"role": "assistant", "content": "{\\n  \\"success\\": false,\\n  \\"mode\\": \\"build\\",\\n  \\"payload\\": {\\n    \\"content\\": {},\\n    \\"metadata\\": {\\n      \\"reason\\": \\"function_execution_failed\\"\\n    }\\n  }\\n}", "timestamp": "2025-10-09T20:22:04.536Z"}, {"role": "user", "content": "try again", "timestamp": "2025-10-09T20:22:04.536Z"}]}, "conversationId": "c01c1680-25a0-4bde-a648-e367a4a480d7"}	try again	{"success":false,"mode":"build","payload":{"content":{},"metadata":{"reason":"function_execution_failed"}}}	completed	0	\N	\N	\N	\N	\N	2025-10-09 20:22:05.448+00	300	\N	\N	{}	{}	{}	\N	2025-10-09 20:22:04.541589+00	2025-10-09 20:22:05.448+00
\.


--
-- TOC entry 5012 (class 0 OID 18470)
-- Dependencies: 302
-- Data for Name: user_cidafm_commands; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_cidafm_commands (id, user_id, command_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5013 (class 0 OID 18477)
-- Dependencies: 303
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, display_name, role, roles, created_at, updated_at, namespace_access, status, organization_slug) FROM stdin;
b29a590e-b07f-49df-a25b-574c956b5035	demo.user@orchestratorai.io	Demo User	\N	["user"]	2025-10-09 19:18:09.981049+00	2025-10-09 19:18:09.981049+00	["demo"]	active	\N
a1b2c3d4-e5f6-7890-abcd-ef1234567890	admin@orchestratorai.io	Admin User	\N	["user", "admin"]	2025-10-09 19:28:38.367404+00	2025-10-09 19:28:38.367404+00	["demo", "my-org"]	active	\N
c4d5e6f7-8901-2345-6789-abcdef012345	golfergeek@orchestratorai.io	GolferGeek	\N	["user", "admin"]	2025-10-09 19:28:38.367404+00	2025-10-09 19:28:38.367404+00	["my-org"]	active	\N
\.


--
-- TOC entry 4976 (class 0 OID 17609)
-- Dependencies: 266
-- Data for Name: messages_2025_10_08; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_10_08 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4977 (class 0 OID 17621)
-- Dependencies: 267
-- Data for Name: messages_2025_10_09; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_10_09 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4978 (class 0 OID 17633)
-- Dependencies: 268
-- Data for Name: messages_2025_10_10; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_10_10 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4979 (class 0 OID 17645)
-- Dependencies: 269
-- Data for Name: messages_2025_10_11; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_10_11 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4980 (class 0 OID 17657)
-- Dependencies: 270
-- Data for Name: messages_2025_10_12; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_10_12 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4973 (class 0 OID 17430)
-- Dependencies: 259
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2025-10-09 19:18:06
20211116045059	2025-10-09 19:18:06
20211116050929	2025-10-09 19:18:06
20211116051442	2025-10-09 19:18:06
20211116212300	2025-10-09 19:18:06
20211116213355	2025-10-09 19:18:06
20211116213934	2025-10-09 19:18:06
20211116214523	2025-10-09 19:18:06
20211122062447	2025-10-09 19:18:06
20211124070109	2025-10-09 19:18:06
20211202204204	2025-10-09 19:18:06
20211202204605	2025-10-09 19:18:06
20211210212804	2025-10-09 19:18:06
20211228014915	2025-10-09 19:18:06
20220107221237	2025-10-09 19:18:06
20220228202821	2025-10-09 19:18:06
20220312004840	2025-10-09 19:18:06
20220603231003	2025-10-09 19:18:06
20220603232444	2025-10-09 19:18:06
20220615214548	2025-10-09 19:18:06
20220712093339	2025-10-09 19:18:06
20220908172859	2025-10-09 19:18:06
20220916233421	2025-10-09 19:18:06
20230119133233	2025-10-09 19:18:06
20230128025114	2025-10-09 19:18:06
20230128025212	2025-10-09 19:18:06
20230227211149	2025-10-09 19:18:06
20230228184745	2025-10-09 19:18:06
20230308225145	2025-10-09 19:18:06
20230328144023	2025-10-09 19:18:06
20231018144023	2025-10-09 19:18:06
20231204144023	2025-10-09 19:18:06
20231204144024	2025-10-09 19:18:06
20231204144025	2025-10-09 19:18:06
20240108234812	2025-10-09 19:18:06
20240109165339	2025-10-09 19:18:06
20240227174441	2025-10-09 19:18:06
20240311171622	2025-10-09 19:18:06
20240321100241	2025-10-09 19:18:06
20240401105812	2025-10-09 19:18:06
20240418121054	2025-10-09 19:18:06
20240523004032	2025-10-09 19:18:06
20240618124746	2025-10-09 19:18:06
20240801235015	2025-10-09 19:18:06
20240805133720	2025-10-09 19:18:06
20240827160934	2025-10-09 19:18:06
20240919163303	2025-10-09 19:18:06
20240919163305	2025-10-09 19:18:06
20241019105805	2025-10-09 19:18:06
20241030150047	2025-10-09 19:18:06
20241108114728	2025-10-09 19:18:06
20241121104152	2025-10-09 19:18:06
20241130184212	2025-10-09 19:18:06
20241220035512	2025-10-09 19:18:06
20241220123912	2025-10-09 19:18:06
20241224161212	2025-10-09 19:18:06
20250107150512	2025-10-09 19:18:06
20250110162412	2025-10-09 19:18:06
20250123174212	2025-10-09 19:18:06
20250128220012	2025-10-09 19:18:06
20250506224012	2025-10-09 19:18:06
20250523164012	2025-10-09 19:18:06
20250714121412	2025-10-09 19:18:06
20250905041441	2025-10-09 19:18:06
\.


--
-- TOC entry 4975 (class 0 OID 17453)
-- Dependencies: 262
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at) FROM stdin;
\.


--
-- TOC entry 4964 (class 0 OID 16509)
-- Dependencies: 240
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
\.


--
-- TOC entry 5026 (class 0 OID 19116)
-- Dependencies: 318
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets_analytics (id, type, format, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5027 (class 0 OID 19127)
-- Dependencies: 319
-- Data for Name: iceberg_namespaces; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.iceberg_namespaces (id, bucket_id, name, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5028 (class 0 OID 19143)
-- Dependencies: 320
-- Data for Name: iceberg_tables; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.iceberg_tables (id, namespace_id, bucket_id, name, location, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4966 (class 0 OID 16551)
-- Dependencies: 242
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2025-10-09 19:18:08.515628
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2025-10-09 19:18:08.517105
2	storage-schema	5c7968fd083fcea04050c1b7f6253c9771b99011	2025-10-09 19:18:08.517813
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2025-10-09 19:18:08.521893
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2025-10-09 19:18:08.529538
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2025-10-09 19:18:08.530463
6	change-column-name-in-get-size	f93f62afdf6613ee5e7e815b30d02dc990201044	2025-10-09 19:18:08.53181
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2025-10-09 19:18:08.532876
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2025-10-09 19:18:08.533584
9	fix-search-function	3a0af29f42e35a4d101c259ed955b67e1bee6825	2025-10-09 19:18:08.534332
10	search-files-search-function	68dc14822daad0ffac3746a502234f486182ef6e	2025-10-09 19:18:08.535311
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2025-10-09 19:18:08.537035
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2025-10-09 19:18:08.538384
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2025-10-09 19:18:08.539189
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2025-10-09 19:18:08.539937
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2025-10-09 19:18:08.547467
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2025-10-09 19:18:08.54869
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2025-10-09 19:18:08.549696
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2025-10-09 19:18:08.550633
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2025-10-09 19:18:08.551811
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2025-10-09 19:18:08.55267
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2025-10-09 19:18:08.554671
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2025-10-09 19:18:08.561664
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2025-10-09 19:18:08.567087
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2025-10-09 19:18:08.568232
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2025-10-09 19:18:08.569171
26	objects-prefixes	ef3f7871121cdc47a65308e6702519e853422ae2	2025-10-09 19:18:12.152794
27	search-v2	33b8f2a7ae53105f028e13e9fcda9dc4f356b4a2	2025-10-09 19:18:12.163114
28	object-bucket-name-sorting	ba85ec41b62c6a30a3f136788227ee47f311c436	2025-10-09 19:18:12.16896
29	create-prefixes	a7b1a22c0dc3ab630e3055bfec7ce7d2045c5b7b	2025-10-09 19:18:12.172215
30	update-object-levels	6c6f6cc9430d570f26284a24cf7b210599032db7	2025-10-09 19:18:12.173532
31	objects-level-index	33f1fef7ec7fea08bb892222f4f0f5d79bab5eb8	2025-10-09 19:18:12.241211
32	backward-compatible-index-on-objects	2d51eeb437a96868b36fcdfb1ddefdf13bef1647	2025-10-09 19:18:12.244629
33	backward-compatible-index-on-prefixes	fe473390e1b8c407434c0e470655945b110507bf	2025-10-09 19:18:12.24661
34	optimize-search-function-v1	82b0e469a00e8ebce495e29bfa70a0797f7ebd2c	2025-10-09 19:18:12.246891
35	add-insert-trigger-prefixes	63bb9fd05deb3dc5e9fa66c83e82b152f0caf589	2025-10-09 19:18:12.248933
36	optimise-existing-functions	81cf92eb0c36612865a18016a38496c530443899	2025-10-09 19:18:12.249923
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2025-10-09 19:18:12.252601
38	iceberg-catalog-flag-on-buckets	19a8bd89d5dfa69af7f222a46c726b7c41e462c5	2025-10-09 19:18:12.253849
\.


--
-- TOC entry 4965 (class 0 OID 16524)
-- Dependencies: 241
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata, level) FROM stdin;
\.


--
-- TOC entry 5025 (class 0 OID 19071)
-- Dependencies: 317
-- Data for Name: prefixes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.prefixes (bucket_id, name, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4981 (class 0 OID 17773)
-- Dependencies: 271
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata) FROM stdin;
\.


--
-- TOC entry 4982 (class 0 OID 17787)
-- Dependencies: 272
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- TOC entry 4969 (class 0 OID 16743)
-- Dependencies: 255
-- Data for Name: hooks; Type: TABLE DATA; Schema: supabase_functions; Owner: supabase_functions_admin
--

COPY supabase_functions.hooks (id, hook_table_id, hook_name, created_at, request_id) FROM stdin;
\.


--
-- TOC entry 4967 (class 0 OID 16734)
-- Dependencies: 253
-- Data for Name: migrations; Type: TABLE DATA; Schema: supabase_functions; Owner: supabase_functions_admin
--

COPY supabase_functions.migrations (version, inserted_at) FROM stdin;
initial	2025-10-09 19:17:54.930461+00
20210809183423_update_grants	2025-10-09 19:17:54.930461+00
\.


--
-- TOC entry 4995 (class 0 OID 18146)
-- Dependencies: 285
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: supabase_migrations; Owner: postgres
--

COPY supabase_migrations.schema_migrations (version, statements, name) FROM stdin;
00000000000001	{"SET statement_timeout = 0","SET lock_timeout = 0","SET idle_in_transaction_session_timeout = 0","SET client_encoding = 'UTF8'","SET standard_conforming_strings = on","SELECT pg_catalog.set_config('search_path', '', false)","SET check_function_bodies = false","SET xmloption = content","SET client_min_messages = warning","SET row_security = off","CREATE EXTENSION IF NOT EXISTS \\"pg_net\\" WITH SCHEMA \\"extensions\\"","COMMENT ON SCHEMA \\"public\\" IS 'standard public schema'","CREATE EXTENSION IF NOT EXISTS \\"pg_graphql\\" WITH SCHEMA \\"graphql\\"","CREATE EXTENSION IF NOT EXISTS \\"pg_stat_statements\\" WITH SCHEMA \\"extensions\\"","CREATE EXTENSION IF NOT EXISTS \\"pgcrypto\\" WITH SCHEMA \\"extensions\\"","CREATE EXTENSION IF NOT EXISTS \\"supabase_vault\\" WITH SCHEMA \\"vault\\"","CREATE EXTENSION IF NOT EXISTS \\"uuid-ossp\\" WITH SCHEMA \\"extensions\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"calculate_completion_percentage\\"(\\"requirements\\" \\"jsonb\\") RETURNS integer\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nDECLARE\n    total_fields INTEGER := 12;  -- Total required fields\n    completed_fields INTEGER := 0;\n    field_name TEXT;\nBEGIN\n    -- Count non-null, non-empty required fields\n    FOR field_name IN SELECT * FROM jsonb_object_keys(requirements)\n    LOOP\n        IF requirements ->> field_name IS NOT NULL \n           AND LENGTH(TRIM(requirements ->> field_name)) > 0 THEN\n            completed_fields := completed_fields + 1;\n        END IF;\n    END LOOP;\n    \n    RETURN (completed_fields * 100 / total_fields);\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"calculate_completion_percentage\\"(\\"requirements\\" \\"jsonb\\") OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"cleanup_abandoned_conversations\\"() RETURNS integer\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nDECLARE\n    deleted_count INTEGER;\nBEGIN\n    -- Delete conversations abandoned for more than 7 days\n    DELETE FROM agent_creation_conversations\n    WHERE completion_status = 'in_progress'\n      AND last_activity_at < NOW() - INTERVAL '7 days';\n    \n    GET DIAGNOSTICS deleted_count = ROW_COUNT;\n    RETURN deleted_count;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"cleanup_abandoned_conversations\\"() OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"exec_sql\\"(\\"query\\" \\"text\\" DEFAULT NULL::\\"text\\", \\"sql_query\\" \\"text\\" DEFAULT NULL::\\"text\\") RETURNS SETOF \\"jsonb\\"\n    LANGUAGE \\"plpgsql\\" SECURITY DEFINER\n    SET \\"search_path\\" TO 'public'\n    AS $$\ndeclare\n  q text := coalesce(query, sql_query);\n  r record;\nbegin\n  if q is null or length(trim(q)) = 0 then\n    raise exception 'No SQL provided to exec_sql()';\n  end if;\n\n  -- Execute the query and stream rows as JSONB\n  for r in execute q loop\n    return next to_jsonb(r);\n  end loop;\n  return;\n\nexception when others then\n  -- Return a single JSON object describing the error (so callers get structured feedback)\n  return query select jsonb_build_object(\n    'error', true,\n    'message', sqlerrm,\n    'code', sqlstate\n  );\nend;\n$$","ALTER FUNCTION \\"public\\".\\"exec_sql\\"(\\"query\\" \\"text\\", \\"sql_query\\" \\"text\\") OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"get_global_model_config\\"() RETURNS \\"jsonb\\"\n    LANGUAGE \\"sql\\" STABLE\n    AS $$\n  SELECT value FROM public.system_settings WHERE key = 'model_config_global';\n$$","ALTER FUNCTION \\"public\\".\\"get_global_model_config\\"() OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"log_agent_action\\"(\\"p_action\\" character varying, \\"p_agent_id\\" \\"uuid\\", \\"p_details\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\", \\"p_previous_state\\" \\"jsonb\\" DEFAULT NULL::\\"jsonb\\", \\"p_new_state\\" \\"jsonb\\" DEFAULT NULL::\\"jsonb\\", \\"p_success\\" boolean DEFAULT true, \\"p_error_message\\" \\"text\\" DEFAULT NULL::\\"text\\") RETURNS \\"uuid\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nDECLARE\n    log_id UUID;\nBEGIN\n    INSERT INTO agent_creation_logs (\n        action, agent_configuration_id, performed_by, details,\n        previous_state, new_state, success, error_message\n    ) VALUES (\n        p_action, p_agent_id, auth.uid(), p_details,\n        p_previous_state, p_new_state, p_success, p_error_message\n    ) RETURNING id INTO log_id;\n    \n    RETURN log_id;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"log_agent_action\\"(\\"p_action\\" character varying, \\"p_agent_id\\" \\"uuid\\", \\"p_details\\" \\"jsonb\\", \\"p_previous_state\\" \\"jsonb\\", \\"p_new_state\\" \\"jsonb\\", \\"p_success\\" boolean, \\"p_error_message\\" \\"text\\") OWNER TO \\"postgres\\"","COMMENT ON FUNCTION \\"public\\".\\"log_agent_action\\"(\\"p_action\\" character varying, \\"p_agent_id\\" \\"uuid\\", \\"p_details\\" \\"jsonb\\", \\"p_previous_state\\" \\"jsonb\\", \\"p_new_state\\" \\"jsonb\\", \\"p_success\\" boolean, \\"p_error_message\\" \\"text\\") IS 'Helper function to create audit log entries'","CREATE OR REPLACE FUNCTION \\"public\\".\\"update_agent_configurations_updated_at\\"() RETURNS \\"trigger\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nBEGIN\n    NEW.updated_at = NOW();\n    RETURN NEW;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"update_agent_configurations_updated_at\\"() OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"update_agent_skills_updated_at\\"() RETURNS \\"trigger\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nBEGIN\n    NEW.updated_at = NOW();\n    RETURN NEW;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"update_agent_skills_updated_at\\"() OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"update_agent_usage_analytics\\"(\\"p_agent_id\\" \\"uuid\\", \\"p_conversation_increment\\" integer DEFAULT 0, \\"p_message_increment\\" integer DEFAULT 0, \\"p_response_time_ms\\" integer DEFAULT NULL::integer, \\"p_error_increment\\" integer DEFAULT 0, \\"p_unique_user_increment\\" integer DEFAULT 0) RETURNS \\"void\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nBEGIN\n    INSERT INTO agent_usage_analytics (\n        agent_configuration_id, agent_id, date_period,\n        conversation_count, message_count, error_count, unique_users\n    ) VALUES (\n        p_agent_id, \n        (SELECT agent_id FROM agent_configurations WHERE id = p_agent_id),\n        CURRENT_DATE,\n        p_conversation_increment, p_message_increment, p_error_increment, p_unique_user_increment\n    )\n    ON CONFLICT (agent_configuration_id, date_period) \n    DO UPDATE SET\n        conversation_count = agent_usage_analytics.conversation_count + p_conversation_increment,\n        message_count = agent_usage_analytics.message_count + p_message_increment,\n        error_count = agent_usage_analytics.error_count + p_error_increment,\n        unique_users = agent_usage_analytics.unique_users + p_unique_user_increment,\n        avg_response_time_ms = CASE \n            WHEN p_response_time_ms IS NOT NULL THEN\n                COALESCE(\n                    (agent_usage_analytics.avg_response_time_ms + p_response_time_ms) / 2,\n                    p_response_time_ms\n                )\n            ELSE agent_usage_analytics.avg_response_time_ms\n        END,\n        last_updated = NOW();\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"update_agent_usage_analytics\\"(\\"p_agent_id\\" \\"uuid\\", \\"p_conversation_increment\\" integer, \\"p_message_increment\\" integer, \\"p_response_time_ms\\" integer, \\"p_error_increment\\" integer, \\"p_unique_user_increment\\" integer) OWNER TO \\"postgres\\"","COMMENT ON FUNCTION \\"public\\".\\"update_agent_usage_analytics\\"(\\"p_agent_id\\" \\"uuid\\", \\"p_conversation_increment\\" integer, \\"p_message_increment\\" integer, \\"p_response_time_ms\\" integer, \\"p_error_increment\\" integer, \\"p_unique_user_increment\\" integer) IS 'Helper function to update daily usage stats'","CREATE OR REPLACE FUNCTION \\"public\\".\\"update_completion_percentage\\"() RETURNS \\"trigger\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nBEGIN\n    NEW.completion_percentage = calculate_completion_percentage(NEW.requirements_gathered);\n    RETURN NEW;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"update_completion_percentage\\"() OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"update_conversation_timestamps\\"() RETURNS \\"trigger\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nBEGIN\n    NEW.updated_at = NOW();\n    NEW.last_activity_at = NOW();\n    RETURN NEW;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"update_conversation_timestamps\\"() OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"update_creation_metrics\\"(\\"p_success\\" boolean, \\"p_creation_time_seconds\\" integer DEFAULT NULL::integer, \\"p_questions_answered\\" integer DEFAULT NULL::integer, \\"p_department\\" character varying DEFAULT NULL::character varying) RETURNS \\"void\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nDECLARE\n    current_hour INTEGER;\n    dept_breakdown JSONB;\nBEGIN\n    current_hour := EXTRACT(hour FROM NOW());\n    \n    -- Get current department breakdown or initialize\n    SELECT department_breakdown INTO dept_breakdown\n    FROM agent_creation_metrics\n    WHERE date_period = CURRENT_DATE AND hour_period = current_hour;\n    \n    IF dept_breakdown IS NULL THEN\n        dept_breakdown := '{}';\n    END IF;\n    \n    -- Update department count\n    IF p_department IS NOT NULL THEN\n        dept_breakdown := jsonb_set(\n            dept_breakdown,\n            ARRAY[p_department],\n            to_jsonb(COALESCE((dept_breakdown ->> p_department)::INTEGER, 0) + 1)\n        );\n    END IF;\n    \n    INSERT INTO agent_creation_metrics (\n        date_period, hour_period, total_attempts,\n        successful_creations, failed_creations,\n        avg_creation_time_seconds, avg_questions_to_completion,\n        department_breakdown\n    ) VALUES (\n        CURRENT_DATE, current_hour, 1,\n        CASE WHEN p_success THEN 1 ELSE 0 END,\n        CASE WHEN p_success THEN 0 ELSE 1 END,\n        p_creation_time_seconds, p_questions_answered,\n        dept_breakdown\n    )\n    ON CONFLICT (date_period, hour_period)\n    DO UPDATE SET\n        total_attempts = agent_creation_metrics.total_attempts + 1,\n        successful_creations = agent_creation_metrics.successful_creations + \n            CASE WHEN p_success THEN 1 ELSE 0 END,\n        failed_creations = agent_creation_metrics.failed_creations + \n            CASE WHEN p_success THEN 0 ELSE 1 END,\n        avg_creation_time_seconds = CASE \n            WHEN p_creation_time_seconds IS NOT NULL THEN\n                COALESCE(\n                    (agent_creation_metrics.avg_creation_time_seconds + p_creation_time_seconds) / 2,\n                    p_creation_time_seconds\n                )\n            ELSE agent_creation_metrics.avg_creation_time_seconds\n        END,\n        avg_questions_to_completion = CASE \n            WHEN p_questions_answered IS NOT NULL THEN\n                COALESCE(\n                    (agent_creation_metrics.avg_questions_to_completion + p_questions_answered) / 2.0,\n                    p_questions_answered::DECIMAL\n                )\n            ELSE agent_creation_metrics.avg_questions_to_completion\n        END,\n        department_breakdown = dept_breakdown,\n        last_updated = NOW();\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"update_creation_metrics\\"(\\"p_success\\" boolean, \\"p_creation_time_seconds\\" integer, \\"p_questions_answered\\" integer, \\"p_department\\" character varying) OWNER TO \\"postgres\\"","COMMENT ON FUNCTION \\"public\\".\\"update_creation_metrics\\"(\\"p_success\\" boolean, \\"p_creation_time_seconds\\" integer, \\"p_questions_answered\\" integer, \\"p_department\\" character varying) IS 'Helper function to update system creation metrics'","CREATE OR REPLACE FUNCTION \\"public\\".\\"update_updated_at_column\\"() RETURNS \\"trigger\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nBEGIN\n  NEW.updated_at = NOW();\n  RETURN NEW;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"update_updated_at_column\\"() OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"validate_skill_examples\\"(\\"examples\\" \\"jsonb\\") RETURNS boolean\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nDECLARE\n    example_text TEXT;\n    example_value JSONB;\nBEGIN\n    -- Check each example in the array\n    FOR example_value IN SELECT jsonb_array_elements(examples)\n    LOOP\n        example_text := example_value #>> '{}';\n        \n        -- Ensure example is not empty or too short\n        IF LENGTH(TRIM(example_text)) < 5 THEN\n            RETURN FALSE;\n        END IF;\n        \n        -- Ensure example is a reasonable length (not too long)\n        IF LENGTH(example_text) > 500 THEN\n            RETURN FALSE;\n        END IF;\n    END LOOP;\n    \n    RETURN TRUE;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"validate_skill_examples\\"(\\"examples\\" \\"jsonb\\") OWNER TO \\"postgres\\"","SET default_tablespace = ''","SET default_table_access_method = \\"heap\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"agent_configurations\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"agent_id\\" character varying(100) NOT NULL,\n    \\"display_name\\" character varying(200) NOT NULL,\n    \\"agent_type\\" character varying(50) NOT NULL,\n    \\"department\\" character varying(100) NOT NULL,\n    \\"reports_to\\" character varying(100),\n    \\"created_by\\" \\"uuid\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"updated_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"version\\" integer DEFAULT 1,\n    \\"status\\" character varying(50) DEFAULT 'active'::character varying,\n    \\"primary_purpose\\" \\"text\\" NOT NULL,\n    \\"capabilities\\" \\"jsonb\\" NOT NULL,\n    \\"expertise_areas\\" \\"jsonb\\" NOT NULL,\n    \\"responsibilities\\" \\"jsonb\\" NOT NULL,\n    \\"limitations\\" \\"jsonb\\" NOT NULL,\n    \\"communication_style\\" character varying(100),\n    \\"core_identity\\" \\"text\\",\n    \\"yaml_config\\" \\"text\\" NOT NULL,\n    \\"context_content\\" \\"text\\" NOT NULL,\n    \\"service_content\\" \\"text\\" NOT NULL,\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"last_accessed_at\\" timestamp with time zone,\n    \\"access_count\\" integer DEFAULT 0,\n    CONSTRAINT \\"check_agent_id_format\\" CHECK (((\\"agent_id\\")::\\"text\\" ~ '^[a-z][a-z0-9_]*$'::\\"text\\")),\n    CONSTRAINT \\"check_agent_type\\" CHECK (((\\"agent_type\\")::\\"text\\" = ANY (ARRAY[('context'::character varying)::\\"text\\", ('api'::character varying)::\\"text\\", ('function'::character varying)::\\"text\\"]))),\n    CONSTRAINT \\"check_communication_style\\" CHECK (((\\"communication_style\\")::\\"text\\" = ANY (ARRAY[('professional'::character varying)::\\"text\\", ('casual'::character varying)::\\"text\\", ('technical'::character varying)::\\"text\\", ('conversational'::character varying)::\\"text\\", ('formal'::character varying)::\\"text\\", ('creative'::character varying)::\\"text\\"]))),\n    CONSTRAINT \\"check_department\\" CHECK (((\\"department\\")::\\"text\\" = ANY (ARRAY[('marketing'::character varying)::\\"text\\", ('engineering'::character varying)::\\"text\\", ('operations'::character varying)::\\"text\\", ('finance'::character varying)::\\"text\\", ('hr'::character varying)::\\"text\\", ('sales'::character varying)::\\"text\\", ('research'::character varying)::\\"text\\", ('product'::character varying)::\\"text\\", ('specialists'::character varying)::\\"text\\"]))),\n    CONSTRAINT \\"check_display_name_not_empty\\" CHECK ((\\"length\\"(TRIM(BOTH FROM \\"display_name\\")) > 0)),\n    CONSTRAINT \\"check_primary_purpose_length\\" CHECK ((\\"length\\"(TRIM(BOTH FROM \\"primary_purpose\\")) >= 20)),\n    CONSTRAINT \\"check_status\\" CHECK (((\\"status\\")::\\"text\\" = ANY (ARRAY[('active'::character varying)::\\"text\\", ('inactive'::character varying)::\\"text\\", ('archived'::character varying)::\\"text\\", ('draft'::character varying)::\\"text\\"])))\n)","ALTER TABLE \\"public\\".\\"agent_configurations\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"agent_configurations\\" IS 'Stores dynamically created agent configurations with generated content'","COMMENT ON COLUMN \\"public\\".\\"agent_configurations\\".\\"agent_id\\" IS 'Unique snake_case identifier for routing (e.g., social_media_writer)'","COMMENT ON COLUMN \\"public\\".\\"agent_configurations\\".\\"yaml_config\\" IS 'Generated YAML configuration content'","COMMENT ON COLUMN \\"public\\".\\"agent_configurations\\".\\"context_content\\" IS 'Generated context.md system prompt content'","COMMENT ON COLUMN \\"public\\".\\"agent_configurations\\".\\"service_content\\" IS 'Generated service.ts TypeScript content'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"agent_creation_conversations\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"session_id\\" character varying(100) NOT NULL,\n    \\"user_id\\" \\"uuid\\",\n    \\"agent_configuration_id\\" \\"uuid\\",\n    \\"conversation_data\\" \\"jsonb\\" NOT NULL,\n    \\"requirements_gathered\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"current_phase\\" character varying(50) DEFAULT 'identity'::character varying,\n    \\"current_question\\" integer DEFAULT 1,\n    \\"completion_status\\" character varying(50) DEFAULT 'in_progress'::character varying,\n    \\"completion_percentage\\" integer DEFAULT 0,\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"updated_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"last_activity_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"user_agent\\" \\"text\\",\n    \\"ip_address\\" \\"inet\\",\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    CONSTRAINT \\"check_completion_percentage\\" CHECK (((\\"completion_percentage\\" >= 0) AND (\\"completion_percentage\\" <= 100))),\n    CONSTRAINT \\"check_completion_status\\" CHECK (((\\"completion_status\\")::\\"text\\" = ANY (ARRAY[('in_progress'::character varying)::\\"text\\", ('completed'::character varying)::\\"text\\", ('abandoned'::character varying)::\\"text\\", ('failed'::character varying)::\\"text\\"]))),\n    CONSTRAINT \\"check_current_phase\\" CHECK (((\\"current_phase\\")::\\"text\\" = ANY (ARRAY[('identity'::character varying)::\\"text\\", ('hierarchy'::character varying)::\\"text\\", ('purpose'::character varying)::\\"text\\", ('skills'::character varying)::\\"text\\", ('style'::character varying)::\\"text\\", ('technical'::character varying)::\\"text\\", ('complete'::character varying)::\\"text\\"]))),\n    CONSTRAINT \\"check_current_question_range\\" CHECK (((\\"current_question\\" >= 1) AND (\\"current_question\\" <= 12)))\n)","ALTER TABLE \\"public\\".\\"agent_creation_conversations\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"agent_creation_conversations\\" IS 'Tracks agent creation conversation state for resuming interrupted sessions'","COMMENT ON COLUMN \\"public\\".\\"agent_creation_conversations\\".\\"requirements_gathered\\" IS 'JSON object tracking completion of 12 required fields'","COMMENT ON COLUMN \\"public\\".\\"agent_creation_conversations\\".\\"current_phase\\" IS 'Current phase in structured conversation flow'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"agent_creation_events\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"conversation_id\\" \\"uuid\\" NOT NULL,\n    \\"event_type\\" character varying(50) NOT NULL,\n    \\"event_data\\" \\"jsonb\\" NOT NULL,\n    \\"question_number\\" integer,\n    \\"field_name\\" character varying(100),\n    \\"timestamp\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"user_input\\" \\"text\\",\n    \\"ai_response\\" \\"text\\",\n    \\"validation_result\\" \\"jsonb\\",\n    CONSTRAINT \\"check_event_type\\" CHECK (((\\"event_type\\")::\\"text\\" = ANY (ARRAY[('conversation_started'::character varying)::\\"text\\", ('question_asked'::character varying)::\\"text\\", ('answer_provided'::character varying)::\\"text\\", ('validation_passed'::character varying)::\\"text\\", ('validation_failed'::character varying)::\\"text\\", ('phase_completed'::character varying)::\\"text\\", ('agent_created'::character varying)::\\"text\\", ('conversation_completed'::character varying)::\\"text\\", ('conversation_abandoned'::character varying)::\\"text\\"])))\n)","ALTER TABLE \\"public\\".\\"agent_creation_events\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"agent_creation_events\\" IS 'Detailed log of events during agent creation conversations'","COMMENT ON COLUMN \\"public\\".\\"agent_creation_events\\".\\"event_data\\" IS 'Event-specific data like validation results, user inputs, etc.'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"agent_creation_logs\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"action\\" character varying(100) NOT NULL,\n    \\"agent_configuration_id\\" \\"uuid\\",\n    \\"performed_by\\" \\"uuid\\",\n    \\"performed_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"details\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"ip_address\\" \\"inet\\",\n    \\"user_agent\\" \\"text\\",\n    \\"previous_state\\" \\"jsonb\\",\n    \\"new_state\\" \\"jsonb\\",\n    \\"success\\" boolean DEFAULT true,\n    \\"error_message\\" \\"text\\",\n    CONSTRAINT \\"check_action_type\\" CHECK (((\\"action\\")::\\"text\\" = ANY (ARRAY[('created'::character varying)::\\"text\\", ('updated'::character varying)::\\"text\\", ('activated'::character varying)::\\"text\\", ('deactivated'::character varying)::\\"text\\", ('deleted'::character varying)::\\"text\\", ('accessed'::character varying)::\\"text\\", ('conversation_started'::character varying)::\\"text\\", ('error_occurred'::character varying)::\\"text\\"])))\n)","ALTER TABLE \\"public\\".\\"agent_creation_logs\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"agent_creation_logs\\" IS 'Audit trail for all agent-related actions'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"agent_creation_metrics\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"date_period\\" \\"date\\" NOT NULL,\n    \\"hour_period\\" integer,\n    \\"total_attempts\\" integer DEFAULT 0,\n    \\"successful_creations\\" integer DEFAULT 0,\n    \\"failed_creations\\" integer DEFAULT 0,\n    \\"abandoned_conversations\\" integer DEFAULT 0,\n    \\"avg_creation_time_seconds\\" integer,\n    \\"avg_questions_to_completion\\" numeric(4,2),\n    \\"most_failed_question\\" integer,\n    \\"agents_with_quality_issues\\" integer DEFAULT 0,\n    \\"avg_capabilities_count\\" numeric(4,2),\n    \\"avg_skills_count\\" numeric(4,2),\n    \\"department_breakdown\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"last_updated\\" timestamp with time zone DEFAULT \\"now\\"(),\n    CONSTRAINT \\"check_hour_period\\" CHECK (((\\"hour_period\\" >= 0) AND (\\"hour_period\\" <= 23)))\n)","ALTER TABLE \\"public\\".\\"agent_creation_metrics\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"agent_creation_metrics\\" IS 'System-wide metrics for agent creation process'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"agent_skills\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"agent_configuration_id\\" \\"uuid\\" NOT NULL,\n    \\"skill_id\\" character varying(100) NOT NULL,\n    \\"skill_name\\" character varying(200) NOT NULL,\n    \\"description\\" \\"text\\" NOT NULL,\n    \\"examples\\" \\"jsonb\\" NOT NULL,\n    \\"tags\\" \\"jsonb\\" DEFAULT '[]'::\\"jsonb\\",\n    \\"input_modes\\" \\"jsonb\\" DEFAULT '[\\"text/plain\\", \\"application/json\\"]'::\\"jsonb\\",\n    \\"output_modes\\" \\"jsonb\\" DEFAULT '[\\"text/plain\\", \\"application/json\\"]'::\\"jsonb\\",\n    \\"skill_order\\" integer DEFAULT 0,\n    \\"is_primary\\" boolean DEFAULT false,\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"updated_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    CONSTRAINT \\"check_examples_not_empty\\" CHECK ((\\"jsonb_array_length\\"(\\"examples\\") > 0)),\n    CONSTRAINT \\"check_examples_quality\\" CHECK (\\"public\\".\\"validate_skill_examples\\"(\\"examples\\")),\n    CONSTRAINT \\"check_skill_description_length\\" CHECK ((\\"length\\"(TRIM(BOTH FROM \\"description\\")) >= 10)),\n    CONSTRAINT \\"check_skill_id_format\\" CHECK (((\\"skill_id\\")::\\"text\\" ~ '^[a-z][a-z0-9_]*$'::\\"text\\")),\n    CONSTRAINT \\"check_skill_name_not_empty\\" CHECK ((\\"length\\"(TRIM(BOTH FROM \\"skill_name\\")) > 0))\n)","ALTER TABLE \\"public\\".\\"agent_skills\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"agent_skills\\" IS 'Stores skills and user-provided examples for each agent'","COMMENT ON COLUMN \\"public\\".\\"agent_skills\\".\\"skill_id\\" IS 'Snake_case identifier unique per agent'","COMMENT ON COLUMN \\"public\\".\\"agent_skills\\".\\"examples\\" IS 'Array of concrete example queries from user domain'","COMMENT ON COLUMN \\"public\\".\\"agent_skills\\".\\"is_primary\\" IS 'Whether this is the main/primary skill for the agent'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"agent_usage_analytics\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"agent_configuration_id\\" \\"uuid\\" NOT NULL,\n    \\"agent_id\\" character varying(100) NOT NULL,\n    \\"conversation_count\\" integer DEFAULT 0,\n    \\"message_count\\" integer DEFAULT 0,\n    \\"avg_response_time_ms\\" integer,\n    \\"error_count\\" integer DEFAULT 0,\n    \\"unique_users\\" integer DEFAULT 0,\n    \\"returning_users\\" integer DEFAULT 0,\n    \\"satisfaction_rating\\" numeric(3,2),\n    \\"date_period\\" \\"date\\" NOT NULL,\n    \\"last_updated\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    CONSTRAINT \\"check_satisfaction_rating\\" CHECK (((\\"satisfaction_rating\\" >= 0.0) AND (\\"satisfaction_rating\\" <= 5.0)))\n)","ALTER TABLE \\"public\\".\\"agent_usage_analytics\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"agent_usage_analytics\\" IS 'Daily usage analytics for each agent'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"cidafm_commands\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"type\\" character varying(10) NOT NULL,\n    \\"name\\" character varying(255) NOT NULL,\n    \\"description\\" \\"text\\",\n    \\"default_active\\" boolean DEFAULT false,\n    \\"is_builtin\\" boolean DEFAULT true,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    CONSTRAINT \\"cidafm_commands_type_check\\" CHECK (((\\"type\\")::\\"text\\" = ANY (ARRAY[('^'::character varying)::\\"text\\", ('&'::character varying)::\\"text\\", ('!'::character varying)::\\"text\\"])))\n)","ALTER TABLE \\"public\\".\\"cidafm_commands\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"companies\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"name\\" character varying(255) NOT NULL,\n    \\"industry\\" character varying(100),\n    \\"founded_year\\" integer,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"companies\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"conversations\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"user_id\\" \\"uuid\\",\n    \\"agent_name\\" character varying(255),\n    \\"agent_type\\" character varying(100),\n    \\"started_at\\" timestamp with time zone,\n    \\"last_active_at\\" timestamp with time zone,\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"conversations\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"tasks\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"user_id\\" \\"uuid\\",\n    \\"conversation_id\\" \\"uuid\\",\n    \\"method\\" character varying(255),\n    \\"params\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"prompt\\" \\"text\\",\n    \\"response\\" \\"text\\",\n    \\"status\\" character varying(50) DEFAULT 'pending'::character varying,\n    \\"progress\\" integer DEFAULT 0,\n    \\"progress_message\\" \\"text\\",\n    \\"error_code\\" \\"text\\",\n    \\"error_message\\" \\"text\\",\n    \\"error_data\\" \\"jsonb\\",\n    \\"started_at\\" timestamp with time zone,\n    \\"completed_at\\" timestamp with time zone,\n    \\"timeout_seconds\\" integer DEFAULT 300,\n    \\"deliverable_type\\" \\"text\\",\n    \\"deliverable_metadata\\" \\"jsonb\\",\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"llm_metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"response_metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"evaluation\\" \\"jsonb\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"tasks\\" OWNER TO \\"postgres\\"","CREATE OR REPLACE VIEW \\"public\\".\\"conversations_with_stats\\" AS\n SELECT \\"c\\".\\"id\\",\n    \\"c\\".\\"user_id\\",\n    \\"c\\".\\"agent_name\\",\n    \\"c\\".\\"agent_type\\",\n    \\"c\\".\\"started_at\\",\n    \\"c\\".\\"last_active_at\\",\n    \\"c\\".\\"metadata\\",\n    \\"c\\".\\"created_at\\",\n    \\"c\\".\\"updated_at\\",\n    COALESCE(\\"task_stats\\".\\"task_count\\", (0)::bigint) AS \\"task_count\\",\n    COALESCE(\\"task_stats\\".\\"completed_tasks\\", (0)::bigint) AS \\"completed_tasks\\",\n    COALESCE(\\"task_stats\\".\\"failed_tasks\\", (0)::bigint) AS \\"failed_tasks\\",\n    COALESCE(\\"task_stats\\".\\"active_tasks\\", (0)::bigint) AS \\"active_tasks\\"\n   FROM (\\"public\\".\\"conversations\\" \\"c\\"\n     LEFT JOIN ( SELECT \\"tasks\\".\\"conversation_id\\",\n            \\"count\\"(*) AS \\"task_count\\",\n            \\"count\\"(\n                CASE\n                    WHEN ((\\"tasks\\".\\"status\\")::\\"text\\" = 'completed'::\\"text\\") THEN 1\n                    ELSE NULL::integer\n                END) AS \\"completed_tasks\\",\n            \\"count\\"(\n                CASE\n                    WHEN ((\\"tasks\\".\\"status\\")::\\"text\\" = 'failed'::\\"text\\") THEN 1\n                    ELSE NULL::integer\n                END) AS \\"failed_tasks\\",\n            \\"count\\"(\n                CASE\n                    WHEN ((\\"tasks\\".\\"status\\")::\\"text\\" = ANY (ARRAY[('pending'::character varying)::\\"text\\", ('running'::character varying)::\\"text\\"])) THEN 1\n                    ELSE NULL::integer\n                END) AS \\"active_tasks\\"\n           FROM \\"public\\".\\"tasks\\"\n          GROUP BY \\"tasks\\".\\"conversation_id\\") \\"task_stats\\" ON ((\\"c\\".\\"id\\" = \\"task_stats\\".\\"conversation_id\\")))","ALTER VIEW \\"public\\".\\"conversations_with_stats\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"deliverable_versions\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"deliverable_id\\" \\"uuid\\" NOT NULL,\n    \\"version_number\\" integer NOT NULL,\n    \\"content\\" \\"text\\",\n    \\"format\\" character varying(100),\n    \\"is_current_version\\" boolean DEFAULT false,\n    \\"created_by_type\\" character varying(50) DEFAULT 'ai_response'::character varying,\n    \\"task_id\\" \\"uuid\\",\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"file_attachments\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    CONSTRAINT \\"deliverable_versions_created_by_type_check\\" CHECK (((\\"created_by_type\\")::\\"text\\" = ANY (ARRAY[('ai_response'::character varying)::\\"text\\", ('manual_edit'::character varying)::\\"text\\", ('ai_enhancement'::character varying)::\\"text\\", ('user_request'::character varying)::\\"text\\", ('conversation_task'::character varying)::\\"text\\", ('conversation_merge'::character varying)::\\"text\\", ('llm_rerun'::character varying)::\\"text\\"])))\n)","ALTER TABLE \\"public\\".\\"deliverable_versions\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"deliverables\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"user_id\\" \\"uuid\\" NOT NULL,\n    \\"conversation_id\\" \\"uuid\\",\n    \\"project_step_id\\" \\"uuid\\",\n    \\"agent_name\\" \\"text\\",\n    \\"title\\" \\"text\\" NOT NULL,\n    \\"type\\" character varying(100),\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"deliverables\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"departments\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"company_id\\" \\"uuid\\",\n    \\"name\\" character varying(255) NOT NULL,\n    \\"head_of_department\\" character varying(255),\n    \\"budget\\" numeric(15,2),\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"departments\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"kpi_data\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"department_id\\" \\"uuid\\",\n    \\"metric_id\\" \\"uuid\\",\n    \\"value\\" numeric(15,4) NOT NULL,\n    \\"date_recorded\\" \\"date\\" NOT NULL,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"kpi_data\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"kpi_goals\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"department_id\\" \\"uuid\\",\n    \\"metric_id\\" \\"uuid\\",\n    \\"target_value\\" numeric(15,4),\n    \\"period_start\\" \\"date\\",\n    \\"period_end\\" \\"date\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"kpi_goals\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"kpi_metrics\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"name\\" character varying(255) NOT NULL,\n    \\"metric_type\\" character varying(100),\n    \\"unit\\" character varying(50),\n    \\"description\\" \\"text\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"kpi_metrics\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"llm_models\\" (\n    \\"model_name\\" \\"text\\" NOT NULL,\n    \\"provider_name\\" \\"text\\" NOT NULL,\n    \\"display_name\\" \\"text\\",\n    \\"model_type\\" \\"text\\" DEFAULT 'text-generation'::\\"text\\",\n    \\"model_version\\" \\"text\\",\n    \\"context_window\\" integer DEFAULT 4096,\n    \\"max_output_tokens\\" integer DEFAULT 2048,\n    \\"model_parameters_json\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"pricing_info_json\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"capabilities\\" \\"jsonb\\" DEFAULT '[]'::\\"jsonb\\",\n    \\"model_tier\\" \\"text\\",\n    \\"speed_tier\\" \\"text\\" DEFAULT 'medium'::\\"text\\",\n    \\"loading_priority\\" integer DEFAULT 5,\n    \\"is_local\\" boolean DEFAULT false,\n    \\"is_currently_loaded\\" boolean DEFAULT false,\n    \\"is_active\\" boolean DEFAULT true,\n    \\"training_data_cutoff\\" \\"date\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"llm_models\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"llm_providers\\" (\n    \\"name\\" \\"text\\" NOT NULL,\n    \\"display_name\\" \\"text\\" NOT NULL,\n    \\"api_base_url\\" \\"text\\",\n    \\"configuration_json\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"is_active\\" boolean DEFAULT true,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"llm_providers\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"llm_usage\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"run_id\\" \\"text\\",\n    \\"user_id\\" \\"uuid\\",\n    \\"conversation_id\\" \\"uuid\\",\n    \\"provider_name\\" \\"text\\",\n    \\"model_name\\" \\"text\\",\n    \\"input_tokens\\" integer,\n    \\"output_tokens\\" integer,\n    \\"input_cost\\" numeric,\n    \\"output_cost\\" numeric,\n    \\"duration_ms\\" integer,\n    \\"status\\" \\"text\\" DEFAULT 'completed'::\\"text\\",\n    \\"caller_type\\" \\"text\\",\n    \\"agent_name\\" \\"text\\",\n    \\"is_local\\" boolean DEFAULT false,\n    \\"model_tier\\" \\"text\\",\n    \\"fallback_used\\" boolean DEFAULT false,\n    \\"routing_reason\\" \\"text\\",\n    \\"complexity_level\\" \\"text\\",\n    \\"complexity_score\\" integer,\n    \\"data_classification\\" \\"text\\",\n    \\"started_at\\" timestamp with time zone,\n    \\"completed_at\\" timestamp with time zone,\n    \\"error_message\\" \\"text\\",\n    \\"data_sanitization_applied\\" boolean DEFAULT false,\n    \\"sanitization_level\\" \\"text\\" DEFAULT 'none'::\\"text\\",\n    \\"pii_detected\\" boolean DEFAULT false,\n    \\"pii_types\\" \\"jsonb\\" DEFAULT '[]'::\\"jsonb\\",\n    \\"pseudonyms_used\\" integer DEFAULT 0,\n    \\"pseudonym_types\\" \\"jsonb\\" DEFAULT '[]'::\\"jsonb\\",\n    \\"redactions_applied\\" integer DEFAULT 0,\n    \\"redaction_types\\" \\"jsonb\\" DEFAULT '[]'::\\"jsonb\\",\n    \\"source_blinding_applied\\" boolean DEFAULT false,\n    \\"headers_stripped\\" boolean DEFAULT false,\n    \\"custom_user_agent_used\\" boolean DEFAULT false,\n    \\"proxy_used\\" boolean DEFAULT false,\n    \\"no_train_header_sent\\" boolean DEFAULT false,\n    \\"no_retain_header_sent\\" boolean DEFAULT false,\n    \\"sanitization_time_ms\\" integer DEFAULT 0,\n    \\"reversal_context_size\\" integer DEFAULT 0,\n    \\"policy_profile\\" \\"text\\",\n    \\"sovereign_mode\\" boolean DEFAULT false,\n    \\"compliance_flags\\" \\"jsonb\\" DEFAULT '[]'::\\"jsonb\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"llm_usage\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"project_steps\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"gen_random_uuid\\"() NOT NULL,\n    \\"project_id\\" \\"uuid\\" NOT NULL,\n    \\"step_id\\" \\"text\\" NOT NULL,\n    \\"step_index\\" integer NOT NULL,\n    \\"step_type\\" \\"text\\" NOT NULL,\n    \\"step_name\\" \\"text\\" NOT NULL,\n    \\"agent_name\\" \\"text\\",\n    \\"prompt\\" \\"text\\" NOT NULL,\n    \\"dependencies\\" \\"text\\"[] DEFAULT '{}'::\\"text\\"[],\n    \\"status\\" \\"text\\" DEFAULT 'pending'::\\"text\\" NOT NULL,\n    \\"result\\" \\"jsonb\\",\n    \\"error_details\\" \\"jsonb\\",\n    \\"started_at\\" timestamp with time zone,\n    \\"completed_at\\" timestamp with time zone,\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"updated_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    CONSTRAINT \\"project_steps_status_check\\" CHECK ((\\"status\\" = ANY (ARRAY['pending'::\\"text\\", 'running'::\\"text\\", 'completed'::\\"text\\", 'failed'::\\"text\\", 'pending_approval'::\\"text\\", 'skipped'::\\"text\\"]))),\n    CONSTRAINT \\"project_steps_step_type_check\\" CHECK ((\\"step_type\\" = ANY (ARRAY['agent_step'::\\"text\\", 'human_approval'::\\"text\\"])))\n)","ALTER TABLE \\"public\\".\\"project_steps\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"projects\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"gen_random_uuid\\"() NOT NULL,\n    \\"conversation_id\\" \\"uuid\\" NOT NULL,\n    \\"name\\" \\"text\\",\n    \\"description\\" \\"text\\",\n    \\"plan_json\\" \\"jsonb\\",\n    \\"status\\" \\"text\\" DEFAULT 'planning'::\\"text\\" NOT NULL,\n    \\"current_step_id\\" \\"text\\",\n    \\"error_details\\" \\"jsonb\\",\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"parent_project_id\\" \\"uuid\\",\n    \\"hierarchy_level\\" integer DEFAULT 0,\n    \\"subproject_count\\" integer DEFAULT 0,\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"updated_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    CONSTRAINT \\"projects_status_check\\" CHECK ((\\"status\\" = ANY (ARRAY['planning'::\\"text\\", 'pending_approval'::\\"text\\", 'running'::\\"text\\", 'paused_for_approval'::\\"text\\", 'paused_on_error'::\\"text\\", 'completed'::\\"text\\", 'aborted'::\\"text\\"])))\n)","ALTER TABLE \\"public\\".\\"projects\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"pseudonym_dictionaries\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"original_value\\" \\"text\\" NOT NULL,\n    \\"pseudonym\\" \\"text\\" NOT NULL,\n    \\"data_type\\" character varying(100) NOT NULL,\n    \\"category\\" character varying(100),\n    \\"frequency_weight\\" integer DEFAULT 1,\n    \\"is_active\\" boolean DEFAULT true,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"pseudonym_dictionaries\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"redaction_patterns\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"name\\" character varying(255) NOT NULL,\n    \\"pattern_regex\\" \\"text\\" NOT NULL,\n    \\"replacement\\" \\"text\\" NOT NULL,\n    \\"description\\" \\"text\\",\n    \\"category\\" character varying(100) DEFAULT 'pii_builtin'::character varying,\n    \\"priority\\" integer DEFAULT 50,\n    \\"is_active\\" boolean DEFAULT true,\n    \\"severity\\" character varying(50),\n    \\"data_type\\" character varying(50),\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"redaction_patterns\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"system_settings\\" (\n    \\"key\\" \\"text\\" NOT NULL,\n    \\"value\\" \\"jsonb\\" NOT NULL,\n    \\"updated_at\\" timestamp with time zone DEFAULT \\"now\\"()\n)","ALTER TABLE \\"public\\".\\"system_settings\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"system_settings\\" IS 'System-wide settings (key/value JSON). Used for global model configuration and feature flags.'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"user_cidafm_commands\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"user_id\\" \\"uuid\\" NOT NULL,\n    \\"command_id\\" \\"uuid\\" NOT NULL,\n    \\"is_active\\" boolean DEFAULT true,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"user_cidafm_commands\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"users\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"email\\" character varying(255) NOT NULL,\n    \\"display_name\\" character varying(255),\n    \\"role\\" character varying(50),\n    \\"roles\\" \\"jsonb\\" DEFAULT '[\\"user\\"]'::\\"jsonb\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"namespace_access\\" \\"jsonb\\" DEFAULT '[\\"my-org\\"]'::\\"jsonb\\" NOT NULL,\n    \\"status\\" \\"text\\" DEFAULT 'active'::\\"text\\"\n)","ALTER TABLE \\"public\\".\\"users\\" OWNER TO \\"postgres\\"","COMMENT ON COLUMN \\"public\\".\\"users\\".\\"namespace_access\\" IS 'List of agent namespaces the user may access (e.g., [\\"demo\\",\\"my-org\\"]).'","ALTER TABLE ONLY \\"public\\".\\"agent_configurations\\"\n    ADD CONSTRAINT \\"agent_configurations_agent_id_key\\" UNIQUE (\\"agent_id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_configurations\\"\n    ADD CONSTRAINT \\"agent_configurations_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"conversations\\"\n    ADD CONSTRAINT \\"agent_conversations_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_creation_conversations\\"\n    ADD CONSTRAINT \\"agent_creation_conversations_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_creation_events\\"\n    ADD CONSTRAINT \\"agent_creation_events_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_creation_logs\\"\n    ADD CONSTRAINT \\"agent_creation_logs_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_creation_metrics\\"\n    ADD CONSTRAINT \\"agent_creation_metrics_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_skills\\"\n    ADD CONSTRAINT \\"agent_skills_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_usage_analytics\\"\n    ADD CONSTRAINT \\"agent_usage_analytics_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"cidafm_commands\\"\n    ADD CONSTRAINT \\"cidafm_commands_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"companies\\"\n    ADD CONSTRAINT \\"companies_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"deliverable_versions\\"\n    ADD CONSTRAINT \\"deliverable_versions_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"deliverables\\"\n    ADD CONSTRAINT \\"deliverables_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"departments\\"\n    ADD CONSTRAINT \\"departments_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"kpi_data\\"\n    ADD CONSTRAINT \\"kpi_data_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"kpi_goals\\"\n    ADD CONSTRAINT \\"kpi_goals_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"kpi_metrics\\"\n    ADD CONSTRAINT \\"kpi_metrics_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"llm_models\\"\n    ADD CONSTRAINT \\"llm_models_pkey\\" PRIMARY KEY (\\"provider_name\\", \\"model_name\\")","ALTER TABLE ONLY \\"public\\".\\"llm_providers\\"\n    ADD CONSTRAINT \\"llm_providers_pkey\\" PRIMARY KEY (\\"name\\")","ALTER TABLE ONLY \\"public\\".\\"llm_usage\\"\n    ADD CONSTRAINT \\"llm_usage_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"llm_usage\\"\n    ADD CONSTRAINT \\"llm_usage_run_id_key\\" UNIQUE (\\"run_id\\")","ALTER TABLE ONLY \\"public\\".\\"project_steps\\"\n    ADD CONSTRAINT \\"project_steps_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"projects\\"\n    ADD CONSTRAINT \\"projects_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"pseudonym_dictionaries\\"\n    ADD CONSTRAINT \\"pseudonym_dictionaries_original_value_key\\" UNIQUE (\\"original_value\\")","ALTER TABLE ONLY \\"public\\".\\"pseudonym_dictionaries\\"\n    ADD CONSTRAINT \\"pseudonym_dictionaries_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"redaction_patterns\\"\n    ADD CONSTRAINT \\"redaction_patterns_name_key\\" UNIQUE (\\"name\\")","ALTER TABLE ONLY \\"public\\".\\"redaction_patterns\\"\n    ADD CONSTRAINT \\"redaction_patterns_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"system_settings\\"\n    ADD CONSTRAINT \\"system_settings_pkey\\" PRIMARY KEY (\\"key\\")","ALTER TABLE ONLY \\"public\\".\\"tasks\\"\n    ADD CONSTRAINT \\"tasks_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_usage_analytics\\"\n    ADD CONSTRAINT \\"unique_agent_date_analytics\\" UNIQUE (\\"agent_configuration_id\\", \\"date_period\\")","ALTER TABLE ONLY \\"public\\".\\"agent_creation_metrics\\"\n    ADD CONSTRAINT \\"unique_date_hour_metrics\\" UNIQUE (\\"date_period\\", \\"hour_period\\")","ALTER TABLE ONLY \\"public\\".\\"agent_skills\\"\n    ADD CONSTRAINT \\"unique_skill_id_per_agent\\" UNIQUE (\\"agent_configuration_id\\", \\"skill_id\\")","ALTER TABLE ONLY \\"public\\".\\"user_cidafm_commands\\"\n    ADD CONSTRAINT \\"user_cidafm_commands_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"users\\"\n    ADD CONSTRAINT \\"users_email_key\\" UNIQUE (\\"email\\")","ALTER TABLE ONLY \\"public\\".\\"users\\"\n    ADD CONSTRAINT \\"users_pkey\\" PRIMARY KEY (\\"id\\")","CREATE INDEX \\"idx_agent_configurations_agent_id\\" ON \\"public\\".\\"agent_configurations\\" USING \\"btree\\" (\\"agent_id\\")","CREATE INDEX \\"idx_agent_configurations_created_at\\" ON \\"public\\".\\"agent_configurations\\" USING \\"btree\\" (\\"created_at\\")","CREATE INDEX \\"idx_agent_configurations_created_by\\" ON \\"public\\".\\"agent_configurations\\" USING \\"btree\\" (\\"created_by\\")","CREATE INDEX \\"idx_agent_configurations_department\\" ON \\"public\\".\\"agent_configurations\\" USING \\"btree\\" (\\"department\\")","CREATE INDEX \\"idx_agent_configurations_status\\" ON \\"public\\".\\"agent_configurations\\" USING \\"btree\\" (\\"status\\")","CREATE INDEX \\"idx_agent_conversations_user_id\\" ON \\"public\\".\\"conversations\\" USING \\"btree\\" (\\"user_id\\")","CREATE INDEX \\"idx_agent_skills_agent_config\\" ON \\"public\\".\\"agent_skills\\" USING \\"btree\\" (\\"agent_configuration_id\\")","CREATE INDEX \\"idx_agent_skills_is_primary\\" ON \\"public\\".\\"agent_skills\\" USING \\"btree\\" (\\"is_primary\\")","CREATE INDEX \\"idx_agent_skills_skill_id\\" ON \\"public\\".\\"agent_skills\\" USING \\"btree\\" (\\"skill_id\\")","CREATE INDEX \\"idx_agent_skills_skill_order\\" ON \\"public\\".\\"agent_skills\\" USING \\"btree\\" (\\"skill_order\\")","CREATE INDEX \\"idx_conversations_agent_id\\" ON \\"public\\".\\"agent_creation_conversations\\" USING \\"btree\\" (\\"agent_configuration_id\\")","CREATE INDEX \\"idx_conversations_last_activity\\" ON \\"public\\".\\"agent_creation_conversations\\" USING \\"btree\\" (\\"last_activity_at\\")","CREATE INDEX \\"idx_conversations_session_id\\" ON \\"public\\".\\"agent_creation_conversations\\" USING \\"btree\\" (\\"session_id\\")","CREATE INDEX \\"idx_conversations_status\\" ON \\"public\\".\\"agent_creation_conversations\\" USING \\"btree\\" (\\"completion_status\\")","CREATE INDEX \\"idx_conversations_user_id\\" ON \\"public\\".\\"agent_creation_conversations\\" USING \\"btree\\" (\\"user_id\\")","CREATE INDEX \\"idx_creation_logs_action\\" ON \\"public\\".\\"agent_creation_logs\\" USING \\"btree\\" (\\"action\\")","CREATE INDEX \\"idx_creation_logs_agent_id\\" ON \\"public\\".\\"agent_creation_logs\\" USING \\"btree\\" (\\"agent_configuration_id\\")","CREATE INDEX \\"idx_creation_logs_performed_at\\" ON \\"public\\".\\"agent_creation_logs\\" USING \\"btree\\" (\\"performed_at\\")","CREATE INDEX \\"idx_creation_logs_performed_by\\" ON \\"public\\".\\"agent_creation_logs\\" USING \\"btree\\" (\\"performed_by\\")","CREATE INDEX \\"idx_creation_logs_success\\" ON \\"public\\".\\"agent_creation_logs\\" USING \\"btree\\" (\\"success\\")","CREATE INDEX \\"idx_creation_metrics_date\\" ON \\"public\\".\\"agent_creation_metrics\\" USING \\"btree\\" (\\"date_period\\")","CREATE INDEX \\"idx_creation_metrics_hour\\" ON \\"public\\".\\"agent_creation_metrics\\" USING \\"btree\\" (\\"hour_period\\")","CREATE INDEX \\"idx_events_conversation_id\\" ON \\"public\\".\\"agent_creation_events\\" USING \\"btree\\" (\\"conversation_id\\")","CREATE INDEX \\"idx_events_event_type\\" ON \\"public\\".\\"agent_creation_events\\" USING \\"btree\\" (\\"event_type\\")","CREATE INDEX \\"idx_events_question_number\\" ON \\"public\\".\\"agent_creation_events\\" USING \\"btree\\" (\\"question_number\\")","CREATE INDEX \\"idx_events_timestamp\\" ON \\"public\\".\\"agent_creation_events\\" USING \\"btree\\" (\\"timestamp\\")","CREATE INDEX \\"idx_llm_usage_created_at\\" ON \\"public\\".\\"llm_usage\\" USING \\"btree\\" (\\"created_at\\")","CREATE INDEX \\"idx_project_steps_project_id\\" ON \\"public\\".\\"project_steps\\" USING \\"btree\\" (\\"project_id\\")","CREATE INDEX \\"idx_project_steps_status\\" ON \\"public\\".\\"project_steps\\" USING \\"btree\\" (\\"status\\")","CREATE INDEX \\"idx_project_steps_step_index\\" ON \\"public\\".\\"project_steps\\" USING \\"btree\\" (\\"step_index\\")","CREATE INDEX \\"idx_projects_conversation_id\\" ON \\"public\\".\\"projects\\" USING \\"btree\\" (\\"conversation_id\\")","CREATE INDEX \\"idx_projects_created_at\\" ON \\"public\\".\\"projects\\" USING \\"btree\\" (\\"created_at\\")","CREATE INDEX \\"idx_projects_parent_project_id\\" ON \\"public\\".\\"projects\\" USING \\"btree\\" (\\"parent_project_id\\")","CREATE INDEX \\"idx_projects_status\\" ON \\"public\\".\\"projects\\" USING \\"btree\\" (\\"status\\")","CREATE INDEX \\"idx_projects_updated_at\\" ON \\"public\\".\\"projects\\" USING \\"btree\\" (\\"updated_at\\")","CREATE INDEX \\"idx_pseudonym_dictionaries_original_value\\" ON \\"public\\".\\"pseudonym_dictionaries\\" USING \\"btree\\" (\\"original_value\\")","CREATE INDEX \\"idx_redaction_patterns_active\\" ON \\"public\\".\\"redaction_patterns\\" USING \\"btree\\" (\\"is_active\\", \\"priority\\")","CREATE INDEX \\"idx_tasks_conversation_id\\" ON \\"public\\".\\"tasks\\" USING \\"btree\\" (\\"conversation_id\\")","CREATE INDEX \\"idx_usage_analytics_agent_id\\" ON \\"public\\".\\"agent_usage_analytics\\" USING \\"btree\\" (\\"agent_configuration_id\\")","CREATE INDEX \\"idx_usage_analytics_agent_lookup\\" ON \\"public\\".\\"agent_usage_analytics\\" USING \\"btree\\" (\\"agent_id\\")","CREATE INDEX \\"idx_usage_analytics_date\\" ON \\"public\\".\\"agent_usage_analytics\\" USING \\"btree\\" (\\"date_period\\")","CREATE INDEX \\"idx_users_email\\" ON \\"public\\".\\"users\\" USING \\"btree\\" (\\"email\\")","CREATE OR REPLACE TRIGGER \\"trigger_agent_configurations_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"agent_configurations\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_agent_configurations_updated_at\\"()","CREATE OR REPLACE TRIGGER \\"trigger_agent_skills_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"agent_skills\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_agent_skills_updated_at\\"()","CREATE OR REPLACE TRIGGER \\"trigger_conversations_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"agent_creation_conversations\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_conversation_timestamps\\"()","CREATE OR REPLACE TRIGGER \\"trigger_update_completion_percentage\\" BEFORE UPDATE ON \\"public\\".\\"agent_creation_conversations\\" FOR EACH ROW WHEN ((\\"old\\".\\"requirements_gathered\\" IS DISTINCT FROM \\"new\\".\\"requirements_gathered\\")) EXECUTE FUNCTION \\"public\\".\\"update_completion_percentage\\"()","CREATE OR REPLACE TRIGGER \\"update_project_steps_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"project_steps\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","CREATE OR REPLACE TRIGGER \\"update_projects_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"projects\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","ALTER TABLE ONLY \\"public\\".\\"agent_configurations\\"\n    ADD CONSTRAINT \\"agent_configurations_created_by_fkey\\" FOREIGN KEY (\\"created_by\\") REFERENCES \\"auth\\".\\"users\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"conversations\\"\n    ADD CONSTRAINT \\"agent_conversations_user_id_fkey\\" FOREIGN KEY (\\"user_id\\") REFERENCES \\"public\\".\\"users\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_creation_conversations\\"\n    ADD CONSTRAINT \\"agent_creation_conversations_agent_configuration_id_fkey\\" FOREIGN KEY (\\"agent_configuration_id\\") REFERENCES \\"public\\".\\"agent_configurations\\"(\\"id\\") ON DELETE SET NULL","ALTER TABLE ONLY \\"public\\".\\"agent_creation_conversations\\"\n    ADD CONSTRAINT \\"agent_creation_conversations_user_id_fkey\\" FOREIGN KEY (\\"user_id\\") REFERENCES \\"auth\\".\\"users\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_creation_events\\"\n    ADD CONSTRAINT \\"agent_creation_events_conversation_id_fkey\\" FOREIGN KEY (\\"conversation_id\\") REFERENCES \\"public\\".\\"agent_creation_conversations\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"agent_creation_logs\\"\n    ADD CONSTRAINT \\"agent_creation_logs_agent_configuration_id_fkey\\" FOREIGN KEY (\\"agent_configuration_id\\") REFERENCES \\"public\\".\\"agent_configurations\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"agent_creation_logs\\"\n    ADD CONSTRAINT \\"agent_creation_logs_performed_by_fkey\\" FOREIGN KEY (\\"performed_by\\") REFERENCES \\"auth\\".\\"users\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_skills\\"\n    ADD CONSTRAINT \\"agent_skills_agent_configuration_id_fkey\\" FOREIGN KEY (\\"agent_configuration_id\\") REFERENCES \\"public\\".\\"agent_configurations\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"agent_usage_analytics\\"\n    ADD CONSTRAINT \\"agent_usage_analytics_agent_configuration_id_fkey\\" FOREIGN KEY (\\"agent_configuration_id\\") REFERENCES \\"public\\".\\"agent_configurations\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"deliverable_versions\\"\n    ADD CONSTRAINT \\"deliverable_versions_deliverable_id_fkey\\" FOREIGN KEY (\\"deliverable_id\\") REFERENCES \\"public\\".\\"deliverables\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"deliverable_versions\\"\n    ADD CONSTRAINT \\"deliverable_versions_task_id_fkey\\" FOREIGN KEY (\\"task_id\\") REFERENCES \\"public\\".\\"tasks\\"(\\"id\\") ON DELETE SET NULL","ALTER TABLE ONLY \\"public\\".\\"deliverables\\"\n    ADD CONSTRAINT \\"deliverables_user_id_fkey\\" FOREIGN KEY (\\"user_id\\") REFERENCES \\"public\\".\\"users\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"departments\\"\n    ADD CONSTRAINT \\"departments_company_id_fkey\\" FOREIGN KEY (\\"company_id\\") REFERENCES \\"public\\".\\"companies\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"kpi_data\\"\n    ADD CONSTRAINT \\"kpi_data_department_id_fkey\\" FOREIGN KEY (\\"department_id\\") REFERENCES \\"public\\".\\"departments\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"kpi_data\\"\n    ADD CONSTRAINT \\"kpi_data_metric_id_fkey\\" FOREIGN KEY (\\"metric_id\\") REFERENCES \\"public\\".\\"kpi_metrics\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"kpi_goals\\"\n    ADD CONSTRAINT \\"kpi_goals_department_id_fkey\\" FOREIGN KEY (\\"department_id\\") REFERENCES \\"public\\".\\"departments\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"kpi_goals\\"\n    ADD CONSTRAINT \\"kpi_goals_metric_id_fkey\\" FOREIGN KEY (\\"metric_id\\") REFERENCES \\"public\\".\\"kpi_metrics\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"llm_models\\"\n    ADD CONSTRAINT \\"llm_models_provider_name_fkey\\" FOREIGN KEY (\\"provider_name\\") REFERENCES \\"public\\".\\"llm_providers\\"(\\"name\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"llm_usage\\"\n    ADD CONSTRAINT \\"llm_usage_conversation_id_fkey\\" FOREIGN KEY (\\"conversation_id\\") REFERENCES \\"public\\".\\"conversations\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"project_steps\\"\n    ADD CONSTRAINT \\"project_steps_project_id_fkey\\" FOREIGN KEY (\\"project_id\\") REFERENCES \\"public\\".\\"projects\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"projects\\"\n    ADD CONSTRAINT \\"projects_conversation_id_fkey\\" FOREIGN KEY (\\"conversation_id\\") REFERENCES \\"public\\".\\"conversations\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"projects\\"\n    ADD CONSTRAINT \\"projects_parent_project_id_fkey\\" FOREIGN KEY (\\"parent_project_id\\") REFERENCES \\"public\\".\\"projects\\"(\\"id\\") ON DELETE SET NULL","ALTER TABLE ONLY \\"public\\".\\"tasks\\"\n    ADD CONSTRAINT \\"tasks_conversation_id_fkey\\" FOREIGN KEY (\\"conversation_id\\") REFERENCES \\"public\\".\\"conversations\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"tasks\\"\n    ADD CONSTRAINT \\"tasks_user_id_fkey\\" FOREIGN KEY (\\"user_id\\") REFERENCES \\"public\\".\\"users\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"user_cidafm_commands\\"\n    ADD CONSTRAINT \\"user_cidafm_commands_command_id_fkey\\" FOREIGN KEY (\\"command_id\\") REFERENCES \\"public\\".\\"cidafm_commands\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"user_cidafm_commands\\"\n    ADD CONSTRAINT \\"user_cidafm_commands_user_id_fkey\\" FOREIGN KEY (\\"user_id\\") REFERENCES \\"public\\".\\"users\\"(\\"id\\") ON DELETE CASCADE","CREATE POLICY \\"Authenticated users can view creation metrics\\" ON \\"public\\".\\"agent_creation_metrics\\" FOR SELECT USING ((\\"auth\\".\\"role\\"() = 'authenticated'::\\"text\\"))","CREATE POLICY \\"Users can create agents\\" ON \\"public\\".\\"agent_configurations\\" FOR INSERT WITH CHECK ((\\"auth\\".\\"uid\\"() = \\"created_by\\"))","CREATE POLICY \\"Users can create their own project steps\\" ON \\"public\\".\\"project_steps\\" FOR INSERT WITH CHECK ((\\"project_id\\" IN ( SELECT \\"p\\".\\"id\\"\n   FROM (\\"public\\".\\"projects\\" \\"p\\"\n     JOIN \\"public\\".\\"conversations\\" \\"c\\" ON ((\\"p\\".\\"conversation_id\\" = \\"c\\".\\"id\\")))\n  WHERE (\\"c\\".\\"user_id\\" = \\"auth\\".\\"uid\\"()))))","CREATE POLICY \\"Users can create their own projects\\" ON \\"public\\".\\"projects\\" FOR INSERT WITH CHECK ((\\"conversation_id\\" IN ( SELECT \\"conversations\\".\\"id\\"\n   FROM \\"public\\".\\"conversations\\"\n  WHERE (\\"conversations\\".\\"user_id\\" = \\"auth\\".\\"uid\\"()))))","CREATE POLICY \\"Users can delete their own project steps\\" ON \\"public\\".\\"project_steps\\" FOR DELETE USING ((\\"project_id\\" IN ( SELECT \\"p\\".\\"id\\"\n   FROM (\\"public\\".\\"projects\\" \\"p\\"\n     JOIN \\"public\\".\\"conversations\\" \\"c\\" ON ((\\"p\\".\\"conversation_id\\" = \\"c\\".\\"id\\")))\n  WHERE (\\"c\\".\\"user_id\\" = \\"auth\\".\\"uid\\"()))))","CREATE POLICY \\"Users can delete their own projects\\" ON \\"public\\".\\"projects\\" FOR DELETE USING ((\\"conversation_id\\" IN ( SELECT \\"conversations\\".\\"id\\"\n   FROM \\"public\\".\\"conversations\\"\n  WHERE (\\"conversations\\".\\"user_id\\" = \\"auth\\".\\"uid\\"()))))","CREATE POLICY \\"Users can modify own agents\\" ON \\"public\\".\\"agent_configurations\\" USING ((\\"auth\\".\\"uid\\"() = \\"created_by\\"))","CREATE POLICY \\"Users can modify skills for own agents\\" ON \\"public\\".\\"agent_skills\\" USING ((EXISTS ( SELECT 1\n   FROM \\"public\\".\\"agent_configurations\\" \\"ac\\"\n  WHERE ((\\"ac\\".\\"id\\" = \\"agent_skills\\".\\"agent_configuration_id\\") AND (\\"ac\\".\\"created_by\\" = \\"auth\\".\\"uid\\"())))))","CREATE POLICY \\"Users can update their own project steps\\" ON \\"public\\".\\"project_steps\\" FOR UPDATE USING ((\\"project_id\\" IN ( SELECT \\"p\\".\\"id\\"\n   FROM (\\"public\\".\\"projects\\" \\"p\\"\n     JOIN \\"public\\".\\"conversations\\" \\"c\\" ON ((\\"p\\".\\"conversation_id\\" = \\"c\\".\\"id\\")))\n  WHERE (\\"c\\".\\"user_id\\" = \\"auth\\".\\"uid\\"()))))","CREATE POLICY \\"Users can update their own projects\\" ON \\"public\\".\\"projects\\" FOR UPDATE USING ((\\"conversation_id\\" IN ( SELECT \\"conversations\\".\\"id\\"\n   FROM \\"public\\".\\"conversations\\"\n  WHERE (\\"conversations\\".\\"user_id\\" = \\"auth\\".\\"uid\\"()))))","CREATE POLICY \\"Users can view active agents\\" ON \\"public\\".\\"agent_configurations\\" FOR SELECT USING (((\\"status\\")::\\"text\\" = 'active'::\\"text\\"))","CREATE POLICY \\"Users can view analytics for own agents\\" ON \\"public\\".\\"agent_usage_analytics\\" FOR SELECT USING ((EXISTS ( SELECT 1\n   FROM \\"public\\".\\"agent_configurations\\" \\"ac\\"\n  WHERE ((\\"ac\\".\\"id\\" = \\"agent_usage_analytics\\".\\"agent_configuration_id\\") AND (\\"ac\\".\\"created_by\\" = \\"auth\\".\\"uid\\"())))))","CREATE POLICY \\"Users can view logs for own agents\\" ON \\"public\\".\\"agent_creation_logs\\" FOR SELECT USING (((EXISTS ( SELECT 1\n   FROM \\"public\\".\\"agent_configurations\\" \\"ac\\"\n  WHERE ((\\"ac\\".\\"id\\" = \\"agent_creation_logs\\".\\"agent_configuration_id\\") AND (\\"ac\\".\\"created_by\\" = \\"auth\\".\\"uid\\"())))) OR (\\"performed_by\\" = \\"auth\\".\\"uid\\"())))","CREATE POLICY \\"Users can view own conversation events\\" ON \\"public\\".\\"agent_creation_events\\" USING ((EXISTS ( SELECT 1\n   FROM \\"public\\".\\"agent_creation_conversations\\" \\"c\\"\n  WHERE ((\\"c\\".\\"id\\" = \\"agent_creation_events\\".\\"conversation_id\\") AND (\\"c\\".\\"user_id\\" = \\"auth\\".\\"uid\\"())))))","CREATE POLICY \\"Users can view own conversations\\" ON \\"public\\".\\"agent_creation_conversations\\" USING ((\\"auth\\".\\"uid\\"() = \\"user_id\\"))","CREATE POLICY \\"Users can view skills for active agents\\" ON \\"public\\".\\"agent_skills\\" FOR SELECT USING ((EXISTS ( SELECT 1\n   FROM \\"public\\".\\"agent_configurations\\" \\"ac\\"\n  WHERE ((\\"ac\\".\\"id\\" = \\"agent_skills\\".\\"agent_configuration_id\\") AND ((\\"ac\\".\\"status\\")::\\"text\\" = 'active'::\\"text\\")))))","CREATE POLICY \\"Users can view their own project steps\\" ON \\"public\\".\\"project_steps\\" FOR SELECT USING ((\\"project_id\\" IN ( SELECT \\"p\\".\\"id\\"\n   FROM (\\"public\\".\\"projects\\" \\"p\\"\n     JOIN \\"public\\".\\"conversations\\" \\"c\\" ON ((\\"p\\".\\"conversation_id\\" = \\"c\\".\\"id\\")))\n  WHERE (\\"c\\".\\"user_id\\" = \\"auth\\".\\"uid\\"()))))","CREATE POLICY \\"Users can view their own projects\\" ON \\"public\\".\\"projects\\" FOR SELECT USING ((\\"conversation_id\\" IN ( SELECT \\"conversations\\".\\"id\\"\n   FROM \\"public\\".\\"conversations\\"\n  WHERE (\\"conversations\\".\\"user_id\\" = \\"auth\\".\\"uid\\"()))))","ALTER TABLE \\"public\\".\\"agent_configurations\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"agent_creation_conversations\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"agent_creation_events\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"agent_creation_logs\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"agent_creation_metrics\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"agent_skills\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"agent_usage_analytics\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"project_steps\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"projects\\" ENABLE ROW LEVEL SECURITY","ALTER PUBLICATION \\"supabase_realtime\\" OWNER TO \\"postgres\\"","GRANT USAGE ON SCHEMA \\"public\\" TO \\"postgres\\"","GRANT USAGE ON SCHEMA \\"public\\" TO \\"anon\\"","GRANT USAGE ON SCHEMA \\"public\\" TO \\"authenticated\\"","GRANT USAGE ON SCHEMA \\"public\\" TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"calculate_completion_percentage\\"(\\"requirements\\" \\"jsonb\\") TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"calculate_completion_percentage\\"(\\"requirements\\" \\"jsonb\\") TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"calculate_completion_percentage\\"(\\"requirements\\" \\"jsonb\\") TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"cleanup_abandoned_conversations\\"() TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"cleanup_abandoned_conversations\\"() TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"cleanup_abandoned_conversations\\"() TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"exec_sql\\"(\\"query\\" \\"text\\", \\"sql_query\\" \\"text\\") TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"exec_sql\\"(\\"query\\" \\"text\\", \\"sql_query\\" \\"text\\") TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"exec_sql\\"(\\"query\\" \\"text\\", \\"sql_query\\" \\"text\\") TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"get_global_model_config\\"() TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"get_global_model_config\\"() TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"get_global_model_config\\"() TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"log_agent_action\\"(\\"p_action\\" character varying, \\"p_agent_id\\" \\"uuid\\", \\"p_details\\" \\"jsonb\\", \\"p_previous_state\\" \\"jsonb\\", \\"p_new_state\\" \\"jsonb\\", \\"p_success\\" boolean, \\"p_error_message\\" \\"text\\") TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"log_agent_action\\"(\\"p_action\\" character varying, \\"p_agent_id\\" \\"uuid\\", \\"p_details\\" \\"jsonb\\", \\"p_previous_state\\" \\"jsonb\\", \\"p_new_state\\" \\"jsonb\\", \\"p_success\\" boolean, \\"p_error_message\\" \\"text\\") TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"log_agent_action\\"(\\"p_action\\" character varying, \\"p_agent_id\\" \\"uuid\\", \\"p_details\\" \\"jsonb\\", \\"p_previous_state\\" \\"jsonb\\", \\"p_new_state\\" \\"jsonb\\", \\"p_success\\" boolean, \\"p_error_message\\" \\"text\\") TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_agent_configurations_updated_at\\"() TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_agent_configurations_updated_at\\"() TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_agent_configurations_updated_at\\"() TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_agent_skills_updated_at\\"() TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_agent_skills_updated_at\\"() TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_agent_skills_updated_at\\"() TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_agent_usage_analytics\\"(\\"p_agent_id\\" \\"uuid\\", \\"p_conversation_increment\\" integer, \\"p_message_increment\\" integer, \\"p_response_time_ms\\" integer, \\"p_error_increment\\" integer, \\"p_unique_user_increment\\" integer) TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_agent_usage_analytics\\"(\\"p_agent_id\\" \\"uuid\\", \\"p_conversation_increment\\" integer, \\"p_message_increment\\" integer, \\"p_response_time_ms\\" integer, \\"p_error_increment\\" integer, \\"p_unique_user_increment\\" integer) TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_agent_usage_analytics\\"(\\"p_agent_id\\" \\"uuid\\", \\"p_conversation_increment\\" integer, \\"p_message_increment\\" integer, \\"p_response_time_ms\\" integer, \\"p_error_increment\\" integer, \\"p_unique_user_increment\\" integer) TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_completion_percentage\\"() TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_completion_percentage\\"() TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_completion_percentage\\"() TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_conversation_timestamps\\"() TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_conversation_timestamps\\"() TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_conversation_timestamps\\"() TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_creation_metrics\\"(\\"p_success\\" boolean, \\"p_creation_time_seconds\\" integer, \\"p_questions_answered\\" integer, \\"p_department\\" character varying) TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_creation_metrics\\"(\\"p_success\\" boolean, \\"p_creation_time_seconds\\" integer, \\"p_questions_answered\\" integer, \\"p_department\\" character varying) TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_creation_metrics\\"(\\"p_success\\" boolean, \\"p_creation_time_seconds\\" integer, \\"p_questions_answered\\" integer, \\"p_department\\" character varying) TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_updated_at_column\\"() TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_updated_at_column\\"() TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_updated_at_column\\"() TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"validate_skill_examples\\"(\\"examples\\" \\"jsonb\\") TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"validate_skill_examples\\"(\\"examples\\" \\"jsonb\\") TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"validate_skill_examples\\"(\\"examples\\" \\"jsonb\\") TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_configurations\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_configurations\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_configurations\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_conversations\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_conversations\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_conversations\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_events\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_events\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_events\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_logs\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_logs\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_logs\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_metrics\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_metrics\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_metrics\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_skills\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_skills\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_skills\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_usage_analytics\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_usage_analytics\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_usage_analytics\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"cidafm_commands\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"cidafm_commands\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"cidafm_commands\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"companies\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"companies\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"companies\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"conversations\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"conversations\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"conversations\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"tasks\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"tasks\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"tasks\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"conversations_with_stats\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"conversations_with_stats\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"conversations_with_stats\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"deliverable_versions\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"deliverable_versions\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"deliverable_versions\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"deliverables\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"deliverables\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"deliverables\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"departments\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"departments\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"departments\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"kpi_data\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"kpi_data\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"kpi_data\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"kpi_goals\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"kpi_goals\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"kpi_goals\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"kpi_metrics\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"kpi_metrics\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"kpi_metrics\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_models\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_models\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_models\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_providers\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_providers\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_providers\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_usage\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_usage\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_usage\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"project_steps\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"project_steps\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"project_steps\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"projects\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"projects\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"projects\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"pseudonym_dictionaries\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"pseudonym_dictionaries\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"pseudonym_dictionaries\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"redaction_patterns\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"redaction_patterns\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"redaction_patterns\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"system_settings\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"system_settings\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"system_settings\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"user_cidafm_commands\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"user_cidafm_commands\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"user_cidafm_commands\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"users\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"users\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"users\\" TO \\"service_role\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON SEQUENCES TO \\"postgres\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON SEQUENCES TO \\"anon\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON SEQUENCES TO \\"authenticated\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON SEQUENCES TO \\"service_role\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON FUNCTIONS TO \\"postgres\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON FUNCTIONS TO \\"anon\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON FUNCTIONS TO \\"authenticated\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON FUNCTIONS TO \\"service_role\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON TABLES TO \\"postgres\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON TABLES TO \\"anon\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON TABLES TO \\"authenticated\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON TABLES TO \\"service_role\\"","RESET ALL"}	golden_master_complete
20250108000000	{"-- Jokes Agent Migration\n-- Creates the necessary database structure for the Productivity Jokes Agent\n\n-- Create jokes_agent table to store joke history and sessions\nCREATE TABLE IF NOT EXISTS jokes_agent (\n    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,\n    session_id TEXT NOT NULL,\n    prompt TEXT NOT NULL,\n    joke_output TEXT NOT NULL,\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- Create index for faster session lookups\nCREATE INDEX IF NOT EXISTS idx_jokes_agent_session_id ON jokes_agent(session_id)","CREATE INDEX IF NOT EXISTS idx_jokes_agent_created_at ON jokes_agent(created_at)","-- Create RLS policies for jokes_agent table\nALTER TABLE jokes_agent ENABLE ROW LEVEL SECURITY","-- Policy to allow authenticated users to read their own jokes\nCREATE POLICY \\"Users can view their own jokes\\" ON jokes_agent\n    FOR SELECT USING (auth.uid()::text = session_id OR session_id LIKE 'session_%')","-- Policy to allow authenticated users to insert jokes\nCREATE POLICY \\"Users can insert jokes\\" ON jokes_agent\n    FOR INSERT WITH CHECK (true)","-- Create function to clean up old joke records (older than 30 days)\nCREATE OR REPLACE FUNCTION cleanup_old_jokes()\nRETURNS void\nLANGUAGE plpgsql\nAS $$\nBEGIN\n    DELETE FROM jokes_agent \n    WHERE created_at < NOW() - INTERVAL '30 days';\nEND;\n$$","-- Create a scheduled job to run cleanup weekly (if pg_cron is available)\n-- SELECT cron.schedule('cleanup-jokes', '0 2 * * 0', 'SELECT cleanup_old_jokes();');\n\n-- Insert some sample fallback jokes for error handling\nINSERT INTO jokes_agent (session_id, prompt, joke_output) VALUES\n('fallback', 'error_fallback', 'Why don''t productivity apps ever get stressed? Because they know how to delegate their tasks!'),\n('fallback', 'error_fallback', 'What do you call a programmer who doesn''t comment their code? A mystery novelist!'),\n('fallback', 'error_fallback', 'Why did the spreadsheet go to therapy? It had too many cells of anxiety!'),\n('fallback', 'error_fallback', 'How do you comfort a JavaScript bug? You console it!'),\n('fallback', 'error_fallback', 'Why don''t databases ever get lonely? Because they always have relationships!')\nON CONFLICT DO NOTHING","-- Create a view for joke analytics\nCREATE OR REPLACE VIEW jokes_analytics AS\nSELECT \n    DATE(created_at) as joke_date,\n    COUNT(*) as total_jokes,\n    COUNT(DISTINCT session_id) as unique_sessions,\n    AVG(LENGTH(joke_output)) as avg_joke_length\nFROM jokes_agent \nWHERE session_id != 'fallback'\nGROUP BY DATE(created_at)\nORDER BY joke_date DESC","-- Grant permissions\nGRANT SELECT, INSERT ON jokes_agent TO authenticated","GRANT SELECT ON jokes_analytics TO authenticated"}	jokes_agent_migration
202501160001	{"-- Agent platform base tables\n\n-- Drop legacy filesystem-driven agent tables once we move to database-backed agents\nDROP TABLE IF EXISTS public.agent_usage_analytics CASCADE","DROP TABLE IF EXISTS public.agent_skills CASCADE","DROP TABLE IF EXISTS public.agent_creation_metrics CASCADE","DROP TABLE IF EXISTS public.agent_creation_logs CASCADE","DROP TABLE IF EXISTS public.agent_creation_events CASCADE","DROP TABLE IF EXISTS public.agent_creation_conversations CASCADE","DROP TABLE IF EXISTS public.agent_configurations CASCADE","-- agents table stores metadata, yaml, and derived context/config for runtime\nCREATE TABLE IF NOT EXISTS public.agents (\n    id uuid DEFAULT extensions.uuid_generate_v4() PRIMARY KEY,\n    organization_slug text,\n    slug text NOT NULL,\n    display_name text NOT NULL,\n    description text,\n    agent_type text NOT NULL,\n    mode_profile text NOT NULL,\n    version text,\n    status text DEFAULT 'active',\n    yaml text NOT NULL,\n    agent_card jsonb,\n    context jsonb,\n    config jsonb,\n    created_at timestamptz DEFAULT now(),\n    updated_at timestamptz DEFAULT now(),\n    CONSTRAINT agents_slug_unique UNIQUE (organization_slug, slug)\n)","COMMENT ON TABLE public.agents IS 'Database-backed agent descriptors for the new platform.'","COMMENT ON COLUMN public.agents.organization_slug IS 'Namespace / organization identifier (e.g., demo, my-org).'","COMMENT ON COLUMN public.agents.yaml IS 'Raw YAML/JSON descriptor for auditability.'","COMMENT ON COLUMN public.agents.agent_card IS 'Cached agent card served to clients.'","COMMENT ON COLUMN public.agents.context IS 'System prompt, plan rubric, and reference data.'","COMMENT ON COLUMN public.agents.config IS 'Execution configuration (capabilities, supporting agents, checkpoints, etc.).'","-- organization credentials per org/alias\nCREATE TABLE IF NOT EXISTS public.organization_credentials (\n    id uuid DEFAULT extensions.uuid_generate_v4() PRIMARY KEY,\n    organization_slug text NOT NULL,\n    alias text NOT NULL,\n    credential_type text NOT NULL,\n    encrypted_value bytea NOT NULL,\n    encryption_metadata jsonb DEFAULT '{}'::jsonb,\n    rotated_at timestamptz,\n    created_at timestamptz DEFAULT now(),\n    updated_at timestamptz DEFAULT now(),\n    CONSTRAINT organization_credentials_alias_unique UNIQUE (organization_slug, alias)\n)","COMMENT ON TABLE public.organization_credentials IS 'Encrypted secrets per organization (API keys, service credentials).'","-- conversation plans capture structured plans tied to conversations\nCREATE TABLE IF NOT EXISTS public.conversation_plans (\n    id uuid DEFAULT extensions.uuid_generate_v4() PRIMARY KEY,\n    conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,\n    organization_slug text,\n    agent_slug text NOT NULL,\n    version integer DEFAULT 1,\n    status text DEFAULT 'draft',\n    summary text,\n    plan_json jsonb NOT NULL,\n    created_by uuid,\n    approved_by uuid,\n    created_at timestamptz DEFAULT now(),\n    updated_at timestamptz DEFAULT now()\n)","COMMENT ON TABLE public.conversation_plans IS 'Structured plans generated during plan mode, linked to conversations.'","COMMENT ON COLUMN public.conversation_plans.plan_json IS 'Plan structure including phases, steps, dependencies, checkpoints.'","-- saved orchestrations act as reusable execution recipes for agents\nCREATE TABLE IF NOT EXISTS public.agent_orchestrations (\n    id uuid DEFAULT extensions.uuid_generate_v4() PRIMARY KEY,\n    organization_slug text,\n    agent_slug text NOT NULL,\n    slug text NOT NULL,\n    display_name text NOT NULL,\n    description text,\n    status text DEFAULT 'active',\n    orchestration_json jsonb NOT NULL,\n    prompt_templates jsonb DEFAULT '[]'::jsonb,\n    tags text[] DEFAULT ARRAY[]::text[],\n    version text,\n    created_by uuid,\n    updated_by uuid,\n    created_at timestamptz DEFAULT now(),\n    updated_at timestamptz DEFAULT now(),\n    CONSTRAINT agent_orchestrations_slug_unique UNIQUE (organization_slug, agent_slug, slug)\n)","COMMENT ON TABLE public.agent_orchestrations IS 'Reusable orchestration recipes bound to a specific agent.'","COMMENT ON COLUMN public.agent_orchestrations.orchestration_json IS 'Structured orchestration definition (phases, steps, dependencies).'","COMMENT ON COLUMN public.agent_orchestrations.prompt_templates IS 'Prompt templates with parameter metadata required to launch orchestrations.'","-- orchestration runs instantiate execution of approved plans\nCREATE TABLE IF NOT EXISTS public.orchestration_runs (\n    id uuid DEFAULT extensions.uuid_generate_v4() PRIMARY KEY,\n    plan_id uuid REFERENCES public.conversation_plans(id) ON DELETE SET NULL,\n    origin_type text DEFAULT 'plan',\n    origin_id uuid,\n    orchestration_slug text,\n    prompt_inputs jsonb DEFAULT '{}'::jsonb,\n    organization_slug text,\n    status text DEFAULT 'pending',\n    current_step_index integer,\n    completed_steps jsonb DEFAULT '[]'::jsonb,\n    step_state jsonb DEFAULT '{}'::jsonb,\n    human_checkpoint_id text,\n    metadata jsonb DEFAULT '{}'::jsonb,\n    started_at timestamptz DEFAULT now(),\n    completed_at timestamptz\n)","COMMENT ON TABLE public.orchestration_runs IS 'Live orchestration execution state derived from conversation plans or saved orchestrations.'","COMMENT ON COLUMN public.orchestration_runs.step_state IS 'Per-step status metadata including conversations, deliverables, assignments.'","COMMENT ON COLUMN public.orchestration_runs.origin_type IS 'Execution source (plan, saved_orchestration, ad_hoc).'","COMMENT ON COLUMN public.orchestration_runs.orchestration_slug IS 'Slug of the saved orchestration recipe when origin_type = saved_orchestration.'","COMMENT ON COLUMN public.orchestration_runs.prompt_inputs IS 'Resolved prompt parameter payload provided at orchestration launch.'","-- optional organization reference on users (nullable for legacy accounts)\nALTER TABLE public.users\n    ADD COLUMN IF NOT EXISTS organization_slug text","CREATE INDEX IF NOT EXISTS idx_agents_org_slug ON public.agents(organization_slug)","CREATE INDEX IF NOT EXISTS idx_agents_slug ON public.agents(slug)","CREATE INDEX IF NOT EXISTS idx_conversation_plans_conversation ON public.conversation_plans(conversation_id)","CREATE INDEX IF NOT EXISTS idx_agent_orchestrations_agent ON public.agent_orchestrations(agent_slug)","CREATE INDEX IF NOT EXISTS idx_agent_orchestrations_org ON public.agent_orchestrations(organization_slug)","CREATE INDEX IF NOT EXISTS idx_orchestration_runs_plan ON public.orchestration_runs(plan_id)","CREATE INDEX IF NOT EXISTS idx_org_credentials_org ON public.organization_credentials(organization_slug)"}	agent_platform
202501170001	{"-- Rename legacy project_runs artifacts to orchestration_ equivalents and\n-- backfill saved orchestration support for agents.\n\nBEGIN","-- Rename table and index if they still exist from early migrations.\nALTER TABLE IF EXISTS public.project_runs\n    RENAME TO orchestration_runs","ALTER INDEX IF EXISTS idx_project_runs_plan\n    RENAME TO idx_orchestration_runs_plan","COMMENT ON TABLE public.orchestration_runs IS 'Live orchestration execution state derived from conversation plans or saved orchestrations.'","COMMENT ON COLUMN public.orchestration_runs.step_state IS 'Per-step status metadata including conversations, deliverables, assignments.'","ALTER TABLE IF EXISTS public.orchestration_runs\n    ALTER COLUMN plan_id DROP NOT NULL","ALTER TABLE IF EXISTS public.orchestration_runs\n    DROP CONSTRAINT IF EXISTS orchestration_runs_plan_id_fkey","ALTER TABLE IF EXISTS public.orchestration_runs\n    ADD CONSTRAINT orchestration_runs_plan_id_fkey\n        FOREIGN KEY (plan_id)\n        REFERENCES public.conversation_plans(id)\n        ON DELETE SET NULL","ALTER TABLE IF EXISTS public.orchestration_runs\n    ADD COLUMN IF NOT EXISTS origin_type text DEFAULT 'plan'","ALTER TABLE IF EXISTS public.orchestration_runs\n    ADD COLUMN IF NOT EXISTS origin_id uuid","ALTER TABLE IF EXISTS public.orchestration_runs\n    ADD COLUMN IF NOT EXISTS orchestration_slug text","ALTER TABLE IF EXISTS public.orchestration_runs\n    ADD COLUMN IF NOT EXISTS prompt_inputs jsonb DEFAULT '{}'::jsonb","-- Ensure saved orchestration recipes table is available.\nCREATE TABLE IF NOT EXISTS public.agent_orchestrations (\n    id uuid DEFAULT extensions.uuid_generate_v4() PRIMARY KEY,\n    organization_slug text,\n    agent_slug text NOT NULL,\n    slug text NOT NULL,\n    display_name text NOT NULL,\n    description text,\n    status text DEFAULT 'active',\n    orchestration_json jsonb NOT NULL,\n    prompt_templates jsonb DEFAULT '[]'::jsonb,\n    tags text[] DEFAULT ARRAY[]::text[],\n    version text,\n    created_by uuid,\n    updated_by uuid,\n    created_at timestamptz DEFAULT now(),\n    updated_at timestamptz DEFAULT now(),\n    CONSTRAINT agent_orchestrations_slug_unique UNIQUE (organization_slug, agent_slug, slug)\n)","COMMENT ON TABLE public.agent_orchestrations IS 'Reusable orchestration recipes bound to a specific agent.'","COMMENT ON COLUMN public.agent_orchestrations.orchestration_json IS 'Structured orchestration definition (phases, steps, dependencies).'","COMMENT ON COLUMN public.agent_orchestrations.prompt_templates IS 'Prompt templates with parameter metadata required to launch orchestrations.'","CREATE INDEX IF NOT EXISTS idx_agent_orchestrations_agent ON public.agent_orchestrations(agent_slug)","CREATE INDEX IF NOT EXISTS idx_agent_orchestrations_org ON public.agent_orchestrations(organization_slug)",COMMIT}	orchestration_recipes
202501210001	{"-- Migration: Add `route` column to llm_usage and backfill from is_local\n-- Created: 2025-01-21\n\nBEGIN","-- 1) Add column if it does not exist\nALTER TABLE public.llm_usage\n  ADD COLUMN IF NOT EXISTS route text","-- 2) Backfill existing rows where route is NULL\nUPDATE public.llm_usage\n   SET route = CASE WHEN is_local IS TRUE THEN 'local' ELSE 'remote' END\n WHERE route IS NULL","-- 3) Optional: basic check constraint to keep route normalized\nDO $$\nBEGIN\n  IF NOT EXISTS (\n    SELECT 1\n      FROM pg_constraint\n     WHERE conname = 'llm_usage_route_check'\n  ) THEN\n    ALTER TABLE public.llm_usage\n      ADD CONSTRAINT llm_usage_route_check\n      CHECK (route IS NULL OR route IN ('local','remote'));\n  END IF;\nEND $$",COMMIT}	llm_usage_route
202501210002	{"-- Migration: Index for llm_usage.route for faster route breakdowns\n-- Created: 2025-01-21\n\nBEGIN","CREATE INDEX IF NOT EXISTS llm_usage_route_idx\n  ON public.llm_usage (route)","-- Optional: time-sliced index for common analytics windows\n-- Uncomment if you frequently filter by started_at\n-- CREATE INDEX IF NOT EXISTS llm_usage_route_started_at_idx\n--   ON public.llm_usage (route, started_at DESC);\n\nCOMMIT"}	llm_usage_route_index
202501210003	{"-- Migration: Composite index for llm_usage (route, started_at)\n-- Created: 2025-01-21\n\nBEGIN","CREATE INDEX IF NOT EXISTS llm_usage_route_started_at_idx\n  ON public.llm_usage (route, started_at DESC)",COMMIT}	llm_usage_route_started_at_idx
202501210004	{"-- Migration: Create human_approvals table for gating approvals\n-- Created: 2025-01-21\n\nBEGIN","CREATE TABLE IF NOT EXISTS public.human_approvals (\n  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),\n  organization_slug text NULL,\n  agent_slug text NOT NULL,\n  conversation_id uuid NULL,\n  task_id text NULL,\n  mode text NOT NULL,\n  status text NOT NULL DEFAULT 'pending', -- pending | approved | rejected\n  approved_by text NULL,\n  decision_at timestamptz NULL,\n  metadata jsonb NULL DEFAULT '{}'::jsonb,\n  created_at timestamptz NOT NULL DEFAULT now(),\n  updated_at timestamptz NOT NULL DEFAULT now()\n)","CREATE INDEX IF NOT EXISTS human_approvals_conversation_idx ON public.human_approvals (conversation_id)","CREATE INDEX IF NOT EXISTS human_approvals_status_idx ON public.human_approvals (status)","-- Simple trigger to update updated_at\nCREATE OR REPLACE FUNCTION public.set_timestamp_updated_at()\nRETURNS TRIGGER AS $$\nBEGIN\n  NEW.updated_at = now();\n  RETURN NEW;\nEND;\n$$ LANGUAGE plpgsql","DROP TRIGGER IF EXISTS set_timestamp_updated_at_human_approvals ON public.human_approvals","CREATE TRIGGER set_timestamp_updated_at_human_approvals\nBEFORE UPDATE ON public.human_approvals\nFOR EACH ROW EXECUTE FUNCTION public.set_timestamp_updated_at()",COMMIT}	human_approvals
20250911	{"-- System settings store and global model config accessor\n\nSET statement_timeout = 0","SET lock_timeout = 0","SET idle_in_transaction_session_timeout = 0","SET client_encoding = 'UTF8'","SET standard_conforming_strings = on","SELECT pg_catalog.set_config('search_path', '', false)","SET check_function_bodies = false","SET xmloption = content","SET client_min_messages = warning","SET row_security = off","-- Key/value JSONB settings table\nCREATE TABLE IF NOT EXISTS public.system_settings (\n    key text PRIMARY KEY,\n    value jsonb NOT NULL,\n    updated_at timestamptz DEFAULT now()\n)","COMMENT ON TABLE public.system_settings IS 'System-wide settings (key/value JSON). Used for global model configuration and feature flags.'","-- Function to fetch the global model configuration\nCREATE OR REPLACE FUNCTION public.get_global_model_config()\nRETURNS jsonb\nLANGUAGE sql\nSTABLE\nAS $$\n  SELECT value FROM public.system_settings WHERE key = 'model_config_global';\n$$","GRANT ALL ON TABLE public.system_settings TO anon","GRANT ALL ON TABLE public.system_settings TO authenticated","GRANT ALL ON TABLE public.system_settings TO service_role","GRANT EXECUTE ON FUNCTION public.get_global_model_config() TO anon","GRANT EXECUTE ON FUNCTION public.get_global_model_config() TO authenticated","GRANT EXECUTE ON FUNCTION public.get_global_model_config() TO service_role"}	add_system_settings_global_model_config
20250913000000	{"-- Fix Claude 4 model names to match Anthropic API\n-- Migration to update database model names to correct Anthropic API model names\n\n-- Update Claude 4 Opus model name to Opus 4.1\nUPDATE public.llm_models\nSET model_name = 'claude-opus-4-1-20250805',\n    display_name = 'Claude Opus 4.1'\nWHERE model_name = 'claude-4-opus' AND provider_name = 'anthropic'","-- Update Claude 4 Sonnet model name\nUPDATE public.llm_models\nSET model_name = 'claude-sonnet-4-20250514',\n    display_name = 'Claude Sonnet 4'\nWHERE model_name = 'claude-4-sonnet' AND provider_name = 'anthropic'","-- Verify the updates\n-- SELECT model_name, provider_name, display_name FROM public.llm_models \n-- WHERE provider_name = 'anthropic' AND model_name LIKE '%4%'"}	fix_claude4_model_names
20250914000000	{"-- Migration: Ensure llm_usage has metrics and PII columns\n-- Date: 2025-09-14\n-- Purpose: Backfill schema in environments missing newer columns used by RunMetadataService\n\n-- Tokens and timing\nALTER TABLE IF EXISTS public.llm_usage\n  ADD COLUMN IF NOT EXISTS input_tokens integer,\n  ADD COLUMN IF NOT EXISTS output_tokens integer,\n  ADD COLUMN IF NOT EXISTS duration_ms integer","-- Cost fields (some environments may already have input/output_cost)\nALTER TABLE IF EXISTS public.llm_usage\n  ADD COLUMN IF NOT EXISTS input_cost numeric,\n  ADD COLUMN IF NOT EXISTS output_cost numeric,\n  ADD COLUMN IF NOT EXISTS total_cost numeric","-- Sanitization and PII fields\nALTER TABLE IF EXISTS public.llm_usage\n  ADD COLUMN IF NOT EXISTS data_sanitization_applied boolean DEFAULT false,\n  ADD COLUMN IF NOT EXISTS sanitization_level text DEFAULT 'none',\n  ADD COLUMN IF NOT EXISTS pii_detected boolean DEFAULT false,\n  ADD COLUMN IF NOT EXISTS pii_types jsonb DEFAULT '[]'::jsonb,\n  ADD COLUMN IF NOT EXISTS pseudonyms_used integer DEFAULT 0,\n  ADD COLUMN IF NOT EXISTS pseudonym_types jsonb DEFAULT '[]'::jsonb,\n  ADD COLUMN IF NOT EXISTS redactions_applied integer DEFAULT 0,\n  ADD COLUMN IF NOT EXISTS redaction_types jsonb DEFAULT '[]'::jsonb","-- Optional helpful index to quickly retrieve a specific run\nDO $$\nBEGIN\n  IF NOT EXISTS (\n    SELECT 1 FROM pg_indexes \n    WHERE schemaname = 'public' \n      AND indexname = 'idx_llm_usage_run_id'\n  ) THEN\n    CREATE INDEX idx_llm_usage_run_id ON public.llm_usage(run_id);\n  END IF;\nEND $$"}	update_llm_usage_metrics
20250914000100	{"-- Migration: Create llm_usage_analytics view used by Admin analytics\n-- Date: 2025-09-14\n\n-- Recreate the analytics view to avoid dependency errors\nDROP VIEW IF EXISTS public.llm_usage_analytics","CREATE VIEW public.llm_usage_analytics AS\nSELECT\n  date_trunc('day', started_at)::date AS date,\n  COALESCE(caller_type, 'unknown') AS caller_type,\n  COUNT(*) AS total_requests,\n  SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS successful_requests,\n  -- Prefer persisted total_cost; if null, compute from input/output\n  COALESCE(SUM(total_cost), SUM(COALESCE(input_cost, 0) + COALESCE(output_cost, 0))) AS total_cost,\n  -- Average duration in ms across rows for this day/type\n  AVG(COALESCE(duration_ms, 0))::numeric AS avg_duration_ms,\n  -- Local vs external split\n  SUM(CASE WHEN is_local IS TRUE THEN 1 ELSE 0 END) AS local_requests,\n  SUM(CASE WHEN is_local IS NOT TRUE THEN 1 ELSE 0 END) AS external_requests\nFROM public.llm_usage\nGROUP BY 1, 2\nORDER BY 1 DESC, 2 ASC","-- Optional: grant select\nGRANT SELECT ON public.llm_usage_analytics TO anon, authenticated, service_role"}	create_llm_usage_analytics_view
20250914000200	{"-- Migration: Enforce uniqueness and presence of run_id in llm_usage\n-- Date: 2025-09-14\n\n-- Ensure run_id is not null\nALTER TABLE IF EXISTS public.llm_usage\n  ALTER COLUMN run_id SET NOT NULL","-- Create unique index on run_id to guarantee single update target per run\nDO $$\nBEGIN\n  IF NOT EXISTS (\n    SELECT 1 FROM pg_indexes\n    WHERE schemaname = 'public' AND indexname = 'llm_usage_run_id_unique'\n  ) THEN\n    CREATE UNIQUE INDEX llm_usage_run_id_unique ON public.llm_usage(run_id);\n  END IF;\nEND $$"}	enforce_llm_usage_run_id_unique
20250915001000	{"-- Migration: Add pseudonym_mappings JSONB column to llm_usage\n-- Purpose: Store actual pseudonym mappings (original, pseudonym, type) per run\n\nALTER TABLE IF EXISTS public.llm_usage\n  ADD COLUMN IF NOT EXISTS pseudonym_mappings jsonb DEFAULT '[]'::jsonb","-- Optional: comment for clarity\nCOMMENT ON COLUMN public.llm_usage.pseudonym_mappings IS 'Array of {original, pseudonym, dataType} objects for this run'"}	add_pseudonym_mappings_to_llm_usage
202510010001	{"-- Migration: Create assets table for stored files (images, etc.)\n-- Created: 2025-10-01\n\nBEGIN","CREATE TABLE IF NOT EXISTS public.assets (\n  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),\n  storage text NOT NULL CHECK (storage IN ('local','supabase')),\n  path text NULL,             -- local filesystem path (relative to IMAGE_STORAGE_DIR)\n  bucket text NULL,           -- supabase storage bucket name\n  object_key text NULL,       -- supabase object key\n  mime text NOT NULL,\n  size bigint NULL,\n  width integer NULL,\n  height integer NULL,\n  hash text NULL,\n  user_id uuid NULL,\n  conversation_id uuid NULL,\n  deliverable_version_id uuid NULL REFERENCES public.deliverable_versions(id) ON DELETE SET NULL,\n  created_at timestamptz NOT NULL DEFAULT now(),\n  updated_at timestamptz NOT NULL DEFAULT now()\n)","CREATE INDEX IF NOT EXISTS assets_conversation_idx ON public.assets (conversation_id)","CREATE INDEX IF NOT EXISTS assets_version_idx ON public.assets (deliverable_version_id)","-- ensure updated_at auto-updates on change\nCREATE OR REPLACE FUNCTION public.set_timestamp_updated_at()\nRETURNS TRIGGER AS $$\nBEGIN\n  NEW.updated_at = now();\n  RETURN NEW;\nEND;\n$$ LANGUAGE plpgsql","DROP TRIGGER IF EXISTS set_timestamp_updated_at_assets ON public.assets","CREATE TRIGGER set_timestamp_updated_at_assets\nBEFORE UPDATE ON public.assets\nFOR EACH ROW EXECUTE FUNCTION public.set_timestamp_updated_at()",COMMIT}	assets
202510010002	{"-- Migration: Extend assets for external references\n-- Created: 2025-10-01\n\nBEGIN","-- Allow 'external' storage type\nALTER TABLE public.assets DROP CONSTRAINT IF EXISTS assets_storage_check","ALTER TABLE public.assets ADD CONSTRAINT assets_storage_check CHECK (storage IN ('local','supabase','external'))","-- Add source_url to store original external URLs\nALTER TABLE public.assets ADD COLUMN IF NOT EXISTS source_url text",COMMIT}	assets_external
20251007190433	{"-- Migration: Add n8n workflow - Marketing Swarm - Major Announcement\n-- Source: n8n export\n-- Workflow ID: Q08T7oMX2dZslqV4\n-- Created: 2025-10-08 00:04:33 UTC\n\nINSERT INTO n8n.n8n_workflows (\n  name,\n  active,\n  nodes,\n  connections,\n  settings,\n  created_at,\n  updated_at\n)\nVALUES (\n  'Marketing Swarm - Major Announcement',\n  true,\n  '[{\\"parameters\\":{\\"httpMethod\\":\\"POST\\",\\"path\\":\\"marketing-swarm\\",\\"options\\":{},\\"responseMode\\":\\"responseNode\\"},\\"id\\":\\"webhook\\",\\"name\\":\\"Webhook Trigger\\",\\"type\\":\\"n8n-nodes-base.webhook\\",\\"typeVersion\\":2,\\"position\\":[112,112],\\"webhookId\\":\\"7f338c6b-a9bb-446b-9a1d-702739d89a51\\"}]'::jsonb,\n  '{}'::jsonb,\n  '{}'::jsonb,\n  NOW(),\n  NOW()\n)\nON CONFLICT (name) DO NOTHING","-- Track migration metadata (store as text without uuid cast)\nINSERT INTO n8n.migration_metadata (migration_file, source, workflow_id, notes)\nSELECT\n  '20251007190433_add_n8n_marketing_swarm_major_announcement.sql',\n  'dev',\n  w.id,\n  'Exported from n8n API'\nFROM n8n.n8n_workflows w\nWHERE w.name = 'Marketing Swarm - Major Announcement'\nON CONFLICT (migration_file) DO NOTHING"}	add_n8n_marketing_swarm_major_announcement
202510010004	{"-- Seed OpenAI and Google image function agents under my-org\nBEGIN","DO $$\nDECLARE\n  rec RECORD;\n  payload jsonb;\nBEGIN\n  -- Seed OpenAI image generator\n  SELECT * INTO rec FROM public.agents WHERE organization_slug = 'my-org' AND slug = 'image_openai_generator' LIMIT 1;\n  IF NOT FOUND THEN\n    payload := jsonb_build_object(\n      'metadata', jsonb_build_object(\n        'type','function',\n        'category','image',\n        'displayName','OpenAI Image Generator',\n        'description','Generates images via OpenAI provider'\n      ),\n      'hierarchy', jsonb_build_object(\n        'reports_to','image_orchestrator',\n        'department','images'\n      ),\n      'capabilities', jsonb_build_array('image_generation'),\n      'input_modes', jsonb_build_array('text/plain'),\n      'output_modes', jsonb_build_array('image/png','image/jpeg','application/json'),\n      'configuration', jsonb_build_object(\n        'execution_profile','full_cycle',\n        'execution_capabilities', jsonb_build_object('can_plan', false, 'can_build', true, 'requires_human_gate', false),\n        'function', jsonb_build_object(\n          'language','js',\n          'version','1',\n          'timeout_ms',20000,\n          'code',\n          $CODE$async function handler(input, ctx) {\n  const { prompt, size = '512x512', n = 1, deliverableId = null } = input || {};\n  const out = await ctx.services.images.generate({ prompt, size, n, title: 'OpenAI Images', provider: 'openai', deliverableId });\n  return out;\n}$CODE$\n        )\n      )\n    );\n    INSERT INTO public.agents (\n      organization_slug, slug, display_name, description, agent_type, mode_profile, version, status, yaml, agent_card, context, config\n    ) VALUES (\n      'my-org',\n      'image_openai_generator',\n      'OpenAI Image Generator',\n      'Generates images via OpenAI function handler',\n      'function',\n      'full_cycle',\n      '1.0.0',\n      'active',\n      payload::text,\n      NULL,\n      '{}',\n      (payload - 'metadata')\n    );\n  END IF;\n\n  -- Seed Google image generator (Gemini/Imagen)\n  SELECT * INTO rec FROM public.agents WHERE organization_slug = 'my-org' AND slug = 'image_google_generator' LIMIT 1;\n  IF NOT FOUND THEN\n    payload := jsonb_build_object(\n      'metadata', jsonb_build_object(\n        'type','function',\n        'category','image',\n        'displayName','Google Image Generator',\n        'description','Generates images via Google (Gemini/Imagen) provider'\n      ),\n      'hierarchy', jsonb_build_object(\n        'reports_to','image_orchestrator',\n        'department','images'\n      ),\n      'capabilities', jsonb_build_array('image_generation'),\n      'input_modes', jsonb_build_array('text/plain'),\n      'output_modes', jsonb_build_array('image/png','image/jpeg','application/json'),\n      'configuration', jsonb_build_object(\n        'execution_profile','full_cycle',\n        'execution_capabilities', jsonb_build_object('can_plan', false, 'can_build', true, 'requires_human_gate', false),\n        'function', jsonb_build_object(\n          'language','js',\n          'version','1',\n          'timeout_ms',20000,\n          'code',\n          $CODE$async function handler(input, ctx) {\n  const { prompt, size = '512x512', n = 1, deliverableId = null } = input || {};\n  const out = await ctx.services.images.generate({ prompt, size, n, title: 'Google Images', provider: 'gemini', deliverableId });\n  return out;\n}$CODE$\n        )\n      )\n    );\n    INSERT INTO public.agents (\n      organization_slug, slug, display_name, description, agent_type, mode_profile, version, status, yaml, agent_card, context, config\n    ) VALUES (\n      'my-org',\n      'image_google_generator',\n      'Google Image Generator',\n      'Generates images via Google (Gemini/Imagen) function handler',\n      'function',\n      'full_cycle',\n      '1.0.0',\n      'active',\n      payload::text,\n      NULL,\n      '{}',\n      (payload - 'metadata')\n    );\n  END IF;\nEND$$",COMMIT}	seed_image_function_agent
202510010006	{"-- Seed Image Orchestrator function agent under my-org\nBEGIN","DO $$\nDECLARE\n  rec RECORD;\n  payload jsonb;\nBEGIN\n  SELECT * INTO rec FROM public.agents WHERE organization_slug = 'my-org' AND slug = 'image_orchestrator' LIMIT 1;\n  IF NOT FOUND THEN\n    payload := jsonb_build_object(\n      'metadata', jsonb_build_object(\n        'type','function',\n        'category','image',\n        'displayName','Image Orchestrator',\n        'description','Fans out image generation across multiple providers'\n      ),\n      'hierarchy', jsonb_build_object(\n        'department','images',\n        'team', jsonb_build_array('image_openai_generator','image_google_generator')\n      ),\n      'capabilities', jsonb_build_array('image_generation'),\n      'input_modes', jsonb_build_array('text/plain'),\n      'output_modes', jsonb_build_array('image/png','image/jpeg','application/json'),\n      'configuration', jsonb_build_object(\n        'execution_profile','full_cycle',\n        'execution_capabilities', jsonb_build_object('can_plan', false, 'can_build', true, 'requires_human_gate', false),\n        'function', jsonb_build_object(\n          'language','js',\n          'version','1',\n          'timeout_ms',20000,\n          'code',\n          $CODE$async function handler(input, ctx) {\n  const { prompt, size = '512x512', n = 1, providers = ['openai','gemini'], deliverableId = null } = input || {};\n  let last = null;\n  for (const p of providers) {\n    last = await ctx.services.images.generate({ prompt, size, n, title: 'Image Orchestrator', provider: p, deliverableId });\n  }\n  return last;\n}$CODE$\n        )\n      )\n    );\n\n    INSERT INTO public.agents (\n      organization_slug, slug, display_name, description, agent_type, mode_profile, version, status, yaml, agent_card, context, config\n    ) VALUES (\n      'my-org',\n      'image_orchestrator',\n      'Image Orchestrator',\n      'Fan-out image generation to multiple providers',\n      'function',\n      'full_cycle',\n      '1.0.0',\n      'active',\n      payload::text,\n      NULL,\n      '{}',\n      (payload - 'metadata')\n    );\n  END IF;\nEND$$",COMMIT}	seed_image_orchestrator_agent
202510020101	{"-- Add org/agent scoping and timestamps to pseudonym_dictionaries to match code expectations\nDO $$\nBEGIN\n  IF NOT EXISTS (\n    SELECT 1 FROM information_schema.columns \n    WHERE table_schema = 'public' AND table_name = 'pseudonym_dictionaries' AND column_name = 'organization_slug'\n  ) THEN\n    ALTER TABLE public.pseudonym_dictionaries\n      ADD COLUMN organization_slug text;\n  END IF;\n\n  IF NOT EXISTS (\n    SELECT 1 FROM information_schema.columns \n    WHERE table_schema = 'public' AND table_name = 'pseudonym_dictionaries' AND column_name = 'agent_slug'\n  ) THEN\n    ALTER TABLE public.pseudonym_dictionaries\n      ADD COLUMN agent_slug text;\n  END IF;\n\n  IF NOT EXISTS (\n    SELECT 1 FROM information_schema.columns \n    WHERE table_schema = 'public' AND table_name = 'pseudonym_dictionaries' AND column_name = 'updated_at'\n  ) THEN\n    ALTER TABLE public.pseudonym_dictionaries\n      ADD COLUMN updated_at timestamptz DEFAULT now();\n  END IF;\nEND $$","-- Helpful indexes\nCREATE INDEX IF NOT EXISTS idx_pseudonym_dictionaries_org ON public.pseudonym_dictionaries(organization_slug)","CREATE INDEX IF NOT EXISTS idx_pseudonym_dictionaries_agent ON public.pseudonym_dictionaries(agent_slug)","CREATE INDEX IF NOT EXISTS idx_pseudonym_dictionaries_updated_at ON public.pseudonym_dictionaries(updated_at)"}	pseudonym_dictionaries_org_scope
202510020102	{"-- Add function_code column to agents table\nALTER TABLE public.agents ADD COLUMN IF NOT EXISTS function_code TEXT","-- Add comment to explain the column\nCOMMENT ON COLUMN public.agents.function_code IS 'JavaScript/TypeScript function code for function-type agents'"}	add_function_code_column
202510030001	{"-- Add pseudonym_mappings column to llm_usage table for PII data tracking\n\n-- Add pseudonym_mappings column to llm_usage table if it doesn't exist\nDO $$\nBEGIN\n  IF NOT EXISTS (\n    SELECT 1 FROM information_schema.columns \n    WHERE table_schema = 'public' AND table_name = 'llm_usage' AND column_name = 'pseudonym_mappings'\n  ) THEN\n    ALTER TABLE public.llm_usage\n      ADD COLUMN pseudonym_mappings jsonb;\n  END IF;\nEND $$"}	create_pseudonym_mappings
202510040001	{"-- Migration: Create plans and plan_versions tables\n-- Date: 2025-10-04\n-- Description: Creates plans and plan_versions tables with identical structure to deliverables\n-- Drops old conversation_plan table and replaces with new versioned architecture\n\n-- Drop old conversation_plan and conversation_plans tables if they exist\nDROP TABLE IF EXISTS public.conversation_plan CASCADE","DROP TABLE IF EXISTS public.conversation_plans CASCADE","-- Create plans table (mirrors deliverables structure)\nCREATE TABLE IF NOT EXISTS public.plans (\n  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),\n  conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,\n  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,\n  agent_name TEXT NOT NULL,\n  namespace TEXT NOT NULL,\n  title TEXT NOT NULL,\n  current_version_id UUID,\n  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n\n  -- One plan per conversation constraint\n  CONSTRAINT unique_conversation_plan UNIQUE (conversation_id)\n)","-- Create plan_versions table (mirrors deliverable_versions structure)\nCREATE TABLE IF NOT EXISTS public.plan_versions (\n  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),\n  plan_id UUID NOT NULL REFERENCES public.plans(id) ON DELETE CASCADE,\n  version_number INTEGER NOT NULL,\n  content TEXT NOT NULL,\n  format TEXT NOT NULL DEFAULT 'markdown' CHECK (format IN ('markdown', 'json', 'text')),\n  created_by_type TEXT NOT NULL CHECK (created_by_type IN ('agent', 'user')),\n  created_by_id UUID,\n  task_id UUID,\n  metadata JSONB DEFAULT '{}',\n  is_current_version BOOLEAN DEFAULT false,\n  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n\n  -- Unique constraint on plan_id + version_number\n  CONSTRAINT unique_plan_version UNIQUE (plan_id, version_number)\n)","-- Add foreign key from plans to plan_versions for current_version_id\nDO $$\nBEGIN\n  IF NOT EXISTS (\n    SELECT 1 FROM information_schema.table_constraints \n    WHERE constraint_name = 'fk_plans_current_version' \n    AND table_name = 'plans'\n  ) THEN\n    ALTER TABLE public.plans\n      ADD CONSTRAINT fk_plans_current_version\n      FOREIGN KEY (current_version_id)\n      REFERENCES public.plan_versions(id)\n      ON DELETE SET NULL;\n  END IF;\nEND $$","-- Create indexes for performance\nCREATE INDEX IF NOT EXISTS idx_plans_conversation_id ON public.plans(conversation_id)","CREATE INDEX IF NOT EXISTS idx_plans_user_id ON public.plans(user_id)","CREATE INDEX IF NOT EXISTS idx_plan_versions_plan_id ON public.plan_versions(plan_id)","CREATE INDEX IF NOT EXISTS idx_plan_versions_is_current ON public.plan_versions(is_current_version) WHERE is_current_version = true","CREATE INDEX IF NOT EXISTS idx_plan_versions_task_id ON public.plan_versions(task_id) WHERE task_id IS NOT NULL","-- Create updated_at trigger for plans table\nCREATE OR REPLACE FUNCTION public.update_plans_updated_at()\nRETURNS TRIGGER AS $$\nBEGIN\n  NEW.updated_at = NOW();\n  RETURN NEW;\nEND;\n$$ LANGUAGE plpgsql","DROP TRIGGER IF EXISTS trigger_plans_updated_at ON public.plans","CREATE TRIGGER trigger_plans_updated_at\n  BEFORE UPDATE ON public.plans\n  FOR EACH ROW\n  EXECUTE FUNCTION public.update_plans_updated_at()","-- Add RLS policies (mirroring deliverables)\nALTER TABLE public.plans ENABLE ROW LEVEL SECURITY","ALTER TABLE public.plan_versions ENABLE ROW LEVEL SECURITY","-- Plans policies: users can only access their own plans\nDROP POLICY IF EXISTS plans_select_policy ON public.plans","CREATE POLICY plans_select_policy ON public.plans\n  FOR SELECT\n  USING (auth.uid() = user_id)","DROP POLICY IF EXISTS plans_insert_policy ON public.plans","CREATE POLICY plans_insert_policy ON public.plans\n  FOR INSERT\n  WITH CHECK (auth.uid() = user_id)","DROP POLICY IF EXISTS plans_update_policy ON public.plans","CREATE POLICY plans_update_policy ON public.plans\n  FOR UPDATE\n  USING (auth.uid() = user_id)","DROP POLICY IF EXISTS plans_delete_policy ON public.plans","CREATE POLICY plans_delete_policy ON public.plans\n  FOR DELETE\n  USING (auth.uid() = user_id)","-- Plan versions policies: users can access versions of their plans\nDROP POLICY IF EXISTS plan_versions_select_policy ON public.plan_versions","CREATE POLICY plan_versions_select_policy ON public.plan_versions\n  FOR SELECT\n  USING (\n    EXISTS (\n      SELECT 1 FROM public.plans\n      WHERE public.plans.id = public.plan_versions.plan_id\n      AND public.plans.user_id = auth.uid()\n    )\n  )","DROP POLICY IF EXISTS plan_versions_insert_policy ON public.plan_versions","CREATE POLICY plan_versions_insert_policy ON public.plan_versions\n  FOR INSERT\n  WITH CHECK (\n    EXISTS (\n      SELECT 1 FROM public.plans\n      WHERE public.plans.id = public.plan_versions.plan_id\n      AND public.plans.user_id = auth.uid()\n    )\n  )","DROP POLICY IF EXISTS plan_versions_update_policy ON public.plan_versions","CREATE POLICY plan_versions_update_policy ON public.plan_versions\n  FOR UPDATE\n  USING (\n    EXISTS (\n      SELECT 1 FROM public.plans\n      WHERE public.plans.id = public.plan_versions.plan_id\n      AND public.plans.user_id = auth.uid()\n    )\n  )","DROP POLICY IF EXISTS plan_versions_delete_policy ON public.plan_versions","CREATE POLICY plan_versions_delete_policy ON public.plan_versions\n  FOR DELETE\n  USING (\n    EXISTS (\n      SELECT 1 FROM public.plans\n      WHERE public.plans.id = public.plan_versions.plan_id\n      AND public.plans.user_id = auth.uid()\n    )\n  )","-- Add comments for documentation\nCOMMENT ON TABLE public.plans IS 'Stores plan metadata for agent2agent conversations. One plan per conversation with versioned content.'","COMMENT ON TABLE public.plan_versions IS 'Stores immutable versions of plans. Each edit/refinement creates a new version.'","COMMENT ON COLUMN public.plans.current_version_id IS 'Points to the currently active version of this plan'","COMMENT ON COLUMN public.plan_versions.created_by_type IS 'Whether this version was created by an agent or manually edited by a user'","COMMENT ON COLUMN public.plan_versions.task_id IS 'Reference to the agent task that created this version (if applicable)'","COMMENT ON COLUMN public.plan_versions.metadata IS 'Additional metadata like LLM model used, merge source versions, etc.'"}	create_plans_tables
20251005000001	{"-- Add organization_slug column to conversations table\n-- This properly identifies which organization the conversation belongs to\n-- for database agents (replaces the overloaded agent_type field)\n\nALTER TABLE public.conversations\nADD COLUMN IF NOT EXISTS organization_slug TEXT","-- Create index for efficient lookups by organization\nCREATE INDEX IF NOT EXISTS idx_conversations_organization_slug ON public.conversations(organization_slug)","-- Create index for lookups by organization + agent\nCREATE INDEX IF NOT EXISTS idx_conversations_org_agent ON public.conversations(organization_slug, agent_name)","-- Migrate existing conversations with agent_type that looks like an org slug\n-- (not 'context', 'specialist', 'demo', etc.)\nUPDATE public.conversations\nSET organization_slug = agent_type\nWHERE organization_slug IS NULL\n  AND agent_type NOT IN ('context', 'specialist', 'demo', 'orchestrator')\n  AND agent_type IS NOT NULL\n  AND agent_type != ''","-- Add comment explaining the column\nCOMMENT ON COLUMN public.conversations.organization_slug IS 'Organization slug for database agents (e.g., my-org, acme-corp). NULL for file-based agents.'"}	add_organization_slug_to_conversations
20251005000002	{"-- Add total_cost column to llm_usage table\n-- This stores the sum of input_cost + output_cost for easier querying\n\nALTER TABLE public.llm_usage\nADD COLUMN IF NOT EXISTS total_cost numeric","-- Add comment explaining the column\nCOMMENT ON COLUMN public.llm_usage.total_cost IS 'Total cost (input_cost + output_cost) for this LLM request'","-- Create index for cost analysis queries\nCREATE INDEX IF NOT EXISTS llm_usage_total_cost_idx ON public.llm_usage(total_cost) WHERE total_cost IS NOT NULL"}	add_total_cost_to_llm_usage
20251008114500	{"-- Add total_cost column to llm_usage table if it doesn't exist\nALTER TABLE public.llm_usage ADD COLUMN IF NOT EXISTS total_cost NUMERIC(10, 6)","-- Update total_cost for existing records where it's null\nUPDATE public.llm_usage\nSET total_cost = COALESCE(input_cost, 0) + COALESCE(output_cost, 0)\nWHERE total_cost IS NULL","-- Add comment\nCOMMENT ON COLUMN public.llm_usage.total_cost IS 'Total cost for this LLM request (input_cost + output_cost)'"}	add_total_cost_column
20251005000003	{"-- Seed blog_post_writer agent for testing strict A2A protocol\n-- This agent is used in plan-mode, build-mode, and converse-mode API tests\n\nINSERT INTO public.agents (\n  organization_slug,\n  slug,\n  display_name,\n  description,\n  agent_type,\n  mode_profile,\n  status,\n  yaml\n) VALUES (\n  'my-org',\n  'blog_post_writer',\n  'Blog Post Writer',\n  'Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.',\n  'context',\n  'plan-build-converse',\n  'active',\n  '\nname: blog_post_writer\ndisplay_name: Blog Post Writer\ndescription: Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\nagent_type: context\nmode_profile: plan-build-converse\nversion: \\"1.0\\"\nstatus: active\n\nsystem_prompt: |\n  Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\n\n  When creating a plan for a blog post, structure it with the following sections:\n\n  # Blog Post Plan\n\n  ## Title & Topic\n  - Working title\n  - Target topic/theme\n  - Angle or unique perspective\n\n  ## Audience & Purpose\n  - Target audience description\n  - Primary goal (inform, persuade, entertain, etc.)\n  - Reader takeaway\n\n  ## Content Strategy\n  - Word count target\n  - SEO keywords\n  - Key points to cover\n\n  When building a deliverable, create:\n  - Engaging introduction\n  - Clear section headings\n  - Actionable content\n  - Strong conclusion with CTA\n\n  When conversing, provide helpful suggestions for improving blog content.\n\nmodes:\n  plan:\n    enabled: true\n    actions:\n      - create\n      - read\n      - list\n      - edit\n      - set_current\n      - delete_version\n      - merge_versions\n      - copy_version\n      - delete\n\n  build:\n    enabled: true\n    actions:\n      - create\n      - read\n      - list\n      - edit\n      - rerun\n      - set_current\n      - delete_version\n      - merge_versions\n      - copy_version\n      - delete\n\n  converse:\n    enabled: true\n\nllm_defaults:\n  provider: ollama\n  model: llama3.2:1b\n  temperature: 0.7\n'\n) ON CONFLICT (organization_slug, slug) DO UPDATE SET\n  display_name = EXCLUDED.display_name,\n  description = EXCLUDED.description,\n  yaml = EXCLUDED.yaml,\n  updated_at = now()","-- Add agent_card and context\nUPDATE public.agents\nSET\n  agent_card = jsonb_build_object(\n    'system_prompt', 'Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\n\nWhen creating a plan for a blog post, structure it with the following sections:\n\n# Blog Post Plan\n\n## Title & Topic\n- Working title\n- Target topic/theme\n- Angle or unique perspective\n\n## Audience & Purpose\n- Target audience description\n- Primary goal (inform, persuade, entertain, etc.)\n- Reader takeaway\n\n## Content Strategy\n- Word count target\n- SEO keywords\n- Key points to cover\n\nWhen building a deliverable, create:\n- Engaging introduction\n- Clear section headings\n- Actionable content\n- Strong conclusion with CTA\n\nWhen conversing, provide helpful suggestions for improving blog content.'\n  ),\n  context = jsonb_build_object(\n    'plan', jsonb_build_object(\n      'template', 'Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\n\nWhen creating a plan for a blog post, structure it with the following sections:\n\n# Blog Post Plan\n\n## Title & Topic\n- Working title\n- Target topic/theme\n- Angle or unique perspective\n\n## Audience & Purpose\n- Target audience description\n- Primary goal (inform, persuade, entertain, etc.)\n- Reader takeaway\n\n## Content Strategy\n- Word count target\n- SEO keywords\n- Key points to cover\n\nWhen building a deliverable, create:\n- Engaging introduction\n- Clear section headings\n- Actionable content\n- Strong conclusion with CTA\n\nWhen conversing, provide helpful suggestions for improving blog content.'\n    ),\n    'build', jsonb_build_object(\n      'template', 'Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\n\nWhen creating a plan for a blog post, structure it with the following sections:\n\n# Blog Post Plan\n\n## Title & Topic\n- Working title\n- Target topic/theme\n- Angle or unique perspective\n\n## Audience & Purpose\n- Target audience description\n- Primary goal (inform, persuade, entertain, etc.)\n- Reader takeaway\n\n## Content Strategy\n- Word count target\n- SEO keywords\n- Key points to cover\n\nWhen building a deliverable, create:\n- Engaging introduction\n- Clear section headings\n- Actionable content\n- Strong conclusion with CTA\n\nWhen conversing, provide helpful suggestions for improving blog content.'\n    ),\n    'converse', jsonb_build_object(\n      'template', 'Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\n\nWhen creating a plan for a blog post, structure it with the following sections:\n\n# Blog Post Plan\n\n## Title & Topic\n- Working title\n- Target topic/theme\n- Angle or unique perspective\n\n## Audience & Purpose\n- Target audience description\n- Primary goal (inform, persuade, entertain, etc.)\n- Reader takeaway\n\n## Content Strategy\n- Word count target\n- SEO keywords\n- Key points to cover\n\nWhen building a deliverable, create:\n- Engaging introduction\n- Clear section headings\n- Actionable content\n- Strong conclusion with CTA\n\nWhen conversing, provide helpful suggestions for improving blog content.'\n    )\n  ),\n  config = jsonb_build_object(\n    'llm_defaults', jsonb_build_object(\n      'provider', 'ollama',\n      'model', 'llama3.2:1b',\n      'temperature', 0.7\n    )\n  )\nWHERE slug = 'blog_post_writer' AND organization_slug = 'my-org'"}	seed_blog_post_writer_agent
202510060001	{"-- Update conversations_with_stats view to include organization_slug\n-- Because CREATE OR REPLACE VIEW cannot change the column list/order,\n-- we drop and recreate the view, then re-grant permissions.\n\n-- Ensure required columns exist on conversations\nALTER TABLE public.conversations\n  ADD COLUMN IF NOT EXISTS ended_at timestamptz,\n  ADD COLUMN IF NOT EXISTS started_at timestamptz,\n  ADD COLUMN IF NOT EXISTS last_active_at timestamptz,\n  ADD COLUMN IF NOT EXISTS metadata jsonb DEFAULT '{}'::jsonb,\n  ADD COLUMN IF NOT EXISTS organization_slug text","DROP VIEW IF EXISTS public.conversations_with_stats","CREATE VIEW public.conversations_with_stats AS\nSELECT\n  c.id,\n  c.user_id,\n  c.agent_name,\n  c.agent_type,\n  c.ended_at,\n  c.started_at,\n  c.last_active_at,\n  c.metadata,\n  c.created_at,\n  c.updated_at,\n  COALESCE(task_stats.task_count, 0)::bigint AS task_count,\n  COALESCE(task_stats.completed_tasks, 0)::bigint AS completed_tasks,\n  COALESCE(task_stats.failed_tasks, 0)::bigint AS failed_tasks,\n  COALESCE(task_stats.active_tasks, 0)::bigint AS active_tasks,\n  c.organization_slug\nFROM public.conversations c\nLEFT JOIN (\n  SELECT\n    t.conversation_id,\n    COUNT(*) AS task_count,\n    COUNT(CASE WHEN t.status::text = 'completed' THEN 1 END) AS completed_tasks,\n    COUNT(CASE WHEN t.status::text = 'failed' THEN 1 END) AS failed_tasks,\n    COUNT(CASE WHEN t.status::text IN ('pending','running') THEN 1 END) AS active_tasks\n  FROM public.tasks t\n  GROUP BY t.conversation_id\n) task_stats ON c.id = task_stats.conversation_id","-- Re-grant permissions (Supabase roles)\nGRANT SELECT ON public.conversations_with_stats TO anon","GRANT SELECT ON public.conversations_with_stats TO authenticated","GRANT SELECT ON public.conversations_with_stats TO service_role"}	update_conversations_with_stats_add_org_slug
20251007124515	{"-- Create n8n workflows table for sync system\n-- This stores workflow definitions that can be synced between environments\nCREATE SCHEMA IF NOT EXISTS n8n","CREATE TABLE IF NOT EXISTS n8n.n8n_workflows (\n  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),\n  name TEXT NOT NULL,\n  active BOOLEAN DEFAULT true,\n  nodes JSONB NOT NULL DEFAULT '[]'::jsonb,\n  connections JSONB NOT NULL DEFAULT '{}'::jsonb,\n  settings JSONB NOT NULL DEFAULT '{}'::jsonb,\n  created_at TIMESTAMPTZ DEFAULT NOW(),\n  updated_at TIMESTAMPTZ DEFAULT NOW(),\n  UNIQUE(name)\n)","-- Create migration metadata table for n8n workflow sync\n-- Track migration sources and workflow associations\nCREATE TABLE IF NOT EXISTS n8n.migration_metadata (\n  migration_file TEXT PRIMARY KEY,\n  source TEXT NOT NULL CHECK (source IN ('dev', 'prod', 'staging')),\n  workflow_id UUID REFERENCES n8n.n8n_workflows(id),\n  created_at TIMESTAMPTZ DEFAULT NOW(),\n  synced_at TIMESTAMPTZ DEFAULT NOW(),\n  notes TEXT\n)","-- Indexes for performance\nCREATE INDEX IF NOT EXISTS idx_n8n_workflows_name ON n8n.n8n_workflows(name)","CREATE INDEX IF NOT EXISTS idx_n8n_workflows_active ON n8n.n8n_workflows(active)","CREATE INDEX IF NOT EXISTS idx_n8n_workflows_updated ON n8n.n8n_workflows(updated_at)","CREATE INDEX IF NOT EXISTS idx_migration_metadata_source ON n8n.migration_metadata(source)","CREATE INDEX IF NOT EXISTS idx_migration_metadata_workflow ON n8n.migration_metadata(workflow_id)","CREATE INDEX IF NOT EXISTS idx_migration_metadata_synced ON n8n.migration_metadata(synced_at)","-- Comments for documentation\nCOMMENT ON TABLE n8n.n8n_workflows IS 'Stores n8n workflow definitions for sync between environments'","COMMENT ON TABLE n8n.migration_metadata IS 'Tracks the source and metadata of n8n workflow migrations'","COMMENT ON COLUMN n8n.migration_metadata.source IS 'Origin of the migration: dev, prod, or staging'","COMMENT ON COLUMN n8n.migration_metadata.workflow_id IS 'References the n8n workflow this migration manages'"}	create_migration_metadata
20251007124941	{"-- Create n8n schema for workflow automation\nCREATE SCHEMA IF NOT EXISTS n8n","-- Grant necessary permissions\nGRANT USAGE ON SCHEMA n8n TO postgres","GRANT CREATE ON SCHEMA n8n TO postgres","GRANT ALL ON ALL TABLES IN SCHEMA n8n TO postgres","GRANT ALL ON ALL SEQUENCES IN SCHEMA n8n TO postgres","-- Set default privileges for future objects\nALTER DEFAULT PRIVILEGES IN SCHEMA n8n GRANT ALL ON TABLES TO postgres","ALTER DEFAULT PRIVILEGES IN SCHEMA n8n GRANT ALL ON SEQUENCES TO postgres","-- Move n8n_workflows table to n8n schema if it exists in public\nDO $$\nBEGIN\n  IF EXISTS (\n    SELECT 1 FROM information_schema.tables\n    WHERE table_schema = 'public' AND table_name = 'n8n_workflows'\n  ) THEN\n    EXECUTE 'ALTER TABLE public.n8n_workflows SET SCHEMA n8n';\n  END IF;\nEND $$","-- Update foreign key constraint to reference the moved table\nDO $$\nBEGIN\n  IF EXISTS (\n    SELECT 1 FROM information_schema.tables\n    WHERE table_schema = 'public' AND table_name = 'migration_metadata'\n  ) THEN\n    ALTER TABLE public.migration_metadata \n    DROP CONSTRAINT IF EXISTS migration_metadata_workflow_id_fkey;\n\n    ALTER TABLE public.migration_metadata \n    ADD CONSTRAINT migration_metadata_workflow_id_fkey \n    FOREIGN KEY (workflow_id) REFERENCES n8n.n8n_workflows(id);\n  END IF;\nEND $$","-- Add comment explaining the schema organization\nCOMMENT ON SCHEMA n8n IS 'Schema for n8n workflow automation tables and data'","COMMENT ON TABLE n8n.n8n_workflows IS 'Stores n8n workflow definitions for sync between environments (moved from public schema)'","DO $$\nBEGIN\n  IF EXISTS (\n    SELECT 1 FROM information_schema.tables\n    WHERE table_schema = 'public' AND table_name = 'migration_metadata'\n  ) THEN\n    EXECUTE 'COMMENT ON TABLE public.migration_metadata IS ''Tracks n8n workflow migration sources and metadata (stays in public for API access)''';\n  END IF;\nEND $$"}	create_n8n_schema_and_move_tables
20251007125030	{"-- Move migration_metadata table to n8n schema for better organization\n-- This table is specifically for n8n workflow migration tracking\n\n-- Move the table to n8n schema if it exists in public\nDO $$\nBEGIN\n  IF EXISTS (\n    SELECT 1 FROM information_schema.tables\n    WHERE table_schema = 'public' AND table_name = 'migration_metadata'\n  ) THEN\n    EXECUTE 'ALTER TABLE public.migration_metadata SET SCHEMA n8n';\n  END IF;\nEND $$","-- Update the comment to reflect the new location\nCOMMENT ON TABLE n8n.migration_metadata IS 'Tracks n8n workflow migration sources and metadata (moved to n8n schema for better organization)'"}	move_migration_metadata_to_n8n_schema
202510120001	{BEGIN,"-- Drop legacy projects tables if exist\nDROP TABLE IF EXISTS public.project_steps CASCADE","DROP TABLE IF EXISTS public.projects CASCADE","-- Drop legacy conversation_plans if present (we're moving to plans)\nDROP TABLE IF EXISTS public.conversation_plans CASCADE","-- Create plans table\nCREATE TABLE IF NOT EXISTS public.plans (\n  id uuid DEFAULT extensions.uuid_generate_v4() PRIMARY KEY,\n  conversation_id uuid REFERENCES public.conversations(id) ON DELETE SET NULL,\n  organization_slug text,\n  agent_slug text,\n  title text,\n  status text DEFAULT 'draft',\n  summary text,\n  plan_json jsonb NOT NULL,\n  created_by uuid,\n  approved_by uuid,\n  created_at timestamptz DEFAULT now(),\n  updated_at timestamptz DEFAULT now()\n)","-- Ensure plan_json exists if table was created previously without it\nALTER TABLE public.plans\n  ADD COLUMN IF NOT EXISTS plan_json jsonb NOT NULL DEFAULT '{}'::jsonb","ALTER TABLE public.plans\n  ADD COLUMN IF NOT EXISTS organization_slug text","COMMENT ON TABLE public.plans IS 'Structured execution plans, replacing conversation_plans.'","COMMENT ON COLUMN public.plans.plan_json IS 'Plan structure with phases, steps, dependencies, checkpoints.'","-- Create plan_deliverables table\nCREATE TABLE IF NOT EXISTS public.plan_deliverables (\n  id uuid DEFAULT extensions.uuid_generate_v4() PRIMARY KEY,\n  plan_id uuid NOT NULL REFERENCES public.plans(id) ON DELETE CASCADE,\n  deliverable_id uuid REFERENCES public.deliverables(id) ON DELETE SET NULL,\n  label text,\n  notes text,\n  metadata jsonb DEFAULT '{}'::jsonb,\n  created_at timestamptz DEFAULT now(),\n  updated_at timestamptz DEFAULT now()\n)","-- Indexes\nCREATE INDEX IF NOT EXISTS idx_plans_conversation ON public.plans(conversation_id)","CREATE INDEX IF NOT EXISTS idx_plans_org_slug ON public.plans(organization_slug)","CREATE INDEX IF NOT EXISTS idx_plan_deliverables_plan ON public.plan_deliverables(plan_id)",COMMIT}	drop_projects_and_conversation_plans_add_plans
202510120010	{BEGIN,"-- Drop legacy projects & steps\nDROP TABLE IF EXISTS public.project_steps CASCADE","DROP TABLE IF EXISTS public.projects CASCADE","-- Drop legacy jokes tables\nDROP TABLE IF EXISTS public.jokes_analysis CASCADE","DROP TABLE IF EXISTS public.jokes CASCADE",COMMIT}	drop_legacy_projects_and_jokes
202510120020	{BEGIN,"-- Drop jokes-related tables\nDROP TABLE IF EXISTS public.jokes_analysis CASCADE","DROP TABLE IF EXISTS public.jokes CASCADE","-- Drop planned deliverables if present (we use deliverables only)\nDROP TABLE IF EXISTS public.plan_deliverables CASCADE","-- Drop legacy projects tables\nDROP TABLE IF EXISTS public.project_steps CASCADE","DROP TABLE IF EXISTS public.projects CASCADE",COMMIT}	remove_legacy_jokes_and_planned_deliverables
202510120025	{BEGIN,"DROP TABLE IF EXISTS public.jokes_agent CASCADE","DROP TABLE IF EXISTS public.jokes_analytics CASCADE",COMMIT}	drop_jokes_agent_and_jokes_analytics
\.


--
-- TOC entry 5024 (class 0 OID 19057)
-- Dependencies: 316
-- Data for Name: seed_files; Type: TABLE DATA; Schema: supabase_migrations; Owner: postgres
--

COPY supabase_migrations.seed_files (path, hash) FROM stdin;
supabase/seed.sql	075b772b0fb4f6928be4eb0670df13777e3e03eb9035484affeda4efc8568045
\.


--
-- TOC entry 3929 (class 0 OID 16650)
-- Dependencies: 245
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5358 (class 0 OID 0)
-- Dependencies: 235
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 3, true);


--
-- TOC entry 5359 (class 0 OID 0)
-- Dependencies: 337
-- Name: auth_provider_sync_history_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.auth_provider_sync_history_id_seq', 1, false);


--
-- TOC entry 5360 (class 0 OID 0)
-- Dependencies: 349
-- Name: execution_annotations_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.execution_annotations_id_seq', 1, false);


--
-- TOC entry 5361 (class 0 OID 0)
-- Dependencies: 324
-- Name: execution_entity_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.execution_entity_id_seq', 1, false);


--
-- TOC entry 5362 (class 0 OID 0)
-- Dependencies: 346
-- Name: execution_metadata_temp_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.execution_metadata_temp_id_seq', 1, false);


--
-- TOC entry 5363 (class 0 OID 0)
-- Dependencies: 361
-- Name: insights_by_period_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.insights_by_period_id_seq', 1, false);


--
-- TOC entry 5364 (class 0 OID 0)
-- Dependencies: 357
-- Name: insights_metadata_metaId_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n."insights_metadata_metaId_seq"', 1, false);


--
-- TOC entry 5365 (class 0 OID 0)
-- Dependencies: 359
-- Name: insights_raw_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.insights_raw_id_seq', 1, false);


--
-- TOC entry 5366 (class 0 OID 0)
-- Dependencies: 321
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.migrations_id_seq', 99, true);


--
-- TOC entry 5367 (class 0 OID 0)
-- Dependencies: 261
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_admin
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- TOC entry 5368 (class 0 OID 0)
-- Dependencies: 254
-- Name: hooks_id_seq; Type: SEQUENCE SET; Schema: supabase_functions; Owner: supabase_functions_admin
--

SELECT pg_catalog.setval('supabase_functions.hooks_id_seq', 1, false);


--
-- TOC entry 4329 (class 2606 OID 17385)
-- Name: extensions extensions_pkey; Type: CONSTRAINT; Schema: _realtime; Owner: supabase_admin
--

ALTER TABLE ONLY _realtime.extensions
    ADD CONSTRAINT extensions_pkey PRIMARY KEY (id);


--
-- TOC entry 4324 (class 2606 OID 17369)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: _realtime; Owner: supabase_admin
--

ALTER TABLE ONLY _realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4327 (class 2606 OID 17377)
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: _realtime; Owner: supabase_admin
--

ALTER TABLE ONLY _realtime.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- TOC entry 4384 (class 2606 OID 17947)
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- TOC entry 4295 (class 2606 OID 16494)
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- TOC entry 4407 (class 2606 OID 18053)
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- TOC entry 4363 (class 2606 OID 18071)
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- TOC entry 4365 (class 2606 OID 18081)
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- TOC entry 4293 (class 2606 OID 16487)
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- TOC entry 4386 (class 2606 OID 17940)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- TOC entry 4382 (class 2606 OID 17928)
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- TOC entry 4374 (class 2606 OID 18121)
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- TOC entry 4376 (class 2606 OID 17915)
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- TOC entry 4417 (class 2606 OID 18142)
-- Name: oauth_clients oauth_clients_client_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_client_id_key UNIQUE (client_id);


--
-- TOC entry 4420 (class 2606 OID 18140)
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- TOC entry 4411 (class 2606 OID 18106)
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 4287 (class 2606 OID 16477)
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 4290 (class 2606 OID 17857)
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- TOC entry 4396 (class 2606 OID 17987)
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- TOC entry 4398 (class 2606 OID 17985)
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 4403 (class 2606 OID 18001)
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- TOC entry 4298 (class 2606 OID 16500)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4369 (class 2606 OID 17878)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 4393 (class 2606 OID 17968)
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- TOC entry 4388 (class 2606 OID 17959)
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 4280 (class 2606 OID 18041)
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- TOC entry 4282 (class 2606 OID 16464)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4654 (class 2606 OID 20362)
-- Name: test_run PK_011c050f566e9db509a0fadb9b9; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.test_run
    ADD CONSTRAINT "PK_011c050f566e9db509a0fadb9b9" PRIMARY KEY (id);


--
-- TOC entry 4585 (class 2606 OID 19520)
-- Name: installed_packages PK_08cc9197c39b028c1e9beca225940576fd1a5804; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.installed_packages
    ADD CONSTRAINT "PK_08cc9197c39b028c1e9beca225940576fd1a5804" PRIMARY KEY ("packageName");


--
-- TOC entry 4620 (class 2606 OID 20042)
-- Name: execution_metadata PK_17a0b6284f8d626aae88e1c16e4; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_metadata
    ADD CONSTRAINT "PK_17a0b6284f8d626aae88e1c16e4" PRIMARY KEY (id);


--
-- TOC entry 4611 (class 2606 OID 19969)
-- Name: project_relation PK_1caaa312a5d7184a003be0f0cb6; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.project_relation
    ADD CONSTRAINT "PK_1caaa312a5d7184a003be0f0cb6" PRIMARY KEY ("projectId", "userId");


--
-- TOC entry 4643 (class 2606 OID 20250)
-- Name: folder_tag PK_27e4e00852f6b06a925a4d83a3e; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.folder_tag
    ADD CONSTRAINT "PK_27e4e00852f6b06a925a4d83a3e" PRIMARY KEY ("folderId", "tagId");


--
-- TOC entry 4661 (class 2606 OID 20405)
-- Name: role PK_35c9b140caaf6da09cfabb0d675; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.role
    ADD CONSTRAINT "PK_35c9b140caaf6da09cfabb0d675" PRIMARY KEY (slug);


--
-- TOC entry 4607 (class 2606 OID 19960)
-- Name: project PK_4d68b1358bb5b766d3e78f32f57; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.project
    ADD CONSTRAINT "PK_4d68b1358bb5b766d3e78f32f57" PRIMARY KEY (id);


--
-- TOC entry 4622 (class 2606 OID 20055)
-- Name: invalid_auth_token PK_5779069b7235b256d91f7af1a15; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.invalid_auth_token
    ADD CONSTRAINT "PK_5779069b7235b256d91f7af1a15" PRIMARY KEY (token);


--
-- TOC entry 4617 (class 2606 OID 20023)
-- Name: shared_workflow PK_5ba87620386b847201c9531c58f; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.shared_workflow
    ADD CONSTRAINT "PK_5ba87620386b847201c9531c58f" PRIMARY KEY ("workflowId", "projectId");


--
-- TOC entry 4641 (class 2606 OID 20234)
-- Name: folder PK_6278a41a706740c94c02e288df8; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.folder
    ADD CONSTRAINT "PK_6278a41a706740c94c02e288df8" PRIMARY KEY (id);


--
-- TOC entry 4670 (class 2606 OID 20482)
-- Name: data_table_column PK_673cb121ee4a8a5e27850c72c51; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.data_table_column
    ADD CONSTRAINT "PK_673cb121ee4a8a5e27850c72c51" PRIMARY KEY (id);


--
-- TOC entry 4628 (class 2606 OID 20082)
-- Name: annotation_tag_entity PK_69dfa041592c30bbc0d4b84aa00; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.annotation_tag_entity
    ADD CONSTRAINT "PK_69dfa041592c30bbc0d4b84aa00" PRIMARY KEY (id);


--
-- TOC entry 4625 (class 2606 OID 20069)
-- Name: execution_annotations PK_7afcf93ffa20c4252869a7c6a23; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_annotations
    ADD CONSTRAINT "PK_7afcf93ffa20c4252869a7c6a23" PRIMARY KEY (id);


--
-- TOC entry 4552 (class 2606 OID 19317)
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- TOC entry 4587 (class 2606 OID 19528)
-- Name: installed_nodes PK_8ebd28194e4f792f96b5933423fc439df97d9689; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.installed_nodes
    ADD CONSTRAINT "PK_8ebd28194e4f792f96b5933423fc439df97d9689" PRIMARY KEY (name);


--
-- TOC entry 4615 (class 2606 OID 19997)
-- Name: shared_credentials PK_8ef3a59796a228913f251779cff; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.shared_credentials
    ADD CONSTRAINT "PK_8ef3a59796a228913f251779cff" PRIMARY KEY ("credentialsId", "projectId");


--
-- TOC entry 4657 (class 2606 OID 20377)
-- Name: test_case_execution PK_90c121f77a78a6580e94b794bce; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.test_case_execution
    ADD CONSTRAINT "PK_90c121f77a78a6580e94b794bce" PRIMARY KEY (id);


--
-- TOC entry 4636 (class 2606 OID 20109)
-- Name: user_api_keys PK_978fa5caa3468f463dac9d92e69; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.user_api_keys
    ADD CONSTRAINT "PK_978fa5caa3468f463dac9d92e69" PRIMARY KEY (id);


--
-- TOC entry 4632 (class 2606 OID 20088)
-- Name: execution_annotation_tags PK_979ec03d31294cca484be65d11f; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_annotation_tags
    ADD CONSTRAINT "PK_979ec03d31294cca484be65d11f" PRIMARY KEY ("annotationId", "tagId");


--
-- TOC entry 4568 (class 2606 OID 19353)
-- Name: webhook_entity PK_b21ace2e13596ccd87dc9bf4ea6; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.webhook_entity
    ADD CONSTRAINT "PK_b21ace2e13596ccd87dc9bf4ea6" PRIMARY KEY ("webhookPath", method);


--
-- TOC entry 4651 (class 2606 OID 20347)
-- Name: insights_by_period PK_b606942249b90cc39b0265f0575; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_by_period
    ADD CONSTRAINT "PK_b606942249b90cc39b0265f0575" PRIMARY KEY (id);


--
-- TOC entry 4605 (class 2606 OID 19733)
-- Name: workflow_history PK_b6572dd6173e4cd06fe79937b58; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflow_history
    ADD CONSTRAINT "PK_b6572dd6173e4cd06fe79937b58" PRIMARY KEY ("versionId");


--
-- TOC entry 4659 (class 2606 OID 20397)
-- Name: scope PK_bfc45df0481abd7f355d6187da1; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.scope
    ADD CONSTRAINT "PK_bfc45df0481abd7f355d6187da1" PRIMARY KEY (slug);


--
-- TOC entry 4638 (class 2606 OID 20125)
-- Name: processed_data PK_ca04b9d8dc72de268fe07a65773; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.processed_data
    ADD CONSTRAINT "PK_ca04b9d8dc72de268fe07a65773" PRIMARY KEY ("workflowId", context);


--
-- TOC entry 4583 (class 2606 OID 19513)
-- Name: settings PK_dc0fe14e6d9943f268e7b119f69ab8bd; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.settings
    ADD CONSTRAINT "PK_dc0fe14e6d9943f268e7b119f69ab8bd" PRIMARY KEY (key);


--
-- TOC entry 4666 (class 2606 OID 20468)
-- Name: data_table PK_e226d0001b9e6097cbfe70617cb; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.data_table
    ADD CONSTRAINT "PK_e226d0001b9e6097cbfe70617cb" PRIMARY KEY (id);


--
-- TOC entry 4578 (class 2606 OID 19452)
-- Name: user PK_ea8f538c94b6e352418254ed6474a81f; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n."user"
    ADD CONSTRAINT "PK_ea8f538c94b6e352418254ed6474a81f" PRIMARY KEY (id);


--
-- TOC entry 4648 (class 2606 OID 20335)
-- Name: insights_raw PK_ec15125755151e3a7e00e00014f; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_raw
    ADD CONSTRAINT "PK_ec15125755151e3a7e00e00014f" PRIMARY KEY (id);


--
-- TOC entry 4646 (class 2606 OID 20317)
-- Name: insights_metadata PK_f448a94c35218b6208ce20cf5a1; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_metadata
    ADD CONSTRAINT "PK_f448a94c35218b6208ce20cf5a1" PRIMARY KEY ("metaId");


--
-- TOC entry 4664 (class 2606 OID 20410)
-- Name: role_scope PK_role_scope; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.role_scope
    ADD CONSTRAINT "PK_role_scope" PRIMARY KEY ("roleSlug", "scopeSlug");


--
-- TOC entry 4672 (class 2606 OID 20484)
-- Name: data_table_column UQ_8082ec4890f892f0bc77473a123; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.data_table_column
    ADD CONSTRAINT "UQ_8082ec4890f892f0bc77473a123" UNIQUE ("dataTableId", name);


--
-- TOC entry 4668 (class 2606 OID 20470)
-- Name: data_table UQ_b23096ef747281ac944d28e8b0d; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.data_table
    ADD CONSTRAINT "UQ_b23096ef747281ac944d28e8b0d" UNIQUE ("projectId", name);


--
-- TOC entry 4580 (class 2606 OID 19454)
-- Name: user UQ_e12875dfb3b1d92d7d7c5377e2; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n."user"
    ADD CONSTRAINT "UQ_e12875dfb3b1d92d7d7c5377e2" UNIQUE (email);


--
-- TOC entry 4593 (class 2606 OID 19609)
-- Name: auth_identity auth_identity_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.auth_identity
    ADD CONSTRAINT auth_identity_pkey PRIMARY KEY ("providerId", "providerType");


--
-- TOC entry 4595 (class 2606 OID 19625)
-- Name: auth_provider_sync_history auth_provider_sync_history_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.auth_provider_sync_history
    ADD CONSTRAINT auth_provider_sync_history_pkey PRIMARY KEY (id);


--
-- TOC entry 4554 (class 2606 OID 19707)
-- Name: credentials_entity credentials_entity_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.credentials_entity
    ADD CONSTRAINT credentials_entity_pkey PRIMARY KEY (id);


--
-- TOC entry 4591 (class 2606 OID 19580)
-- Name: event_destinations event_destinations_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.event_destinations
    ADD CONSTRAINT event_destinations_pkey PRIMARY KEY (id);


--
-- TOC entry 4602 (class 2606 OID 19723)
-- Name: execution_data execution_data_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_data
    ADD CONSTRAINT execution_data_pkey PRIMARY KEY ("executionId");


--
-- TOC entry 4537 (class 2606 OID 19018)
-- Name: migration_metadata migration_metadata_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.migration_metadata
    ADD CONSTRAINT migration_metadata_pkey PRIMARY KEY (migration_file);


--
-- TOC entry 4530 (class 2606 OID 19008)
-- Name: n8n_workflows n8n_workflows_name_key; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.n8n_workflows
    ADD CONSTRAINT n8n_workflows_name_key UNIQUE (name);


--
-- TOC entry 4532 (class 2606 OID 19006)
-- Name: n8n_workflows n8n_workflows_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.n8n_workflows
    ADD CONSTRAINT n8n_workflows_pkey PRIMARY KEY (id);


--
-- TOC entry 4562 (class 2606 OID 19336)
-- Name: execution_entity pk_e3e63bbf986767844bbe1166d4e; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_entity
    ADD CONSTRAINT pk_e3e63bbf986767844bbe1166d4e PRIMARY KEY (id);


--
-- TOC entry 4589 (class 2606 OID 19676)
-- Name: workflow_statistics pk_workflow_statistics; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflow_statistics
    ADD CONSTRAINT pk_workflow_statistics PRIMARY KEY ("workflowId", name);


--
-- TOC entry 4576 (class 2606 OID 19655)
-- Name: workflows_tags pk_workflows_tags; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflows_tags
    ADD CONSTRAINT pk_workflows_tags PRIMARY KEY ("workflowId", "tagId");


--
-- TOC entry 4573 (class 2606 OID 19696)
-- Name: tag_entity tag_entity_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.tag_entity
    ADD CONSTRAINT tag_entity_pkey PRIMARY KEY (id);


--
-- TOC entry 4598 (class 2606 OID 19635)
-- Name: variables variables_key_key; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.variables
    ADD CONSTRAINT variables_key_key UNIQUE (key);


--
-- TOC entry 4600 (class 2606 OID 19710)
-- Name: variables variables_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.variables
    ADD CONSTRAINT variables_pkey PRIMARY KEY (id);


--
-- TOC entry 4566 (class 2606 OID 19694)
-- Name: workflow_entity workflow_entity_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflow_entity
    ADD CONSTRAINT workflow_entity_pkey PRIMARY KEY (id);


--
-- TOC entry 4428 (class 2606 OID 18493)
-- Name: conversations agent_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT agent_conversations_pkey PRIMARY KEY (id);


--
-- TOC entry 4495 (class 2606 OID 18833)
-- Name: agent_orchestrations agent_orchestrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_orchestrations
    ADD CONSTRAINT agent_orchestrations_pkey PRIMARY KEY (id);


--
-- TOC entry 4497 (class 2606 OID 18835)
-- Name: agent_orchestrations agent_orchestrations_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_orchestrations
    ADD CONSTRAINT agent_orchestrations_slug_unique UNIQUE (organization_slug, agent_slug, slug);


--
-- TOC entry 4484 (class 2606 OID 18788)
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- TOC entry 4486 (class 2606 OID 18790)
-- Name: agents agents_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_slug_unique UNIQUE (organization_slug, slug);


--
-- TOC entry 4509 (class 2606 OID 18906)
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- TOC entry 4424 (class 2606 OID 18507)
-- Name: cidafm_commands cidafm_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cidafm_commands
    ADD CONSTRAINT cidafm_commands_pkey PRIMARY KEY (id);


--
-- TOC entry 4426 (class 2606 OID 18509)
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- TOC entry 4436 (class 2606 OID 18511)
-- Name: deliverable_versions deliverable_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverable_versions
    ADD CONSTRAINT deliverable_versions_pkey PRIMARY KEY (id);


--
-- TOC entry 4438 (class 2606 OID 18513)
-- Name: deliverables deliverables_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverables
    ADD CONSTRAINT deliverables_pkey PRIMARY KEY (id);


--
-- TOC entry 4440 (class 2606 OID 18515)
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- TOC entry 4505 (class 2606 OID 18883)
-- Name: human_approvals human_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.human_approvals
    ADD CONSTRAINT human_approvals_pkey PRIMARY KEY (id);


--
-- TOC entry 4442 (class 2606 OID 18517)
-- Name: kpi_data kpi_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kpi_data
    ADD CONSTRAINT kpi_data_pkey PRIMARY KEY (id);


--
-- TOC entry 4444 (class 2606 OID 18519)
-- Name: kpi_goals kpi_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kpi_goals
    ADD CONSTRAINT kpi_goals_pkey PRIMARY KEY (id);


--
-- TOC entry 4446 (class 2606 OID 18521)
-- Name: kpi_metrics kpi_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kpi_metrics
    ADD CONSTRAINT kpi_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 4448 (class 2606 OID 18523)
-- Name: llm_models llm_models_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_pkey PRIMARY KEY (provider_name, model_name);


--
-- TOC entry 4450 (class 2606 OID 18525)
-- Name: llm_providers llm_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_providers
    ADD CONSTRAINT llm_providers_pkey PRIMARY KEY (name);


--
-- TOC entry 4454 (class 2606 OID 18527)
-- Name: llm_usage llm_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_usage
    ADD CONSTRAINT llm_usage_pkey PRIMARY KEY (id);


--
-- TOC entry 4458 (class 2606 OID 18529)
-- Name: llm_usage llm_usage_run_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_usage
    ADD CONSTRAINT llm_usage_run_id_key UNIQUE (run_id);


--
-- TOC entry 4502 (class 2606 OID 18850)
-- Name: orchestration_runs orchestration_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orchestration_runs
    ADD CONSTRAINT orchestration_runs_pkey PRIMARY KEY (id);


--
-- TOC entry 4491 (class 2606 OID 18803)
-- Name: organization_credentials organization_credentials_alias_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_credentials
    ADD CONSTRAINT organization_credentials_alias_unique UNIQUE (organization_slug, alias);


--
-- TOC entry 4493 (class 2606 OID 18801)
-- Name: organization_credentials organization_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_credentials
    ADD CONSTRAINT organization_credentials_pkey PRIMARY KEY (id);


--
-- TOC entry 4523 (class 2606 OID 18955)
-- Name: plan_versions plan_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_versions
    ADD CONSTRAINT plan_versions_pkey PRIMARY KEY (id);


--
-- TOC entry 4516 (class 2606 OID 18929)
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- TOC entry 4466 (class 2606 OID 18535)
-- Name: pseudonym_dictionaries pseudonym_dictionaries_original_value_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pseudonym_dictionaries
    ADD CONSTRAINT pseudonym_dictionaries_original_value_key UNIQUE (original_value);


--
-- TOC entry 4468 (class 2606 OID 18537)
-- Name: pseudonym_dictionaries pseudonym_dictionaries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pseudonym_dictionaries
    ADD CONSTRAINT pseudonym_dictionaries_pkey PRIMARY KEY (id);


--
-- TOC entry 4471 (class 2606 OID 18539)
-- Name: redaction_patterns redaction_patterns_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redaction_patterns
    ADD CONSTRAINT redaction_patterns_name_key UNIQUE (name);


--
-- TOC entry 4473 (class 2606 OID 18541)
-- Name: redaction_patterns redaction_patterns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redaction_patterns
    ADD CONSTRAINT redaction_patterns_pkey PRIMARY KEY (id);


--
-- TOC entry 4475 (class 2606 OID 18543)
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- TOC entry 4434 (class 2606 OID 18545)
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- TOC entry 4518 (class 2606 OID 18931)
-- Name: plans unique_conversation_plan; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT unique_conversation_plan UNIQUE (conversation_id);


--
-- TOC entry 4525 (class 2606 OID 18957)
-- Name: plan_versions unique_plan_version; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_versions
    ADD CONSTRAINT unique_plan_version UNIQUE (plan_id, version_number);


--
-- TOC entry 4477 (class 2606 OID 18553)
-- Name: user_cidafm_commands user_cidafm_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_cidafm_commands
    ADD CONSTRAINT user_cidafm_commands_pkey PRIMARY KEY (id);


--
-- TOC entry 4480 (class 2606 OID 18555)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 4482 (class 2606 OID 18557)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4340 (class 2606 OID 17606)
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4343 (class 2606 OID 17617)
-- Name: messages_2025_10_08 messages_2025_10_08_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_10_08
    ADD CONSTRAINT messages_2025_10_08_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4346 (class 2606 OID 17629)
-- Name: messages_2025_10_09 messages_2025_10_09_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_10_09
    ADD CONSTRAINT messages_2025_10_09_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4349 (class 2606 OID 17641)
-- Name: messages_2025_10_10 messages_2025_10_10_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_10_10
    ADD CONSTRAINT messages_2025_10_10_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4352 (class 2606 OID 17653)
-- Name: messages_2025_10_11 messages_2025_10_11_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_10_11
    ADD CONSTRAINT messages_2025_10_11_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4355 (class 2606 OID 17665)
-- Name: messages_2025_10_12 messages_2025_10_12_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_10_12
    ADD CONSTRAINT messages_2025_10_12_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4336 (class 2606 OID 17461)
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- TOC entry 4333 (class 2606 OID 17434)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4544 (class 2606 OID 19126)
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- TOC entry 4301 (class 2606 OID 16517)
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- TOC entry 4546 (class 2606 OID 19136)
-- Name: iceberg_namespaces iceberg_namespaces_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.iceberg_namespaces
    ADD CONSTRAINT iceberg_namespaces_pkey PRIMARY KEY (id);


--
-- TOC entry 4549 (class 2606 OID 19152)
-- Name: iceberg_tables iceberg_tables_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_pkey PRIMARY KEY (id);


--
-- TOC entry 4311 (class 2606 OID 16558)
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- TOC entry 4313 (class 2606 OID 16556)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 4309 (class 2606 OID 16534)
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- TOC entry 4542 (class 2606 OID 19080)
-- Name: prefixes prefixes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT prefixes_pkey PRIMARY KEY (bucket_id, level, name);


--
-- TOC entry 4360 (class 2606 OID 17796)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- TOC entry 4358 (class 2606 OID 17781)
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- TOC entry 4320 (class 2606 OID 16751)
-- Name: hooks hooks_pkey; Type: CONSTRAINT; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER TABLE ONLY supabase_functions.hooks
    ADD CONSTRAINT hooks_pkey PRIMARY KEY (id);


--
-- TOC entry 4318 (class 2606 OID 16741)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER TABLE ONLY supabase_functions.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4422 (class 2606 OID 18152)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: supabase_migrations; Owner: postgres
--

ALTER TABLE ONLY supabase_migrations.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4539 (class 2606 OID 19063)
-- Name: seed_files seed_files_pkey; Type: CONSTRAINT; Schema: supabase_migrations; Owner: postgres
--

ALTER TABLE ONLY supabase_migrations.seed_files
    ADD CONSTRAINT seed_files_pkey PRIMARY KEY (path);


--
-- TOC entry 4330 (class 1259 OID 17422)
-- Name: extensions_tenant_external_id_index; Type: INDEX; Schema: _realtime; Owner: supabase_admin
--

CREATE INDEX extensions_tenant_external_id_index ON _realtime.extensions USING btree (tenant_external_id);


--
-- TOC entry 4331 (class 1259 OID 17413)
-- Name: extensions_tenant_external_id_type_index; Type: INDEX; Schema: _realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX extensions_tenant_external_id_type_index ON _realtime.extensions USING btree (tenant_external_id, type);


--
-- TOC entry 4325 (class 1259 OID 17406)
-- Name: tenants_external_id_index; Type: INDEX; Schema: _realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX tenants_external_id_index ON _realtime.tenants USING btree (external_id);


--
-- TOC entry 4296 (class 1259 OID 16495)
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- TOC entry 4270 (class 1259 OID 17867)
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4271 (class 1259 OID 17869)
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4272 (class 1259 OID 17870)
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4372 (class 1259 OID 17949)
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- TOC entry 4405 (class 1259 OID 18057)
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- TOC entry 4361 (class 1259 OID 18037)
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- TOC entry 5369 (class 0 OID 0)
-- Dependencies: 4361
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- TOC entry 4366 (class 1259 OID 17864)
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- TOC entry 4408 (class 1259 OID 18054)
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- TOC entry 4409 (class 1259 OID 18055)
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- TOC entry 4380 (class 1259 OID 18060)
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- TOC entry 4377 (class 1259 OID 17921)
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- TOC entry 4378 (class 1259 OID 18066)
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- TOC entry 4415 (class 1259 OID 18143)
-- Name: oauth_clients_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_clients_client_id_idx ON auth.oauth_clients USING btree (client_id);


--
-- TOC entry 4418 (class 1259 OID 18144)
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- TOC entry 4412 (class 1259 OID 18113)
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- TOC entry 4413 (class 1259 OID 18112)
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- TOC entry 4414 (class 1259 OID 18114)
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- TOC entry 4273 (class 1259 OID 17871)
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4274 (class 1259 OID 17868)
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4283 (class 1259 OID 16478)
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- TOC entry 4284 (class 1259 OID 16479)
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- TOC entry 4285 (class 1259 OID 17863)
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- TOC entry 4288 (class 1259 OID 17951)
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- TOC entry 4291 (class 1259 OID 18056)
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- TOC entry 4399 (class 1259 OID 17993)
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- TOC entry 4400 (class 1259 OID 18058)
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- TOC entry 4401 (class 1259 OID 18008)
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- TOC entry 4404 (class 1259 OID 18007)
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- TOC entry 4367 (class 1259 OID 18059)
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- TOC entry 4370 (class 1259 OID 17950)
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- TOC entry 4391 (class 1259 OID 17975)
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- TOC entry 4394 (class 1259 OID 17974)
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- TOC entry 4389 (class 1259 OID 17960)
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- TOC entry 4390 (class 1259 OID 18122)
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- TOC entry 4379 (class 1259 OID 18119)
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- TOC entry 4371 (class 1259 OID 17948)
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- TOC entry 4275 (class 1259 OID 18028)
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- TOC entry 5370 (class 0 OID 0)
-- Dependencies: 4275
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- TOC entry 4276 (class 1259 OID 17865)
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- TOC entry 4277 (class 1259 OID 16468)
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- TOC entry 4278 (class 1259 OID 18083)
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- TOC entry 4639 (class 1259 OID 20245)
-- Name: IDX_14f68deffaf858465715995508; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_14f68deffaf858465715995508" ON n8n.folder USING btree ("projectId", id);


--
-- TOC entry 4644 (class 1259 OID 20328)
-- Name: IDX_1d8ab99d5861c9388d2dc1cf73; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_1d8ab99d5861c9388d2dc1cf73" ON n8n.insights_metadata USING btree ("workflowId");


--
-- TOC entry 4603 (class 1259 OID 19739)
-- Name: IDX_1e31657f5fe46816c34be7c1b4; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_1e31657f5fe46816c34be7c1b4" ON n8n.workflow_history USING btree ("workflowId");


--
-- TOC entry 4633 (class 1259 OID 20116)
-- Name: IDX_1ef35bac35d20bdae979d917a3; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_1ef35bac35d20bdae979d917a3" ON n8n.user_api_keys USING btree ("apiKey");


--
-- TOC entry 4608 (class 1259 OID 19981)
-- Name: IDX_5f0643f6717905a05164090dde; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_5f0643f6717905a05164090dde" ON n8n.project_relation USING btree ("userId");


--
-- TOC entry 4649 (class 1259 OID 20353)
-- Name: IDX_60b6a84299eeb3f671dfec7693; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_60b6a84299eeb3f671dfec7693" ON n8n.insights_by_period USING btree ("periodStart", type, "periodUnit", "metaId");


--
-- TOC entry 4609 (class 1259 OID 19980)
-- Name: IDX_61448d56d61802b5dfde5cdb00; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_61448d56d61802b5dfde5cdb00" ON n8n.project_relation USING btree ("projectId");


--
-- TOC entry 4634 (class 1259 OID 20115)
-- Name: IDX_63d7bbae72c767cf162d459fcc; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_63d7bbae72c767cf162d459fcc" ON n8n.user_api_keys USING btree ("userId", label);


--
-- TOC entry 4655 (class 1259 OID 20388)
-- Name: IDX_8e4b4774db42f1e6dda3452b2a; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_8e4b4774db42f1e6dda3452b2a" ON n8n.test_case_execution USING btree ("testRunId");


--
-- TOC entry 4623 (class 1259 OID 20075)
-- Name: IDX_97f863fa83c4786f1956508496; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_97f863fa83c4786f1956508496" ON n8n.execution_annotations USING btree ("executionId");


--
-- TOC entry 4629 (class 1259 OID 20099)
-- Name: IDX_a3697779b366e131b2bbdae297; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_a3697779b366e131b2bbdae297" ON n8n.execution_annotation_tags USING btree ("tagId");


--
-- TOC entry 4626 (class 1259 OID 20083)
-- Name: IDX_ae51b54c4bb430cf92f48b623f; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_ae51b54c4bb430cf92f48b623f" ON n8n.annotation_tag_entity USING btree (name);


--
-- TOC entry 4630 (class 1259 OID 20100)
-- Name: IDX_c1519757391996eb06064f0e7c; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_c1519757391996eb06064f0e7c" ON n8n.execution_annotation_tags USING btree ("annotationId");


--
-- TOC entry 4618 (class 1259 OID 20048)
-- Name: IDX_cec8eea3bf49551482ccb4933e; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_cec8eea3bf49551482ccb4933e" ON n8n.execution_metadata USING btree ("executionId", key);


--
-- TOC entry 4652 (class 1259 OID 20368)
-- Name: IDX_d6870d3b6e4c185d33926f423c; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_d6870d3b6e4c185d33926f423c" ON n8n.test_run USING btree ("workflowId");


--
-- TOC entry 4557 (class 1259 OID 19740)
-- Name: IDX_execution_entity_deletedAt; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_execution_entity_deletedAt" ON n8n.execution_entity USING btree ("deletedAt");


--
-- TOC entry 4662 (class 1259 OID 20421)
-- Name: IDX_role_scope_scopeSlug; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_role_scope_scopeSlug" ON n8n.role_scope USING btree ("scopeSlug");


--
-- TOC entry 4563 (class 1259 OID 19724)
-- Name: IDX_workflow_entity_name; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_workflow_entity_name" ON n8n.workflow_entity USING btree (name);


--
-- TOC entry 4555 (class 1259 OID 19431)
-- Name: idx_07fde106c0b471d8cc80a64fc8; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_07fde106c0b471d8cc80a64fc8 ON n8n.credentials_entity USING btree (type);


--
-- TOC entry 4569 (class 1259 OID 19355)
-- Name: idx_16f4436789e804e3e1c9eeb240; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_16f4436789e804e3e1c9eeb240 ON n8n.webhook_entity USING btree ("webhookId", method, "pathLength");


--
-- TOC entry 4570 (class 1259 OID 19363)
-- Name: idx_812eb05f7451ca757fb98444ce; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX idx_812eb05f7451ca757fb98444ce ON n8n.tag_entity USING btree (name);


--
-- TOC entry 4558 (class 1259 OID 20058)
-- Name: idx_execution_entity_stopped_at_status_deleted_at; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_execution_entity_stopped_at_status_deleted_at ON n8n.execution_entity USING btree ("stoppedAt", status, "deletedAt") WHERE (("stoppedAt" IS NOT NULL) AND ("deletedAt" IS NULL));


--
-- TOC entry 4559 (class 1259 OID 20057)
-- Name: idx_execution_entity_wait_till_status_deleted_at; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_execution_entity_wait_till_status_deleted_at ON n8n.execution_entity USING btree ("waitTill", status, "deletedAt") WHERE (("waitTill" IS NOT NULL) AND ("deletedAt" IS NULL));


--
-- TOC entry 4560 (class 1259 OID 20056)
-- Name: idx_execution_entity_workflow_id_started_at; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_execution_entity_workflow_id_started_at ON n8n.execution_entity USING btree ("workflowId", "startedAt") WHERE (("startedAt" IS NOT NULL) AND ("deletedAt" IS NULL));


--
-- TOC entry 4533 (class 1259 OID 19027)
-- Name: idx_migration_metadata_source; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_migration_metadata_source ON n8n.migration_metadata USING btree (source);


--
-- TOC entry 4534 (class 1259 OID 19029)
-- Name: idx_migration_metadata_synced; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_migration_metadata_synced ON n8n.migration_metadata USING btree (synced_at);


--
-- TOC entry 4535 (class 1259 OID 19028)
-- Name: idx_migration_metadata_workflow; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_migration_metadata_workflow ON n8n.migration_metadata USING btree (workflow_id);


--
-- TOC entry 4526 (class 1259 OID 19025)
-- Name: idx_n8n_workflows_active; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_n8n_workflows_active ON n8n.n8n_workflows USING btree (active);


--
-- TOC entry 4527 (class 1259 OID 19024)
-- Name: idx_n8n_workflows_name; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_n8n_workflows_name ON n8n.n8n_workflows USING btree (name);


--
-- TOC entry 4528 (class 1259 OID 19026)
-- Name: idx_n8n_workflows_updated; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_n8n_workflows_updated ON n8n.n8n_workflows USING btree (updated_at);


--
-- TOC entry 4574 (class 1259 OID 19656)
-- Name: idx_workflows_tags_workflow_id; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_workflows_tags_workflow_id ON n8n.workflows_tags USING btree ("workflowId");


--
-- TOC entry 4556 (class 1259 OID 19697)
-- Name: pk_credentials_entity_id; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX pk_credentials_entity_id ON n8n.credentials_entity USING btree (id);


--
-- TOC entry 4571 (class 1259 OID 19653)
-- Name: pk_tag_entity_id; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX pk_tag_entity_id ON n8n.tag_entity USING btree (id);


--
-- TOC entry 4596 (class 1259 OID 19708)
-- Name: pk_variables_id; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX pk_variables_id ON n8n.variables USING btree (id);


--
-- TOC entry 4564 (class 1259 OID 19652)
-- Name: pk_workflow_entity_id; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX pk_workflow_entity_id ON n8n.workflow_entity USING btree (id);


--
-- TOC entry 4612 (class 1259 OID 20492)
-- Name: project_relation_role_idx; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX project_relation_role_idx ON n8n.project_relation USING btree (role);


--
-- TOC entry 4613 (class 1259 OID 20493)
-- Name: project_relation_role_project_idx; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX project_relation_role_project_idx ON n8n.project_relation USING btree ("projectId", role);


--
-- TOC entry 4581 (class 1259 OID 20494)
-- Name: user_role_idx; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX user_role_idx ON n8n."user" USING btree ("roleSlug");


--
-- TOC entry 4507 (class 1259 OID 18912)
-- Name: assets_conversation_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX assets_conversation_idx ON public.assets USING btree (conversation_id);


--
-- TOC entry 4510 (class 1259 OID 18913)
-- Name: assets_version_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX assets_version_idx ON public.assets USING btree (deliverable_version_id);


--
-- TOC entry 4503 (class 1259 OID 18884)
-- Name: human_approvals_conversation_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX human_approvals_conversation_idx ON public.human_approvals USING btree (conversation_id);


--
-- TOC entry 4506 (class 1259 OID 18885)
-- Name: human_approvals_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX human_approvals_status_idx ON public.human_approvals USING btree (status);


--
-- TOC entry 4429 (class 1259 OID 18563)
-- Name: idx_agent_conversations_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_conversations_user_id ON public.conversations USING btree (user_id);


--
-- TOC entry 4498 (class 1259 OID 18859)
-- Name: idx_agent_orchestrations_agent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_orchestrations_agent ON public.agent_orchestrations USING btree (agent_slug);


--
-- TOC entry 4499 (class 1259 OID 18860)
-- Name: idx_agent_orchestrations_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_orchestrations_org ON public.agent_orchestrations USING btree (organization_slug);


--
-- TOC entry 4487 (class 1259 OID 18856)
-- Name: idx_agents_org_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_org_slug ON public.agents USING btree (organization_slug);


--
-- TOC entry 4488 (class 1259 OID 18857)
-- Name: idx_agents_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_slug ON public.agents USING btree (slug);


--
-- TOC entry 4430 (class 1259 OID 18985)
-- Name: idx_conversations_org_agent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_conversations_org_agent ON public.conversations USING btree (organization_slug, agent_name);


--
-- TOC entry 4431 (class 1259 OID 18984)
-- Name: idx_conversations_organization_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_conversations_organization_slug ON public.conversations USING btree (organization_slug);


--
-- TOC entry 4451 (class 1259 OID 18584)
-- Name: idx_llm_usage_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_llm_usage_created_at ON public.llm_usage USING btree (created_at);


--
-- TOC entry 4452 (class 1259 OID 18888)
-- Name: idx_llm_usage_run_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_llm_usage_run_id ON public.llm_usage USING btree (run_id);


--
-- TOC entry 4500 (class 1259 OID 18861)
-- Name: idx_orchestration_runs_plan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestration_runs_plan ON public.orchestration_runs USING btree (plan_id);


--
-- TOC entry 4489 (class 1259 OID 18862)
-- Name: idx_org_credentials_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_org_credentials_org ON public.organization_credentials USING btree (organization_slug);


--
-- TOC entry 4519 (class 1259 OID 18971)
-- Name: idx_plan_versions_is_current; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_plan_versions_is_current ON public.plan_versions USING btree (is_current_version) WHERE (is_current_version = true);


--
-- TOC entry 4520 (class 1259 OID 18970)
-- Name: idx_plan_versions_plan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_plan_versions_plan_id ON public.plan_versions USING btree (plan_id);


--
-- TOC entry 4521 (class 1259 OID 18972)
-- Name: idx_plan_versions_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_plan_versions_task_id ON public.plan_versions USING btree (task_id) WHERE (task_id IS NOT NULL);


--
-- TOC entry 4511 (class 1259 OID 19054)
-- Name: idx_plans_conversation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_plans_conversation ON public.plans USING btree (conversation_id);


--
-- TOC entry 4512 (class 1259 OID 18968)
-- Name: idx_plans_conversation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_plans_conversation_id ON public.plans USING btree (conversation_id);


--
-- TOC entry 4513 (class 1259 OID 19055)
-- Name: idx_plans_org_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_plans_org_slug ON public.plans USING btree (organization_slug);


--
-- TOC entry 4514 (class 1259 OID 18969)
-- Name: idx_plans_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_plans_user_id ON public.plans USING btree (user_id);


--
-- TOC entry 4461 (class 1259 OID 18918)
-- Name: idx_pseudonym_dictionaries_agent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pseudonym_dictionaries_agent ON public.pseudonym_dictionaries USING btree (agent_slug);


--
-- TOC entry 4462 (class 1259 OID 18917)
-- Name: idx_pseudonym_dictionaries_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pseudonym_dictionaries_org ON public.pseudonym_dictionaries USING btree (organization_slug);


--
-- TOC entry 4463 (class 1259 OID 18593)
-- Name: idx_pseudonym_dictionaries_original_value; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pseudonym_dictionaries_original_value ON public.pseudonym_dictionaries USING btree (original_value);


--
-- TOC entry 4464 (class 1259 OID 18919)
-- Name: idx_pseudonym_dictionaries_updated_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pseudonym_dictionaries_updated_at ON public.pseudonym_dictionaries USING btree (updated_at);


--
-- TOC entry 4469 (class 1259 OID 18594)
-- Name: idx_redaction_patterns_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_redaction_patterns_active ON public.redaction_patterns USING btree (is_active, priority);


--
-- TOC entry 4432 (class 1259 OID 18595)
-- Name: idx_tasks_conversation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_conversation_id ON public.tasks USING btree (conversation_id);


--
-- TOC entry 4478 (class 1259 OID 18599)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 4455 (class 1259 OID 18870)
-- Name: llm_usage_route_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX llm_usage_route_idx ON public.llm_usage USING btree (route);


--
-- TOC entry 4456 (class 1259 OID 18871)
-- Name: llm_usage_route_started_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX llm_usage_route_started_at_idx ON public.llm_usage USING btree (route, started_at DESC);


--
-- TOC entry 4459 (class 1259 OID 18894)
-- Name: llm_usage_run_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX llm_usage_run_id_unique ON public.llm_usage USING btree (run_id);


--
-- TOC entry 4460 (class 1259 OID 18986)
-- Name: llm_usage_total_cost_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX llm_usage_total_cost_idx ON public.llm_usage USING btree (total_cost) WHERE (total_cost IS NOT NULL);


--
-- TOC entry 4334 (class 1259 OID 17607)
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- TOC entry 4338 (class 1259 OID 17608)
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4341 (class 1259 OID 17618)
-- Name: messages_2025_10_08_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX messages_2025_10_08_inserted_at_topic_idx ON realtime.messages_2025_10_08 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4344 (class 1259 OID 17630)
-- Name: messages_2025_10_09_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX messages_2025_10_09_inserted_at_topic_idx ON realtime.messages_2025_10_09 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4347 (class 1259 OID 17642)
-- Name: messages_2025_10_10_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX messages_2025_10_10_inserted_at_topic_idx ON realtime.messages_2025_10_10 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4350 (class 1259 OID 17654)
-- Name: messages_2025_10_11_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX messages_2025_10_11_inserted_at_topic_idx ON realtime.messages_2025_10_11 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4353 (class 1259 OID 17666)
-- Name: messages_2025_10_12_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX messages_2025_10_12_inserted_at_topic_idx ON realtime.messages_2025_10_12 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4337 (class 1259 OID 17510)
-- Name: subscription_subscription_id_entity_filters_key; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_key ON realtime.subscription USING btree (subscription_id, entity, filters);


--
-- TOC entry 4299 (class 1259 OID 16523)
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- TOC entry 4302 (class 1259 OID 16545)
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- TOC entry 4547 (class 1259 OID 19142)
-- Name: idx_iceberg_namespaces_bucket_id; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX idx_iceberg_namespaces_bucket_id ON storage.iceberg_namespaces USING btree (bucket_id, name);


--
-- TOC entry 4550 (class 1259 OID 19163)
-- Name: idx_iceberg_tables_namespace_id; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX idx_iceberg_tables_namespace_id ON storage.iceberg_tables USING btree (namespace_id, name);


--
-- TOC entry 4356 (class 1259 OID 17807)
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- TOC entry 4303 (class 1259 OID 19098)
-- Name: idx_name_bucket_level_unique; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX idx_name_bucket_level_unique ON storage.objects USING btree (name COLLATE "C", bucket_id, level);


--
-- TOC entry 4304 (class 1259 OID 17772)
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- TOC entry 4305 (class 1259 OID 19100)
-- Name: idx_objects_lower_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_lower_name ON storage.objects USING btree ((path_tokens[level]), lower(name) text_pattern_ops, bucket_id, level);


--
-- TOC entry 4540 (class 1259 OID 19101)
-- Name: idx_prefixes_lower_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_prefixes_lower_name ON storage.prefixes USING btree (bucket_id, level, ((string_to_array(name, '/'::text))[level]), lower(name) text_pattern_ops);


--
-- TOC entry 4306 (class 1259 OID 16546)
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- TOC entry 4307 (class 1259 OID 19099)
-- Name: objects_bucket_id_level_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX objects_bucket_id_level_idx ON storage.objects USING btree (bucket_id, level, name COLLATE "C");


--
-- TOC entry 4321 (class 1259 OID 16753)
-- Name: supabase_functions_hooks_h_table_id_h_name_idx; Type: INDEX; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE INDEX supabase_functions_hooks_h_table_id_h_name_idx ON supabase_functions.hooks USING btree (hook_table_id, hook_name);


--
-- TOC entry 4322 (class 1259 OID 16752)
-- Name: supabase_functions_hooks_request_id_idx; Type: INDEX; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE INDEX supabase_functions_hooks_request_id_idx ON supabase_functions.hooks USING btree (request_id);


--
-- TOC entry 4673 (class 0 OID 0)
-- Name: messages_2025_10_08_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_08_inserted_at_topic_idx;


--
-- TOC entry 4674 (class 0 OID 0)
-- Name: messages_2025_10_08_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_08_pkey;


--
-- TOC entry 4675 (class 0 OID 0)
-- Name: messages_2025_10_09_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_09_inserted_at_topic_idx;


--
-- TOC entry 4676 (class 0 OID 0)
-- Name: messages_2025_10_09_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_09_pkey;


--
-- TOC entry 4677 (class 0 OID 0)
-- Name: messages_2025_10_10_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_10_inserted_at_topic_idx;


--
-- TOC entry 4678 (class 0 OID 0)
-- Name: messages_2025_10_10_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_10_pkey;


--
-- TOC entry 4679 (class 0 OID 0)
-- Name: messages_2025_10_11_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_11_inserted_at_topic_idx;


--
-- TOC entry 4680 (class 0 OID 0)
-- Name: messages_2025_10_11_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_11_pkey;


--
-- TOC entry 4681 (class 0 OID 0)
-- Name: messages_2025_10_12_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_12_inserted_at_topic_idx;


--
-- TOC entry 4682 (class 0 OID 0)
-- Name: messages_2025_10_12_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_12_pkey;


--
-- TOC entry 4770 (class 2620 OID 18914)
-- Name: assets set_timestamp_updated_at_assets; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_timestamp_updated_at_assets BEFORE UPDATE ON public.assets FOR EACH ROW EXECUTE FUNCTION public.set_timestamp_updated_at();


--
-- TOC entry 4769 (class 2620 OID 18887)
-- Name: human_approvals set_timestamp_updated_at_human_approvals; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_timestamp_updated_at_human_approvals BEFORE UPDATE ON public.human_approvals FOR EACH ROW EXECUTE FUNCTION public.set_timestamp_updated_at();


--
-- TOC entry 4771 (class 2620 OID 18974)
-- Name: plans trigger_plans_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_plans_updated_at BEFORE UPDATE ON public.plans FOR EACH ROW EXECUTE FUNCTION public.update_plans_updated_at();


--
-- TOC entry 4768 (class 2620 OID 17466)
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_admin
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- TOC entry 4763 (class 2620 OID 19108)
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- TOC entry 4764 (class 2620 OID 19096)
-- Name: objects objects_delete_delete_prefix; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER objects_delete_delete_prefix AFTER DELETE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- TOC entry 4765 (class 2620 OID 19094)
-- Name: objects objects_insert_create_prefix; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER objects_insert_create_prefix BEFORE INSERT ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.objects_insert_prefix_trigger();


--
-- TOC entry 4766 (class 2620 OID 19095)
-- Name: objects objects_update_create_prefix; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER objects_update_create_prefix BEFORE UPDATE ON storage.objects FOR EACH ROW WHEN (((new.name <> old.name) OR (new.bucket_id <> old.bucket_id))) EXECUTE FUNCTION storage.objects_update_prefix_trigger();


--
-- TOC entry 4772 (class 2620 OID 19104)
-- Name: prefixes prefixes_create_hierarchy; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER prefixes_create_hierarchy BEFORE INSERT ON storage.prefixes FOR EACH ROW WHEN ((pg_trigger_depth() < 1)) EXECUTE FUNCTION storage.prefixes_insert_trigger();


--
-- TOC entry 4773 (class 2620 OID 19093)
-- Name: prefixes prefixes_delete_hierarchy; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER prefixes_delete_hierarchy AFTER DELETE ON storage.prefixes FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- TOC entry 4767 (class 2620 OID 17760)
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- TOC entry 4685 (class 2606 OID 17414)
-- Name: extensions extensions_tenant_external_id_fkey; Type: FK CONSTRAINT; Schema: _realtime; Owner: supabase_admin
--

ALTER TABLE ONLY _realtime.extensions
    ADD CONSTRAINT extensions_tenant_external_id_fkey FOREIGN KEY (tenant_external_id) REFERENCES _realtime.tenants(external_id) ON DELETE CASCADE;


--
-- TOC entry 4689 (class 2606 OID 17851)
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4693 (class 2606 OID 17941)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 4692 (class 2606 OID 17929)
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- TOC entry 4691 (class 2606 OID 17916)
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4698 (class 2606 OID 18107)
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4683 (class 2606 OID 17884)
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 4695 (class 2606 OID 17988)
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4696 (class 2606 OID 18061)
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- TOC entry 4697 (class 2606 OID 18002)
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4690 (class 2606 OID 17879)
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4694 (class 2606 OID 17969)
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4747 (class 2606 OID 20126)
-- Name: processed_data FK_06a69a7032c97a763c2c7599464; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.processed_data
    ADD CONSTRAINT "FK_06a69a7032c97a763c2c7599464" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4752 (class 2606 OID 20318)
-- Name: insights_metadata FK_1d8ab99d5861c9388d2dc1cf733; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_metadata
    ADD CONSTRAINT "FK_1d8ab99d5861c9388d2dc1cf733" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE SET NULL;


--
-- TOC entry 4734 (class 2606 OID 19734)
-- Name: workflow_history FK_1e31657f5fe46816c34be7c1b4b; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflow_history
    ADD CONSTRAINT "FK_1e31657f5fe46816c34be7c1b4b" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4753 (class 2606 OID 20323)
-- Name: insights_metadata FK_2375a1eda085adb16b24615b69c; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_metadata
    ADD CONSTRAINT "FK_2375a1eda085adb16b24615b69c" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE SET NULL;


--
-- TOC entry 4742 (class 2606 OID 20043)
-- Name: execution_metadata FK_31d0b4c93fb85ced26f6005cda3; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_metadata
    ADD CONSTRAINT "FK_31d0b4c93fb85ced26f6005cda3" FOREIGN KEY ("executionId") REFERENCES n8n.execution_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4738 (class 2606 OID 19998)
-- Name: shared_credentials FK_416f66fc846c7c442970c094ccf; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.shared_credentials
    ADD CONSTRAINT "FK_416f66fc846c7c442970c094ccf" FOREIGN KEY ("credentialsId") REFERENCES n8n.credentials_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4735 (class 2606 OID 19975)
-- Name: project_relation FK_5f0643f6717905a05164090dde7; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.project_relation
    ADD CONSTRAINT "FK_5f0643f6717905a05164090dde7" FOREIGN KEY ("userId") REFERENCES n8n."user"(id) ON DELETE CASCADE;


--
-- TOC entry 4736 (class 2606 OID 19970)
-- Name: project_relation FK_61448d56d61802b5dfde5cdb002; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.project_relation
    ADD CONSTRAINT "FK_61448d56d61802b5dfde5cdb002" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4755 (class 2606 OID 20348)
-- Name: insights_by_period FK_6414cfed98daabbfdd61a1cfbc0; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_by_period
    ADD CONSTRAINT "FK_6414cfed98daabbfdd61a1cfbc0" FOREIGN KEY ("metaId") REFERENCES n8n.insights_metadata("metaId") ON DELETE CASCADE;


--
-- TOC entry 4754 (class 2606 OID 20336)
-- Name: insights_raw FK_6e2e33741adef2a7c5d66befa4e; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_raw
    ADD CONSTRAINT "FK_6e2e33741adef2a7c5d66befa4e" FOREIGN KEY ("metaId") REFERENCES n8n.insights_metadata("metaId") ON DELETE CASCADE;


--
-- TOC entry 4730 (class 2606 OID 19529)
-- Name: installed_nodes FK_73f857fc5dce682cef8a99c11dbddbc969618951; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.installed_nodes
    ADD CONSTRAINT "FK_73f857fc5dce682cef8a99c11dbddbc969618951" FOREIGN KEY (package) REFERENCES n8n.installed_packages("packageName") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4748 (class 2606 OID 20240)
-- Name: folder FK_804ea52f6729e3940498bd54d78; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.folder
    ADD CONSTRAINT "FK_804ea52f6729e3940498bd54d78" FOREIGN KEY ("parentFolderId") REFERENCES n8n.folder(id) ON DELETE CASCADE;


--
-- TOC entry 4739 (class 2606 OID 20003)
-- Name: shared_credentials FK_812c2852270da1247756e77f5a4; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.shared_credentials
    ADD CONSTRAINT "FK_812c2852270da1247756e77f5a4" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4757 (class 2606 OID 20378)
-- Name: test_case_execution FK_8e4b4774db42f1e6dda3452b2af; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.test_case_execution
    ADD CONSTRAINT "FK_8e4b4774db42f1e6dda3452b2af" FOREIGN KEY ("testRunId") REFERENCES n8n.test_run(id) ON DELETE CASCADE;


--
-- TOC entry 4762 (class 2606 OID 20485)
-- Name: data_table_column FK_930b6e8faaf88294cef23484160; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.data_table_column
    ADD CONSTRAINT "FK_930b6e8faaf88294cef23484160" FOREIGN KEY ("dataTableId") REFERENCES n8n.data_table(id) ON DELETE CASCADE;


--
-- TOC entry 4750 (class 2606 OID 20251)
-- Name: folder_tag FK_94a60854e06f2897b2e0d39edba; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.folder_tag
    ADD CONSTRAINT "FK_94a60854e06f2897b2e0d39edba" FOREIGN KEY ("folderId") REFERENCES n8n.folder(id) ON DELETE CASCADE;


--
-- TOC entry 4743 (class 2606 OID 20070)
-- Name: execution_annotations FK_97f863fa83c4786f19565084960; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_annotations
    ADD CONSTRAINT "FK_97f863fa83c4786f19565084960" FOREIGN KEY ("executionId") REFERENCES n8n.execution_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4744 (class 2606 OID 20094)
-- Name: execution_annotation_tags FK_a3697779b366e131b2bbdae2976; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_annotation_tags
    ADD CONSTRAINT "FK_a3697779b366e131b2bbdae2976" FOREIGN KEY ("tagId") REFERENCES n8n.annotation_tag_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4740 (class 2606 OID 20029)
-- Name: shared_workflow FK_a45ea5f27bcfdc21af9b4188560; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.shared_workflow
    ADD CONSTRAINT "FK_a45ea5f27bcfdc21af9b4188560" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4749 (class 2606 OID 20235)
-- Name: folder FK_a8260b0b36939c6247f385b8221; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.folder
    ADD CONSTRAINT "FK_a8260b0b36939c6247f385b8221" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4745 (class 2606 OID 20089)
-- Name: execution_annotation_tags FK_c1519757391996eb06064f0e7c8; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_annotation_tags
    ADD CONSTRAINT "FK_c1519757391996eb06064f0e7c8" FOREIGN KEY ("annotationId") REFERENCES n8n.execution_annotations(id) ON DELETE CASCADE;


--
-- TOC entry 4761 (class 2606 OID 20471)
-- Name: data_table FK_c2a794257dee48af7c9abf681de; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.data_table
    ADD CONSTRAINT "FK_c2a794257dee48af7c9abf681de" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4737 (class 2606 OID 20428)
-- Name: project_relation FK_c6b99592dc96b0d836d7a21db91; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.project_relation
    ADD CONSTRAINT "FK_c6b99592dc96b0d836d7a21db91" FOREIGN KEY (role) REFERENCES n8n.role(slug);


--
-- TOC entry 4756 (class 2606 OID 20363)
-- Name: test_run FK_d6870d3b6e4c185d33926f423c8; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.test_run
    ADD CONSTRAINT "FK_d6870d3b6e4c185d33926f423c8" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4741 (class 2606 OID 20024)
-- Name: shared_workflow FK_daa206a04983d47d0a9c34649ce; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.shared_workflow
    ADD CONSTRAINT "FK_daa206a04983d47d0a9c34649ce" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4751 (class 2606 OID 20256)
-- Name: folder_tag FK_dc88164176283de80af47621746; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.folder_tag
    ADD CONSTRAINT "FK_dc88164176283de80af47621746" FOREIGN KEY ("tagId") REFERENCES n8n.tag_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4746 (class 2606 OID 20110)
-- Name: user_api_keys FK_e131705cbbc8fb589889b02d457; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.user_api_keys
    ADD CONSTRAINT "FK_e131705cbbc8fb589889b02d457" FOREIGN KEY ("userId") REFERENCES n8n."user"(id) ON DELETE CASCADE;


--
-- TOC entry 4758 (class 2606 OID 20383)
-- Name: test_case_execution FK_e48965fac35d0f5b9e7f51d8c44; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.test_case_execution
    ADD CONSTRAINT "FK_e48965fac35d0f5b9e7f51d8c44" FOREIGN KEY ("executionId") REFERENCES n8n.execution_entity(id) ON DELETE SET NULL;


--
-- TOC entry 4729 (class 2606 OID 20423)
-- Name: user FK_eaea92ee7bfb9c1b6cd01505d56; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n."user"
    ADD CONSTRAINT "FK_eaea92ee7bfb9c1b6cd01505d56" FOREIGN KEY ("roleSlug") REFERENCES n8n.role(slug);


--
-- TOC entry 4759 (class 2606 OID 20411)
-- Name: role_scope FK_role; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.role_scope
    ADD CONSTRAINT "FK_role" FOREIGN KEY ("roleSlug") REFERENCES n8n.role(slug) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4760 (class 2606 OID 20416)
-- Name: role_scope FK_scope; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.role_scope
    ADD CONSTRAINT "FK_scope" FOREIGN KEY ("scopeSlug") REFERENCES n8n.scope(slug) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4732 (class 2606 OID 19610)
-- Name: auth_identity auth_identity_userId_fkey; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.auth_identity
    ADD CONSTRAINT "auth_identity_userId_fkey" FOREIGN KEY ("userId") REFERENCES n8n."user"(id);


--
-- TOC entry 4733 (class 2606 OID 19716)
-- Name: execution_data execution_data_fk; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_data
    ADD CONSTRAINT execution_data_fk FOREIGN KEY ("executionId") REFERENCES n8n.execution_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4724 (class 2606 OID 19688)
-- Name: execution_entity fk_execution_entity_workflow_id; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_entity
    ADD CONSTRAINT fk_execution_entity_workflow_id FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4726 (class 2606 OID 19682)
-- Name: webhook_entity fk_webhook_entity_workflow_id; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.webhook_entity
    ADD CONSTRAINT fk_webhook_entity_workflow_id FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4725 (class 2606 OID 20307)
-- Name: workflow_entity fk_workflow_parent_folder; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflow_entity
    ADD CONSTRAINT fk_workflow_parent_folder FOREIGN KEY ("parentFolderId") REFERENCES n8n.folder(id) ON DELETE CASCADE;


--
-- TOC entry 4731 (class 2606 OID 19677)
-- Name: workflow_statistics fk_workflow_statistics_workflow_id; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflow_statistics
    ADD CONSTRAINT fk_workflow_statistics_workflow_id FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4727 (class 2606 OID 19662)
-- Name: workflows_tags fk_workflows_tags_tag_id; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflows_tags
    ADD CONSTRAINT fk_workflows_tags_tag_id FOREIGN KEY ("tagId") REFERENCES n8n.tag_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4728 (class 2606 OID 19657)
-- Name: workflows_tags fk_workflows_tags_workflow_id; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflows_tags
    ADD CONSTRAINT fk_workflows_tags_workflow_id FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4719 (class 2606 OID 19019)
-- Name: migration_metadata migration_metadata_workflow_id_fkey; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.migration_metadata
    ADD CONSTRAINT migration_metadata_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES n8n.n8n_workflows(id);


--
-- TOC entry 4699 (class 2606 OID 18611)
-- Name: conversations agent_conversations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT agent_conversations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 4714 (class 2606 OID 18907)
-- Name: assets assets_deliverable_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_deliverable_version_id_fkey FOREIGN KEY (deliverable_version_id) REFERENCES public.deliverable_versions(id) ON DELETE SET NULL;


--
-- TOC entry 4702 (class 2606 OID 18651)
-- Name: deliverable_versions deliverable_versions_deliverable_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverable_versions
    ADD CONSTRAINT deliverable_versions_deliverable_id_fkey FOREIGN KEY (deliverable_id) REFERENCES public.deliverables(id) ON DELETE CASCADE;


--
-- TOC entry 4703 (class 2606 OID 18656)
-- Name: deliverable_versions deliverable_versions_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverable_versions
    ADD CONSTRAINT deliverable_versions_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- TOC entry 4704 (class 2606 OID 18661)
-- Name: deliverables deliverables_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverables
    ADD CONSTRAINT deliverables_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 4705 (class 2606 OID 18666)
-- Name: departments departments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- TOC entry 4715 (class 2606 OID 18963)
-- Name: plans fk_plans_current_version; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT fk_plans_current_version FOREIGN KEY (current_version_id) REFERENCES public.plan_versions(id) ON DELETE SET NULL;


--
-- TOC entry 4706 (class 2606 OID 18671)
-- Name: kpi_data kpi_data_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kpi_data
    ADD CONSTRAINT kpi_data_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE CASCADE;


--
-- TOC entry 4707 (class 2606 OID 18676)
-- Name: kpi_data kpi_data_metric_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kpi_data
    ADD CONSTRAINT kpi_data_metric_id_fkey FOREIGN KEY (metric_id) REFERENCES public.kpi_metrics(id) ON DELETE CASCADE;


--
-- TOC entry 4708 (class 2606 OID 18681)
-- Name: kpi_goals kpi_goals_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kpi_goals
    ADD CONSTRAINT kpi_goals_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE CASCADE;


--
-- TOC entry 4709 (class 2606 OID 18686)
-- Name: kpi_goals kpi_goals_metric_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kpi_goals
    ADD CONSTRAINT kpi_goals_metric_id_fkey FOREIGN KEY (metric_id) REFERENCES public.kpi_metrics(id) ON DELETE CASCADE;


--
-- TOC entry 4710 (class 2606 OID 18691)
-- Name: llm_models llm_models_provider_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_provider_name_fkey FOREIGN KEY (provider_name) REFERENCES public.llm_providers(name) ON DELETE CASCADE;


--
-- TOC entry 4711 (class 2606 OID 18696)
-- Name: llm_usage llm_usage_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_usage
    ADD CONSTRAINT llm_usage_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- TOC entry 4718 (class 2606 OID 18958)
-- Name: plan_versions plan_versions_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_versions
    ADD CONSTRAINT plan_versions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- TOC entry 4716 (class 2606 OID 18932)
-- Name: plans plans_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- TOC entry 4717 (class 2606 OID 18937)
-- Name: plans plans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4700 (class 2606 OID 18716)
-- Name: tasks tasks_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- TOC entry 4701 (class 2606 OID 18721)
-- Name: tasks tasks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 4712 (class 2606 OID 18726)
-- Name: user_cidafm_commands user_cidafm_commands_command_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_cidafm_commands
    ADD CONSTRAINT user_cidafm_commands_command_id_fkey FOREIGN KEY (command_id) REFERENCES public.cidafm_commands(id) ON DELETE CASCADE;


--
-- TOC entry 4713 (class 2606 OID 18731)
-- Name: user_cidafm_commands user_cidafm_commands_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_cidafm_commands
    ADD CONSTRAINT user_cidafm_commands_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4721 (class 2606 OID 19137)
-- Name: iceberg_namespaces iceberg_namespaces_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.iceberg_namespaces
    ADD CONSTRAINT iceberg_namespaces_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_analytics(id) ON DELETE CASCADE;


--
-- TOC entry 4722 (class 2606 OID 19158)
-- Name: iceberg_tables iceberg_tables_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_analytics(id) ON DELETE CASCADE;


--
-- TOC entry 4723 (class 2606 OID 19153)
-- Name: iceberg_tables iceberg_tables_namespace_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES storage.iceberg_namespaces(id) ON DELETE CASCADE;


--
-- TOC entry 4684 (class 2606 OID 16535)
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4720 (class 2606 OID 19081)
-- Name: prefixes prefixes_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT "prefixes_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4686 (class 2606 OID 17782)
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4687 (class 2606 OID 17802)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4688 (class 2606 OID 17797)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- TOC entry 4924 (class 0 OID 16488)
-- Dependencies: 238
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4941 (class 0 OID 18047)
-- Dependencies: 282
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4932 (class 0 OID 17844)
-- Dependencies: 273
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4923 (class 0 OID 16481)
-- Dependencies: 237
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4936 (class 0 OID 17934)
-- Dependencies: 277
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4935 (class 0 OID 17922)
-- Dependencies: 276
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4934 (class 0 OID 17909)
-- Dependencies: 275
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4942 (class 0 OID 18097)
-- Dependencies: 283
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4922 (class 0 OID 16470)
-- Dependencies: 236
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4939 (class 0 OID 17976)
-- Dependencies: 280
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4940 (class 0 OID 17994)
-- Dependencies: 281
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4925 (class 0 OID 16496)
-- Dependencies: 239
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4933 (class 0 OID 17874)
-- Dependencies: 274
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4938 (class 0 OID 17961)
-- Dependencies: 279
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4937 (class 0 OID 17952)
-- Dependencies: 278
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4921 (class 0 OID 16458)
-- Dependencies: 234
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4944 (class 0 OID 18942)
-- Dependencies: 312
-- Name: plan_versions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.plan_versions ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4956 (class 3256 OID 18982)
-- Name: plan_versions plan_versions_delete_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY plan_versions_delete_policy ON public.plan_versions FOR DELETE USING ((EXISTS ( SELECT 1
   FROM public.plans
  WHERE ((plans.id = plan_versions.plan_id) AND (plans.user_id = auth.uid())))));


--
-- TOC entry 4954 (class 3256 OID 18980)
-- Name: plan_versions plan_versions_insert_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY plan_versions_insert_policy ON public.plan_versions FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM public.plans
  WHERE ((plans.id = plan_versions.plan_id) AND (plans.user_id = auth.uid())))));


--
-- TOC entry 4953 (class 3256 OID 18979)
-- Name: plan_versions plan_versions_select_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY plan_versions_select_policy ON public.plan_versions FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.plans
  WHERE ((plans.id = plan_versions.plan_id) AND (plans.user_id = auth.uid())))));


--
-- TOC entry 4955 (class 3256 OID 18981)
-- Name: plan_versions plan_versions_update_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY plan_versions_update_policy ON public.plan_versions FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM public.plans
  WHERE ((plans.id = plan_versions.plan_id) AND (plans.user_id = auth.uid())))));


--
-- TOC entry 4943 (class 0 OID 18920)
-- Dependencies: 311
-- Name: plans; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.plans ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4952 (class 3256 OID 18978)
-- Name: plans plans_delete_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY plans_delete_policy ON public.plans FOR DELETE USING ((auth.uid() = user_id));


--
-- TOC entry 4950 (class 3256 OID 18976)
-- Name: plans plans_insert_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY plans_insert_policy ON public.plans FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- TOC entry 4949 (class 3256 OID 18975)
-- Name: plans plans_select_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY plans_select_policy ON public.plans FOR SELECT USING ((auth.uid() = user_id));


--
-- TOC entry 4951 (class 3256 OID 18977)
-- Name: plans plans_update_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY plans_update_policy ON public.plans FOR UPDATE USING ((auth.uid() = user_id));


--
-- TOC entry 4929 (class 0 OID 17592)
-- Dependencies: 265
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4926 (class 0 OID 16509)
-- Dependencies: 240
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4946 (class 0 OID 19116)
-- Dependencies: 318
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4947 (class 0 OID 19127)
-- Dependencies: 319
-- Name: iceberg_namespaces; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.iceberg_namespaces ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4948 (class 0 OID 19143)
-- Dependencies: 320
-- Name: iceberg_tables; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.iceberg_tables ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4928 (class 0 OID 16551)
-- Dependencies: 242
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4927 (class 0 OID 16524)
-- Dependencies: 241
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4945 (class 0 OID 19071)
-- Dependencies: 317
-- Name: prefixes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.prefixes ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4930 (class 0 OID 17773)
-- Dependencies: 271
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4931 (class 0 OID 17787)
-- Dependencies: 272
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4957 (class 6104 OID 16388)
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION supabase_realtime OWNER TO postgres;

--
-- TOC entry 5085 (class 0 OID 0)
-- Dependencies: 5083
-- Name: DATABASE postgres; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE postgres TO dashboard_user;


--
-- TOC entry 5087 (class 0 OID 0)
-- Dependencies: 23
-- Name: SCHEMA auth; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA auth TO anon;
GRANT USAGE ON SCHEMA auth TO authenticated;
GRANT USAGE ON SCHEMA auth TO service_role;
GRANT ALL ON SCHEMA auth TO supabase_auth_admin;
GRANT ALL ON SCHEMA auth TO dashboard_user;
GRANT USAGE ON SCHEMA auth TO postgres;


--
-- TOC entry 5088 (class 0 OID 0)
-- Dependencies: 16
-- Name: SCHEMA extensions; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA extensions TO anon;
GRANT USAGE ON SCHEMA extensions TO authenticated;
GRANT USAGE ON SCHEMA extensions TO service_role;
GRANT ALL ON SCHEMA extensions TO dashboard_user;


--
-- TOC entry 5091 (class 0 OID 0)
-- Dependencies: 11
-- Name: SCHEMA net; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA net TO supabase_functions_admin;
GRANT USAGE ON SCHEMA net TO postgres;
GRANT USAGE ON SCHEMA net TO anon;
GRANT USAGE ON SCHEMA net TO authenticated;
GRANT USAGE ON SCHEMA net TO service_role;


--
-- TOC entry 5092 (class 0 OID 0)
-- Dependencies: 17
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;


--
-- TOC entry 5093 (class 0 OID 0)
-- Dependencies: 14
-- Name: SCHEMA realtime; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA realtime TO postgres;
GRANT USAGE ON SCHEMA realtime TO anon;
GRANT USAGE ON SCHEMA realtime TO authenticated;
GRANT USAGE ON SCHEMA realtime TO service_role;
GRANT ALL ON SCHEMA realtime TO supabase_realtime_admin;


--
-- TOC entry 5094 (class 0 OID 0)
-- Dependencies: 22
-- Name: SCHEMA storage; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA storage TO postgres;
GRANT USAGE ON SCHEMA storage TO anon;
GRANT USAGE ON SCHEMA storage TO authenticated;
GRANT USAGE ON SCHEMA storage TO service_role;
GRANT ALL ON SCHEMA storage TO supabase_storage_admin;
GRANT ALL ON SCHEMA storage TO dashboard_user;


--
-- TOC entry 5095 (class 0 OID 0)
-- Dependencies: 25
-- Name: SCHEMA supabase_functions; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA supabase_functions TO postgres;
GRANT USAGE ON SCHEMA supabase_functions TO anon;
GRANT USAGE ON SCHEMA supabase_functions TO authenticated;
GRANT USAGE ON SCHEMA supabase_functions TO service_role;
GRANT ALL ON SCHEMA supabase_functions TO supabase_functions_admin;


--
-- TOC entry 5096 (class 0 OID 0)
-- Dependencies: 19
-- Name: SCHEMA vault; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA vault TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA vault TO service_role;


--
-- TOC entry 5104 (class 0 OID 0)
-- Dependencies: 392
-- Name: FUNCTION email(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.email() TO dashboard_user;


--
-- TOC entry 5105 (class 0 OID 0)
-- Dependencies: 499
-- Name: FUNCTION jwt(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.jwt() TO postgres;
GRANT ALL ON FUNCTION auth.jwt() TO dashboard_user;


--
-- TOC entry 5107 (class 0 OID 0)
-- Dependencies: 410
-- Name: FUNCTION role(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.role() TO dashboard_user;


--
-- TOC entry 5109 (class 0 OID 0)
-- Dependencies: 391
-- Name: FUNCTION uid(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.uid() TO dashboard_user;


--
-- TOC entry 5110 (class 0 OID 0)
-- Dependencies: 421
-- Name: FUNCTION algorithm_sign(signables text, secret text, algorithm text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.algorithm_sign(signables text, secret text, algorithm text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.algorithm_sign(signables text, secret text, algorithm text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5111 (class 0 OID 0)
-- Dependencies: 452
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.armor(bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5112 (class 0 OID 0)
-- Dependencies: 453
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5113 (class 0 OID 0)
-- Dependencies: 406
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.crypt(text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5114 (class 0 OID 0)
-- Dependencies: 454
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.dearmor(text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5115 (class 0 OID 0)
-- Dependencies: 386
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5116 (class 0 OID 0)
-- Dependencies: 383
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5117 (class 0 OID 0)
-- Dependencies: 403
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5118 (class 0 OID 0)
-- Dependencies: 371
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.digest(text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5119 (class 0 OID 0)
-- Dependencies: 385
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5120 (class 0 OID 0)
-- Dependencies: 387
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5121 (class 0 OID 0)
-- Dependencies: 384
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5122 (class 0 OID 0)
-- Dependencies: 388
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO postgres WITH GRANT OPTION;


--
-- TOC entry 5123 (class 0 OID 0)
-- Dependencies: 401
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.gen_salt(text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5124 (class 0 OID 0)
-- Dependencies: 407
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5126 (class 0 OID 0)
-- Dependencies: 462
-- Name: FUNCTION grant_pg_cron_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_cron_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO dashboard_user;


--
-- TOC entry 5128 (class 0 OID 0)
-- Dependencies: 430
-- Name: FUNCTION grant_pg_graphql_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.grant_pg_graphql_access() TO postgres WITH GRANT OPTION;


--
-- TOC entry 5130 (class 0 OID 0)
-- Dependencies: 474
-- Name: FUNCTION grant_pg_net_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_net_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO dashboard_user;


--
-- TOC entry 5131 (class 0 OID 0)
-- Dependencies: 405
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5132 (class 0 OID 0)
-- Dependencies: 404
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5133 (class 0 OID 0)
-- Dependencies: 456
-- Name: FUNCTION pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5134 (class 0 OID 0)
-- Dependencies: 422
-- Name: FUNCTION pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5135 (class 0 OID 0)
-- Dependencies: 455
-- Name: FUNCTION pg_stat_statements_reset(userid oid, dbid oid, queryid bigint); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5136 (class 0 OID 0)
-- Dependencies: 418
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5137 (class 0 OID 0)
-- Dependencies: 451
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5138 (class 0 OID 0)
-- Dependencies: 416
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5139 (class 0 OID 0)
-- Dependencies: 447
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5140 (class 0 OID 0)
-- Dependencies: 449
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5141 (class 0 OID 0)
-- Dependencies: 446
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5142 (class 0 OID 0)
-- Dependencies: 448
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5143 (class 0 OID 0)
-- Dependencies: 450
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5144 (class 0 OID 0)
-- Dependencies: 412
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5145 (class 0 OID 0)
-- Dependencies: 414
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5146 (class 0 OID 0)
-- Dependencies: 413
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5147 (class 0 OID 0)
-- Dependencies: 415
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5148 (class 0 OID 0)
-- Dependencies: 443
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5149 (class 0 OID 0)
-- Dependencies: 445
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5150 (class 0 OID 0)
-- Dependencies: 444
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5151 (class 0 OID 0)
-- Dependencies: 411
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5152 (class 0 OID 0)
-- Dependencies: 408
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5153 (class 0 OID 0)
-- Dependencies: 441
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5154 (class 0 OID 0)
-- Dependencies: 409
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5155 (class 0 OID 0)
-- Dependencies: 442
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5156 (class 0 OID 0)
-- Dependencies: 429
-- Name: FUNCTION pgrst_ddl_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_ddl_watch() TO postgres WITH GRANT OPTION;


--
-- TOC entry 5157 (class 0 OID 0)
-- Dependencies: 457
-- Name: FUNCTION pgrst_drop_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_drop_watch() TO postgres WITH GRANT OPTION;


--
-- TOC entry 5159 (class 0 OID 0)
-- Dependencies: 458
-- Name: FUNCTION set_graphql_placeholder(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.set_graphql_placeholder() TO postgres WITH GRANT OPTION;


--
-- TOC entry 5160 (class 0 OID 0)
-- Dependencies: 440
-- Name: FUNCTION sign(payload json, secret text, algorithm text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.sign(payload json, secret text, algorithm text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.sign(payload json, secret text, algorithm text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5161 (class 0 OID 0)
-- Dependencies: 399
-- Name: FUNCTION try_cast_double(inp text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.try_cast_double(inp text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.try_cast_double(inp text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5162 (class 0 OID 0)
-- Dependencies: 420
-- Name: FUNCTION url_decode(data text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.url_decode(data text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.url_decode(data text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5163 (class 0 OID 0)
-- Dependencies: 419
-- Name: FUNCTION url_encode(data bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.url_encode(data bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.url_encode(data bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5164 (class 0 OID 0)
-- Dependencies: 397
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO postgres WITH GRANT OPTION;


--
-- TOC entry 5165 (class 0 OID 0)
-- Dependencies: 389
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO postgres WITH GRANT OPTION;


--
-- TOC entry 5166 (class 0 OID 0)
-- Dependencies: 398
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5167 (class 0 OID 0)
-- Dependencies: 370
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO postgres WITH GRANT OPTION;


--
-- TOC entry 5168 (class 0 OID 0)
-- Dependencies: 402
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5169 (class 0 OID 0)
-- Dependencies: 390
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_nil() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO postgres WITH GRANT OPTION;


--
-- TOC entry 5170 (class 0 OID 0)
-- Dependencies: 393
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO postgres WITH GRANT OPTION;


--
-- TOC entry 5171 (class 0 OID 0)
-- Dependencies: 395
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO postgres WITH GRANT OPTION;


--
-- TOC entry 5172 (class 0 OID 0)
-- Dependencies: 394
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO postgres WITH GRANT OPTION;


--
-- TOC entry 5173 (class 0 OID 0)
-- Dependencies: 396
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO postgres WITH GRANT OPTION;


--
-- TOC entry 5174 (class 0 OID 0)
-- Dependencies: 400
-- Name: FUNCTION verify(token text, secret text, algorithm text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.verify(token text, secret text, algorithm text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.verify(token text, secret text, algorithm text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 5175 (class 0 OID 0)
-- Dependencies: 459
-- Name: FUNCTION graphql("operationName" text, query text, variables jsonb, extensions jsonb); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO postgres;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO anon;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO authenticated;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO service_role;


--
-- TOC entry 5176 (class 0 OID 0)
-- Dependencies: 472
-- Name: FUNCTION http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer); Type: ACL; Schema: net; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO postgres;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO anon;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO authenticated;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO service_role;


--
-- TOC entry 5177 (class 0 OID 0)
-- Dependencies: 473
-- Name: FUNCTION http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer); Type: ACL; Schema: net; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO postgres;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO anon;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO authenticated;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO service_role;


--
-- TOC entry 5178 (class 0 OID 0)
-- Dependencies: 463
-- Name: FUNCTION get_auth(p_usename text); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION pgbouncer.get_auth(p_usename text) FROM PUBLIC;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO pgbouncer;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO postgres;


--
-- TOC entry 5179 (class 0 OID 0)
-- Dependencies: 500
-- Name: FUNCTION calculate_completion_percentage(requirements jsonb); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.calculate_completion_percentage(requirements jsonb) TO anon;
GRANT ALL ON FUNCTION public.calculate_completion_percentage(requirements jsonb) TO authenticated;
GRANT ALL ON FUNCTION public.calculate_completion_percentage(requirements jsonb) TO service_role;


--
-- TOC entry 5180 (class 0 OID 0)
-- Dependencies: 484
-- Name: FUNCTION cleanup_abandoned_conversations(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.cleanup_abandoned_conversations() TO anon;
GRANT ALL ON FUNCTION public.cleanup_abandoned_conversations() TO authenticated;
GRANT ALL ON FUNCTION public.cleanup_abandoned_conversations() TO service_role;


--
-- TOC entry 5181 (class 0 OID 0)
-- Dependencies: 512
-- Name: FUNCTION cleanup_old_jokes(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.cleanup_old_jokes() TO anon;
GRANT ALL ON FUNCTION public.cleanup_old_jokes() TO authenticated;
GRANT ALL ON FUNCTION public.cleanup_old_jokes() TO service_role;


--
-- TOC entry 5182 (class 0 OID 0)
-- Dependencies: 485
-- Name: FUNCTION exec_sql(query text, sql_query text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.exec_sql(query text, sql_query text) TO anon;
GRANT ALL ON FUNCTION public.exec_sql(query text, sql_query text) TO authenticated;
GRANT ALL ON FUNCTION public.exec_sql(query text, sql_query text) TO service_role;


--
-- TOC entry 5183 (class 0 OID 0)
-- Dependencies: 513
-- Name: FUNCTION get_global_model_config(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_global_model_config() TO anon;
GRANT ALL ON FUNCTION public.get_global_model_config() TO authenticated;
GRANT ALL ON FUNCTION public.get_global_model_config() TO service_role;


--
-- TOC entry 5185 (class 0 OID 0)
-- Dependencies: 501
-- Name: FUNCTION log_agent_action(p_action character varying, p_agent_id uuid, p_details jsonb, p_previous_state jsonb, p_new_state jsonb, p_success boolean, p_error_message text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.log_agent_action(p_action character varying, p_agent_id uuid, p_details jsonb, p_previous_state jsonb, p_new_state jsonb, p_success boolean, p_error_message text) TO anon;
GRANT ALL ON FUNCTION public.log_agent_action(p_action character varying, p_agent_id uuid, p_details jsonb, p_previous_state jsonb, p_new_state jsonb, p_success boolean, p_error_message text) TO authenticated;
GRANT ALL ON FUNCTION public.log_agent_action(p_action character varying, p_agent_id uuid, p_details jsonb, p_previous_state jsonb, p_new_state jsonb, p_success boolean, p_error_message text) TO service_role;


--
-- TOC entry 5186 (class 0 OID 0)
-- Dependencies: 489
-- Name: FUNCTION set_timestamp_updated_at(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.set_timestamp_updated_at() TO anon;
GRANT ALL ON FUNCTION public.set_timestamp_updated_at() TO authenticated;
GRANT ALL ON FUNCTION public.set_timestamp_updated_at() TO service_role;


--
-- TOC entry 5187 (class 0 OID 0)
-- Dependencies: 502
-- Name: FUNCTION update_agent_configurations_updated_at(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_agent_configurations_updated_at() TO anon;
GRANT ALL ON FUNCTION public.update_agent_configurations_updated_at() TO authenticated;
GRANT ALL ON FUNCTION public.update_agent_configurations_updated_at() TO service_role;


--
-- TOC entry 5188 (class 0 OID 0)
-- Dependencies: 503
-- Name: FUNCTION update_agent_skills_updated_at(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_agent_skills_updated_at() TO anon;
GRANT ALL ON FUNCTION public.update_agent_skills_updated_at() TO authenticated;
GRANT ALL ON FUNCTION public.update_agent_skills_updated_at() TO service_role;


--
-- TOC entry 5190 (class 0 OID 0)
-- Dependencies: 504
-- Name: FUNCTION update_agent_usage_analytics(p_agent_id uuid, p_conversation_increment integer, p_message_increment integer, p_response_time_ms integer, p_error_increment integer, p_unique_user_increment integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_agent_usage_analytics(p_agent_id uuid, p_conversation_increment integer, p_message_increment integer, p_response_time_ms integer, p_error_increment integer, p_unique_user_increment integer) TO anon;
GRANT ALL ON FUNCTION public.update_agent_usage_analytics(p_agent_id uuid, p_conversation_increment integer, p_message_increment integer, p_response_time_ms integer, p_error_increment integer, p_unique_user_increment integer) TO authenticated;
GRANT ALL ON FUNCTION public.update_agent_usage_analytics(p_agent_id uuid, p_conversation_increment integer, p_message_increment integer, p_response_time_ms integer, p_error_increment integer, p_unique_user_increment integer) TO service_role;


--
-- TOC entry 5191 (class 0 OID 0)
-- Dependencies: 505
-- Name: FUNCTION update_completion_percentage(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_completion_percentage() TO anon;
GRANT ALL ON FUNCTION public.update_completion_percentage() TO authenticated;
GRANT ALL ON FUNCTION public.update_completion_percentage() TO service_role;


--
-- TOC entry 5192 (class 0 OID 0)
-- Dependencies: 506
-- Name: FUNCTION update_conversation_timestamps(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_conversation_timestamps() TO anon;
GRANT ALL ON FUNCTION public.update_conversation_timestamps() TO authenticated;
GRANT ALL ON FUNCTION public.update_conversation_timestamps() TO service_role;


--
-- TOC entry 5194 (class 0 OID 0)
-- Dependencies: 509
-- Name: FUNCTION update_creation_metrics(p_success boolean, p_creation_time_seconds integer, p_questions_answered integer, p_department character varying); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_creation_metrics(p_success boolean, p_creation_time_seconds integer, p_questions_answered integer, p_department character varying) TO anon;
GRANT ALL ON FUNCTION public.update_creation_metrics(p_success boolean, p_creation_time_seconds integer, p_questions_answered integer, p_department character varying) TO authenticated;
GRANT ALL ON FUNCTION public.update_creation_metrics(p_success boolean, p_creation_time_seconds integer, p_questions_answered integer, p_department character varying) TO service_role;


--
-- TOC entry 5195 (class 0 OID 0)
-- Dependencies: 490
-- Name: FUNCTION update_plans_updated_at(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_plans_updated_at() TO anon;
GRANT ALL ON FUNCTION public.update_plans_updated_at() TO authenticated;
GRANT ALL ON FUNCTION public.update_plans_updated_at() TO service_role;


--
-- TOC entry 5196 (class 0 OID 0)
-- Dependencies: 510
-- Name: FUNCTION update_updated_at_column(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_updated_at_column() TO anon;
GRANT ALL ON FUNCTION public.update_updated_at_column() TO authenticated;
GRANT ALL ON FUNCTION public.update_updated_at_column() TO service_role;


--
-- TOC entry 5197 (class 0 OID 0)
-- Dependencies: 511
-- Name: FUNCTION validate_skill_examples(examples jsonb); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.validate_skill_examples(examples jsonb) TO anon;
GRANT ALL ON FUNCTION public.validate_skill_examples(examples jsonb) TO authenticated;
GRANT ALL ON FUNCTION public.validate_skill_examples(examples jsonb) TO service_role;


--
-- TOC entry 5198 (class 0 OID 0)
-- Dependencies: 481
-- Name: FUNCTION apply_rls(wal jsonb, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO service_role;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO supabase_realtime_admin;


--
-- TOC entry 5199 (class 0 OID 0)
-- Dependencies: 491
-- Name: FUNCTION broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO postgres;
GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO dashboard_user;


--
-- TOC entry 5200 (class 0 OID 0)
-- Dependencies: 480
-- Name: FUNCTION build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO postgres;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO anon;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO service_role;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO supabase_realtime_admin;


--
-- TOC entry 5201 (class 0 OID 0)
-- Dependencies: 478
-- Name: FUNCTION "cast"(val text, type_ regtype); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO postgres;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO dashboard_user;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO anon;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO authenticated;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO service_role;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO supabase_realtime_admin;


--
-- TOC entry 5202 (class 0 OID 0)
-- Dependencies: 486
-- Name: FUNCTION check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO postgres;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO anon;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO authenticated;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO service_role;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO supabase_realtime_admin;


--
-- TOC entry 5203 (class 0 OID 0)
-- Dependencies: 483
-- Name: FUNCTION is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO postgres;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO anon;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO service_role;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO supabase_realtime_admin;


--
-- TOC entry 5204 (class 0 OID 0)
-- Dependencies: 482
-- Name: FUNCTION list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO service_role;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO supabase_realtime_admin;


--
-- TOC entry 5205 (class 0 OID 0)
-- Dependencies: 477
-- Name: FUNCTION quote_wal2json(entity regclass); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO postgres;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO anon;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO authenticated;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO service_role;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO supabase_realtime_admin;


--
-- TOC entry 5206 (class 0 OID 0)
-- Dependencies: 475
-- Name: FUNCTION send(payload jsonb, event text, topic text, private boolean); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO postgres;
GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO dashboard_user;


--
-- TOC entry 5207 (class 0 OID 0)
-- Dependencies: 487
-- Name: FUNCTION subscription_check_filters(); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO postgres;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO dashboard_user;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO anon;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO authenticated;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO service_role;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO supabase_realtime_admin;


--
-- TOC entry 5208 (class 0 OID 0)
-- Dependencies: 479
-- Name: FUNCTION to_regrole(role_name text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO postgres;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO anon;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO authenticated;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO service_role;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO supabase_realtime_admin;


--
-- TOC entry 5209 (class 0 OID 0)
-- Dependencies: 488
-- Name: FUNCTION topic(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.topic() TO postgres;
GRANT ALL ON FUNCTION realtime.topic() TO dashboard_user;


--
-- TOC entry 5210 (class 0 OID 0)
-- Dependencies: 476
-- Name: FUNCTION http_request(); Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

REVOKE ALL ON FUNCTION supabase_functions.http_request() FROM PUBLIC;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO postgres;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO anon;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO authenticated;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO service_role;


--
-- TOC entry 5211 (class 0 OID 0)
-- Dependencies: 437
-- Name: FUNCTION _crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO service_role;


--
-- TOC entry 5212 (class 0 OID 0)
-- Dependencies: 438
-- Name: FUNCTION create_secret(new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- TOC entry 5213 (class 0 OID 0)
-- Dependencies: 439
-- Name: FUNCTION update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- TOC entry 5215 (class 0 OID 0)
-- Dependencies: 238
-- Name: TABLE audit_log_entries; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.audit_log_entries TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.audit_log_entries TO postgres;
GRANT SELECT ON TABLE auth.audit_log_entries TO postgres WITH GRANT OPTION;


--
-- TOC entry 5217 (class 0 OID 0)
-- Dependencies: 282
-- Name: TABLE flow_state; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.flow_state TO postgres;
GRANT SELECT ON TABLE auth.flow_state TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.flow_state TO dashboard_user;


--
-- TOC entry 5220 (class 0 OID 0)
-- Dependencies: 273
-- Name: TABLE identities; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.identities TO postgres;
GRANT SELECT ON TABLE auth.identities TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.identities TO dashboard_user;


--
-- TOC entry 5222 (class 0 OID 0)
-- Dependencies: 237
-- Name: TABLE instances; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.instances TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.instances TO postgres;
GRANT SELECT ON TABLE auth.instances TO postgres WITH GRANT OPTION;


--
-- TOC entry 5224 (class 0 OID 0)
-- Dependencies: 277
-- Name: TABLE mfa_amr_claims; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.mfa_amr_claims TO postgres;
GRANT SELECT ON TABLE auth.mfa_amr_claims TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_amr_claims TO dashboard_user;


--
-- TOC entry 5226 (class 0 OID 0)
-- Dependencies: 276
-- Name: TABLE mfa_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.mfa_challenges TO postgres;
GRANT SELECT ON TABLE auth.mfa_challenges TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_challenges TO dashboard_user;


--
-- TOC entry 5228 (class 0 OID 0)
-- Dependencies: 275
-- Name: TABLE mfa_factors; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.mfa_factors TO postgres;
GRANT SELECT ON TABLE auth.mfa_factors TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_factors TO dashboard_user;


--
-- TOC entry 5229 (class 0 OID 0)
-- Dependencies: 284
-- Name: TABLE oauth_clients; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_clients TO postgres;
GRANT ALL ON TABLE auth.oauth_clients TO dashboard_user;


--
-- TOC entry 5230 (class 0 OID 0)
-- Dependencies: 283
-- Name: TABLE one_time_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.one_time_tokens TO postgres;
GRANT SELECT ON TABLE auth.one_time_tokens TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.one_time_tokens TO dashboard_user;


--
-- TOC entry 5232 (class 0 OID 0)
-- Dependencies: 236
-- Name: TABLE refresh_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.refresh_tokens TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.refresh_tokens TO postgres;
GRANT SELECT ON TABLE auth.refresh_tokens TO postgres WITH GRANT OPTION;


--
-- TOC entry 5234 (class 0 OID 0)
-- Dependencies: 235
-- Name: SEQUENCE refresh_tokens_id_seq; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO dashboard_user;
GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO postgres;


--
-- TOC entry 5236 (class 0 OID 0)
-- Dependencies: 280
-- Name: TABLE saml_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.saml_providers TO postgres;
GRANT SELECT ON TABLE auth.saml_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_providers TO dashboard_user;


--
-- TOC entry 5238 (class 0 OID 0)
-- Dependencies: 281
-- Name: TABLE saml_relay_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.saml_relay_states TO postgres;
GRANT SELECT ON TABLE auth.saml_relay_states TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_relay_states TO dashboard_user;


--
-- TOC entry 5240 (class 0 OID 0)
-- Dependencies: 239
-- Name: TABLE schema_migrations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE auth.schema_migrations TO postgres WITH GRANT OPTION;


--
-- TOC entry 5243 (class 0 OID 0)
-- Dependencies: 274
-- Name: TABLE sessions; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.sessions TO postgres;
GRANT SELECT ON TABLE auth.sessions TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sessions TO dashboard_user;


--
-- TOC entry 5245 (class 0 OID 0)
-- Dependencies: 279
-- Name: TABLE sso_domains; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.sso_domains TO postgres;
GRANT SELECT ON TABLE auth.sso_domains TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_domains TO dashboard_user;


--
-- TOC entry 5248 (class 0 OID 0)
-- Dependencies: 278
-- Name: TABLE sso_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.sso_providers TO postgres;
GRANT SELECT ON TABLE auth.sso_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_providers TO dashboard_user;


--
-- TOC entry 5251 (class 0 OID 0)
-- Dependencies: 234
-- Name: TABLE users; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.users TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.users TO postgres;
GRANT SELECT ON TABLE auth.users TO postgres WITH GRANT OPTION;


--
-- TOC entry 5252 (class 0 OID 0)
-- Dependencies: 244
-- Name: TABLE pg_stat_statements; Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON TABLE extensions.pg_stat_statements TO postgres WITH GRANT OPTION;


--
-- TOC entry 5253 (class 0 OID 0)
-- Dependencies: 243
-- Name: TABLE pg_stat_statements_info; Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON TABLE extensions.pg_stat_statements_info TO postgres WITH GRANT OPTION;


--
-- TOC entry 5279 (class 0 OID 0)
-- Dependencies: 306
-- Name: TABLE agent_orchestrations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.agent_orchestrations TO anon;
GRANT ALL ON TABLE public.agent_orchestrations TO authenticated;
GRANT ALL ON TABLE public.agent_orchestrations TO service_role;


--
-- TOC entry 5287 (class 0 OID 0)
-- Dependencies: 304
-- Name: TABLE agents; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.agents TO anon;
GRANT ALL ON TABLE public.agents TO authenticated;
GRANT ALL ON TABLE public.agents TO service_role;


--
-- TOC entry 5288 (class 0 OID 0)
-- Dependencies: 310
-- Name: TABLE assets; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.assets TO anon;
GRANT ALL ON TABLE public.assets TO authenticated;
GRANT ALL ON TABLE public.assets TO service_role;


--
-- TOC entry 5289 (class 0 OID 0)
-- Dependencies: 286
-- Name: TABLE cidafm_commands; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.cidafm_commands TO anon;
GRANT ALL ON TABLE public.cidafm_commands TO authenticated;
GRANT ALL ON TABLE public.cidafm_commands TO service_role;


--
-- TOC entry 5290 (class 0 OID 0)
-- Dependencies: 287
-- Name: TABLE companies; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.companies TO anon;
GRANT ALL ON TABLE public.companies TO authenticated;
GRANT ALL ON TABLE public.companies TO service_role;


--
-- TOC entry 5292 (class 0 OID 0)
-- Dependencies: 288
-- Name: TABLE conversations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.conversations TO anon;
GRANT ALL ON TABLE public.conversations TO authenticated;
GRANT ALL ON TABLE public.conversations TO service_role;


--
-- TOC entry 5293 (class 0 OID 0)
-- Dependencies: 289
-- Name: TABLE tasks; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tasks TO anon;
GRANT ALL ON TABLE public.tasks TO authenticated;
GRANT ALL ON TABLE public.tasks TO service_role;


--
-- TOC entry 5294 (class 0 OID 0)
-- Dependencies: 313
-- Name: TABLE conversations_with_stats; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.conversations_with_stats TO anon;
GRANT ALL ON TABLE public.conversations_with_stats TO authenticated;
GRANT ALL ON TABLE public.conversations_with_stats TO service_role;


--
-- TOC entry 5295 (class 0 OID 0)
-- Dependencies: 290
-- Name: TABLE deliverable_versions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.deliverable_versions TO anon;
GRANT ALL ON TABLE public.deliverable_versions TO authenticated;
GRANT ALL ON TABLE public.deliverable_versions TO service_role;


--
-- TOC entry 5296 (class 0 OID 0)
-- Dependencies: 291
-- Name: TABLE deliverables; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.deliverables TO anon;
GRANT ALL ON TABLE public.deliverables TO authenticated;
GRANT ALL ON TABLE public.deliverables TO service_role;


--
-- TOC entry 5297 (class 0 OID 0)
-- Dependencies: 292
-- Name: TABLE departments; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.departments TO anon;
GRANT ALL ON TABLE public.departments TO authenticated;
GRANT ALL ON TABLE public.departments TO service_role;


--
-- TOC entry 5298 (class 0 OID 0)
-- Dependencies: 308
-- Name: TABLE human_approvals; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.human_approvals TO anon;
GRANT ALL ON TABLE public.human_approvals TO authenticated;
GRANT ALL ON TABLE public.human_approvals TO service_role;


--
-- TOC entry 5299 (class 0 OID 0)
-- Dependencies: 293
-- Name: TABLE kpi_data; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.kpi_data TO anon;
GRANT ALL ON TABLE public.kpi_data TO authenticated;
GRANT ALL ON TABLE public.kpi_data TO service_role;


--
-- TOC entry 5300 (class 0 OID 0)
-- Dependencies: 294
-- Name: TABLE kpi_goals; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.kpi_goals TO anon;
GRANT ALL ON TABLE public.kpi_goals TO authenticated;
GRANT ALL ON TABLE public.kpi_goals TO service_role;


--
-- TOC entry 5301 (class 0 OID 0)
-- Dependencies: 295
-- Name: TABLE kpi_metrics; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.kpi_metrics TO anon;
GRANT ALL ON TABLE public.kpi_metrics TO authenticated;
GRANT ALL ON TABLE public.kpi_metrics TO service_role;


--
-- TOC entry 5302 (class 0 OID 0)
-- Dependencies: 296
-- Name: TABLE llm_models; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.llm_models TO anon;
GRANT ALL ON TABLE public.llm_models TO authenticated;
GRANT ALL ON TABLE public.llm_models TO service_role;


--
-- TOC entry 5303 (class 0 OID 0)
-- Dependencies: 297
-- Name: TABLE llm_providers; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.llm_providers TO anon;
GRANT ALL ON TABLE public.llm_providers TO authenticated;
GRANT ALL ON TABLE public.llm_providers TO service_role;


--
-- TOC entry 5306 (class 0 OID 0)
-- Dependencies: 298
-- Name: TABLE llm_usage; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.llm_usage TO anon;
GRANT ALL ON TABLE public.llm_usage TO authenticated;
GRANT ALL ON TABLE public.llm_usage TO service_role;


--
-- TOC entry 5307 (class 0 OID 0)
-- Dependencies: 309
-- Name: TABLE llm_usage_analytics; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.llm_usage_analytics TO anon;
GRANT ALL ON TABLE public.llm_usage_analytics TO authenticated;
GRANT ALL ON TABLE public.llm_usage_analytics TO service_role;


--
-- TOC entry 5313 (class 0 OID 0)
-- Dependencies: 307
-- Name: TABLE orchestration_runs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.orchestration_runs TO anon;
GRANT ALL ON TABLE public.orchestration_runs TO authenticated;
GRANT ALL ON TABLE public.orchestration_runs TO service_role;


--
-- TOC entry 5315 (class 0 OID 0)
-- Dependencies: 305
-- Name: TABLE organization_credentials; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.organization_credentials TO anon;
GRANT ALL ON TABLE public.organization_credentials TO authenticated;
GRANT ALL ON TABLE public.organization_credentials TO service_role;


--
-- TOC entry 5320 (class 0 OID 0)
-- Dependencies: 312
-- Name: TABLE plan_versions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.plan_versions TO anon;
GRANT ALL ON TABLE public.plan_versions TO authenticated;
GRANT ALL ON TABLE public.plan_versions TO service_role;


--
-- TOC entry 5324 (class 0 OID 0)
-- Dependencies: 311
-- Name: TABLE plans; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.plans TO anon;
GRANT ALL ON TABLE public.plans TO authenticated;
GRANT ALL ON TABLE public.plans TO service_role;


--
-- TOC entry 5325 (class 0 OID 0)
-- Dependencies: 299
-- Name: TABLE pseudonym_dictionaries; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.pseudonym_dictionaries TO anon;
GRANT ALL ON TABLE public.pseudonym_dictionaries TO authenticated;
GRANT ALL ON TABLE public.pseudonym_dictionaries TO service_role;


--
-- TOC entry 5326 (class 0 OID 0)
-- Dependencies: 300
-- Name: TABLE redaction_patterns; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.redaction_patterns TO anon;
GRANT ALL ON TABLE public.redaction_patterns TO authenticated;
GRANT ALL ON TABLE public.redaction_patterns TO service_role;


--
-- TOC entry 5328 (class 0 OID 0)
-- Dependencies: 301
-- Name: TABLE system_settings; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.system_settings TO anon;
GRANT ALL ON TABLE public.system_settings TO authenticated;
GRANT ALL ON TABLE public.system_settings TO service_role;


--
-- TOC entry 5329 (class 0 OID 0)
-- Dependencies: 302
-- Name: TABLE user_cidafm_commands; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_cidafm_commands TO anon;
GRANT ALL ON TABLE public.user_cidafm_commands TO authenticated;
GRANT ALL ON TABLE public.user_cidafm_commands TO service_role;


--
-- TOC entry 5331 (class 0 OID 0)
-- Dependencies: 303
-- Name: TABLE users; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.users TO anon;
GRANT ALL ON TABLE public.users TO authenticated;
GRANT ALL ON TABLE public.users TO service_role;


--
-- TOC entry 5332 (class 0 OID 0)
-- Dependencies: 265
-- Name: TABLE messages; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE realtime.messages TO postgres;
GRANT ALL ON TABLE realtime.messages TO dashboard_user;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO anon;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO authenticated;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO service_role;


--
-- TOC entry 5333 (class 0 OID 0)
-- Dependencies: 266
-- Name: TABLE messages_2025_10_08; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_10_08 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_10_08 TO dashboard_user;


--
-- TOC entry 5334 (class 0 OID 0)
-- Dependencies: 267
-- Name: TABLE messages_2025_10_09; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_10_09 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_10_09 TO dashboard_user;


--
-- TOC entry 5335 (class 0 OID 0)
-- Dependencies: 268
-- Name: TABLE messages_2025_10_10; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_10_10 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_10_10 TO dashboard_user;


--
-- TOC entry 5336 (class 0 OID 0)
-- Dependencies: 269
-- Name: TABLE messages_2025_10_11; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_10_11 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_10_11 TO dashboard_user;


--
-- TOC entry 5337 (class 0 OID 0)
-- Dependencies: 270
-- Name: TABLE messages_2025_10_12; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_10_12 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_10_12 TO dashboard_user;


--
-- TOC entry 5338 (class 0 OID 0)
-- Dependencies: 259
-- Name: TABLE schema_migrations; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.schema_migrations TO postgres;
GRANT ALL ON TABLE realtime.schema_migrations TO dashboard_user;
GRANT SELECT ON TABLE realtime.schema_migrations TO anon;
GRANT SELECT ON TABLE realtime.schema_migrations TO authenticated;
GRANT SELECT ON TABLE realtime.schema_migrations TO service_role;
GRANT ALL ON TABLE realtime.schema_migrations TO supabase_realtime_admin;


--
-- TOC entry 5339 (class 0 OID 0)
-- Dependencies: 262
-- Name: TABLE subscription; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.subscription TO postgres;
GRANT ALL ON TABLE realtime.subscription TO dashboard_user;
GRANT SELECT ON TABLE realtime.subscription TO anon;
GRANT SELECT ON TABLE realtime.subscription TO authenticated;
GRANT SELECT ON TABLE realtime.subscription TO service_role;
GRANT ALL ON TABLE realtime.subscription TO supabase_realtime_admin;


--
-- TOC entry 5340 (class 0 OID 0)
-- Dependencies: 261
-- Name: SEQUENCE subscription_id_seq; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO postgres;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO dashboard_user;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO anon;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO authenticated;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO service_role;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO supabase_realtime_admin;


--
-- TOC entry 5342 (class 0 OID 0)
-- Dependencies: 240
-- Name: TABLE buckets; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.buckets TO anon;
GRANT ALL ON TABLE storage.buckets TO authenticated;
GRANT ALL ON TABLE storage.buckets TO service_role;
GRANT ALL ON TABLE storage.buckets TO postgres;


--
-- TOC entry 5343 (class 0 OID 0)
-- Dependencies: 318
-- Name: TABLE buckets_analytics; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.buckets_analytics TO service_role;
GRANT ALL ON TABLE storage.buckets_analytics TO authenticated;
GRANT ALL ON TABLE storage.buckets_analytics TO anon;


--
-- TOC entry 5344 (class 0 OID 0)
-- Dependencies: 319
-- Name: TABLE iceberg_namespaces; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.iceberg_namespaces TO service_role;
GRANT SELECT ON TABLE storage.iceberg_namespaces TO authenticated;
GRANT SELECT ON TABLE storage.iceberg_namespaces TO anon;


--
-- TOC entry 5345 (class 0 OID 0)
-- Dependencies: 320
-- Name: TABLE iceberg_tables; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.iceberg_tables TO service_role;
GRANT SELECT ON TABLE storage.iceberg_tables TO authenticated;
GRANT SELECT ON TABLE storage.iceberg_tables TO anon;


--
-- TOC entry 5347 (class 0 OID 0)
-- Dependencies: 241
-- Name: TABLE objects; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.objects TO anon;
GRANT ALL ON TABLE storage.objects TO authenticated;
GRANT ALL ON TABLE storage.objects TO service_role;
GRANT ALL ON TABLE storage.objects TO postgres;


--
-- TOC entry 5348 (class 0 OID 0)
-- Dependencies: 317
-- Name: TABLE prefixes; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.prefixes TO service_role;
GRANT ALL ON TABLE storage.prefixes TO authenticated;
GRANT ALL ON TABLE storage.prefixes TO anon;


--
-- TOC entry 5349 (class 0 OID 0)
-- Dependencies: 271
-- Name: TABLE s3_multipart_uploads; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO anon;


--
-- TOC entry 5350 (class 0 OID 0)
-- Dependencies: 272
-- Name: TABLE s3_multipart_uploads_parts; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads_parts TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO anon;


--
-- TOC entry 5352 (class 0 OID 0)
-- Dependencies: 255
-- Name: TABLE hooks; Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

GRANT ALL ON TABLE supabase_functions.hooks TO postgres;
GRANT ALL ON TABLE supabase_functions.hooks TO anon;
GRANT ALL ON TABLE supabase_functions.hooks TO authenticated;
GRANT ALL ON TABLE supabase_functions.hooks TO service_role;


--
-- TOC entry 5354 (class 0 OID 0)
-- Dependencies: 254
-- Name: SEQUENCE hooks_id_seq; Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO postgres;
GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO anon;
GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO authenticated;
GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO service_role;


--
-- TOC entry 5355 (class 0 OID 0)
-- Dependencies: 253
-- Name: TABLE migrations; Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

GRANT ALL ON TABLE supabase_functions.migrations TO postgres;
GRANT ALL ON TABLE supabase_functions.migrations TO anon;
GRANT ALL ON TABLE supabase_functions.migrations TO authenticated;
GRANT ALL ON TABLE supabase_functions.migrations TO service_role;


--
-- TOC entry 5356 (class 0 OID 0)
-- Dependencies: 245
-- Name: TABLE secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.secrets TO service_role;


--
-- TOC entry 5357 (class 0 OID 0)
-- Dependencies: 246
-- Name: TABLE decrypted_secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.decrypted_secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.decrypted_secrets TO service_role;


--
-- TOC entry 2735 (class 826 OID 16597)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES  TO dashboard_user;


--
-- TOC entry 2736 (class 826 OID 16598)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS  TO dashboard_user;


--
-- TOC entry 2734 (class 826 OID 16596)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES  TO dashboard_user;


--
-- TOC entry 2745 (class 826 OID 16671)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON SEQUENCES  TO postgres WITH GRANT OPTION;


--
-- TOC entry 2744 (class 826 OID 16670)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON FUNCTIONS  TO postgres WITH GRANT OPTION;


--
-- TOC entry 2743 (class 826 OID 16669)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON TABLES  TO postgres WITH GRANT OPTION;


--
-- TOC entry 2748 (class 826 OID 16631)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES  TO service_role;


--
-- TOC entry 2747 (class 826 OID 16630)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS  TO service_role;


--
-- TOC entry 2746 (class 826 OID 16629)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES  TO service_role;


--
-- TOC entry 2740 (class 826 OID 16611)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES  TO service_role;


--
-- TOC entry 2742 (class 826 OID 16610)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS  TO service_role;


--
-- TOC entry 2741 (class 826 OID 16609)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES  TO service_role;


--
-- TOC entry 2756 (class 826 OID 19031)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: n8n; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA n8n GRANT ALL ON SEQUENCES  TO postgres;


--
-- TOC entry 2755 (class 826 OID 19030)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: n8n; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA n8n GRANT ALL ON TABLES  TO postgres;


--
-- TOC entry 2752 (class 826 OID 16453)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES  TO service_role;


--
-- TOC entry 2728 (class 826 OID 16454)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES  TO service_role;


--
-- TOC entry 2753 (class 826 OID 16452)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS  TO service_role;


--
-- TOC entry 2730 (class 826 OID 16456)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS  TO service_role;


--
-- TOC entry 2754 (class 826 OID 16451)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES  TO service_role;


--
-- TOC entry 2729 (class 826 OID 16455)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES  TO service_role;


--
-- TOC entry 2738 (class 826 OID 16601)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES  TO dashboard_user;


--
-- TOC entry 2739 (class 826 OID 16602)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS  TO dashboard_user;


--
-- TOC entry 2737 (class 826 OID 16600)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES  TO dashboard_user;


--
-- TOC entry 2733 (class 826 OID 16508)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES  TO service_role;


--
-- TOC entry 2732 (class 826 OID 16507)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS  TO service_role;


--
-- TOC entry 2731 (class 826 OID 16506)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES  TO service_role;


--
-- TOC entry 2751 (class 826 OID 16733)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: supabase_functions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES  TO service_role;


--
-- TOC entry 2750 (class 826 OID 16732)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: supabase_functions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS  TO service_role;


--
-- TOC entry 2749 (class 826 OID 16731)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: supabase_functions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES  TO service_role;


--
-- TOC entry 3922 (class 3466 OID 16615)
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


ALTER EVENT TRIGGER issue_graphql_placeholder OWNER TO supabase_admin;

--
-- TOC entry 3927 (class 3466 OID 16684)
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


ALTER EVENT TRIGGER issue_pg_cron_access OWNER TO supabase_admin;

--
-- TOC entry 3921 (class 3466 OID 16613)
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


ALTER EVENT TRIGGER issue_pg_graphql_access OWNER TO supabase_admin;

--
-- TOC entry 3928 (class 3466 OID 16685)
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


ALTER EVENT TRIGGER issue_pg_net_access OWNER TO supabase_admin;

--
-- TOC entry 3923 (class 3466 OID 16616)
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


ALTER EVENT TRIGGER pgrst_ddl_watch OWNER TO supabase_admin;

--
-- TOC entry 3924 (class 3466 OID 16617)
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


ALTER EVENT TRIGGER pgrst_drop_watch OWNER TO supabase_admin;

-- Completed on 2025-10-09 21:28:14 UTC

--
-- PostgreSQL database dump complete
--

