--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-10-12 12:14:50 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS postgres;
--
-- TOC entry 4677 (class 1262 OID 5)
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = icu LOCALE = 'en_US.UTF-8' ICU_LOCALE = 'en-US';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4678 (class 0 OID 0)
-- Dependencies: 4677
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- TOC entry 4680 (class 0 OID 0)
-- Name: postgres; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE postgres SET "app.settings.jwt_secret" TO 'super-secret-jwt-token-with-at-least-32-characters-long';
ALTER DATABASE postgres SET "app.settings.jwt_exp" TO '3600';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 10 (class 2615 OID 16706)
-- Name: _realtime; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA _realtime;


ALTER SCHEMA _realtime OWNER TO postgres;

--
-- TOC entry 23 (class 2615 OID 16457)
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO supabase_admin;

--
-- TOC entry 25 (class 2615 OID 18864)
-- Name: company; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA company;


ALTER SCHEMA company OWNER TO postgres;

--
-- TOC entry 4682 (class 0 OID 0)
-- Dependencies: 25
-- Name: SCHEMA company; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA company IS 'Company-related data including organizations, departments, and KPI metrics';


--
-- TOC entry 16 (class 2615 OID 16394)
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA extensions;


ALTER SCHEMA extensions OWNER TO postgres;

--
-- TOC entry 22 (class 2615 OID 16624)
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql;


ALTER SCHEMA graphql OWNER TO supabase_admin;

--
-- TOC entry 21 (class 2615 OID 16613)
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql_public;


ALTER SCHEMA graphql_public OWNER TO supabase_admin;

--
-- TOC entry 15 (class 2615 OID 16779)
-- Name: n8n; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA n8n;


ALTER SCHEMA n8n OWNER TO postgres;

--
-- TOC entry 7 (class 3079 OID 16707)
-- Name: pg_net; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;


--
-- TOC entry 4685 (class 0 OID 0)
-- Dependencies: 7
-- Name: EXTENSION pg_net; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_net IS 'Async HTTP';


--
-- TOC entry 12 (class 2615 OID 16386)
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA pgbouncer;


ALTER SCHEMA pgbouncer OWNER TO pgbouncer;

--
-- TOC entry 17 (class 2615 OID 16605)
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA realtime;


ALTER SCHEMA realtime OWNER TO supabase_admin;

--
-- TOC entry 24 (class 2615 OID 16505)
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA storage;


ALTER SCHEMA storage OWNER TO supabase_admin;

--
-- TOC entry 13 (class 2615 OID 16750)
-- Name: supabase_functions; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA supabase_functions;


ALTER SCHEMA supabase_functions OWNER TO supabase_admin;

--
-- TOC entry 18 (class 2615 OID 18231)
-- Name: supabase_migrations; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA supabase_migrations;


ALTER SCHEMA supabase_migrations OWNER TO postgres;

--
-- TOC entry 19 (class 2615 OID 16653)
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA vault;


ALTER SCHEMA vault OWNER TO supabase_admin;

--
-- TOC entry 6 (class 3079 OID 16689)
-- Name: pg_graphql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_graphql WITH SCHEMA graphql;


--
-- TOC entry 4692 (class 0 OID 0)
-- Dependencies: 6
-- Name: EXTENSION pg_graphql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_graphql IS 'pg_graphql: GraphQL support';


--
-- TOC entry 4 (class 3079 OID 16565)
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- TOC entry 4693 (class 0 OID 0)
-- Dependencies: 4
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- TOC entry 3 (class 3079 OID 16406)
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- TOC entry 4694 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- TOC entry 5 (class 3079 OID 16654)
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- TOC entry 4695 (class 0 OID 0)
-- Dependencies: 5
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- TOC entry 2 (class 3079 OID 16395)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- TOC entry 4696 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 1220 (class 1247 OID 18010)
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE auth.aal_level OWNER TO supabase_auth_admin;

--
-- TOC entry 1244 (class 1247 OID 18151)
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


ALTER TYPE auth.code_challenge_method OWNER TO supabase_auth_admin;

--
-- TOC entry 1217 (class 1247 OID 18004)
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE auth.factor_status OWNER TO supabase_auth_admin;

--
-- TOC entry 1214 (class 1247 OID 17999)
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE auth.factor_type OWNER TO supabase_auth_admin;

--
-- TOC entry 1250 (class 1247 OID 18193)
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE auth.one_time_token_type OWNER TO supabase_auth_admin;

--
-- TOC entry 1160 (class 1247 OID 17568)
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE realtime.action OWNER TO supabase_admin;

--
-- TOC entry 1151 (class 1247 OID 17528)
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


ALTER TYPE realtime.equality_op OWNER TO supabase_admin;

--
-- TOC entry 1154 (class 1247 OID 17543)
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text
);


ALTER TYPE realtime.user_defined_filter OWNER TO supabase_admin;

--
-- TOC entry 1166 (class 1247 OID 17610)
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


ALTER TYPE realtime.wal_column OWNER TO supabase_admin;

--
-- TOC entry 1163 (class 1247 OID 17581)
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


ALTER TYPE realtime.wal_rls OWNER TO supabase_admin;

--
-- TOC entry 1196 (class 1247 OID 17880)
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS'
);


ALTER TYPE storage.buckettype OWNER TO supabase_storage_admin;

--
-- TOC entry 471 (class 1255 OID 16503)
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION auth.email() OWNER TO supabase_auth_admin;

--
-- TOC entry 4697 (class 0 OID 0)
-- Dependencies: 471
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- TOC entry 368 (class 1255 OID 17981)
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION auth.jwt() OWNER TO supabase_auth_admin;

--
-- TOC entry 403 (class 1255 OID 16502)
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION auth.role() OWNER TO supabase_auth_admin;

--
-- TOC entry 4700 (class 0 OID 0)
-- Dependencies: 403
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- TOC entry 400 (class 1255 OID 16501)
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION auth.uid() OWNER TO supabase_auth_admin;

--
-- TOC entry 4702 (class 0 OID 0)
-- Dependencies: 400
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- TOC entry 467 (class 1255 OID 16560)
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_cron_access() OWNER TO supabase_admin;

--
-- TOC entry 4718 (class 0 OID 0)
-- Dependencies: 467
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- TOC entry 450 (class 1255 OID 16618)
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN
        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        DROP FUNCTION IF EXISTS graphql_public.graphql;
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

        -- This hook executes when `graphql.resolve` is created. That is not necessarily the last
        -- function in the extension so we need to grant permissions on existing entities AND
        -- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;

        -- Allow postgres role to allow granting usage on graphql and graphql_public schemas to custom roles
        grant usage on schema graphql_public to postgres with grant option;
        grant usage on schema graphql to postgres with grant option;
    END IF;

END;
$_$;


ALTER FUNCTION extensions.grant_pg_graphql_access() OWNER TO supabase_admin;

--
-- TOC entry 4720 (class 0 OID 0)
-- Dependencies: 450
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- TOC entry 387 (class 1255 OID 16562)
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
    ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

    ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
    ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

    REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
    REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

    GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_net_access() OWNER TO supabase_admin;

--
-- TOC entry 4722 (class 0 OID 0)
-- Dependencies: 387
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- TOC entry 411 (class 1255 OID 16609)
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_ddl_watch() OWNER TO supabase_admin;

--
-- TOC entry 382 (class 1255 OID 16610)
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_drop_watch() OWNER TO supabase_admin;

--
-- TOC entry 419 (class 1255 OID 16620)
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION extensions.set_graphql_placeholder() OWNER TO supabase_admin;

--
-- TOC entry 4751 (class 0 OID 0)
-- Dependencies: 419
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- TOC entry 440 (class 1255 OID 16387)
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $_$
begin
    raise debug 'PgBouncer auth request: %', p_usename;

    return query
    select 
        rolname::text, 
        case when rolvaliduntil < now() 
            then null 
            else rolpassword::text 
        end 
    from pg_authid 
    where rolname=$1 and rolcanlogin;
end;
$_$;


ALTER FUNCTION pgbouncer.get_auth(p_usename text) OWNER TO supabase_admin;

--
-- TOC entry 435 (class 1255 OID 18239)
-- Name: calculate_completion_percentage(jsonb); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.calculate_completion_percentage(requirements jsonb) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    total_fields INTEGER := 12;  -- Total required fields
    completed_fields INTEGER := 0;
    field_name TEXT;
BEGIN
    -- Count non-null, non-empty required fields
    FOR field_name IN SELECT * FROM jsonb_object_keys(requirements)
    LOOP
        IF requirements ->> field_name IS NOT NULL 
           AND LENGTH(TRIM(requirements ->> field_name)) > 0 THEN
            completed_fields := completed_fields + 1;
        END IF;
    END LOOP;
    
    RETURN (completed_fields * 100 / total_fields);
END;
$$;


ALTER FUNCTION public.calculate_completion_percentage(requirements jsonb) OWNER TO postgres;

--
-- TOC entry 329 (class 1255 OID 18240)
-- Name: cleanup_abandoned_conversations(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cleanup_abandoned_conversations() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    -- Delete conversations abandoned for more than 7 days
    DELETE FROM agent_creation_conversations
    WHERE completion_status = 'in_progress'
      AND last_activity_at < NOW() - INTERVAL '7 days';
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$;


ALTER FUNCTION public.cleanup_abandoned_conversations() OWNER TO postgres;

--
-- TOC entry 428 (class 1255 OID 18859)
-- Name: cleanup_old_jokes(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cleanup_old_jokes() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM jokes_agent 
    WHERE created_at < NOW() - INTERVAL '30 days';
END;
$$;


ALTER FUNCTION public.cleanup_old_jokes() OWNER TO postgres;

--
-- TOC entry 447 (class 1255 OID 18241)
-- Name: exec_sql(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.exec_sql(query text DEFAULT NULL::text, sql_query text DEFAULT NULL::text) RETURNS SETOF jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  q text := coalesce(query, sql_query);
  r record;
begin
  if q is null or length(trim(q)) = 0 then
    raise exception 'No SQL provided to exec_sql()';
  end if;

  -- Execute the query and stream rows as JSONB
  for r in execute q loop
    return next to_jsonb(r);
  end loop;
  return;

exception when others then
  -- Return a single JSON object describing the error (so callers get structured feedback)
  return query select jsonb_build_object(
    'error', true,
    'message', sqlerrm,
    'code', sqlstate
  );
end;
$$;


ALTER FUNCTION public.exec_sql(query text, sql_query text) OWNER TO postgres;

--
-- TOC entry 363 (class 1255 OID 18242)
-- Name: get_global_model_config(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_global_model_config() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  SELECT value FROM public.system_settings WHERE key = 'model_config_global';
$$;


ALTER FUNCTION public.get_global_model_config() OWNER TO postgres;

--
-- TOC entry 469 (class 1255 OID 18243)
-- Name: log_agent_action(character varying, uuid, jsonb, jsonb, jsonb, boolean, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.log_agent_action(p_action character varying, p_agent_id uuid, p_details jsonb DEFAULT '{}'::jsonb, p_previous_state jsonb DEFAULT NULL::jsonb, p_new_state jsonb DEFAULT NULL::jsonb, p_success boolean DEFAULT true, p_error_message text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    log_id UUID;
BEGIN
    INSERT INTO agent_creation_logs (
        action, agent_configuration_id, performed_by, details,
        previous_state, new_state, success, error_message
    ) VALUES (
        p_action, p_agent_id, auth.uid(), p_details,
        p_previous_state, p_new_state, p_success, p_error_message
    ) RETURNING id INTO log_id;
    
    RETURN log_id;
END;
$$;


ALTER FUNCTION public.log_agent_action(p_action character varying, p_agent_id uuid, p_details jsonb, p_previous_state jsonb, p_new_state jsonb, p_success boolean, p_error_message text) OWNER TO postgres;

--
-- TOC entry 4772 (class 0 OID 0)
-- Dependencies: 469
-- Name: FUNCTION log_agent_action(p_action character varying, p_agent_id uuid, p_details jsonb, p_previous_state jsonb, p_new_state jsonb, p_success boolean, p_error_message text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.log_agent_action(p_action character varying, p_agent_id uuid, p_details jsonb, p_previous_state jsonb, p_new_state jsonb, p_success boolean, p_error_message text) IS 'Helper function to create audit log entries';


--
-- TOC entry 361 (class 1255 OID 18998)
-- Name: set_timestamp_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_timestamp_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_timestamp_updated_at() OWNER TO postgres;

--
-- TOC entry 345 (class 1255 OID 18244)
-- Name: update_agent_configurations_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_agent_configurations_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_agent_configurations_updated_at() OWNER TO postgres;

--
-- TOC entry 330 (class 1255 OID 18245)
-- Name: update_agent_skills_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_agent_skills_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_agent_skills_updated_at() OWNER TO postgres;

--
-- TOC entry 454 (class 1255 OID 18246)
-- Name: update_agent_usage_analytics(uuid, integer, integer, integer, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_agent_usage_analytics(p_agent_id uuid, p_conversation_increment integer DEFAULT 0, p_message_increment integer DEFAULT 0, p_response_time_ms integer DEFAULT NULL::integer, p_error_increment integer DEFAULT 0, p_unique_user_increment integer DEFAULT 0) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO agent_usage_analytics (
        agent_configuration_id, agent_id, date_period,
        conversation_count, message_count, error_count, unique_users
    ) VALUES (
        p_agent_id, 
        (SELECT agent_id FROM agent_configurations WHERE id = p_agent_id),
        CURRENT_DATE,
        p_conversation_increment, p_message_increment, p_error_increment, p_unique_user_increment
    )
    ON CONFLICT (agent_configuration_id, date_period) 
    DO UPDATE SET
        conversation_count = agent_usage_analytics.conversation_count + p_conversation_increment,
        message_count = agent_usage_analytics.message_count + p_message_increment,
        error_count = agent_usage_analytics.error_count + p_error_increment,
        unique_users = agent_usage_analytics.unique_users + p_unique_user_increment,
        avg_response_time_ms = CASE 
            WHEN p_response_time_ms IS NOT NULL THEN
                COALESCE(
                    (agent_usage_analytics.avg_response_time_ms + p_response_time_ms) / 2,
                    p_response_time_ms
                )
            ELSE agent_usage_analytics.avg_response_time_ms
        END,
        last_updated = NOW();
END;
$$;


ALTER FUNCTION public.update_agent_usage_analytics(p_agent_id uuid, p_conversation_increment integer, p_message_increment integer, p_response_time_ms integer, p_error_increment integer, p_unique_user_increment integer) OWNER TO postgres;

--
-- TOC entry 4777 (class 0 OID 0)
-- Dependencies: 454
-- Name: FUNCTION update_agent_usage_analytics(p_agent_id uuid, p_conversation_increment integer, p_message_increment integer, p_response_time_ms integer, p_error_increment integer, p_unique_user_increment integer); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.update_agent_usage_analytics(p_agent_id uuid, p_conversation_increment integer, p_message_increment integer, p_response_time_ms integer, p_error_increment integer, p_unique_user_increment integer) IS 'Helper function to update daily usage stats';


--
-- TOC entry 451 (class 1255 OID 18247)
-- Name: update_completion_percentage(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_completion_percentage() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.completion_percentage = calculate_completion_percentage(NEW.requirements_gathered);
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_completion_percentage() OWNER TO postgres;

--
-- TOC entry 399 (class 1255 OID 18248)
-- Name: update_conversation_timestamps(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_conversation_timestamps() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    NEW.last_activity_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_conversation_timestamps() OWNER TO postgres;

--
-- TOC entry 421 (class 1255 OID 18249)
-- Name: update_creation_metrics(boolean, integer, integer, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_creation_metrics(p_success boolean, p_creation_time_seconds integer DEFAULT NULL::integer, p_questions_answered integer DEFAULT NULL::integer, p_department character varying DEFAULT NULL::character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    current_hour INTEGER;
    dept_breakdown JSONB;
BEGIN
    current_hour := EXTRACT(hour FROM NOW());
    
    -- Get current department breakdown or initialize
    SELECT department_breakdown INTO dept_breakdown
    FROM agent_creation_metrics
    WHERE date_period = CURRENT_DATE AND hour_period = current_hour;
    
    IF dept_breakdown IS NULL THEN
        dept_breakdown := '{}';
    END IF;
    
    -- Update department count
    IF p_department IS NOT NULL THEN
        dept_breakdown := jsonb_set(
            dept_breakdown,
            ARRAY[p_department],
            to_jsonb(COALESCE((dept_breakdown ->> p_department)::INTEGER, 0) + 1)
        );
    END IF;
    
    INSERT INTO agent_creation_metrics (
        date_period, hour_period, total_attempts,
        successful_creations, failed_creations,
        avg_creation_time_seconds, avg_questions_to_completion,
        department_breakdown
    ) VALUES (
        CURRENT_DATE, current_hour, 1,
        CASE WHEN p_success THEN 1 ELSE 0 END,
        CASE WHEN p_success THEN 0 ELSE 1 END,
        p_creation_time_seconds, p_questions_answered,
        dept_breakdown
    )
    ON CONFLICT (date_period, hour_period)
    DO UPDATE SET
        total_attempts = agent_creation_metrics.total_attempts + 1,
        successful_creations = agent_creation_metrics.successful_creations + 
            CASE WHEN p_success THEN 1 ELSE 0 END,
        failed_creations = agent_creation_metrics.failed_creations + 
            CASE WHEN p_success THEN 0 ELSE 1 END,
        avg_creation_time_seconds = CASE 
            WHEN p_creation_time_seconds IS NOT NULL THEN
                COALESCE(
                    (agent_creation_metrics.avg_creation_time_seconds + p_creation_time_seconds) / 2,
                    p_creation_time_seconds
                )
            ELSE agent_creation_metrics.avg_creation_time_seconds
        END,
        avg_questions_to_completion = CASE 
            WHEN p_questions_answered IS NOT NULL THEN
                COALESCE(
                    (agent_creation_metrics.avg_questions_to_completion + p_questions_answered) / 2.0,
                    p_questions_answered::DECIMAL
                )
            ELSE agent_creation_metrics.avg_questions_to_completion
        END,
        department_breakdown = dept_breakdown,
        last_updated = NOW();
END;
$$;


ALTER FUNCTION public.update_creation_metrics(p_success boolean, p_creation_time_seconds integer, p_questions_answered integer, p_department character varying) OWNER TO postgres;

--
-- TOC entry 4781 (class 0 OID 0)
-- Dependencies: 421
-- Name: FUNCTION update_creation_metrics(p_success boolean, p_creation_time_seconds integer, p_questions_answered integer, p_department character varying); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.update_creation_metrics(p_success boolean, p_creation_time_seconds integer, p_questions_answered integer, p_department character varying) IS 'Helper function to update system creation metrics';


--
-- TOC entry 427 (class 1255 OID 19144)
-- Name: update_plans_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_plans_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_plans_updated_at() OWNER TO postgres;

--
-- TOC entry 410 (class 1255 OID 18250)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

--
-- TOC entry 384 (class 1255 OID 18251)
-- Name: validate_skill_examples(jsonb); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.validate_skill_examples(examples jsonb) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    example_text TEXT;
    example_value JSONB;
BEGIN
    -- Check each example in the array
    FOR example_value IN SELECT jsonb_array_elements(examples)
    LOOP
        example_text := example_value #>> '{}';
        
        -- Ensure example is not empty or too short
        IF LENGTH(TRIM(example_text)) < 5 THEN
            RETURN FALSE;
        END IF;
        
        -- Ensure example is a reasonable length (not too long)
        IF LENGTH(example_text) > 500 THEN
            RETURN FALSE;
        END IF;
    END LOOP;
    
    RETURN TRUE;
END;
$$;


ALTER FUNCTION public.validate_skill_examples(examples jsonb) OWNER TO postgres;

--
-- TOC entry 442 (class 1255 OID 17603)
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_;

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or (
                          action = 'DELETE'
                          and realtime.is_visible_through_filters(old_columns, subs.filters)
                        )
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) OWNER TO supabase_admin;

--
-- TOC entry 423 (class 1255 OID 17682)
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) OWNER TO supabase_admin;

--
-- TOC entry 459 (class 1255 OID 17615)
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) OWNER TO supabase_admin;

--
-- TOC entry 383 (class 1255 OID 17565)
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
    declare
      res jsonb;
    begin
      execute format('select to_jsonb(%L::'|| type_::text || ')', val)  into res;
      return res;
    end
    $$;


ALTER FUNCTION realtime."cast"(val text, type_ regtype) OWNER TO supabase_admin;

--
-- TOC entry 364 (class 1255 OID 17560)
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


ALTER FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) OWNER TO supabase_admin;

--
-- TOC entry 466 (class 1255 OID 17611)
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


ALTER FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) OWNER TO supabase_admin;

--
-- TOC entry 413 (class 1255 OID 17622)
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS SETOF realtime.wal_rls
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
      with pub as (
        select
          concat_ws(
            ',',
            case when bool_or(pubinsert) then 'insert' else null end,
            case when bool_or(pubupdate) then 'update' else null end,
            case when bool_or(pubdelete) then 'delete' else null end
          ) as w2j_actions,
          coalesce(
            string_agg(
              realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
              ','
            ) filter (where ppt.tablename is not null and ppt.tablename not like '% %'),
            ''
          ) w2j_add_tables
        from
          pg_publication pp
          left join pg_publication_tables ppt
            on pp.pubname = ppt.pubname
        where
          pp.pubname = publication
        group by
          pp.pubname
        limit 1
      ),
      w2j as (
        select
          x.*, pub.w2j_add_tables
        from
          pub,
          pg_logical_slot_get_changes(
            slot_name, null, max_changes,
            'include-pk', 'true',
            'include-transaction', 'false',
            'include-timestamp', 'true',
            'include-type-oids', 'true',
            'format-version', '2',
            'actions', pub.w2j_actions,
            'add-tables', pub.w2j_add_tables
          ) x
      )
      select
        xyz.wal,
        xyz.is_rls_enabled,
        xyz.subscription_ids,
        xyz.errors
      from
        w2j,
        realtime.apply_rls(
          wal := w2j.data::jsonb,
          max_record_bytes := max_record_bytes
        ) xyz(wal, is_rls_enabled, subscription_ids, errors)
      where
        w2j.w2j_add_tables <> ''
        and xyz.subscription_ids[1] is not null
    $$;


ALTER FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) OWNER TO supabase_admin;

--
-- TOC entry 395 (class 1255 OID 17559)
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


ALTER FUNCTION realtime.quote_wal2json(entity regclass) OWNER TO supabase_admin;

--
-- TOC entry 462 (class 1255 OID 17681)
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  BEGIN
    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    -- Attempt to insert the message
    INSERT INTO realtime.messages (payload, event, topic, private, extension)
    VALUES (payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      -- Capture and notify the error
      RAISE WARNING 'ErrorSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) OWNER TO supabase_admin;

--
-- TOC entry 356 (class 1255 OID 17557)
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


ALTER FUNCTION realtime.subscription_check_filters() OWNER TO supabase_admin;

--
-- TOC entry 415 (class 1255 OID 17592)
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION realtime.to_regrole(role_name text) OWNER TO supabase_admin;

--
-- TOC entry 463 (class 1255 OID 17675)
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION realtime.topic() OWNER TO supabase_realtime_admin;

--
-- TOC entry 425 (class 1255 OID 17858)
-- Name: add_prefixes(text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.add_prefixes(_bucket_id text, _name text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    prefixes text[];
BEGIN
    prefixes := "storage"."get_prefixes"("_name");

    IF array_length(prefixes, 1) > 0 THEN
        INSERT INTO storage.prefixes (name, bucket_id)
        SELECT UNNEST(prefixes) as name, "_bucket_id" ON CONFLICT DO NOTHING;
    END IF;
END;
$$;


ALTER FUNCTION storage.add_prefixes(_bucket_id text, _name text) OWNER TO supabase_storage_admin;

--
-- TOC entry 354 (class 1255 OID 17784)
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) OWNER TO supabase_storage_admin;

--
-- TOC entry 366 (class 1255 OID 17859)
-- Name: delete_prefix(text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.delete_prefix(_bucket_id text, _name text) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    -- Check if we can delete the prefix
    IF EXISTS(
        SELECT FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name") + 1
          AND "prefixes"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    )
    OR EXISTS(
        SELECT FROM "storage"."objects"
        WHERE "objects"."bucket_id" = "_bucket_id"
          AND "storage"."get_level"("objects"."name") = "storage"."get_level"("_name") + 1
          AND "objects"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    ) THEN
    -- There are sub-objects, skip deletion
    RETURN false;
    ELSE
        DELETE FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name")
          AND "prefixes"."name" = "_name";
        RETURN true;
    END IF;
END;
$$;


ALTER FUNCTION storage.delete_prefix(_bucket_id text, _name text) OWNER TO supabase_storage_admin;

--
-- TOC entry 429 (class 1255 OID 17862)
-- Name: delete_prefix_hierarchy_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.delete_prefix_hierarchy_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    prefix text;
BEGIN
    prefix := "storage"."get_prefix"(OLD."name");

    IF coalesce(prefix, '') != '' THEN
        PERFORM "storage"."delete_prefix"(OLD."bucket_id", prefix);
    END IF;

    RETURN OLD;
END;
$$;


ALTER FUNCTION storage.delete_prefix_hierarchy_trigger() OWNER TO supabase_storage_admin;

--
-- TOC entry 407 (class 1255 OID 17877)
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION storage.enforce_bucket_name_length() OWNER TO supabase_storage_admin;

--
-- TOC entry 362 (class 1255 OID 17758)
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    SELECT _parts[array_length(_parts,1)] INTO _filename;
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION storage.extension(name text) OWNER TO supabase_storage_admin;

--
-- TOC entry 349 (class 1255 OID 17757)
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION storage.filename(name text) OWNER TO supabase_storage_admin;

--
-- TOC entry 347 (class 1255 OID 17756)
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION storage.foldername(name text) OWNER TO supabase_storage_admin;

--
-- TOC entry 344 (class 1255 OID 17840)
-- Name: get_level(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_level(name text) RETURNS integer
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
SELECT array_length(string_to_array("name", '/'), 1);
$$;


ALTER FUNCTION storage.get_level(name text) OWNER TO supabase_storage_admin;

--
-- TOC entry 445 (class 1255 OID 17856)
-- Name: get_prefix(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_prefix(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$
SELECT
    CASE WHEN strpos("name", '/') > 0 THEN
             regexp_replace("name", '[\/]{1}[^\/]+\/?$', '')
         ELSE
             ''
        END;
$_$;


ALTER FUNCTION storage.get_prefix(name text) OWNER TO supabase_storage_admin;

--
-- TOC entry 358 (class 1255 OID 17857)
-- Name: get_prefixes(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_prefixes(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $$
DECLARE
    parts text[];
    prefixes text[];
    prefix text;
BEGIN
    -- Split the name into parts by '/'
    parts := string_to_array("name", '/');
    prefixes := '{}';

    -- Construct the prefixes, stopping one level below the last part
    FOR i IN 1..array_length(parts, 1) - 1 LOOP
            prefix := array_to_string(parts[1:i], '/');
            prefixes := array_append(prefixes, prefix);
    END LOOP;

    RETURN prefixes;
END;
$$;


ALTER FUNCTION storage.get_prefixes(name text) OWNER TO supabase_storage_admin;

--
-- TOC entry 351 (class 1255 OID 17875)
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION storage.get_size_by_bucket() OWNER TO supabase_storage_admin;

--
-- TOC entry 338 (class 1255 OID 17823)
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, next_key_token text, next_upload_token text) OWNER TO supabase_storage_admin;

--
-- TOC entry 470 (class 1255 OID 17786)
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(name COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                        substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1)))
                    ELSE
                        name
                END AS name, id, metadata, updated_at
            FROM
                storage.objects
            WHERE
                bucket_id = $5 AND
                name ILIKE $1 || ''%'' AND
                CASE
                    WHEN $6 != '''' THEN
                    name COLLATE "C" > $6
                ELSE true END
                AND CASE
                    WHEN $4 != '''' THEN
                        CASE
                            WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                                substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                name COLLATE "C" > $4
                            END
                    ELSE
                        true
                END
            ORDER BY
                name COLLATE "C" ASC) as e order by name COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_token, bucket_id, start_after;
END;
$_$;


ALTER FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, start_after text, next_token text) OWNER TO supabase_storage_admin;

--
-- TOC entry 390 (class 1255 OID 17861)
-- Name: objects_insert_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.objects_insert_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    NEW.level := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.objects_insert_prefix_trigger() OWNER TO supabase_storage_admin;

--
-- TOC entry 409 (class 1255 OID 17876)
-- Name: objects_update_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.objects_update_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    old_prefixes TEXT[];
BEGIN
    -- Ensure this is an update operation and the name has changed
    IF TG_OP = 'UPDATE' AND (NEW."name" <> OLD."name" OR NEW."bucket_id" <> OLD."bucket_id") THEN
        -- Retrieve old prefixes
        old_prefixes := "storage"."get_prefixes"(OLD."name");

        -- Remove old prefixes that are only used by this object
        WITH all_prefixes as (
            SELECT unnest(old_prefixes) as prefix
        ),
        can_delete_prefixes as (
             SELECT prefix
             FROM all_prefixes
             WHERE NOT EXISTS (
                 SELECT 1 FROM "storage"."objects"
                 WHERE "bucket_id" = OLD."bucket_id"
                   AND "name" <> OLD."name"
                   AND "name" LIKE (prefix || '%')
             )
         )
        DELETE FROM "storage"."prefixes" WHERE name IN (SELECT prefix FROM can_delete_prefixes);

        -- Add new prefixes
        PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    END IF;
    -- Set the new level
    NEW."level" := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.objects_update_prefix_trigger() OWNER TO supabase_storage_admin;

--
-- TOC entry 426 (class 1255 OID 17839)
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION storage.operation() OWNER TO supabase_storage_admin;

--
-- TOC entry 441 (class 1255 OID 17860)
-- Name: prefixes_insert_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.prefixes_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.prefixes_insert_trigger() OWNER TO supabase_storage_admin;

--
-- TOC entry 424 (class 1255 OID 17773)
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql
    AS $$
declare
    can_bypass_rls BOOLEAN;
begin
    SELECT rolbypassrls
    INTO can_bypass_rls
    FROM pg_roles
    WHERE rolname = coalesce(nullif(current_setting('role', true), 'none'), current_user);

    IF can_bypass_rls THEN
        RETURN QUERY SELECT * FROM storage.search_v1_optimised(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    ELSE
        RETURN QUERY SELECT * FROM storage.search_legacy_v1(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    END IF;
end;
$$;


ALTER FUNCTION storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- TOC entry 371 (class 1255 OID 17873)
-- Name: search_legacy_v1(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_legacy_v1(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select path_tokens[$1] as folder
           from storage.objects
             where objects.name ilike $2 || $3 || ''%''
               and bucket_id = $4
               and array_length(objects.path_tokens, 1) <> $1
           group by folder
           order by folder ' || v_sort_order || '
     )
     (select folder as "name",
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[$1] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where objects.name ilike $2 || $3 || ''%''
       and bucket_id = $4
       and array_length(objects.path_tokens, 1) = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


ALTER FUNCTION storage.search_legacy_v1(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- TOC entry 402 (class 1255 OID 17872)
-- Name: search_v1_optimised(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_v1_optimised(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select (string_to_array(name, ''/''))[level] as name
           from storage.prefixes
             where lower(prefixes.name) like lower($2 || $3) || ''%''
               and bucket_id = $4
               and level = $1
           order by name ' || v_sort_order || '
     )
     (select name,
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[level] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where lower(objects.name) like lower($2 || $3) || ''%''
       and bucket_id = $4
       and level = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


ALTER FUNCTION storage.search_v1_optimised(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- TOC entry 420 (class 1255 OID 17867)
-- Name: search_v2(text, text, integer, integer, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
BEGIN
    RETURN query EXECUTE
        $sql$
        SELECT * FROM (
            (
                SELECT
                    split_part(name, '/', $4) AS key,
                    name || '/' AS name,
                    NULL::uuid AS id,
                    NULL::timestamptz AS updated_at,
                    NULL::timestamptz AS created_at,
                    NULL::jsonb AS metadata
                FROM storage.prefixes
                WHERE name COLLATE "C" LIKE $1 || '%'
                AND bucket_id = $2
                AND level = $4
                AND name COLLATE "C" > $5
                ORDER BY prefixes.name COLLATE "C" LIMIT $3
            )
            UNION ALL
            (SELECT split_part(name, '/', $4) AS key,
                name,
                id,
                updated_at,
                created_at,
                metadata
            FROM storage.objects
            WHERE name COLLATE "C" LIKE $1 || '%'
                AND bucket_id = $2
                AND level = $4
                AND name COLLATE "C" > $5
            ORDER BY name COLLATE "C" LIMIT $3)
        ) obj
        ORDER BY name COLLATE "C" LIMIT $3;
        $sql$
        USING prefix, bucket_name, limits, levels, start_after;
END;
$_$;


ALTER FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer, levels integer, start_after text) OWNER TO supabase_storage_admin;

--
-- TOC entry 379 (class 1255 OID 17774)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION storage.update_updated_at_column() OWNER TO supabase_storage_admin;

--
-- TOC entry 432 (class 1255 OID 16774)
-- Name: http_request(); Type: FUNCTION; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE FUNCTION supabase_functions.http_request() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'supabase_functions'
    AS $$
  DECLARE
    request_id bigint;
    payload jsonb;
    url text := TG_ARGV[0]::text;
    method text := TG_ARGV[1]::text;
    headers jsonb DEFAULT '{}'::jsonb;
    params jsonb DEFAULT '{}'::jsonb;
    timeout_ms integer DEFAULT 1000;
  BEGIN
    IF url IS NULL OR url = 'null' THEN
      RAISE EXCEPTION 'url argument is missing';
    END IF;

    IF method IS NULL OR method = 'null' THEN
      RAISE EXCEPTION 'method argument is missing';
    END IF;

    IF TG_ARGV[2] IS NULL OR TG_ARGV[2] = 'null' THEN
      headers = '{"Content-Type": "application/json"}'::jsonb;
    ELSE
      headers = TG_ARGV[2]::jsonb;
    END IF;

    IF TG_ARGV[3] IS NULL OR TG_ARGV[3] = 'null' THEN
      params = '{}'::jsonb;
    ELSE
      params = TG_ARGV[3]::jsonb;
    END IF;

    IF TG_ARGV[4] IS NULL OR TG_ARGV[4] = 'null' THEN
      timeout_ms = 1000;
    ELSE
      timeout_ms = TG_ARGV[4]::integer;
    END IF;

    CASE
      WHEN method = 'GET' THEN
        SELECT http_get INTO request_id FROM net.http_get(
          url,
          params,
          headers,
          timeout_ms
        );
      WHEN method = 'POST' THEN
        payload = jsonb_build_object(
          'old_record', OLD,
          'record', NEW,
          'type', TG_OP,
          'table', TG_TABLE_NAME,
          'schema', TG_TABLE_SCHEMA
        );

        SELECT http_post INTO request_id FROM net.http_post(
          url,
          payload,
          params,
          headers,
          timeout_ms
        );
      ELSE
        RAISE EXCEPTION 'method argument % is invalid', method;
    END CASE;

    INSERT INTO supabase_functions.hooks
      (hook_table_id, hook_name, request_id)
    VALUES
      (TG_RELID, TG_NAME, request_id);

    RETURN NEW;
  END
$$;


ALTER FUNCTION supabase_functions.http_request() OWNER TO supabase_functions_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 261 (class 1259 OID 17399)
-- Name: extensions; Type: TABLE; Schema: _realtime; Owner: supabase_admin
--

CREATE TABLE _realtime.extensions (
    id uuid NOT NULL,
    type text,
    settings jsonb,
    tenant_external_id text,
    inserted_at timestamp(0) without time zone NOT NULL,
    updated_at timestamp(0) without time zone NOT NULL
);


ALTER TABLE _realtime.extensions OWNER TO supabase_admin;

--
-- TOC entry 259 (class 1259 OID 17385)
-- Name: schema_migrations; Type: TABLE; Schema: _realtime; Owner: supabase_admin
--

CREATE TABLE _realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


ALTER TABLE _realtime.schema_migrations OWNER TO supabase_admin;

--
-- TOC entry 260 (class 1259 OID 17390)
-- Name: tenants; Type: TABLE; Schema: _realtime; Owner: supabase_admin
--

CREATE TABLE _realtime.tenants (
    id uuid NOT NULL,
    name text,
    external_id text,
    jwt_secret text,
    max_concurrent_users integer DEFAULT 200 NOT NULL,
    inserted_at timestamp(0) without time zone NOT NULL,
    updated_at timestamp(0) without time zone NOT NULL,
    max_events_per_second integer DEFAULT 100 NOT NULL,
    postgres_cdc_default text DEFAULT 'postgres_cdc_rls'::text,
    max_bytes_per_second integer DEFAULT 100000 NOT NULL,
    max_channels_per_client integer DEFAULT 100 NOT NULL,
    max_joins_per_second integer DEFAULT 500 NOT NULL,
    suspend boolean DEFAULT false,
    jwt_jwks jsonb,
    notify_private_alpha boolean DEFAULT false,
    private_only boolean DEFAULT false NOT NULL,
    migrations_ran integer DEFAULT 0,
    broadcast_adapter character varying(255) DEFAULT 'gen_rpc'::character varying,
    max_presence_events_per_second integer DEFAULT 10000,
    max_payload_size_in_kb integer DEFAULT 3000
);


ALTER TABLE _realtime.tenants OWNER TO supabase_admin;

--
-- TOC entry 241 (class 1259 OID 16488)
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE auth.audit_log_entries OWNER TO supabase_auth_admin;

--
-- TOC entry 4802 (class 0 OID 0)
-- Dependencies: 241
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- TOC entry 289 (class 1259 OID 18155)
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text NOT NULL,
    code_challenge_method auth.code_challenge_method NOT NULL,
    code_challenge text NOT NULL,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone
);


ALTER TABLE auth.flow_state OWNER TO supabase_auth_admin;

--
-- TOC entry 4804 (class 0 OID 0)
-- Dependencies: 289
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.flow_state IS 'stores metadata for pkce logins';


--
-- TOC entry 280 (class 1259 OID 17953)
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE auth.identities OWNER TO supabase_auth_admin;

--
-- TOC entry 4806 (class 0 OID 0)
-- Dependencies: 280
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- TOC entry 4807 (class 0 OID 0)
-- Dependencies: 280
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- TOC entry 240 (class 1259 OID 16481)
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE auth.instances OWNER TO supabase_auth_admin;

--
-- TOC entry 4809 (class 0 OID 0)
-- Dependencies: 240
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- TOC entry 284 (class 1259 OID 18042)
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE auth.mfa_amr_claims OWNER TO supabase_auth_admin;

--
-- TOC entry 4811 (class 0 OID 0)
-- Dependencies: 284
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- TOC entry 283 (class 1259 OID 18030)
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


ALTER TABLE auth.mfa_challenges OWNER TO supabase_auth_admin;

--
-- TOC entry 4813 (class 0 OID 0)
-- Dependencies: 283
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- TOC entry 282 (class 1259 OID 18017)
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid
);


ALTER TABLE auth.mfa_factors OWNER TO supabase_auth_admin;

--
-- TOC entry 4815 (class 0 OID 0)
-- Dependencies: 282
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- TOC entry 290 (class 1259 OID 18205)
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


ALTER TABLE auth.one_time_tokens OWNER TO supabase_auth_admin;

--
-- TOC entry 239 (class 1259 OID 16470)
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


ALTER TABLE auth.refresh_tokens OWNER TO supabase_auth_admin;

--
-- TOC entry 4818 (class 0 OID 0)
-- Dependencies: 239
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- TOC entry 238 (class 1259 OID 16469)
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE auth.refresh_tokens_id_seq OWNER TO supabase_auth_admin;

--
-- TOC entry 4820 (class 0 OID 0)
-- Dependencies: 238
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- TOC entry 287 (class 1259 OID 18084)
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


ALTER TABLE auth.saml_providers OWNER TO supabase_auth_admin;

--
-- TOC entry 4822 (class 0 OID 0)
-- Dependencies: 287
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- TOC entry 288 (class 1259 OID 18102)
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


ALTER TABLE auth.saml_relay_states OWNER TO supabase_auth_admin;

--
-- TOC entry 4824 (class 0 OID 0)
-- Dependencies: 288
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- TOC entry 242 (class 1259 OID 16496)
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE auth.schema_migrations OWNER TO supabase_auth_admin;

--
-- TOC entry 4826 (class 0 OID 0)
-- Dependencies: 242
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- TOC entry 281 (class 1259 OID 17983)
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text
);


ALTER TABLE auth.sessions OWNER TO supabase_auth_admin;

--
-- TOC entry 4828 (class 0 OID 0)
-- Dependencies: 281
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- TOC entry 4829 (class 0 OID 0)
-- Dependencies: 281
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- TOC entry 286 (class 1259 OID 18069)
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


ALTER TABLE auth.sso_domains OWNER TO supabase_auth_admin;

--
-- TOC entry 4831 (class 0 OID 0)
-- Dependencies: 286
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- TOC entry 285 (class 1259 OID 18060)
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


ALTER TABLE auth.sso_providers OWNER TO supabase_auth_admin;

--
-- TOC entry 4833 (class 0 OID 0)
-- Dependencies: 285
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- TOC entry 4834 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- TOC entry 237 (class 1259 OID 16458)
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


ALTER TABLE auth.users OWNER TO supabase_auth_admin;

--
-- TOC entry 4836 (class 0 OID 0)
-- Dependencies: 237
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- TOC entry 4837 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- TOC entry 293 (class 1259 OID 18365)
-- Name: companies; Type: TABLE; Schema: company; Owner: postgres
--

CREATE TABLE company.companies (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    industry character varying(100),
    founded_year integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE company.companies OWNER TO postgres;

--
-- TOC entry 4839 (class 0 OID 0)
-- Dependencies: 293
-- Name: TABLE companies; Type: COMMENT; Schema: company; Owner: postgres
--

COMMENT ON TABLE company.companies IS 'Company information and metadata';


--
-- TOC entry 298 (class 1259 OID 18421)
-- Name: departments; Type: TABLE; Schema: company; Owner: postgres
--

CREATE TABLE company.departments (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    company_id uuid,
    name character varying(255) NOT NULL,
    head_of_department character varying(255),
    budget numeric(15,2),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE company.departments OWNER TO postgres;

--
-- TOC entry 4841 (class 0 OID 0)
-- Dependencies: 298
-- Name: TABLE departments; Type: COMMENT; Schema: company; Owner: postgres
--

COMMENT ON TABLE company.departments IS 'Company departments and organizational structure';


--
-- TOC entry 299 (class 1259 OID 18429)
-- Name: kpi_data; Type: TABLE; Schema: company; Owner: postgres
--

CREATE TABLE company.kpi_data (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    department_id uuid,
    metric_id uuid,
    value numeric(15,4) NOT NULL,
    date_recorded date NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE company.kpi_data OWNER TO postgres;

--
-- TOC entry 4843 (class 0 OID 0)
-- Dependencies: 299
-- Name: TABLE kpi_data; Type: COMMENT; Schema: company; Owner: postgres
--

COMMENT ON TABLE company.kpi_data IS 'Actual KPI data points and measurements';


--
-- TOC entry 300 (class 1259 OID 18435)
-- Name: kpi_goals; Type: TABLE; Schema: company; Owner: postgres
--

CREATE TABLE company.kpi_goals (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    department_id uuid,
    metric_id uuid,
    target_value numeric(15,4),
    period_start date,
    period_end date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE company.kpi_goals OWNER TO postgres;

--
-- TOC entry 4845 (class 0 OID 0)
-- Dependencies: 300
-- Name: TABLE kpi_goals; Type: COMMENT; Schema: company; Owner: postgres
--

COMMENT ON TABLE company.kpi_goals IS 'Department KPI goals and targets';


--
-- TOC entry 301 (class 1259 OID 18441)
-- Name: kpi_metrics; Type: TABLE; Schema: company; Owner: postgres
--

CREATE TABLE company.kpi_metrics (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    metric_type character varying(100),
    unit character varying(50),
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE company.kpi_metrics OWNER TO postgres;

--
-- TOC entry 4847 (class 0 OID 0)
-- Dependencies: 301
-- Name: TABLE kpi_metrics; Type: COMMENT; Schema: company; Owner: postgres
--

COMMENT ON TABLE company.kpi_metrics IS 'KPI metric definitions and metadata';


--
-- TOC entry 316 (class 1259 OID 18933)
-- Name: agent_orchestrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_orchestrations (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    organization_slug text,
    agent_slug text NOT NULL,
    slug text NOT NULL,
    display_name text NOT NULL,
    description text,
    status text DEFAULT 'active'::text,
    orchestration_json jsonb NOT NULL,
    prompt_templates jsonb DEFAULT '[]'::jsonb,
    tags text[] DEFAULT ARRAY[]::text[],
    version text,
    created_by uuid,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.agent_orchestrations OWNER TO postgres;

--
-- TOC entry 4851 (class 0 OID 0)
-- Dependencies: 316
-- Name: TABLE agent_orchestrations; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.agent_orchestrations IS 'Reusable orchestration recipes bound to a specific agent.';


--
-- TOC entry 4852 (class 0 OID 0)
-- Dependencies: 316
-- Name: COLUMN agent_orchestrations.orchestration_json; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.agent_orchestrations.orchestration_json IS 'Structured orchestration definition (phases, steps, dependencies).';


--
-- TOC entry 4853 (class 0 OID 0)
-- Dependencies: 316
-- Name: COLUMN agent_orchestrations.prompt_templates; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.agent_orchestrations.prompt_templates IS 'Prompt templates with parameter metadata required to launch orchestrations.';


--
-- TOC entry 314 (class 1259 OID 18890)
-- Name: agents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agents (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    organization_slug text,
    slug text NOT NULL,
    display_name text NOT NULL,
    description text,
    agent_type text NOT NULL,
    mode_profile text NOT NULL,
    version text,
    status text DEFAULT 'active'::text,
    yaml text NOT NULL,
    agent_card jsonb,
    context jsonb,
    config jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    function_code text
);


ALTER TABLE public.agents OWNER TO postgres;

--
-- TOC entry 4855 (class 0 OID 0)
-- Dependencies: 314
-- Name: TABLE agents; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.agents IS 'Database-backed agent descriptors for the new platform.';


--
-- TOC entry 4856 (class 0 OID 0)
-- Dependencies: 314
-- Name: COLUMN agents.organization_slug; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.agents.organization_slug IS 'Namespace / organization identifier (e.g., demo, my-org).';


--
-- TOC entry 4857 (class 0 OID 0)
-- Dependencies: 314
-- Name: COLUMN agents.yaml; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.agents.yaml IS 'Raw YAML/JSON descriptor for auditability.';


--
-- TOC entry 4858 (class 0 OID 0)
-- Dependencies: 314
-- Name: COLUMN agents.agent_card; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.agents.agent_card IS 'Cached agent card served to clients.';


--
-- TOC entry 4859 (class 0 OID 0)
-- Dependencies: 314
-- Name: COLUMN agents.context; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.agents.context IS 'System prompt, plan rubric, and reference data.';


--
-- TOC entry 4860 (class 0 OID 0)
-- Dependencies: 314
-- Name: COLUMN agents.config; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.agents.config IS 'Execution configuration (capabilities, supporting agents, checkpoints, etc.).';


--
-- TOC entry 4861 (class 0 OID 0)
-- Dependencies: 314
-- Name: COLUMN agents.function_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.agents.function_code IS 'JavaScript/TypeScript function code for function-type agents';


--
-- TOC entry 323 (class 1259 OID 19067)
-- Name: assets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    storage text NOT NULL,
    path text,
    bucket text,
    object_key text,
    mime text NOT NULL,
    size bigint,
    width integer,
    height integer,
    hash text,
    user_id uuid,
    conversation_id uuid,
    deliverable_version_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    source_url text,
    CONSTRAINT assets_storage_check CHECK ((storage = ANY (ARRAY['local'::text, 'supabase'::text, 'external'::text])))
);


ALTER TABLE public.assets OWNER TO postgres;

--
-- TOC entry 292 (class 1259 OID 18354)
-- Name: cidafm_commands; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cidafm_commands (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    type character varying(10) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    default_active boolean DEFAULT false,
    is_builtin boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT cidafm_commands_type_check CHECK (((type)::text = ANY (ARRAY[('^'::character varying)::text, ('&'::character varying)::text, ('!'::character varying)::text])))
);


ALTER TABLE public.cidafm_commands OWNER TO postgres;

--
-- TOC entry 294 (class 1259 OID 18371)
-- Name: conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversations (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    user_id uuid,
    agent_name character varying(255),
    agent_type character varying(100),
    started_at timestamp with time zone,
    last_active_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    organization_slug text,
    ended_at timestamp with time zone
);


ALTER TABLE public.conversations OWNER TO postgres;

--
-- TOC entry 4865 (class 0 OID 0)
-- Dependencies: 294
-- Name: COLUMN conversations.organization_slug; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.conversations.organization_slug IS 'Organization slug for database agents (e.g., my-org, acme-corp). NULL for file-based agents.';


--
-- TOC entry 295 (class 1259 OID 18380)
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    user_id uuid,
    conversation_id uuid,
    method character varying(255),
    params jsonb DEFAULT '{}'::jsonb,
    prompt text,
    response text,
    status character varying(50) DEFAULT 'pending'::character varying,
    progress integer DEFAULT 0,
    progress_message text,
    error_code text,
    error_message text,
    error_data jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    timeout_seconds integer DEFAULT 300,
    deliverable_type text,
    deliverable_metadata jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    llm_metadata jsonb DEFAULT '{}'::jsonb,
    response_metadata jsonb DEFAULT '{}'::jsonb,
    evaluation jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- TOC entry 326 (class 1259 OID 19159)
-- Name: conversations_with_stats; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.conversations_with_stats AS
 SELECT c.id,
    c.user_id,
    c.agent_name,
    c.agent_type,
    c.ended_at,
    c.started_at,
    c.last_active_at,
    c.metadata,
    c.created_at,
    c.updated_at,
    COALESCE(task_stats.task_count, (0)::bigint) AS task_count,
    COALESCE(task_stats.completed_tasks, (0)::bigint) AS completed_tasks,
    COALESCE(task_stats.failed_tasks, (0)::bigint) AS failed_tasks,
    COALESCE(task_stats.active_tasks, (0)::bigint) AS active_tasks,
    c.organization_slug
   FROM (public.conversations c
     LEFT JOIN ( SELECT t.conversation_id,
            count(*) AS task_count,
            count(
                CASE
                    WHEN ((t.status)::text = 'completed'::text) THEN 1
                    ELSE NULL::integer
                END) AS completed_tasks,
            count(
                CASE
                    WHEN ((t.status)::text = 'failed'::text) THEN 1
                    ELSE NULL::integer
                END) AS failed_tasks,
            count(
                CASE
                    WHEN ((t.status)::text = ANY (ARRAY['pending'::text, 'running'::text])) THEN 1
                    ELSE NULL::integer
                END) AS active_tasks
           FROM public.tasks t
          GROUP BY t.conversation_id) task_stats ON ((c.id = task_stats.conversation_id)));


ALTER VIEW public.conversations_with_stats OWNER TO postgres;

--
-- TOC entry 296 (class 1259 OID 18400)
-- Name: deliverable_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deliverable_versions (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    deliverable_id uuid NOT NULL,
    version_number integer NOT NULL,
    content text,
    format character varying(100),
    is_current_version boolean DEFAULT false,
    created_by_type character varying(50) DEFAULT 'ai_response'::character varying,
    task_id uuid,
    metadata jsonb DEFAULT '{}'::jsonb,
    file_attachments jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT deliverable_versions_created_by_type_check CHECK (((created_by_type)::text = ANY (ARRAY[('ai_response'::character varying)::text, ('manual_edit'::character varying)::text, ('ai_enhancement'::character varying)::text, ('user_request'::character varying)::text, ('conversation_task'::character varying)::text, ('conversation_merge'::character varying)::text, ('llm_rerun'::character varying)::text])))
);


ALTER TABLE public.deliverable_versions OWNER TO postgres;

--
-- TOC entry 297 (class 1259 OID 18413)
-- Name: deliverables; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deliverables (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    conversation_id uuid,
    project_step_id uuid,
    agent_name text,
    title text NOT NULL,
    type character varying(100),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.deliverables OWNER TO postgres;

--
-- TOC entry 318 (class 1259 OID 18984)
-- Name: human_approvals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.human_approvals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_slug text,
    agent_slug text NOT NULL,
    conversation_id uuid,
    task_id text,
    mode text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    approved_by text,
    decision_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.human_approvals OWNER TO postgres;

--
-- TOC entry 312 (class 1259 OID 18845)
-- Name: jokes_agent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jokes_agent (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id text NOT NULL,
    prompt text NOT NULL,
    joke_output text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.jokes_agent OWNER TO postgres;

--
-- TOC entry 313 (class 1259 OID 18860)
-- Name: jokes_analytics; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.jokes_analytics AS
 SELECT date(created_at) AS joke_date,
    count(*) AS total_jokes,
    count(DISTINCT session_id) AS unique_sessions,
    avg(length(joke_output)) AS avg_joke_length
   FROM public.jokes_agent
  WHERE (session_id <> 'fallback'::text)
  GROUP BY (date(created_at))
  ORDER BY (date(created_at)) DESC;


ALTER VIEW public.jokes_analytics OWNER TO postgres;

--
-- TOC entry 302 (class 1259 OID 18449)
-- Name: llm_models; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llm_models (
    model_name text NOT NULL,
    provider_name text NOT NULL,
    display_name text,
    model_type text DEFAULT 'text-generation'::text,
    model_version text,
    context_window integer DEFAULT 4096,
    max_output_tokens integer DEFAULT 2048,
    model_parameters_json jsonb DEFAULT '{}'::jsonb,
    pricing_info_json jsonb DEFAULT '{}'::jsonb,
    capabilities jsonb DEFAULT '[]'::jsonb,
    model_tier text,
    speed_tier text DEFAULT 'medium'::text,
    loading_priority integer DEFAULT 5,
    is_local boolean DEFAULT false,
    is_currently_loaded boolean DEFAULT false,
    is_active boolean DEFAULT true,
    training_data_cutoff date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.llm_models OWNER TO postgres;

--
-- TOC entry 303 (class 1259 OID 18467)
-- Name: llm_providers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llm_providers (
    name text NOT NULL,
    display_name text NOT NULL,
    api_base_url text,
    configuration_json jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.llm_providers OWNER TO postgres;

--
-- TOC entry 304 (class 1259 OID 18476)
-- Name: llm_usage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llm_usage (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    run_id text NOT NULL,
    user_id uuid,
    conversation_id uuid,
    provider_name text,
    model_name text,
    input_tokens integer,
    output_tokens integer,
    input_cost numeric,
    output_cost numeric,
    duration_ms integer,
    status text DEFAULT 'completed'::text,
    caller_type text,
    agent_name text,
    is_local boolean DEFAULT false,
    model_tier text,
    fallback_used boolean DEFAULT false,
    routing_reason text,
    complexity_level text,
    complexity_score integer,
    data_classification text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_message text,
    data_sanitization_applied boolean DEFAULT false,
    sanitization_level text DEFAULT 'none'::text,
    pii_detected boolean DEFAULT false,
    pii_types jsonb DEFAULT '[]'::jsonb,
    pseudonyms_used integer DEFAULT 0,
    pseudonym_types jsonb DEFAULT '[]'::jsonb,
    redactions_applied integer DEFAULT 0,
    redaction_types jsonb DEFAULT '[]'::jsonb,
    source_blinding_applied boolean DEFAULT false,
    headers_stripped boolean DEFAULT false,
    custom_user_agent_used boolean DEFAULT false,
    proxy_used boolean DEFAULT false,
    no_train_header_sent boolean DEFAULT false,
    no_retain_header_sent boolean DEFAULT false,
    sanitization_time_ms integer DEFAULT 0,
    reversal_context_size integer DEFAULT 0,
    policy_profile text,
    sovereign_mode boolean DEFAULT false,
    compliance_flags jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    route text,
    total_cost numeric,
    pseudonym_mappings jsonb DEFAULT '[]'::jsonb,
    CONSTRAINT llm_usage_route_check CHECK (((route IS NULL) OR (route = ANY (ARRAY['local'::text, 'remote'::text]))))
);


ALTER TABLE public.llm_usage OWNER TO postgres;

--
-- TOC entry 4876 (class 0 OID 0)
-- Dependencies: 304
-- Name: COLUMN llm_usage.total_cost; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.llm_usage.total_cost IS 'Total cost (input_cost + output_cost) for this LLM request';


--
-- TOC entry 4877 (class 0 OID 0)
-- Dependencies: 304
-- Name: COLUMN llm_usage.pseudonym_mappings; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.llm_usage.pseudonym_mappings IS 'Array of {original, pseudonym, dataType} objects for this run';


--
-- TOC entry 322 (class 1259 OID 19060)
-- Name: llm_usage_analytics; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.llm_usage_analytics AS
 SELECT (date_trunc('day'::text, started_at))::date AS date,
    COALESCE(caller_type, 'unknown'::text) AS caller_type,
    count(*) AS total_requests,
    sum(
        CASE
            WHEN (status = 'completed'::text) THEN 1
            ELSE 0
        END) AS successful_requests,
    COALESCE(sum(total_cost), sum((COALESCE(input_cost, (0)::numeric) + COALESCE(output_cost, (0)::numeric)))) AS total_cost,
    avg(COALESCE(duration_ms, 0)) AS avg_duration_ms,
    sum(
        CASE
            WHEN (is_local IS TRUE) THEN 1
            ELSE 0
        END) AS local_requests,
    sum(
        CASE
            WHEN (is_local IS NOT TRUE) THEN 1
            ELSE 0
        END) AS external_requests
   FROM public.llm_usage
  GROUP BY ((date_trunc('day'::text, started_at))::date), COALESCE(caller_type, 'unknown'::text)
  ORDER BY ((date_trunc('day'::text, started_at))::date) DESC, COALESCE(caller_type, 'unknown'::text);


ALTER VIEW public.llm_usage_analytics OWNER TO postgres;

--
-- TOC entry 321 (class 1259 OID 19042)
-- Name: orchestration_checkpoints; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orchestration_checkpoints (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    orchestration_run_id uuid NOT NULL,
    step_index integer,
    label text,
    state jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.orchestration_checkpoints OWNER TO postgres;

--
-- TOC entry 4880 (class 0 OID 0)
-- Dependencies: 321
-- Name: TABLE orchestration_checkpoints; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.orchestration_checkpoints IS 'Serializable snapshots that allow orchestration resumes.';


--
-- TOC entry 4881 (class 0 OID 0)
-- Dependencies: 321
-- Name: COLUMN orchestration_checkpoints.state; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.orchestration_checkpoints.state IS 'Serializable execution state at checkpoint.';


--
-- TOC entry 317 (class 1259 OID 18948)
-- Name: orchestration_runs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orchestration_runs (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    plan_id uuid,
    origin_type text DEFAULT 'plan'::text,
    origin_id uuid,
    orchestration_slug text,
    prompt_inputs jsonb DEFAULT '{}'::jsonb,
    organization_slug text,
    status text DEFAULT 'pending'::text,
    current_step_index integer,
    completed_steps jsonb DEFAULT '[]'::jsonb,
    step_state jsonb DEFAULT '{}'::jsonb,
    human_checkpoint_id text,
    metadata jsonb DEFAULT '{}'::jsonb,
    started_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone
);


ALTER TABLE public.orchestration_runs OWNER TO postgres;

--
-- TOC entry 4883 (class 0 OID 0)
-- Dependencies: 317
-- Name: TABLE orchestration_runs; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.orchestration_runs IS 'Live orchestration execution state derived from conversation plans or saved orchestrations.';


--
-- TOC entry 4884 (class 0 OID 0)
-- Dependencies: 317
-- Name: COLUMN orchestration_runs.origin_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.orchestration_runs.origin_type IS 'Execution source (plan, saved_orchestration, ad_hoc).';


--
-- TOC entry 4885 (class 0 OID 0)
-- Dependencies: 317
-- Name: COLUMN orchestration_runs.orchestration_slug; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.orchestration_runs.orchestration_slug IS 'Slug of the saved orchestration recipe when origin_type = saved_orchestration.';


--
-- TOC entry 4886 (class 0 OID 0)
-- Dependencies: 317
-- Name: COLUMN orchestration_runs.prompt_inputs; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.orchestration_runs.prompt_inputs IS 'Resolved prompt parameter payload provided at orchestration launch.';


--
-- TOC entry 4887 (class 0 OID 0)
-- Dependencies: 317
-- Name: COLUMN orchestration_runs.step_state; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.orchestration_runs.step_state IS 'Per-step status metadata including conversations, deliverables, assignments.';


--
-- TOC entry 320 (class 1259 OID 19020)
-- Name: orchestration_steps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orchestration_steps (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    orchestration_run_id uuid NOT NULL,
    step_index integer NOT NULL,
    step_key text,
    status text DEFAULT 'pending'::text NOT NULL,
    agent_slug text,
    input jsonb DEFAULT '{}'::jsonb,
    output jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    error jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.orchestration_steps OWNER TO postgres;

--
-- TOC entry 4889 (class 0 OID 0)
-- Dependencies: 320
-- Name: TABLE orchestration_steps; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.orchestration_steps IS 'Durable record of each orchestration step state.';


--
-- TOC entry 4890 (class 0 OID 0)
-- Dependencies: 320
-- Name: COLUMN orchestration_steps.step_key; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.orchestration_steps.step_key IS 'Optional identifier from plan/orchestration definition.';


--
-- TOC entry 4891 (class 0 OID 0)
-- Dependencies: 320
-- Name: COLUMN orchestration_steps.metadata; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.orchestration_steps.metadata IS 'Execution metadata (progress markers, retries, etc.).';


--
-- TOC entry 4892 (class 0 OID 0)
-- Dependencies: 320
-- Name: COLUMN orchestration_steps.error; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.orchestration_steps.error IS 'Latest error payload if the step failed.';


--
-- TOC entry 315 (class 1259 OID 18903)
-- Name: organization_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_credentials (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    organization_slug text NOT NULL,
    alias text NOT NULL,
    credential_type text NOT NULL,
    encrypted_value bytea NOT NULL,
    encryption_metadata jsonb DEFAULT '{}'::jsonb,
    rotated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.organization_credentials OWNER TO postgres;

--
-- TOC entry 4894 (class 0 OID 0)
-- Dependencies: 315
-- Name: TABLE organization_credentials; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.organization_credentials IS 'Encrypted secrets per organization (API keys, service credentials).';


--
-- TOC entry 325 (class 1259 OID 19113)
-- Name: plan_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plan_id uuid NOT NULL,
    version_number integer NOT NULL,
    content text NOT NULL,
    format text DEFAULT 'markdown'::text NOT NULL,
    created_by_type text NOT NULL,
    created_by_id uuid,
    task_id uuid,
    metadata jsonb DEFAULT '{}'::jsonb,
    is_current_version boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT plan_versions_created_by_type_check CHECK ((created_by_type = ANY (ARRAY['agent'::text, 'user'::text]))),
    CONSTRAINT plan_versions_format_check CHECK ((format = ANY (ARRAY['markdown'::text, 'json'::text, 'text'::text])))
);


ALTER TABLE public.plan_versions OWNER TO postgres;

--
-- TOC entry 4896 (class 0 OID 0)
-- Dependencies: 325
-- Name: TABLE plan_versions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.plan_versions IS 'Stores immutable versions of plans. Each edit/refinement creates a new version.';


--
-- TOC entry 4897 (class 0 OID 0)
-- Dependencies: 325
-- Name: COLUMN plan_versions.created_by_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.plan_versions.created_by_type IS 'Whether this version was created by an agent or manually edited by a user';


--
-- TOC entry 4898 (class 0 OID 0)
-- Dependencies: 325
-- Name: COLUMN plan_versions.task_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.plan_versions.task_id IS 'Reference to the agent task that created this version (if applicable)';


--
-- TOC entry 4899 (class 0 OID 0)
-- Dependencies: 325
-- Name: COLUMN plan_versions.metadata; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.plan_versions.metadata IS 'Additional metadata like LLM model used, merge source versions, etc.';


--
-- TOC entry 324 (class 1259 OID 19091)
-- Name: plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    conversation_id uuid NOT NULL,
    user_id uuid NOT NULL,
    agent_name text NOT NULL,
    namespace text NOT NULL,
    title text NOT NULL,
    current_version_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.plans OWNER TO postgres;

--
-- TOC entry 4901 (class 0 OID 0)
-- Dependencies: 324
-- Name: TABLE plans; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.plans IS 'Stores plan metadata for agent2agent conversations. One plan per conversation with versioned content.';


--
-- TOC entry 4902 (class 0 OID 0)
-- Dependencies: 324
-- Name: COLUMN plans.current_version_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.plans.current_version_id IS 'Points to the currently active version of this plan';


--
-- TOC entry 305 (class 1259 OID 18504)
-- Name: project_steps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_steps (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    step_id text NOT NULL,
    step_index integer NOT NULL,
    step_type text NOT NULL,
    step_name text NOT NULL,
    agent_name text,
    prompt text NOT NULL,
    dependencies text[] DEFAULT '{}'::text[],
    status text DEFAULT 'pending'::text NOT NULL,
    result jsonb,
    error_details jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT project_steps_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'running'::text, 'completed'::text, 'failed'::text, 'pending_approval'::text, 'skipped'::text]))),
    CONSTRAINT project_steps_step_type_check CHECK ((step_type = ANY (ARRAY['agent_step'::text, 'human_approval'::text])))
);


ALTER TABLE public.project_steps OWNER TO postgres;

--
-- TOC entry 306 (class 1259 OID 18517)
-- Name: projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    conversation_id uuid NOT NULL,
    name text,
    description text,
    plan_json jsonb,
    status text DEFAULT 'planning'::text NOT NULL,
    current_step_id text,
    error_details jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    parent_project_id uuid,
    hierarchy_level integer DEFAULT 0,
    subproject_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT projects_status_check CHECK ((status = ANY (ARRAY['planning'::text, 'pending_approval'::text, 'running'::text, 'paused_for_approval'::text, 'paused_on_error'::text, 'completed'::text, 'aborted'::text])))
);


ALTER TABLE public.projects OWNER TO postgres;

--
-- TOC entry 307 (class 1259 OID 18530)
-- Name: pseudonym_dictionaries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pseudonym_dictionaries (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    original_value text NOT NULL,
    pseudonym text NOT NULL,
    data_type character varying(100) NOT NULL,
    category character varying(100),
    frequency_weight integer DEFAULT 1,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    organization_slug text,
    agent_slug text,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.pseudonym_dictionaries OWNER TO postgres;

--
-- TOC entry 308 (class 1259 OID 18539)
-- Name: redaction_patterns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.redaction_patterns (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    pattern_regex text NOT NULL,
    replacement text NOT NULL,
    description text,
    category character varying(100) DEFAULT 'pii_builtin'::character varying,
    priority integer DEFAULT 50,
    is_active boolean DEFAULT true,
    severity character varying(50),
    data_type character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.redaction_patterns OWNER TO postgres;

--
-- TOC entry 309 (class 1259 OID 18550)
-- Name: system_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_settings (
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.system_settings OWNER TO postgres;

--
-- TOC entry 4908 (class 0 OID 0)
-- Dependencies: 309
-- Name: TABLE system_settings; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.system_settings IS 'System-wide settings (key/value JSON). Used for global model configuration and feature flags.';


--
-- TOC entry 319 (class 1259 OID 19000)
-- Name: task_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_messages (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    task_id uuid NOT NULL,
    user_id uuid,
    content text NOT NULL,
    message_type text DEFAULT 'info'::text NOT NULL,
    progress_percentage numeric,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone DEFAULT (now() + '01:00:00'::interval) NOT NULL
);


ALTER TABLE public.task_messages OWNER TO postgres;

--
-- TOC entry 4910 (class 0 OID 0)
-- Dependencies: 319
-- Name: TABLE task_messages; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.task_messages IS 'Short-lived task streaming messages used for SSE + polling replay.';


--
-- TOC entry 310 (class 1259 OID 18556)
-- Name: user_cidafm_commands; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_cidafm_commands (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    command_id uuid NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_cidafm_commands OWNER TO postgres;

--
-- TOC entry 311 (class 1259 OID 18563)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    display_name character varying(255),
    role character varying(50),
    roles jsonb DEFAULT '["user"]'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    namespace_access jsonb DEFAULT '["my-org"]'::jsonb NOT NULL,
    status text DEFAULT 'active'::text,
    organization_slug text
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 4913 (class 0 OID 0)
-- Dependencies: 311
-- Name: COLUMN users.namespace_access; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.namespace_access IS 'List of agent namespaces the user may access (e.g., ["demo","my-org"]).';


--
-- TOC entry 268 (class 1259 OID 17685)
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
)
PARTITION BY RANGE (inserted_at);


ALTER TABLE realtime.messages OWNER TO supabase_realtime_admin;

--
-- TOC entry 269 (class 1259 OID 17701)
-- Name: messages_2025_10_10; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_10_10 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_10_10 OWNER TO supabase_admin;

--
-- TOC entry 270 (class 1259 OID 17712)
-- Name: messages_2025_10_11; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_10_11 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_10_11 OWNER TO supabase_admin;

--
-- TOC entry 271 (class 1259 OID 17723)
-- Name: messages_2025_10_12; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_10_12 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_10_12 OWNER TO supabase_admin;

--
-- TOC entry 272 (class 1259 OID 17734)
-- Name: messages_2025_10_13; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_10_13 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_10_13 OWNER TO supabase_admin;

--
-- TOC entry 273 (class 1259 OID 17745)
-- Name: messages_2025_10_14; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_10_14 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_10_14 OWNER TO supabase_admin;

--
-- TOC entry 262 (class 1259 OID 17522)
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


ALTER TABLE realtime.schema_migrations OWNER TO supabase_admin;

--
-- TOC entry 265 (class 1259 OID 17545)
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);


ALTER TABLE realtime.subscription OWNER TO supabase_admin;

--
-- TOC entry 264 (class 1259 OID 17544)
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 243 (class 1259 OID 16509)
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


ALTER TABLE storage.buckets OWNER TO supabase_storage_admin;

--
-- TOC entry 4924 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- TOC entry 277 (class 1259 OID 17886)
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets_analytics (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.buckets_analytics OWNER TO supabase_storage_admin;

--
-- TOC entry 278 (class 1259 OID 17897)
-- Name: iceberg_namespaces; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.iceberg_namespaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.iceberg_namespaces OWNER TO supabase_storage_admin;

--
-- TOC entry 279 (class 1259 OID 17913)
-- Name: iceberg_tables; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.iceberg_tables (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    namespace_id uuid NOT NULL,
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    location text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.iceberg_tables OWNER TO supabase_storage_admin;

--
-- TOC entry 245 (class 1259 OID 16551)
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE storage.migrations OWNER TO supabase_storage_admin;

--
-- TOC entry 244 (class 1259 OID 16524)
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb,
    level integer
);


ALTER TABLE storage.objects OWNER TO supabase_storage_admin;

--
-- TOC entry 4929 (class 0 OID 0)
-- Dependencies: 244
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- TOC entry 276 (class 1259 OID 17841)
-- Name: prefixes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.prefixes (
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    level integer GENERATED ALWAYS AS (storage.get_level(name)) STORED NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE storage.prefixes OWNER TO supabase_storage_admin;

--
-- TOC entry 274 (class 1259 OID 17788)
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb
);


ALTER TABLE storage.s3_multipart_uploads OWNER TO supabase_storage_admin;

--
-- TOC entry 275 (class 1259 OID 17802)
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.s3_multipart_uploads_parts OWNER TO supabase_storage_admin;

--
-- TOC entry 258 (class 1259 OID 16763)
-- Name: hooks; Type: TABLE; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE TABLE supabase_functions.hooks (
    id bigint NOT NULL,
    hook_table_id integer NOT NULL,
    hook_name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    request_id bigint
);


ALTER TABLE supabase_functions.hooks OWNER TO supabase_functions_admin;

--
-- TOC entry 4934 (class 0 OID 0)
-- Dependencies: 258
-- Name: TABLE hooks; Type: COMMENT; Schema: supabase_functions; Owner: supabase_functions_admin
--

COMMENT ON TABLE supabase_functions.hooks IS 'Supabase Functions Hooks: Audit trail for triggered hooks.';


--
-- TOC entry 257 (class 1259 OID 16762)
-- Name: hooks_id_seq; Type: SEQUENCE; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE SEQUENCE supabase_functions.hooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE supabase_functions.hooks_id_seq OWNER TO supabase_functions_admin;

--
-- TOC entry 4936 (class 0 OID 0)
-- Dependencies: 257
-- Name: hooks_id_seq; Type: SEQUENCE OWNED BY; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER SEQUENCE supabase_functions.hooks_id_seq OWNED BY supabase_functions.hooks.id;


--
-- TOC entry 256 (class 1259 OID 16754)
-- Name: migrations; Type: TABLE; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE TABLE supabase_functions.migrations (
    version text NOT NULL,
    inserted_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE supabase_functions.migrations OWNER TO supabase_functions_admin;

--
-- TOC entry 291 (class 1259 OID 18232)
-- Name: schema_migrations; Type: TABLE; Schema: supabase_migrations; Owner: postgres
--

CREATE TABLE supabase_migrations.schema_migrations (
    version text NOT NULL,
    statements text[],
    name text
);


ALTER TABLE supabase_migrations.schema_migrations OWNER TO postgres;

--
-- TOC entry 3760 (class 0 OID 0)
-- Name: messages_2025_10_10; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_10 FOR VALUES FROM ('2025-10-10 00:00:00') TO ('2025-10-11 00:00:00');


--
-- TOC entry 3761 (class 0 OID 0)
-- Name: messages_2025_10_11; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_11 FOR VALUES FROM ('2025-10-11 00:00:00') TO ('2025-10-12 00:00:00');


--
-- TOC entry 3762 (class 0 OID 0)
-- Name: messages_2025_10_12; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_12 FOR VALUES FROM ('2025-10-12 00:00:00') TO ('2025-10-13 00:00:00');


--
-- TOC entry 3763 (class 0 OID 0)
-- Name: messages_2025_10_13; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_13 FOR VALUES FROM ('2025-10-13 00:00:00') TO ('2025-10-14 00:00:00');


--
-- TOC entry 3764 (class 0 OID 0)
-- Name: messages_2025_10_14; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_14 FOR VALUES FROM ('2025-10-14 00:00:00') TO ('2025-10-15 00:00:00');


--
-- TOC entry 3774 (class 2604 OID 16473)
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- TOC entry 3794 (class 2604 OID 16766)
-- Name: hooks id; Type: DEFAULT; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER TABLE ONLY supabase_functions.hooks ALTER COLUMN id SET DEFAULT nextval('supabase_functions.hooks_id_seq'::regclass);


--
-- TOC entry 4613 (class 0 OID 17399)
-- Dependencies: 261
-- Data for Name: extensions; Type: TABLE DATA; Schema: _realtime; Owner: supabase_admin
--

COPY _realtime.extensions (id, type, settings, tenant_external_id, inserted_at, updated_at) FROM stdin;
65df2eaa-f7f8-4b45-b8e3-5c77233caef2	postgres_cdc_rls	{"region": "us-east-1", "db_host": "tAy3GUAuUlGE0yG6KUUpk0/ZVyoeWKveyb9k1Nv4OwY=", "db_name": "sWBpZNdjggEPTQVlI52Zfw==", "db_port": "+enMDFi1J/3IrrquHHwUmA==", "db_user": "uxbEq/zz8DXVD53TOI1zmw==", "slot_name": "supabase_realtime_replication_slot", "db_password": "sWBpZNdjggEPTQVlI52Zfw==", "publication": "supabase_realtime", "ssl_enforced": false, "poll_interval_ms": 100, "poll_max_changes": 100, "poll_max_record_bytes": 1048576}	realtime-dev	2025-10-11 22:54:01	2025-10-11 22:54:01
\.


--
-- TOC entry 4611 (class 0 OID 17385)
-- Dependencies: 259
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: _realtime; Owner: supabase_admin
--

COPY _realtime.schema_migrations (version, inserted_at) FROM stdin;
20210706140551	2025-10-11 22:54:00
20220329161857	2025-10-11 22:54:00
20220410212326	2025-10-11 22:54:00
20220506102948	2025-10-11 22:54:00
20220527210857	2025-10-11 22:54:00
20220815211129	2025-10-11 22:54:00
20220815215024	2025-10-11 22:54:00
20220818141501	2025-10-11 22:54:00
20221018173709	2025-10-11 22:54:00
20221102172703	2025-10-11 22:54:00
20221223010058	2025-10-11 22:54:00
20230110180046	2025-10-11 22:54:00
20230810220907	2025-10-11 22:54:00
20230810220924	2025-10-11 22:54:00
20231024094642	2025-10-11 22:54:00
20240306114423	2025-10-11 22:54:00
20240418082835	2025-10-11 22:54:00
20240625211759	2025-10-11 22:54:00
20240704172020	2025-10-11 22:54:00
20240902173232	2025-10-11 22:54:00
20241106103258	2025-10-11 22:54:00
20250424203323	2025-10-11 22:54:00
20250613072131	2025-10-11 22:54:00
20250711044927	2025-10-11 22:54:00
20250811121559	2025-10-11 22:54:00
\.


--
-- TOC entry 4612 (class 0 OID 17390)
-- Dependencies: 260
-- Data for Name: tenants; Type: TABLE DATA; Schema: _realtime; Owner: supabase_admin
--

COPY _realtime.tenants (id, name, external_id, jwt_secret, max_concurrent_users, inserted_at, updated_at, max_events_per_second, postgres_cdc_default, max_bytes_per_second, max_channels_per_client, max_joins_per_second, suspend, jwt_jwks, notify_private_alpha, private_only, migrations_ran, broadcast_adapter, max_presence_events_per_second, max_payload_size_in_kb) FROM stdin;
a5c319b2-7c10-4b43-af79-f2134f91b0cf	realtime-dev	realtime-dev	iNjicxc4+llvc9wovDvqymwfnj9teWMlyOIbJ8Fh6j2WNU8CIJ2ZgjR6MUIKqSmeDmvpsKLsZ9jgXJmQPpwL8w==	200	2025-10-11 22:54:01	2025-10-11 22:54:01	100	postgres_cdc_rls	100000	100	100	f	\N	f	f	63	gen_rpc	10000	3000
\.


--
-- TOC entry 4603 (class 0 OID 16488)
-- Dependencies: 241
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- TOC entry 4637 (class 0 OID 18155)
-- Dependencies: 289
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at) FROM stdin;
\.


--
-- TOC entry 4628 (class 0 OID 17953)
-- Dependencies: 280
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
\.


--
-- TOC entry 4602 (class 0 OID 16481)
-- Dependencies: 240
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4632 (class 0 OID 18042)
-- Dependencies: 284
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
\.


--
-- TOC entry 4631 (class 0 OID 18030)
-- Dependencies: 283
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- TOC entry 4630 (class 0 OID 18017)
-- Dependencies: 282
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid) FROM stdin;
\.


--
-- TOC entry 4638 (class 0 OID 18205)
-- Dependencies: 290
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4601 (class 0 OID 16470)
-- Dependencies: 239
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
\.


--
-- TOC entry 4635 (class 0 OID 18084)
-- Dependencies: 287
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- TOC entry 4636 (class 0 OID 18102)
-- Dependencies: 288
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- TOC entry 4604 (class 0 OID 16496)
-- Dependencies: 242
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
\.


--
-- TOC entry 4629 (class 0 OID 17983)
-- Dependencies: 281
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag) FROM stdin;
\.


--
-- TOC entry 4634 (class 0 OID 18069)
-- Dependencies: 286
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4633 (class 0 OID 18060)
-- Dependencies: 285
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- TOC entry 4599 (class 0 OID 16458)
-- Dependencies: 237
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
\.


--
-- TOC entry 4641 (class 0 OID 18365)
-- Dependencies: 293
-- Data for Name: companies; Type: TABLE DATA; Schema: company; Owner: postgres
--

COPY company.companies (id, name, industry, founded_year, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4646 (class 0 OID 18421)
-- Dependencies: 298
-- Data for Name: departments; Type: TABLE DATA; Schema: company; Owner: postgres
--

COPY company.departments (id, company_id, name, head_of_department, budget, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4647 (class 0 OID 18429)
-- Dependencies: 299
-- Data for Name: kpi_data; Type: TABLE DATA; Schema: company; Owner: postgres
--

COPY company.kpi_data (id, department_id, metric_id, value, date_recorded, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4648 (class 0 OID 18435)
-- Dependencies: 300
-- Data for Name: kpi_goals; Type: TABLE DATA; Schema: company; Owner: postgres
--

COPY company.kpi_goals (id, department_id, metric_id, target_value, period_start, period_end, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4649 (class 0 OID 18441)
-- Dependencies: 301
-- Data for Name: kpi_metrics; Type: TABLE DATA; Schema: company; Owner: postgres
--

COPY company.kpi_metrics (id, name, metric_type, unit, description, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4663 (class 0 OID 18933)
-- Dependencies: 316
-- Data for Name: agent_orchestrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_orchestrations (id, organization_slug, agent_slug, slug, display_name, description, status, orchestration_json, prompt_templates, tags, version, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4661 (class 0 OID 18890)
-- Dependencies: 314
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agents (id, organization_slug, slug, display_name, description, agent_type, mode_profile, version, status, yaml, agent_card, context, config, created_at, updated_at, function_code) FROM stdin;
5f72997b-233f-41f2-af6a-0e07aa2d706c	my-org	image_openai_generator	OpenAI Image Generator	Generates images via OpenAI function handler	function	full_cycle	1.0.0	active	{"metadata": {"type": "function", "category": "image", "description": "Generates images via OpenAI provider", "displayName": "OpenAI Image Generator"}, "hierarchy": {"department": "images", "reports_to": "image_orchestrator"}, "input_modes": ["text/plain"], "capabilities": ["image_generation"], "output_modes": ["image/png", "image/jpeg", "application/json"], "configuration": {"function": {"code": "async function handler(input, ctx) {\\n  const { prompt, size = '512x512', n = 1, deliverableId = null } = input || {};\\n  const out = await ctx.services.images.generate({ prompt, size, n, title: 'OpenAI Images', provider: 'openai', deliverableId });\\n  return out;\\n}", "version": "1", "language": "js", "timeout_ms": 20000}, "execution_profile": "full_cycle", "execution_capabilities": {"can_plan": false, "can_build": true, "requires_human_gate": false}}}	\N	{}	{"hierarchy": {"department": "images", "reports_to": "image_orchestrator"}, "input_modes": ["text/plain"], "capabilities": ["image_generation"], "output_modes": ["image/png", "image/jpeg", "application/json"], "configuration": {"function": {"code": "async function handler(input, ctx) {\\n  const { prompt, size = '512x512', n = 1, deliverableId = null } = input || {};\\n  const out = await ctx.services.images.generate({ prompt, size, n, title: 'OpenAI Images', provider: 'openai', deliverableId });\\n  return out;\\n}", "version": "1", "language": "js", "timeout_ms": 20000}, "execution_profile": "full_cycle", "execution_capabilities": {"can_plan": false, "can_build": true, "requires_human_gate": false}}}	2025-10-11 22:54:03.580548+00	2025-10-11 22:54:03.580548+00	\N
c41f9813-bfa3-4c79-b024-37a43ad7896b	my-org	image_google_generator	Google Image Generator	Generates images via Google (Gemini/Imagen) function handler	function	full_cycle	1.0.0	active	{"metadata": {"type": "function", "category": "image", "description": "Generates images via Google (Gemini/Imagen) provider", "displayName": "Google Image Generator"}, "hierarchy": {"department": "images", "reports_to": "image_orchestrator"}, "input_modes": ["text/plain"], "capabilities": ["image_generation"], "output_modes": ["image/png", "image/jpeg", "application/json"], "configuration": {"function": {"code": "async function handler(input, ctx) {\\n  const { prompt, size = '512x512', n = 1, deliverableId = null } = input || {};\\n  const out = await ctx.services.images.generate({ prompt, size, n, title: 'Google Images', provider: 'gemini', deliverableId });\\n  return out;\\n}", "version": "1", "language": "js", "timeout_ms": 20000}, "execution_profile": "full_cycle", "execution_capabilities": {"can_plan": false, "can_build": true, "requires_human_gate": false}}}	\N	{}	{"hierarchy": {"department": "images", "reports_to": "image_orchestrator"}, "input_modes": ["text/plain"], "capabilities": ["image_generation"], "output_modes": ["image/png", "image/jpeg", "application/json"], "configuration": {"function": {"code": "async function handler(input, ctx) {\\n  const { prompt, size = '512x512', n = 1, deliverableId = null } = input || {};\\n  const out = await ctx.services.images.generate({ prompt, size, n, title: 'Google Images', provider: 'gemini', deliverableId });\\n  return out;\\n}", "version": "1", "language": "js", "timeout_ms": 20000}, "execution_profile": "full_cycle", "execution_capabilities": {"can_plan": false, "can_build": true, "requires_human_gate": false}}}	2025-10-11 22:54:03.580548+00	2025-10-11 22:54:03.580548+00	\N
b85e0982-8d63-49c2-842b-6d175ff00866	my-org	image_orchestrator	Image Orchestrator	Fan-out image generation to multiple providers	function	full_cycle	1.0.0	active	{"metadata": {"type": "function", "category": "image", "description": "Fans out image generation across multiple providers", "displayName": "Image Orchestrator"}, "hierarchy": {"team": ["image_openai_generator", "image_google_generator"], "department": "images"}, "input_modes": ["text/plain"], "capabilities": ["image_generation"], "output_modes": ["image/png", "image/jpeg", "application/json"], "configuration": {"function": {"code": "async function handler(input, ctx) {\\n  const { prompt, size = '512x512', n = 1, providers = ['openai','gemini'], deliverableId = null } = input || {};\\n  let last = null;\\n  for (const p of providers) {\\n    last = await ctx.services.images.generate({ prompt, size, n, title: 'Image Orchestrator', provider: p, deliverableId });\\n  }\\n  return last;\\n}", "version": "1", "language": "js", "timeout_ms": 20000}, "execution_profile": "full_cycle", "execution_capabilities": {"can_plan": false, "can_build": true, "requires_human_gate": false}}}	\N	{}	{"hierarchy": {"team": ["image_openai_generator", "image_google_generator"], "department": "images"}, "input_modes": ["text/plain"], "capabilities": ["image_generation"], "output_modes": ["image/png", "image/jpeg", "application/json"], "configuration": {"function": {"code": "async function handler(input, ctx) {\\n  const { prompt, size = '512x512', n = 1, providers = ['openai','gemini'], deliverableId = null } = input || {};\\n  let last = null;\\n  for (const p of providers) {\\n    last = await ctx.services.images.generate({ prompt, size, n, title: 'Image Orchestrator', provider: p, deliverableId });\\n  }\\n  return last;\\n}", "version": "1", "language": "js", "timeout_ms": 20000}, "execution_profile": "full_cycle", "execution_capabilities": {"can_plan": false, "can_build": true, "requires_human_gate": false}}}	2025-10-11 22:54:03.582327+00	2025-10-11 22:54:03.582327+00	\N
372cb88a-473e-4719-989d-fdb3300aad1d	my-org	blog_post_writer	Blog Post Writer	Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.	context	plan-build-converse	\N	active	\nname: blog_post_writer\ndisplay_name: Blog Post Writer\ndescription: Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\nagent_type: context\nmode_profile: plan-build-converse\nversion: "1.0"\nstatus: active\n\nsystem_prompt: |\n  Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\n\n  When creating a plan for a blog post, structure it with the following sections:\n\n  # Blog Post Plan\n\n  ## Title & Topic\n  - Working title\n  - Target topic/theme\n  - Angle or unique perspective\n\n  ## Audience & Purpose\n  - Target audience description\n  - Primary goal (inform, persuade, entertain, etc.)\n  - Reader takeaway\n\n  ## Content Strategy\n  - Word count target\n  - SEO keywords\n  - Key points to cover\n\n  When building a deliverable, create:\n  - Engaging introduction\n  - Clear section headings\n  - Actionable content\n  - Strong conclusion with CTA\n\n  When conversing, provide helpful suggestions for improving blog content.\n\nmodes:\n  plan:\n    enabled: true\n    actions:\n      - create\n      - read\n      - list\n      - edit\n      - set_current\n      - delete_version\n      - merge_versions\n      - copy_version\n      - delete\n\n  build:\n    enabled: true\n    actions:\n      - create\n      - read\n      - list\n      - edit\n      - rerun\n      - set_current\n      - delete_version\n      - merge_versions\n      - copy_version\n      - delete\n\n  converse:\n    enabled: true\n\nllm_defaults:\n  provider: ollama\n  model: llama3.2:1b\n  temperature: 0.7\n	{"system_prompt": "Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\\n\\nWhen creating a plan for a blog post, structure it with the following sections:\\n\\n# Blog Post Plan\\n\\n## Title & Topic\\n- Working title\\n- Target topic/theme\\n- Angle or unique perspective\\n\\n## Audience & Purpose\\n- Target audience description\\n- Primary goal (inform, persuade, entertain, etc.)\\n- Reader takeaway\\n\\n## Content Strategy\\n- Word count target\\n- SEO keywords\\n- Key points to cover\\n\\nWhen building a deliverable, create:\\n- Engaging introduction\\n- Clear section headings\\n- Actionable content\\n- Strong conclusion with CTA\\n\\nWhen conversing, provide helpful suggestions for improving blog content."}	{"plan": {"template": "Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\\n\\nWhen creating a plan for a blog post, structure it with the following sections:\\n\\n# Blog Post Plan\\n\\n## Title & Topic\\n- Working title\\n- Target topic/theme\\n- Angle or unique perspective\\n\\n## Audience & Purpose\\n- Target audience description\\n- Primary goal (inform, persuade, entertain, etc.)\\n- Reader takeaway\\n\\n## Content Strategy\\n- Word count target\\n- SEO keywords\\n- Key points to cover\\n\\nWhen building a deliverable, create:\\n- Engaging introduction\\n- Clear section headings\\n- Actionable content\\n- Strong conclusion with CTA\\n\\nWhen conversing, provide helpful suggestions for improving blog content."}, "build": {"template": "Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\\n\\nWhen creating a plan for a blog post, structure it with the following sections:\\n\\n# Blog Post Plan\\n\\n## Title & Topic\\n- Working title\\n- Target topic/theme\\n- Angle or unique perspective\\n\\n## Audience & Purpose\\n- Target audience description\\n- Primary goal (inform, persuade, entertain, etc.)\\n- Reader takeaway\\n\\n## Content Strategy\\n- Word count target\\n- SEO keywords\\n- Key points to cover\\n\\nWhen building a deliverable, create:\\n- Engaging introduction\\n- Clear section headings\\n- Actionable content\\n- Strong conclusion with CTA\\n\\nWhen conversing, provide helpful suggestions for improving blog content."}, "converse": {"template": "Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\\n\\nWhen creating a plan for a blog post, structure it with the following sections:\\n\\n# Blog Post Plan\\n\\n## Title & Topic\\n- Working title\\n- Target topic/theme\\n- Angle or unique perspective\\n\\n## Audience & Purpose\\n- Target audience description\\n- Primary goal (inform, persuade, entertain, etc.)\\n- Reader takeaway\\n\\n## Content Strategy\\n- Word count target\\n- SEO keywords\\n- Key points to cover\\n\\nWhen building a deliverable, create:\\n- Engaging introduction\\n- Clear section headings\\n- Actionable content\\n- Strong conclusion with CTA\\n\\nWhen conversing, provide helpful suggestions for improving blog content."}}	{"llm_defaults": {"model": "llama3.2:1b", "provider": "ollama", "temperature": 0.7}}	2025-10-11 22:54:03.607192+00	2025-10-11 22:54:03.607192+00	\N
\.


--
-- TOC entry 4669 (class 0 OID 19067)
-- Dependencies: 323
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.assets (id, storage, path, bucket, object_key, mime, size, width, height, hash, user_id, conversation_id, deliverable_version_id, created_at, updated_at, source_url) FROM stdin;
\.


--
-- TOC entry 4640 (class 0 OID 18354)
-- Dependencies: 292
-- Data for Name: cidafm_commands; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cidafm_commands (id, type, name, description, default_active, is_builtin, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4642 (class 0 OID 18371)
-- Dependencies: 294
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conversations (id, user_id, agent_name, agent_type, started_at, last_active_at, metadata, created_at, updated_at, organization_slug, ended_at) FROM stdin;
\.


--
-- TOC entry 4644 (class 0 OID 18400)
-- Dependencies: 296
-- Data for Name: deliverable_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deliverable_versions (id, deliverable_id, version_number, content, format, is_current_version, created_by_type, task_id, metadata, file_attachments, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4645 (class 0 OID 18413)
-- Dependencies: 297
-- Data for Name: deliverables; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deliverables (id, user_id, conversation_id, project_step_id, agent_name, title, type, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4665 (class 0 OID 18984)
-- Dependencies: 318
-- Data for Name: human_approvals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.human_approvals (id, organization_slug, agent_slug, conversation_id, task_id, mode, status, approved_by, decision_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4660 (class 0 OID 18845)
-- Dependencies: 312
-- Data for Name: jokes_agent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jokes_agent (id, session_id, prompt, joke_output, created_at, updated_at) FROM stdin;
d1a3c0dd-3147-4ef0-945c-3fef79afd974	fallback	error_fallback	Why don't productivity apps ever get stressed? Because they know how to delegate their tasks!	2025-10-11 22:54:03.509222+00	2025-10-11 22:54:03.509222+00
e1d41fb4-3d16-4f4d-8656-244d6fc5c4aa	fallback	error_fallback	What do you call a programmer who doesn't comment their code? A mystery novelist!	2025-10-11 22:54:03.509222+00	2025-10-11 22:54:03.509222+00
9b9e0a11-7d90-4242-8aa7-567bc6bfb9d8	fallback	error_fallback	Why did the spreadsheet go to therapy? It had too many cells of anxiety!	2025-10-11 22:54:03.509222+00	2025-10-11 22:54:03.509222+00
6265e5a7-9eef-4aff-9aaf-e419ae194c24	fallback	error_fallback	How do you comfort a JavaScript bug? You console it!	2025-10-11 22:54:03.509222+00	2025-10-11 22:54:03.509222+00
6e3ba4e0-ca64-4d9d-beba-d7e44b2d51bd	fallback	error_fallback	Why don't databases ever get lonely? Because they always have relationships!	2025-10-11 22:54:03.509222+00	2025-10-11 22:54:03.509222+00
\.


--
-- TOC entry 4650 (class 0 OID 18449)
-- Dependencies: 302
-- Data for Name: llm_models; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llm_models (model_name, provider_name, display_name, model_type, model_version, context_window, max_output_tokens, model_parameters_json, pricing_info_json, capabilities, model_tier, speed_tier, loading_priority, is_local, is_currently_loaded, is_active, training_data_cutoff, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4651 (class 0 OID 18467)
-- Dependencies: 303
-- Data for Name: llm_providers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llm_providers (name, display_name, api_base_url, configuration_json, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4652 (class 0 OID 18476)
-- Dependencies: 304
-- Data for Name: llm_usage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llm_usage (id, run_id, user_id, conversation_id, provider_name, model_name, input_tokens, output_tokens, input_cost, output_cost, duration_ms, status, caller_type, agent_name, is_local, model_tier, fallback_used, routing_reason, complexity_level, complexity_score, data_classification, started_at, completed_at, error_message, data_sanitization_applied, sanitization_level, pii_detected, pii_types, pseudonyms_used, pseudonym_types, redactions_applied, redaction_types, source_blinding_applied, headers_stripped, custom_user_agent_used, proxy_used, no_train_header_sent, no_retain_header_sent, sanitization_time_ms, reversal_context_size, policy_profile, sovereign_mode, compliance_flags, created_at, route, total_cost, pseudonym_mappings) FROM stdin;
\.


--
-- TOC entry 4668 (class 0 OID 19042)
-- Dependencies: 321
-- Data for Name: orchestration_checkpoints; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orchestration_checkpoints (id, orchestration_run_id, step_index, label, state, metadata, created_by, created_at) FROM stdin;
\.


--
-- TOC entry 4664 (class 0 OID 18948)
-- Dependencies: 317
-- Data for Name: orchestration_runs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orchestration_runs (id, plan_id, origin_type, origin_id, orchestration_slug, prompt_inputs, organization_slug, status, current_step_index, completed_steps, step_state, human_checkpoint_id, metadata, started_at, completed_at) FROM stdin;
\.


--
-- TOC entry 4667 (class 0 OID 19020)
-- Dependencies: 320
-- Data for Name: orchestration_steps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orchestration_steps (id, orchestration_run_id, step_index, step_key, status, agent_slug, input, output, metadata, error, started_at, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4662 (class 0 OID 18903)
-- Dependencies: 315
-- Data for Name: organization_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_credentials (id, organization_slug, alias, credential_type, encrypted_value, encryption_metadata, rotated_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4671 (class 0 OID 19113)
-- Dependencies: 325
-- Data for Name: plan_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_versions (id, plan_id, version_number, content, format, created_by_type, created_by_id, task_id, metadata, is_current_version, created_at) FROM stdin;
\.


--
-- TOC entry 4670 (class 0 OID 19091)
-- Dependencies: 324
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plans (id, conversation_id, user_id, agent_name, namespace, title, current_version_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4653 (class 0 OID 18504)
-- Dependencies: 305
-- Data for Name: project_steps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_steps (id, project_id, step_id, step_index, step_type, step_name, agent_name, prompt, dependencies, status, result, error_details, started_at, completed_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4654 (class 0 OID 18517)
-- Dependencies: 306
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects (id, conversation_id, name, description, plan_json, status, current_step_id, error_details, metadata, parent_project_id, hierarchy_level, subproject_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4655 (class 0 OID 18530)
-- Dependencies: 307
-- Data for Name: pseudonym_dictionaries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pseudonym_dictionaries (id, original_value, pseudonym, data_type, category, frequency_weight, is_active, created_at, organization_slug, agent_slug, updated_at) FROM stdin;
\.


--
-- TOC entry 4656 (class 0 OID 18539)
-- Dependencies: 308
-- Data for Name: redaction_patterns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.redaction_patterns (id, name, pattern_regex, replacement, description, category, priority, is_active, severity, data_type, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4657 (class 0 OID 18550)
-- Dependencies: 309
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_settings (key, value, updated_at) FROM stdin;
\.


--
-- TOC entry 4666 (class 0 OID 19000)
-- Dependencies: 319
-- Data for Name: task_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_messages (id, task_id, user_id, content, message_type, progress_percentage, metadata, created_at, expires_at) FROM stdin;
\.


--
-- TOC entry 4643 (class 0 OID 18380)
-- Dependencies: 295
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (id, user_id, conversation_id, method, params, prompt, response, status, progress, progress_message, error_code, error_message, error_data, started_at, completed_at, timeout_seconds, deliverable_type, deliverable_metadata, metadata, llm_metadata, response_metadata, evaluation, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4658 (class 0 OID 18556)
-- Dependencies: 310
-- Data for Name: user_cidafm_commands; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_cidafm_commands (id, user_id, command_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4659 (class 0 OID 18563)
-- Dependencies: 311
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, display_name, role, roles, created_at, updated_at, namespace_access, status, organization_slug) FROM stdin;
\.


--
-- TOC entry 4617 (class 0 OID 17701)
-- Dependencies: 269
-- Data for Name: messages_2025_10_10; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_10_10 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4618 (class 0 OID 17712)
-- Dependencies: 270
-- Data for Name: messages_2025_10_11; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_10_11 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4619 (class 0 OID 17723)
-- Dependencies: 271
-- Data for Name: messages_2025_10_12; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_10_12 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4620 (class 0 OID 17734)
-- Dependencies: 272
-- Data for Name: messages_2025_10_13; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_10_13 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4621 (class 0 OID 17745)
-- Dependencies: 273
-- Data for Name: messages_2025_10_14; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_10_14 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4614 (class 0 OID 17522)
-- Dependencies: 262
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2025-10-11 22:54:01
20211116045059	2025-10-11 22:54:01
20211116050929	2025-10-11 22:54:01
20211116051442	2025-10-11 22:54:01
20211116212300	2025-10-11 22:54:01
20211116213355	2025-10-11 22:54:01
20211116213934	2025-10-11 22:54:01
20211116214523	2025-10-11 22:54:01
20211122062447	2025-10-11 22:54:01
20211124070109	2025-10-11 22:54:01
20211202204204	2025-10-11 22:54:01
20211202204605	2025-10-11 22:54:01
20211210212804	2025-10-11 22:54:01
20211228014915	2025-10-11 22:54:01
20220107221237	2025-10-11 22:54:01
20220228202821	2025-10-11 22:54:01
20220312004840	2025-10-11 22:54:01
20220603231003	2025-10-11 22:54:01
20220603232444	2025-10-11 22:54:01
20220615214548	2025-10-11 22:54:01
20220712093339	2025-10-11 22:54:01
20220908172859	2025-10-11 22:54:01
20220916233421	2025-10-11 22:54:01
20230119133233	2025-10-11 22:54:01
20230128025114	2025-10-11 22:54:01
20230128025212	2025-10-11 22:54:01
20230227211149	2025-10-11 22:54:01
20230228184745	2025-10-11 22:54:01
20230308225145	2025-10-11 22:54:01
20230328144023	2025-10-11 22:54:01
20231018144023	2025-10-11 22:54:01
20231204144023	2025-10-11 22:54:01
20231204144024	2025-10-11 22:54:01
20231204144025	2025-10-11 22:54:01
20240108234812	2025-10-11 22:54:01
20240109165339	2025-10-11 22:54:01
20240227174441	2025-10-11 22:54:01
20240311171622	2025-10-11 22:54:01
20240321100241	2025-10-11 22:54:01
20240401105812	2025-10-11 22:54:01
20240418121054	2025-10-11 22:54:01
20240523004032	2025-10-11 22:54:01
20240618124746	2025-10-11 22:54:01
20240801235015	2025-10-11 22:54:01
20240805133720	2025-10-11 22:54:01
20240827160934	2025-10-11 22:54:01
20240919163303	2025-10-11 22:54:01
20240919163305	2025-10-11 22:54:01
20241019105805	2025-10-11 22:54:01
20241030150047	2025-10-11 22:54:01
20241108114728	2025-10-11 22:54:01
20241121104152	2025-10-11 22:54:01
20241130184212	2025-10-11 22:54:01
20241220035512	2025-10-11 22:54:01
20241220123912	2025-10-11 22:54:01
20241224161212	2025-10-11 22:54:01
20250107150512	2025-10-11 22:54:01
20250110162412	2025-10-11 22:54:01
20250123174212	2025-10-11 22:54:01
20250128220012	2025-10-11 22:54:01
20250506224012	2025-10-11 22:54:01
20250523164012	2025-10-11 22:54:01
20250714121412	2025-10-11 22:54:01
\.


--
-- TOC entry 4616 (class 0 OID 17545)
-- Dependencies: 265
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at) FROM stdin;
\.


--
-- TOC entry 4605 (class 0 OID 16509)
-- Dependencies: 243
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
\.


--
-- TOC entry 4625 (class 0 OID 17886)
-- Dependencies: 277
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets_analytics (id, type, format, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4626 (class 0 OID 17897)
-- Dependencies: 278
-- Data for Name: iceberg_namespaces; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.iceberg_namespaces (id, bucket_id, name, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4627 (class 0 OID 17913)
-- Dependencies: 279
-- Data for Name: iceberg_tables; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.iceberg_tables (id, namespace_id, bucket_id, name, location, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4607 (class 0 OID 16551)
-- Dependencies: 245
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2025-10-11 22:54:02.640163
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2025-10-11 22:54:02.642047
2	storage-schema	5c7968fd083fcea04050c1b7f6253c9771b99011	2025-10-11 22:54:02.642878
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2025-10-11 22:54:02.646568
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2025-10-11 22:54:02.649061
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2025-10-11 22:54:02.649874
6	change-column-name-in-get-size	f93f62afdf6613ee5e7e815b30d02dc990201044	2025-10-11 22:54:02.651088
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2025-10-11 22:54:02.652262
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2025-10-11 22:54:02.653049
9	fix-search-function	3a0af29f42e35a4d101c259ed955b67e1bee6825	2025-10-11 22:54:02.653827
10	search-files-search-function	68dc14822daad0ffac3746a502234f486182ef6e	2025-10-11 22:54:02.654901
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2025-10-11 22:54:02.655904
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2025-10-11 22:54:02.656958
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2025-10-11 22:54:02.657638
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2025-10-11 22:54:02.658346
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2025-10-11 22:54:02.663372
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2025-10-11 22:54:02.664224
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2025-10-11 22:54:02.66488
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2025-10-11 22:54:02.665729
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2025-10-11 22:54:02.666721
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2025-10-11 22:54:02.667398
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2025-10-11 22:54:02.668583
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2025-10-11 22:54:02.671281
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2025-10-11 22:54:02.673348
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2025-10-11 22:54:02.675165
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2025-10-11 22:54:02.676013
26	objects-prefixes	ef3f7871121cdc47a65308e6702519e853422ae2	2025-10-11 22:54:02.676776
27	search-v2	33b8f2a7ae53105f028e13e9fcda9dc4f356b4a2	2025-10-11 22:54:02.680155
28	object-bucket-name-sorting	ba85ec41b62c6a30a3f136788227ee47f311c436	2025-10-11 22:54:02.702357
29	create-prefixes	a7b1a22c0dc3ab630e3055bfec7ce7d2045c5b7b	2025-10-11 22:54:02.70374
30	update-object-levels	6c6f6cc9430d570f26284a24cf7b210599032db7	2025-10-11 22:54:02.704597
31	objects-level-index	33f1fef7ec7fea08bb892222f4f0f5d79bab5eb8	2025-10-11 22:54:02.70555
32	backward-compatible-index-on-objects	2d51eeb437a96868b36fcdfb1ddefdf13bef1647	2025-10-11 22:54:02.706462
33	backward-compatible-index-on-prefixes	fe473390e1b8c407434c0e470655945b110507bf	2025-10-11 22:54:02.707295
34	optimize-search-function-v1	82b0e469a00e8ebce495e29bfa70a0797f7ebd2c	2025-10-11 22:54:02.707473
35	add-insert-trigger-prefixes	63bb9fd05deb3dc5e9fa66c83e82b152f0caf589	2025-10-11 22:54:02.709067
36	optimise-existing-functions	81cf92eb0c36612865a18016a38496c530443899	2025-10-11 22:54:02.709773
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2025-10-11 22:54:02.711775
38	iceberg-catalog-flag-on-buckets	19a8bd89d5dfa69af7f222a46c726b7c41e462c5	2025-10-11 22:54:02.712548
\.


--
-- TOC entry 4606 (class 0 OID 16524)
-- Dependencies: 244
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata, level) FROM stdin;
\.


--
-- TOC entry 4624 (class 0 OID 17841)
-- Dependencies: 276
-- Data for Name: prefixes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.prefixes (bucket_id, name, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4622 (class 0 OID 17788)
-- Dependencies: 274
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata) FROM stdin;
\.


--
-- TOC entry 4623 (class 0 OID 17802)
-- Dependencies: 275
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- TOC entry 4610 (class 0 OID 16763)
-- Dependencies: 258
-- Data for Name: hooks; Type: TABLE DATA; Schema: supabase_functions; Owner: supabase_functions_admin
--

COPY supabase_functions.hooks (id, hook_table_id, hook_name, created_at, request_id) FROM stdin;
\.


--
-- TOC entry 4608 (class 0 OID 16754)
-- Dependencies: 256
-- Data for Name: migrations; Type: TABLE DATA; Schema: supabase_functions; Owner: supabase_functions_admin
--

COPY supabase_functions.migrations (version, inserted_at) FROM stdin;
initial	2025-10-11 22:53:50.287879+00
20210809183423_update_grants	2025-10-11 22:53:50.287879+00
\.


--
-- TOC entry 4639 (class 0 OID 18232)
-- Dependencies: 291
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: supabase_migrations; Owner: postgres
--

COPY supabase_migrations.schema_migrations (version, statements, name) FROM stdin;
00000000000001	{"SET statement_timeout = 0","SET lock_timeout = 0","SET idle_in_transaction_session_timeout = 0","SET client_encoding = 'UTF8'","SET standard_conforming_strings = on","SELECT pg_catalog.set_config('search_path', '', false)","SET check_function_bodies = false","SET xmloption = content","SET client_min_messages = warning","SET row_security = off","CREATE EXTENSION IF NOT EXISTS \\"pg_net\\" WITH SCHEMA \\"extensions\\"","COMMENT ON SCHEMA \\"public\\" IS 'standard public schema'","CREATE EXTENSION IF NOT EXISTS \\"pg_graphql\\" WITH SCHEMA \\"graphql\\"","CREATE EXTENSION IF NOT EXISTS \\"pg_stat_statements\\" WITH SCHEMA \\"extensions\\"","CREATE EXTENSION IF NOT EXISTS \\"pgcrypto\\" WITH SCHEMA \\"extensions\\"","CREATE EXTENSION IF NOT EXISTS \\"supabase_vault\\" WITH SCHEMA \\"vault\\"","CREATE EXTENSION IF NOT EXISTS \\"uuid-ossp\\" WITH SCHEMA \\"extensions\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"calculate_completion_percentage\\"(\\"requirements\\" \\"jsonb\\") RETURNS integer\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nDECLARE\n    total_fields INTEGER := 12;  -- Total required fields\n    completed_fields INTEGER := 0;\n    field_name TEXT;\nBEGIN\n    -- Count non-null, non-empty required fields\n    FOR field_name IN SELECT * FROM jsonb_object_keys(requirements)\n    LOOP\n        IF requirements ->> field_name IS NOT NULL \n           AND LENGTH(TRIM(requirements ->> field_name)) > 0 THEN\n            completed_fields := completed_fields + 1;\n        END IF;\n    END LOOP;\n    \n    RETURN (completed_fields * 100 / total_fields);\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"calculate_completion_percentage\\"(\\"requirements\\" \\"jsonb\\") OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"cleanup_abandoned_conversations\\"() RETURNS integer\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nDECLARE\n    deleted_count INTEGER;\nBEGIN\n    -- Delete conversations abandoned for more than 7 days\n    DELETE FROM agent_creation_conversations\n    WHERE completion_status = 'in_progress'\n      AND last_activity_at < NOW() - INTERVAL '7 days';\n    \n    GET DIAGNOSTICS deleted_count = ROW_COUNT;\n    RETURN deleted_count;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"cleanup_abandoned_conversations\\"() OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"exec_sql\\"(\\"query\\" \\"text\\" DEFAULT NULL::\\"text\\", \\"sql_query\\" \\"text\\" DEFAULT NULL::\\"text\\") RETURNS SETOF \\"jsonb\\"\n    LANGUAGE \\"plpgsql\\" SECURITY DEFINER\n    SET \\"search_path\\" TO 'public'\n    AS $$\ndeclare\n  q text := coalesce(query, sql_query);\n  r record;\nbegin\n  if q is null or length(trim(q)) = 0 then\n    raise exception 'No SQL provided to exec_sql()';\n  end if;\n\n  -- Execute the query and stream rows as JSONB\n  for r in execute q loop\n    return next to_jsonb(r);\n  end loop;\n  return;\n\nexception when others then\n  -- Return a single JSON object describing the error (so callers get structured feedback)\n  return query select jsonb_build_object(\n    'error', true,\n    'message', sqlerrm,\n    'code', sqlstate\n  );\nend;\n$$","ALTER FUNCTION \\"public\\".\\"exec_sql\\"(\\"query\\" \\"text\\", \\"sql_query\\" \\"text\\") OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"get_global_model_config\\"() RETURNS \\"jsonb\\"\n    LANGUAGE \\"sql\\" STABLE\n    AS $$\n  SELECT value FROM public.system_settings WHERE key = 'model_config_global';\n$$","ALTER FUNCTION \\"public\\".\\"get_global_model_config\\"() OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"log_agent_action\\"(\\"p_action\\" character varying, \\"p_agent_id\\" \\"uuid\\", \\"p_details\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\", \\"p_previous_state\\" \\"jsonb\\" DEFAULT NULL::\\"jsonb\\", \\"p_new_state\\" \\"jsonb\\" DEFAULT NULL::\\"jsonb\\", \\"p_success\\" boolean DEFAULT true, \\"p_error_message\\" \\"text\\" DEFAULT NULL::\\"text\\") RETURNS \\"uuid\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nDECLARE\n    log_id UUID;\nBEGIN\n    INSERT INTO agent_creation_logs (\n        action, agent_configuration_id, performed_by, details,\n        previous_state, new_state, success, error_message\n    ) VALUES (\n        p_action, p_agent_id, auth.uid(), p_details,\n        p_previous_state, p_new_state, p_success, p_error_message\n    ) RETURNING id INTO log_id;\n    \n    RETURN log_id;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"log_agent_action\\"(\\"p_action\\" character varying, \\"p_agent_id\\" \\"uuid\\", \\"p_details\\" \\"jsonb\\", \\"p_previous_state\\" \\"jsonb\\", \\"p_new_state\\" \\"jsonb\\", \\"p_success\\" boolean, \\"p_error_message\\" \\"text\\") OWNER TO \\"postgres\\"","COMMENT ON FUNCTION \\"public\\".\\"log_agent_action\\"(\\"p_action\\" character varying, \\"p_agent_id\\" \\"uuid\\", \\"p_details\\" \\"jsonb\\", \\"p_previous_state\\" \\"jsonb\\", \\"p_new_state\\" \\"jsonb\\", \\"p_success\\" boolean, \\"p_error_message\\" \\"text\\") IS 'Helper function to create audit log entries'","CREATE OR REPLACE FUNCTION \\"public\\".\\"update_agent_configurations_updated_at\\"() RETURNS \\"trigger\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nBEGIN\n    NEW.updated_at = NOW();\n    RETURN NEW;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"update_agent_configurations_updated_at\\"() OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"update_agent_skills_updated_at\\"() RETURNS \\"trigger\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nBEGIN\n    NEW.updated_at = NOW();\n    RETURN NEW;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"update_agent_skills_updated_at\\"() OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"update_agent_usage_analytics\\"(\\"p_agent_id\\" \\"uuid\\", \\"p_conversation_increment\\" integer DEFAULT 0, \\"p_message_increment\\" integer DEFAULT 0, \\"p_response_time_ms\\" integer DEFAULT NULL::integer, \\"p_error_increment\\" integer DEFAULT 0, \\"p_unique_user_increment\\" integer DEFAULT 0) RETURNS \\"void\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nBEGIN\n    INSERT INTO agent_usage_analytics (\n        agent_configuration_id, agent_id, date_period,\n        conversation_count, message_count, error_count, unique_users\n    ) VALUES (\n        p_agent_id, \n        (SELECT agent_id FROM agent_configurations WHERE id = p_agent_id),\n        CURRENT_DATE,\n        p_conversation_increment, p_message_increment, p_error_increment, p_unique_user_increment\n    )\n    ON CONFLICT (agent_configuration_id, date_period) \n    DO UPDATE SET\n        conversation_count = agent_usage_analytics.conversation_count + p_conversation_increment,\n        message_count = agent_usage_analytics.message_count + p_message_increment,\n        error_count = agent_usage_analytics.error_count + p_error_increment,\n        unique_users = agent_usage_analytics.unique_users + p_unique_user_increment,\n        avg_response_time_ms = CASE \n            WHEN p_response_time_ms IS NOT NULL THEN\n                COALESCE(\n                    (agent_usage_analytics.avg_response_time_ms + p_response_time_ms) / 2,\n                    p_response_time_ms\n                )\n            ELSE agent_usage_analytics.avg_response_time_ms\n        END,\n        last_updated = NOW();\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"update_agent_usage_analytics\\"(\\"p_agent_id\\" \\"uuid\\", \\"p_conversation_increment\\" integer, \\"p_message_increment\\" integer, \\"p_response_time_ms\\" integer, \\"p_error_increment\\" integer, \\"p_unique_user_increment\\" integer) OWNER TO \\"postgres\\"","COMMENT ON FUNCTION \\"public\\".\\"update_agent_usage_analytics\\"(\\"p_agent_id\\" \\"uuid\\", \\"p_conversation_increment\\" integer, \\"p_message_increment\\" integer, \\"p_response_time_ms\\" integer, \\"p_error_increment\\" integer, \\"p_unique_user_increment\\" integer) IS 'Helper function to update daily usage stats'","CREATE OR REPLACE FUNCTION \\"public\\".\\"update_completion_percentage\\"() RETURNS \\"trigger\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nBEGIN\n    NEW.completion_percentage = calculate_completion_percentage(NEW.requirements_gathered);\n    RETURN NEW;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"update_completion_percentage\\"() OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"update_conversation_timestamps\\"() RETURNS \\"trigger\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nBEGIN\n    NEW.updated_at = NOW();\n    NEW.last_activity_at = NOW();\n    RETURN NEW;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"update_conversation_timestamps\\"() OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"update_creation_metrics\\"(\\"p_success\\" boolean, \\"p_creation_time_seconds\\" integer DEFAULT NULL::integer, \\"p_questions_answered\\" integer DEFAULT NULL::integer, \\"p_department\\" character varying DEFAULT NULL::character varying) RETURNS \\"void\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nDECLARE\n    current_hour INTEGER;\n    dept_breakdown JSONB;\nBEGIN\n    current_hour := EXTRACT(hour FROM NOW());\n    \n    -- Get current department breakdown or initialize\n    SELECT department_breakdown INTO dept_breakdown\n    FROM agent_creation_metrics\n    WHERE date_period = CURRENT_DATE AND hour_period = current_hour;\n    \n    IF dept_breakdown IS NULL THEN\n        dept_breakdown := '{}';\n    END IF;\n    \n    -- Update department count\n    IF p_department IS NOT NULL THEN\n        dept_breakdown := jsonb_set(\n            dept_breakdown,\n            ARRAY[p_department],\n            to_jsonb(COALESCE((dept_breakdown ->> p_department)::INTEGER, 0) + 1)\n        );\n    END IF;\n    \n    INSERT INTO agent_creation_metrics (\n        date_period, hour_period, total_attempts,\n        successful_creations, failed_creations,\n        avg_creation_time_seconds, avg_questions_to_completion,\n        department_breakdown\n    ) VALUES (\n        CURRENT_DATE, current_hour, 1,\n        CASE WHEN p_success THEN 1 ELSE 0 END,\n        CASE WHEN p_success THEN 0 ELSE 1 END,\n        p_creation_time_seconds, p_questions_answered,\n        dept_breakdown\n    )\n    ON CONFLICT (date_period, hour_period)\n    DO UPDATE SET\n        total_attempts = agent_creation_metrics.total_attempts + 1,\n        successful_creations = agent_creation_metrics.successful_creations + \n            CASE WHEN p_success THEN 1 ELSE 0 END,\n        failed_creations = agent_creation_metrics.failed_creations + \n            CASE WHEN p_success THEN 0 ELSE 1 END,\n        avg_creation_time_seconds = CASE \n            WHEN p_creation_time_seconds IS NOT NULL THEN\n                COALESCE(\n                    (agent_creation_metrics.avg_creation_time_seconds + p_creation_time_seconds) / 2,\n                    p_creation_time_seconds\n                )\n            ELSE agent_creation_metrics.avg_creation_time_seconds\n        END,\n        avg_questions_to_completion = CASE \n            WHEN p_questions_answered IS NOT NULL THEN\n                COALESCE(\n                    (agent_creation_metrics.avg_questions_to_completion + p_questions_answered) / 2.0,\n                    p_questions_answered::DECIMAL\n                )\n            ELSE agent_creation_metrics.avg_questions_to_completion\n        END,\n        department_breakdown = dept_breakdown,\n        last_updated = NOW();\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"update_creation_metrics\\"(\\"p_success\\" boolean, \\"p_creation_time_seconds\\" integer, \\"p_questions_answered\\" integer, \\"p_department\\" character varying) OWNER TO \\"postgres\\"","COMMENT ON FUNCTION \\"public\\".\\"update_creation_metrics\\"(\\"p_success\\" boolean, \\"p_creation_time_seconds\\" integer, \\"p_questions_answered\\" integer, \\"p_department\\" character varying) IS 'Helper function to update system creation metrics'","CREATE OR REPLACE FUNCTION \\"public\\".\\"update_updated_at_column\\"() RETURNS \\"trigger\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nBEGIN\n  NEW.updated_at = NOW();\n  RETURN NEW;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"update_updated_at_column\\"() OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"validate_skill_examples\\"(\\"examples\\" \\"jsonb\\") RETURNS boolean\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nDECLARE\n    example_text TEXT;\n    example_value JSONB;\nBEGIN\n    -- Check each example in the array\n    FOR example_value IN SELECT jsonb_array_elements(examples)\n    LOOP\n        example_text := example_value #>> '{}';\n        \n        -- Ensure example is not empty or too short\n        IF LENGTH(TRIM(example_text)) < 5 THEN\n            RETURN FALSE;\n        END IF;\n        \n        -- Ensure example is a reasonable length (not too long)\n        IF LENGTH(example_text) > 500 THEN\n            RETURN FALSE;\n        END IF;\n    END LOOP;\n    \n    RETURN TRUE;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"validate_skill_examples\\"(\\"examples\\" \\"jsonb\\") OWNER TO \\"postgres\\"","SET default_tablespace = ''","SET default_table_access_method = \\"heap\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"agent_configurations\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"agent_id\\" character varying(100) NOT NULL,\n    \\"display_name\\" character varying(200) NOT NULL,\n    \\"agent_type\\" character varying(50) NOT NULL,\n    \\"department\\" character varying(100) NOT NULL,\n    \\"reports_to\\" character varying(100),\n    \\"created_by\\" \\"uuid\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"updated_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"version\\" integer DEFAULT 1,\n    \\"status\\" character varying(50) DEFAULT 'active'::character varying,\n    \\"primary_purpose\\" \\"text\\" NOT NULL,\n    \\"capabilities\\" \\"jsonb\\" NOT NULL,\n    \\"expertise_areas\\" \\"jsonb\\" NOT NULL,\n    \\"responsibilities\\" \\"jsonb\\" NOT NULL,\n    \\"limitations\\" \\"jsonb\\" NOT NULL,\n    \\"communication_style\\" character varying(100),\n    \\"core_identity\\" \\"text\\",\n    \\"yaml_config\\" \\"text\\" NOT NULL,\n    \\"context_content\\" \\"text\\" NOT NULL,\n    \\"service_content\\" \\"text\\" NOT NULL,\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"last_accessed_at\\" timestamp with time zone,\n    \\"access_count\\" integer DEFAULT 0,\n    CONSTRAINT \\"check_agent_id_format\\" CHECK (((\\"agent_id\\")::\\"text\\" ~ '^[a-z][a-z0-9_]*$'::\\"text\\")),\n    CONSTRAINT \\"check_agent_type\\" CHECK (((\\"agent_type\\")::\\"text\\" = ANY (ARRAY[('context'::character varying)::\\"text\\", ('api'::character varying)::\\"text\\", ('function'::character varying)::\\"text\\"]))),\n    CONSTRAINT \\"check_communication_style\\" CHECK (((\\"communication_style\\")::\\"text\\" = ANY (ARRAY[('professional'::character varying)::\\"text\\", ('casual'::character varying)::\\"text\\", ('technical'::character varying)::\\"text\\", ('conversational'::character varying)::\\"text\\", ('formal'::character varying)::\\"text\\", ('creative'::character varying)::\\"text\\"]))),\n    CONSTRAINT \\"check_department\\" CHECK (((\\"department\\")::\\"text\\" = ANY (ARRAY[('marketing'::character varying)::\\"text\\", ('engineering'::character varying)::\\"text\\", ('operations'::character varying)::\\"text\\", ('finance'::character varying)::\\"text\\", ('hr'::character varying)::\\"text\\", ('sales'::character varying)::\\"text\\", ('research'::character varying)::\\"text\\", ('product'::character varying)::\\"text\\", ('specialists'::character varying)::\\"text\\"]))),\n    CONSTRAINT \\"check_display_name_not_empty\\" CHECK ((\\"length\\"(TRIM(BOTH FROM \\"display_name\\")) > 0)),\n    CONSTRAINT \\"check_primary_purpose_length\\" CHECK ((\\"length\\"(TRIM(BOTH FROM \\"primary_purpose\\")) >= 20)),\n    CONSTRAINT \\"check_status\\" CHECK (((\\"status\\")::\\"text\\" = ANY (ARRAY[('active'::character varying)::\\"text\\", ('inactive'::character varying)::\\"text\\", ('archived'::character varying)::\\"text\\", ('draft'::character varying)::\\"text\\"])))\n)","ALTER TABLE \\"public\\".\\"agent_configurations\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"agent_configurations\\" IS 'Stores dynamically created agent configurations with generated content'","COMMENT ON COLUMN \\"public\\".\\"agent_configurations\\".\\"agent_id\\" IS 'Unique snake_case identifier for routing (e.g., social_media_writer)'","COMMENT ON COLUMN \\"public\\".\\"agent_configurations\\".\\"yaml_config\\" IS 'Generated YAML configuration content'","COMMENT ON COLUMN \\"public\\".\\"agent_configurations\\".\\"context_content\\" IS 'Generated context.md system prompt content'","COMMENT ON COLUMN \\"public\\".\\"agent_configurations\\".\\"service_content\\" IS 'Generated service.ts TypeScript content'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"agent_creation_conversations\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"session_id\\" character varying(100) NOT NULL,\n    \\"user_id\\" \\"uuid\\",\n    \\"agent_configuration_id\\" \\"uuid\\",\n    \\"conversation_data\\" \\"jsonb\\" NOT NULL,\n    \\"requirements_gathered\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"current_phase\\" character varying(50) DEFAULT 'identity'::character varying,\n    \\"current_question\\" integer DEFAULT 1,\n    \\"completion_status\\" character varying(50) DEFAULT 'in_progress'::character varying,\n    \\"completion_percentage\\" integer DEFAULT 0,\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"updated_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"last_activity_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"user_agent\\" \\"text\\",\n    \\"ip_address\\" \\"inet\\",\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    CONSTRAINT \\"check_completion_percentage\\" CHECK (((\\"completion_percentage\\" >= 0) AND (\\"completion_percentage\\" <= 100))),\n    CONSTRAINT \\"check_completion_status\\" CHECK (((\\"completion_status\\")::\\"text\\" = ANY (ARRAY[('in_progress'::character varying)::\\"text\\", ('completed'::character varying)::\\"text\\", ('abandoned'::character varying)::\\"text\\", ('failed'::character varying)::\\"text\\"]))),\n    CONSTRAINT \\"check_current_phase\\" CHECK (((\\"current_phase\\")::\\"text\\" = ANY (ARRAY[('identity'::character varying)::\\"text\\", ('hierarchy'::character varying)::\\"text\\", ('purpose'::character varying)::\\"text\\", ('skills'::character varying)::\\"text\\", ('style'::character varying)::\\"text\\", ('technical'::character varying)::\\"text\\", ('complete'::character varying)::\\"text\\"]))),\n    CONSTRAINT \\"check_current_question_range\\" CHECK (((\\"current_question\\" >= 1) AND (\\"current_question\\" <= 12)))\n)","ALTER TABLE \\"public\\".\\"agent_creation_conversations\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"agent_creation_conversations\\" IS 'Tracks agent creation conversation state for resuming interrupted sessions'","COMMENT ON COLUMN \\"public\\".\\"agent_creation_conversations\\".\\"requirements_gathered\\" IS 'JSON object tracking completion of 12 required fields'","COMMENT ON COLUMN \\"public\\".\\"agent_creation_conversations\\".\\"current_phase\\" IS 'Current phase in structured conversation flow'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"agent_creation_events\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"conversation_id\\" \\"uuid\\" NOT NULL,\n    \\"event_type\\" character varying(50) NOT NULL,\n    \\"event_data\\" \\"jsonb\\" NOT NULL,\n    \\"question_number\\" integer,\n    \\"field_name\\" character varying(100),\n    \\"timestamp\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"user_input\\" \\"text\\",\n    \\"ai_response\\" \\"text\\",\n    \\"validation_result\\" \\"jsonb\\",\n    CONSTRAINT \\"check_event_type\\" CHECK (((\\"event_type\\")::\\"text\\" = ANY (ARRAY[('conversation_started'::character varying)::\\"text\\", ('question_asked'::character varying)::\\"text\\", ('answer_provided'::character varying)::\\"text\\", ('validation_passed'::character varying)::\\"text\\", ('validation_failed'::character varying)::\\"text\\", ('phase_completed'::character varying)::\\"text\\", ('agent_created'::character varying)::\\"text\\", ('conversation_completed'::character varying)::\\"text\\", ('conversation_abandoned'::character varying)::\\"text\\"])))\n)","ALTER TABLE \\"public\\".\\"agent_creation_events\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"agent_creation_events\\" IS 'Detailed log of events during agent creation conversations'","COMMENT ON COLUMN \\"public\\".\\"agent_creation_events\\".\\"event_data\\" IS 'Event-specific data like validation results, user inputs, etc.'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"agent_creation_logs\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"action\\" character varying(100) NOT NULL,\n    \\"agent_configuration_id\\" \\"uuid\\",\n    \\"performed_by\\" \\"uuid\\",\n    \\"performed_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"details\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"ip_address\\" \\"inet\\",\n    \\"user_agent\\" \\"text\\",\n    \\"previous_state\\" \\"jsonb\\",\n    \\"new_state\\" \\"jsonb\\",\n    \\"success\\" boolean DEFAULT true,\n    \\"error_message\\" \\"text\\",\n    CONSTRAINT \\"check_action_type\\" CHECK (((\\"action\\")::\\"text\\" = ANY (ARRAY[('created'::character varying)::\\"text\\", ('updated'::character varying)::\\"text\\", ('activated'::character varying)::\\"text\\", ('deactivated'::character varying)::\\"text\\", ('deleted'::character varying)::\\"text\\", ('accessed'::character varying)::\\"text\\", ('conversation_started'::character varying)::\\"text\\", ('error_occurred'::character varying)::\\"text\\"])))\n)","ALTER TABLE \\"public\\".\\"agent_creation_logs\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"agent_creation_logs\\" IS 'Audit trail for all agent-related actions'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"agent_creation_metrics\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"date_period\\" \\"date\\" NOT NULL,\n    \\"hour_period\\" integer,\n    \\"total_attempts\\" integer DEFAULT 0,\n    \\"successful_creations\\" integer DEFAULT 0,\n    \\"failed_creations\\" integer DEFAULT 0,\n    \\"abandoned_conversations\\" integer DEFAULT 0,\n    \\"avg_creation_time_seconds\\" integer,\n    \\"avg_questions_to_completion\\" numeric(4,2),\n    \\"most_failed_question\\" integer,\n    \\"agents_with_quality_issues\\" integer DEFAULT 0,\n    \\"avg_capabilities_count\\" numeric(4,2),\n    \\"avg_skills_count\\" numeric(4,2),\n    \\"department_breakdown\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"last_updated\\" timestamp with time zone DEFAULT \\"now\\"(),\n    CONSTRAINT \\"check_hour_period\\" CHECK (((\\"hour_period\\" >= 0) AND (\\"hour_period\\" <= 23)))\n)","ALTER TABLE \\"public\\".\\"agent_creation_metrics\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"agent_creation_metrics\\" IS 'System-wide metrics for agent creation process'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"agent_skills\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"agent_configuration_id\\" \\"uuid\\" NOT NULL,\n    \\"skill_id\\" character varying(100) NOT NULL,\n    \\"skill_name\\" character varying(200) NOT NULL,\n    \\"description\\" \\"text\\" NOT NULL,\n    \\"examples\\" \\"jsonb\\" NOT NULL,\n    \\"tags\\" \\"jsonb\\" DEFAULT '[]'::\\"jsonb\\",\n    \\"input_modes\\" \\"jsonb\\" DEFAULT '[\\"text/plain\\", \\"application/json\\"]'::\\"jsonb\\",\n    \\"output_modes\\" \\"jsonb\\" DEFAULT '[\\"text/plain\\", \\"application/json\\"]'::\\"jsonb\\",\n    \\"skill_order\\" integer DEFAULT 0,\n    \\"is_primary\\" boolean DEFAULT false,\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"updated_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    CONSTRAINT \\"check_examples_not_empty\\" CHECK ((\\"jsonb_array_length\\"(\\"examples\\") > 0)),\n    CONSTRAINT \\"check_examples_quality\\" CHECK (\\"public\\".\\"validate_skill_examples\\"(\\"examples\\")),\n    CONSTRAINT \\"check_skill_description_length\\" CHECK ((\\"length\\"(TRIM(BOTH FROM \\"description\\")) >= 10)),\n    CONSTRAINT \\"check_skill_id_format\\" CHECK (((\\"skill_id\\")::\\"text\\" ~ '^[a-z][a-z0-9_]*$'::\\"text\\")),\n    CONSTRAINT \\"check_skill_name_not_empty\\" CHECK ((\\"length\\"(TRIM(BOTH FROM \\"skill_name\\")) > 0))\n)","ALTER TABLE \\"public\\".\\"agent_skills\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"agent_skills\\" IS 'Stores skills and user-provided examples for each agent'","COMMENT ON COLUMN \\"public\\".\\"agent_skills\\".\\"skill_id\\" IS 'Snake_case identifier unique per agent'","COMMENT ON COLUMN \\"public\\".\\"agent_skills\\".\\"examples\\" IS 'Array of concrete example queries from user domain'","COMMENT ON COLUMN \\"public\\".\\"agent_skills\\".\\"is_primary\\" IS 'Whether this is the main/primary skill for the agent'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"agent_usage_analytics\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"agent_configuration_id\\" \\"uuid\\" NOT NULL,\n    \\"agent_id\\" character varying(100) NOT NULL,\n    \\"conversation_count\\" integer DEFAULT 0,\n    \\"message_count\\" integer DEFAULT 0,\n    \\"avg_response_time_ms\\" integer,\n    \\"error_count\\" integer DEFAULT 0,\n    \\"unique_users\\" integer DEFAULT 0,\n    \\"returning_users\\" integer DEFAULT 0,\n    \\"satisfaction_rating\\" numeric(3,2),\n    \\"date_period\\" \\"date\\" NOT NULL,\n    \\"last_updated\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    CONSTRAINT \\"check_satisfaction_rating\\" CHECK (((\\"satisfaction_rating\\" >= 0.0) AND (\\"satisfaction_rating\\" <= 5.0)))\n)","ALTER TABLE \\"public\\".\\"agent_usage_analytics\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"agent_usage_analytics\\" IS 'Daily usage analytics for each agent'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"cidafm_commands\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"type\\" character varying(10) NOT NULL,\n    \\"name\\" character varying(255) NOT NULL,\n    \\"description\\" \\"text\\",\n    \\"default_active\\" boolean DEFAULT false,\n    \\"is_builtin\\" boolean DEFAULT true,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    CONSTRAINT \\"cidafm_commands_type_check\\" CHECK (((\\"type\\")::\\"text\\" = ANY (ARRAY[('^'::character varying)::\\"text\\", ('&'::character varying)::\\"text\\", ('!'::character varying)::\\"text\\"])))\n)","ALTER TABLE \\"public\\".\\"cidafm_commands\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"companies\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"name\\" character varying(255) NOT NULL,\n    \\"industry\\" character varying(100),\n    \\"founded_year\\" integer,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"companies\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"conversations\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"user_id\\" \\"uuid\\",\n    \\"agent_name\\" character varying(255),\n    \\"agent_type\\" character varying(100),\n    \\"started_at\\" timestamp with time zone,\n    \\"last_active_at\\" timestamp with time zone,\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"conversations\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"tasks\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"user_id\\" \\"uuid\\",\n    \\"conversation_id\\" \\"uuid\\",\n    \\"method\\" character varying(255),\n    \\"params\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"prompt\\" \\"text\\",\n    \\"response\\" \\"text\\",\n    \\"status\\" character varying(50) DEFAULT 'pending'::character varying,\n    \\"progress\\" integer DEFAULT 0,\n    \\"progress_message\\" \\"text\\",\n    \\"error_code\\" \\"text\\",\n    \\"error_message\\" \\"text\\",\n    \\"error_data\\" \\"jsonb\\",\n    \\"started_at\\" timestamp with time zone,\n    \\"completed_at\\" timestamp with time zone,\n    \\"timeout_seconds\\" integer DEFAULT 300,\n    \\"deliverable_type\\" \\"text\\",\n    \\"deliverable_metadata\\" \\"jsonb\\",\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"llm_metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"response_metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"evaluation\\" \\"jsonb\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"tasks\\" OWNER TO \\"postgres\\"","CREATE OR REPLACE VIEW \\"public\\".\\"conversations_with_stats\\" AS\n SELECT \\"c\\".\\"id\\",\n    \\"c\\".\\"user_id\\",\n    \\"c\\".\\"agent_name\\",\n    \\"c\\".\\"agent_type\\",\n    \\"c\\".\\"started_at\\",\n    \\"c\\".\\"last_active_at\\",\n    \\"c\\".\\"metadata\\",\n    \\"c\\".\\"created_at\\",\n    \\"c\\".\\"updated_at\\",\n    COALESCE(\\"task_stats\\".\\"task_count\\", (0)::bigint) AS \\"task_count\\",\n    COALESCE(\\"task_stats\\".\\"completed_tasks\\", (0)::bigint) AS \\"completed_tasks\\",\n    COALESCE(\\"task_stats\\".\\"failed_tasks\\", (0)::bigint) AS \\"failed_tasks\\",\n    COALESCE(\\"task_stats\\".\\"active_tasks\\", (0)::bigint) AS \\"active_tasks\\"\n   FROM (\\"public\\".\\"conversations\\" \\"c\\"\n     LEFT JOIN ( SELECT \\"tasks\\".\\"conversation_id\\",\n            \\"count\\"(*) AS \\"task_count\\",\n            \\"count\\"(\n                CASE\n                    WHEN ((\\"tasks\\".\\"status\\")::\\"text\\" = 'completed'::\\"text\\") THEN 1\n                    ELSE NULL::integer\n                END) AS \\"completed_tasks\\",\n            \\"count\\"(\n                CASE\n                    WHEN ((\\"tasks\\".\\"status\\")::\\"text\\" = 'failed'::\\"text\\") THEN 1\n                    ELSE NULL::integer\n                END) AS \\"failed_tasks\\",\n            \\"count\\"(\n                CASE\n                    WHEN ((\\"tasks\\".\\"status\\")::\\"text\\" = ANY (ARRAY[('pending'::character varying)::\\"text\\", ('running'::character varying)::\\"text\\"])) THEN 1\n                    ELSE NULL::integer\n                END) AS \\"active_tasks\\"\n           FROM \\"public\\".\\"tasks\\"\n          GROUP BY \\"tasks\\".\\"conversation_id\\") \\"task_stats\\" ON ((\\"c\\".\\"id\\" = \\"task_stats\\".\\"conversation_id\\")))","ALTER VIEW \\"public\\".\\"conversations_with_stats\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"deliverable_versions\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"deliverable_id\\" \\"uuid\\" NOT NULL,\n    \\"version_number\\" integer NOT NULL,\n    \\"content\\" \\"text\\",\n    \\"format\\" character varying(100),\n    \\"is_current_version\\" boolean DEFAULT false,\n    \\"created_by_type\\" character varying(50) DEFAULT 'ai_response'::character varying,\n    \\"task_id\\" \\"uuid\\",\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"file_attachments\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    CONSTRAINT \\"deliverable_versions_created_by_type_check\\" CHECK (((\\"created_by_type\\")::\\"text\\" = ANY (ARRAY[('ai_response'::character varying)::\\"text\\", ('manual_edit'::character varying)::\\"text\\", ('ai_enhancement'::character varying)::\\"text\\", ('user_request'::character varying)::\\"text\\", ('conversation_task'::character varying)::\\"text\\", ('conversation_merge'::character varying)::\\"text\\", ('llm_rerun'::character varying)::\\"text\\"])))\n)","ALTER TABLE \\"public\\".\\"deliverable_versions\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"deliverables\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"user_id\\" \\"uuid\\" NOT NULL,\n    \\"conversation_id\\" \\"uuid\\",\n    \\"project_step_id\\" \\"uuid\\",\n    \\"agent_name\\" \\"text\\",\n    \\"title\\" \\"text\\" NOT NULL,\n    \\"type\\" character varying(100),\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"deliverables\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"departments\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"company_id\\" \\"uuid\\",\n    \\"name\\" character varying(255) NOT NULL,\n    \\"head_of_department\\" character varying(255),\n    \\"budget\\" numeric(15,2),\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"departments\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"kpi_data\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"department_id\\" \\"uuid\\",\n    \\"metric_id\\" \\"uuid\\",\n    \\"value\\" numeric(15,4) NOT NULL,\n    \\"date_recorded\\" \\"date\\" NOT NULL,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"kpi_data\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"kpi_goals\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"department_id\\" \\"uuid\\",\n    \\"metric_id\\" \\"uuid\\",\n    \\"target_value\\" numeric(15,4),\n    \\"period_start\\" \\"date\\",\n    \\"period_end\\" \\"date\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"kpi_goals\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"kpi_metrics\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"name\\" character varying(255) NOT NULL,\n    \\"metric_type\\" character varying(100),\n    \\"unit\\" character varying(50),\n    \\"description\\" \\"text\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"kpi_metrics\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"llm_models\\" (\n    \\"model_name\\" \\"text\\" NOT NULL,\n    \\"provider_name\\" \\"text\\" NOT NULL,\n    \\"display_name\\" \\"text\\",\n    \\"model_type\\" \\"text\\" DEFAULT 'text-generation'::\\"text\\",\n    \\"model_version\\" \\"text\\",\n    \\"context_window\\" integer DEFAULT 4096,\n    \\"max_output_tokens\\" integer DEFAULT 2048,\n    \\"model_parameters_json\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"pricing_info_json\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"capabilities\\" \\"jsonb\\" DEFAULT '[]'::\\"jsonb\\",\n    \\"model_tier\\" \\"text\\",\n    \\"speed_tier\\" \\"text\\" DEFAULT 'medium'::\\"text\\",\n    \\"loading_priority\\" integer DEFAULT 5,\n    \\"is_local\\" boolean DEFAULT false,\n    \\"is_currently_loaded\\" boolean DEFAULT false,\n    \\"is_active\\" boolean DEFAULT true,\n    \\"training_data_cutoff\\" \\"date\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"llm_models\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"llm_providers\\" (\n    \\"name\\" \\"text\\" NOT NULL,\n    \\"display_name\\" \\"text\\" NOT NULL,\n    \\"api_base_url\\" \\"text\\",\n    \\"configuration_json\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"is_active\\" boolean DEFAULT true,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"llm_providers\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"llm_usage\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"run_id\\" \\"text\\",\n    \\"user_id\\" \\"uuid\\",\n    \\"conversation_id\\" \\"uuid\\",\n    \\"provider_name\\" \\"text\\",\n    \\"model_name\\" \\"text\\",\n    \\"input_tokens\\" integer,\n    \\"output_tokens\\" integer,\n    \\"input_cost\\" numeric,\n    \\"output_cost\\" numeric,\n    \\"duration_ms\\" integer,\n    \\"status\\" \\"text\\" DEFAULT 'completed'::\\"text\\",\n    \\"caller_type\\" \\"text\\",\n    \\"agent_name\\" \\"text\\",\n    \\"is_local\\" boolean DEFAULT false,\n    \\"model_tier\\" \\"text\\",\n    \\"fallback_used\\" boolean DEFAULT false,\n    \\"routing_reason\\" \\"text\\",\n    \\"complexity_level\\" \\"text\\",\n    \\"complexity_score\\" integer,\n    \\"data_classification\\" \\"text\\",\n    \\"started_at\\" timestamp with time zone,\n    \\"completed_at\\" timestamp with time zone,\n    \\"error_message\\" \\"text\\",\n    \\"data_sanitization_applied\\" boolean DEFAULT false,\n    \\"sanitization_level\\" \\"text\\" DEFAULT 'none'::\\"text\\",\n    \\"pii_detected\\" boolean DEFAULT false,\n    \\"pii_types\\" \\"jsonb\\" DEFAULT '[]'::\\"jsonb\\",\n    \\"pseudonyms_used\\" integer DEFAULT 0,\n    \\"pseudonym_types\\" \\"jsonb\\" DEFAULT '[]'::\\"jsonb\\",\n    \\"redactions_applied\\" integer DEFAULT 0,\n    \\"redaction_types\\" \\"jsonb\\" DEFAULT '[]'::\\"jsonb\\",\n    \\"source_blinding_applied\\" boolean DEFAULT false,\n    \\"headers_stripped\\" boolean DEFAULT false,\n    \\"custom_user_agent_used\\" boolean DEFAULT false,\n    \\"proxy_used\\" boolean DEFAULT false,\n    \\"no_train_header_sent\\" boolean DEFAULT false,\n    \\"no_retain_header_sent\\" boolean DEFAULT false,\n    \\"sanitization_time_ms\\" integer DEFAULT 0,\n    \\"reversal_context_size\\" integer DEFAULT 0,\n    \\"policy_profile\\" \\"text\\",\n    \\"sovereign_mode\\" boolean DEFAULT false,\n    \\"compliance_flags\\" \\"jsonb\\" DEFAULT '[]'::\\"jsonb\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"llm_usage\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"project_steps\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"gen_random_uuid\\"() NOT NULL,\n    \\"project_id\\" \\"uuid\\" NOT NULL,\n    \\"step_id\\" \\"text\\" NOT NULL,\n    \\"step_index\\" integer NOT NULL,\n    \\"step_type\\" \\"text\\" NOT NULL,\n    \\"step_name\\" \\"text\\" NOT NULL,\n    \\"agent_name\\" \\"text\\",\n    \\"prompt\\" \\"text\\" NOT NULL,\n    \\"dependencies\\" \\"text\\"[] DEFAULT '{}'::\\"text\\"[],\n    \\"status\\" \\"text\\" DEFAULT 'pending'::\\"text\\" NOT NULL,\n    \\"result\\" \\"jsonb\\",\n    \\"error_details\\" \\"jsonb\\",\n    \\"started_at\\" timestamp with time zone,\n    \\"completed_at\\" timestamp with time zone,\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"updated_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    CONSTRAINT \\"project_steps_status_check\\" CHECK ((\\"status\\" = ANY (ARRAY['pending'::\\"text\\", 'running'::\\"text\\", 'completed'::\\"text\\", 'failed'::\\"text\\", 'pending_approval'::\\"text\\", 'skipped'::\\"text\\"]))),\n    CONSTRAINT \\"project_steps_step_type_check\\" CHECK ((\\"step_type\\" = ANY (ARRAY['agent_step'::\\"text\\", 'human_approval'::\\"text\\"])))\n)","ALTER TABLE \\"public\\".\\"project_steps\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"projects\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"gen_random_uuid\\"() NOT NULL,\n    \\"conversation_id\\" \\"uuid\\" NOT NULL,\n    \\"name\\" \\"text\\",\n    \\"description\\" \\"text\\",\n    \\"plan_json\\" \\"jsonb\\",\n    \\"status\\" \\"text\\" DEFAULT 'planning'::\\"text\\" NOT NULL,\n    \\"current_step_id\\" \\"text\\",\n    \\"error_details\\" \\"jsonb\\",\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"parent_project_id\\" \\"uuid\\",\n    \\"hierarchy_level\\" integer DEFAULT 0,\n    \\"subproject_count\\" integer DEFAULT 0,\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"updated_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    CONSTRAINT \\"projects_status_check\\" CHECK ((\\"status\\" = ANY (ARRAY['planning'::\\"text\\", 'pending_approval'::\\"text\\", 'running'::\\"text\\", 'paused_for_approval'::\\"text\\", 'paused_on_error'::\\"text\\", 'completed'::\\"text\\", 'aborted'::\\"text\\"])))\n)","ALTER TABLE \\"public\\".\\"projects\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"pseudonym_dictionaries\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"original_value\\" \\"text\\" NOT NULL,\n    \\"pseudonym\\" \\"text\\" NOT NULL,\n    \\"data_type\\" character varying(100) NOT NULL,\n    \\"category\\" character varying(100),\n    \\"frequency_weight\\" integer DEFAULT 1,\n    \\"is_active\\" boolean DEFAULT true,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"pseudonym_dictionaries\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"redaction_patterns\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"name\\" character varying(255) NOT NULL,\n    \\"pattern_regex\\" \\"text\\" NOT NULL,\n    \\"replacement\\" \\"text\\" NOT NULL,\n    \\"description\\" \\"text\\",\n    \\"category\\" character varying(100) DEFAULT 'pii_builtin'::character varying,\n    \\"priority\\" integer DEFAULT 50,\n    \\"is_active\\" boolean DEFAULT true,\n    \\"severity\\" character varying(50),\n    \\"data_type\\" character varying(50),\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"redaction_patterns\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"system_settings\\" (\n    \\"key\\" \\"text\\" NOT NULL,\n    \\"value\\" \\"jsonb\\" NOT NULL,\n    \\"updated_at\\" timestamp with time zone DEFAULT \\"now\\"()\n)","ALTER TABLE \\"public\\".\\"system_settings\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"system_settings\\" IS 'System-wide settings (key/value JSON). Used for global model configuration and feature flags.'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"user_cidafm_commands\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"user_id\\" \\"uuid\\" NOT NULL,\n    \\"command_id\\" \\"uuid\\" NOT NULL,\n    \\"is_active\\" boolean DEFAULT true,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"user_cidafm_commands\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"users\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"email\\" character varying(255) NOT NULL,\n    \\"display_name\\" character varying(255),\n    \\"role\\" character varying(50),\n    \\"roles\\" \\"jsonb\\" DEFAULT '[\\"user\\"]'::\\"jsonb\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"namespace_access\\" \\"jsonb\\" DEFAULT '[\\"my-org\\"]'::\\"jsonb\\" NOT NULL,\n    \\"status\\" \\"text\\" DEFAULT 'active'::\\"text\\"\n)","ALTER TABLE \\"public\\".\\"users\\" OWNER TO \\"postgres\\"","COMMENT ON COLUMN \\"public\\".\\"users\\".\\"namespace_access\\" IS 'List of agent namespaces the user may access (e.g., [\\"demo\\",\\"my-org\\"]).'","ALTER TABLE ONLY \\"public\\".\\"agent_configurations\\"\n    ADD CONSTRAINT \\"agent_configurations_agent_id_key\\" UNIQUE (\\"agent_id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_configurations\\"\n    ADD CONSTRAINT \\"agent_configurations_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"conversations\\"\n    ADD CONSTRAINT \\"agent_conversations_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_creation_conversations\\"\n    ADD CONSTRAINT \\"agent_creation_conversations_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_creation_events\\"\n    ADD CONSTRAINT \\"agent_creation_events_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_creation_logs\\"\n    ADD CONSTRAINT \\"agent_creation_logs_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_creation_metrics\\"\n    ADD CONSTRAINT \\"agent_creation_metrics_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_skills\\"\n    ADD CONSTRAINT \\"agent_skills_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_usage_analytics\\"\n    ADD CONSTRAINT \\"agent_usage_analytics_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"cidafm_commands\\"\n    ADD CONSTRAINT \\"cidafm_commands_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"companies\\"\n    ADD CONSTRAINT \\"companies_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"deliverable_versions\\"\n    ADD CONSTRAINT \\"deliverable_versions_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"deliverables\\"\n    ADD CONSTRAINT \\"deliverables_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"departments\\"\n    ADD CONSTRAINT \\"departments_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"kpi_data\\"\n    ADD CONSTRAINT \\"kpi_data_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"kpi_goals\\"\n    ADD CONSTRAINT \\"kpi_goals_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"kpi_metrics\\"\n    ADD CONSTRAINT \\"kpi_metrics_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"llm_models\\"\n    ADD CONSTRAINT \\"llm_models_pkey\\" PRIMARY KEY (\\"provider_name\\", \\"model_name\\")","ALTER TABLE ONLY \\"public\\".\\"llm_providers\\"\n    ADD CONSTRAINT \\"llm_providers_pkey\\" PRIMARY KEY (\\"name\\")","ALTER TABLE ONLY \\"public\\".\\"llm_usage\\"\n    ADD CONSTRAINT \\"llm_usage_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"llm_usage\\"\n    ADD CONSTRAINT \\"llm_usage_run_id_key\\" UNIQUE (\\"run_id\\")","ALTER TABLE ONLY \\"public\\".\\"project_steps\\"\n    ADD CONSTRAINT \\"project_steps_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"projects\\"\n    ADD CONSTRAINT \\"projects_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"pseudonym_dictionaries\\"\n    ADD CONSTRAINT \\"pseudonym_dictionaries_original_value_key\\" UNIQUE (\\"original_value\\")","ALTER TABLE ONLY \\"public\\".\\"pseudonym_dictionaries\\"\n    ADD CONSTRAINT \\"pseudonym_dictionaries_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"redaction_patterns\\"\n    ADD CONSTRAINT \\"redaction_patterns_name_key\\" UNIQUE (\\"name\\")","ALTER TABLE ONLY \\"public\\".\\"redaction_patterns\\"\n    ADD CONSTRAINT \\"redaction_patterns_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"system_settings\\"\n    ADD CONSTRAINT \\"system_settings_pkey\\" PRIMARY KEY (\\"key\\")","ALTER TABLE ONLY \\"public\\".\\"tasks\\"\n    ADD CONSTRAINT \\"tasks_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_usage_analytics\\"\n    ADD CONSTRAINT \\"unique_agent_date_analytics\\" UNIQUE (\\"agent_configuration_id\\", \\"date_period\\")","ALTER TABLE ONLY \\"public\\".\\"agent_creation_metrics\\"\n    ADD CONSTRAINT \\"unique_date_hour_metrics\\" UNIQUE (\\"date_period\\", \\"hour_period\\")","ALTER TABLE ONLY \\"public\\".\\"agent_skills\\"\n    ADD CONSTRAINT \\"unique_skill_id_per_agent\\" UNIQUE (\\"agent_configuration_id\\", \\"skill_id\\")","ALTER TABLE ONLY \\"public\\".\\"user_cidafm_commands\\"\n    ADD CONSTRAINT \\"user_cidafm_commands_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"users\\"\n    ADD CONSTRAINT \\"users_email_key\\" UNIQUE (\\"email\\")","ALTER TABLE ONLY \\"public\\".\\"users\\"\n    ADD CONSTRAINT \\"users_pkey\\" PRIMARY KEY (\\"id\\")","CREATE INDEX \\"idx_agent_configurations_agent_id\\" ON \\"public\\".\\"agent_configurations\\" USING \\"btree\\" (\\"agent_id\\")","CREATE INDEX \\"idx_agent_configurations_created_at\\" ON \\"public\\".\\"agent_configurations\\" USING \\"btree\\" (\\"created_at\\")","CREATE INDEX \\"idx_agent_configurations_created_by\\" ON \\"public\\".\\"agent_configurations\\" USING \\"btree\\" (\\"created_by\\")","CREATE INDEX \\"idx_agent_configurations_department\\" ON \\"public\\".\\"agent_configurations\\" USING \\"btree\\" (\\"department\\")","CREATE INDEX \\"idx_agent_configurations_status\\" ON \\"public\\".\\"agent_configurations\\" USING \\"btree\\" (\\"status\\")","CREATE INDEX \\"idx_agent_conversations_user_id\\" ON \\"public\\".\\"conversations\\" USING \\"btree\\" (\\"user_id\\")","CREATE INDEX \\"idx_agent_skills_agent_config\\" ON \\"public\\".\\"agent_skills\\" USING \\"btree\\" (\\"agent_configuration_id\\")","CREATE INDEX \\"idx_agent_skills_is_primary\\" ON \\"public\\".\\"agent_skills\\" USING \\"btree\\" (\\"is_primary\\")","CREATE INDEX \\"idx_agent_skills_skill_id\\" ON \\"public\\".\\"agent_skills\\" USING \\"btree\\" (\\"skill_id\\")","CREATE INDEX \\"idx_agent_skills_skill_order\\" ON \\"public\\".\\"agent_skills\\" USING \\"btree\\" (\\"skill_order\\")","CREATE INDEX \\"idx_conversations_agent_id\\" ON \\"public\\".\\"agent_creation_conversations\\" USING \\"btree\\" (\\"agent_configuration_id\\")","CREATE INDEX \\"idx_conversations_last_activity\\" ON \\"public\\".\\"agent_creation_conversations\\" USING \\"btree\\" (\\"last_activity_at\\")","CREATE INDEX \\"idx_conversations_session_id\\" ON \\"public\\".\\"agent_creation_conversations\\" USING \\"btree\\" (\\"session_id\\")","CREATE INDEX \\"idx_conversations_status\\" ON \\"public\\".\\"agent_creation_conversations\\" USING \\"btree\\" (\\"completion_status\\")","CREATE INDEX \\"idx_conversations_user_id\\" ON \\"public\\".\\"agent_creation_conversations\\" USING \\"btree\\" (\\"user_id\\")","CREATE INDEX \\"idx_creation_logs_action\\" ON \\"public\\".\\"agent_creation_logs\\" USING \\"btree\\" (\\"action\\")","CREATE INDEX \\"idx_creation_logs_agent_id\\" ON \\"public\\".\\"agent_creation_logs\\" USING \\"btree\\" (\\"agent_configuration_id\\")","CREATE INDEX \\"idx_creation_logs_performed_at\\" ON \\"public\\".\\"agent_creation_logs\\" USING \\"btree\\" (\\"performed_at\\")","CREATE INDEX \\"idx_creation_logs_performed_by\\" ON \\"public\\".\\"agent_creation_logs\\" USING \\"btree\\" (\\"performed_by\\")","CREATE INDEX \\"idx_creation_logs_success\\" ON \\"public\\".\\"agent_creation_logs\\" USING \\"btree\\" (\\"success\\")","CREATE INDEX \\"idx_creation_metrics_date\\" ON \\"public\\".\\"agent_creation_metrics\\" USING \\"btree\\" (\\"date_period\\")","CREATE INDEX \\"idx_creation_metrics_hour\\" ON \\"public\\".\\"agent_creation_metrics\\" USING \\"btree\\" (\\"hour_period\\")","CREATE INDEX \\"idx_events_conversation_id\\" ON \\"public\\".\\"agent_creation_events\\" USING \\"btree\\" (\\"conversation_id\\")","CREATE INDEX \\"idx_events_event_type\\" ON \\"public\\".\\"agent_creation_events\\" USING \\"btree\\" (\\"event_type\\")","CREATE INDEX \\"idx_events_question_number\\" ON \\"public\\".\\"agent_creation_events\\" USING \\"btree\\" (\\"question_number\\")","CREATE INDEX \\"idx_events_timestamp\\" ON \\"public\\".\\"agent_creation_events\\" USING \\"btree\\" (\\"timestamp\\")","CREATE INDEX \\"idx_llm_usage_created_at\\" ON \\"public\\".\\"llm_usage\\" USING \\"btree\\" (\\"created_at\\")","CREATE INDEX \\"idx_project_steps_project_id\\" ON \\"public\\".\\"project_steps\\" USING \\"btree\\" (\\"project_id\\")","CREATE INDEX \\"idx_project_steps_status\\" ON \\"public\\".\\"project_steps\\" USING \\"btree\\" (\\"status\\")","CREATE INDEX \\"idx_project_steps_step_index\\" ON \\"public\\".\\"project_steps\\" USING \\"btree\\" (\\"step_index\\")","CREATE INDEX \\"idx_projects_conversation_id\\" ON \\"public\\".\\"projects\\" USING \\"btree\\" (\\"conversation_id\\")","CREATE INDEX \\"idx_projects_created_at\\" ON \\"public\\".\\"projects\\" USING \\"btree\\" (\\"created_at\\")","CREATE INDEX \\"idx_projects_parent_project_id\\" ON \\"public\\".\\"projects\\" USING \\"btree\\" (\\"parent_project_id\\")","CREATE INDEX \\"idx_projects_status\\" ON \\"public\\".\\"projects\\" USING \\"btree\\" (\\"status\\")","CREATE INDEX \\"idx_projects_updated_at\\" ON \\"public\\".\\"projects\\" USING \\"btree\\" (\\"updated_at\\")","CREATE INDEX \\"idx_pseudonym_dictionaries_original_value\\" ON \\"public\\".\\"pseudonym_dictionaries\\" USING \\"btree\\" (\\"original_value\\")","CREATE INDEX \\"idx_redaction_patterns_active\\" ON \\"public\\".\\"redaction_patterns\\" USING \\"btree\\" (\\"is_active\\", \\"priority\\")","CREATE INDEX \\"idx_tasks_conversation_id\\" ON \\"public\\".\\"tasks\\" USING \\"btree\\" (\\"conversation_id\\")","CREATE INDEX \\"idx_usage_analytics_agent_id\\" ON \\"public\\".\\"agent_usage_analytics\\" USING \\"btree\\" (\\"agent_configuration_id\\")","CREATE INDEX \\"idx_usage_analytics_agent_lookup\\" ON \\"public\\".\\"agent_usage_analytics\\" USING \\"btree\\" (\\"agent_id\\")","CREATE INDEX \\"idx_usage_analytics_date\\" ON \\"public\\".\\"agent_usage_analytics\\" USING \\"btree\\" (\\"date_period\\")","CREATE INDEX \\"idx_users_email\\" ON \\"public\\".\\"users\\" USING \\"btree\\" (\\"email\\")","CREATE OR REPLACE TRIGGER \\"trigger_agent_configurations_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"agent_configurations\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_agent_configurations_updated_at\\"()","CREATE OR REPLACE TRIGGER \\"trigger_agent_skills_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"agent_skills\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_agent_skills_updated_at\\"()","CREATE OR REPLACE TRIGGER \\"trigger_conversations_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"agent_creation_conversations\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_conversation_timestamps\\"()","CREATE OR REPLACE TRIGGER \\"trigger_update_completion_percentage\\" BEFORE UPDATE ON \\"public\\".\\"agent_creation_conversations\\" FOR EACH ROW WHEN ((\\"old\\".\\"requirements_gathered\\" IS DISTINCT FROM \\"new\\".\\"requirements_gathered\\")) EXECUTE FUNCTION \\"public\\".\\"update_completion_percentage\\"()","CREATE OR REPLACE TRIGGER \\"update_project_steps_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"project_steps\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","CREATE OR REPLACE TRIGGER \\"update_projects_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"projects\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","ALTER TABLE ONLY \\"public\\".\\"agent_configurations\\"\n    ADD CONSTRAINT \\"agent_configurations_created_by_fkey\\" FOREIGN KEY (\\"created_by\\") REFERENCES \\"auth\\".\\"users\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"conversations\\"\n    ADD CONSTRAINT \\"agent_conversations_user_id_fkey\\" FOREIGN KEY (\\"user_id\\") REFERENCES \\"public\\".\\"users\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_creation_conversations\\"\n    ADD CONSTRAINT \\"agent_creation_conversations_agent_configuration_id_fkey\\" FOREIGN KEY (\\"agent_configuration_id\\") REFERENCES \\"public\\".\\"agent_configurations\\"(\\"id\\") ON DELETE SET NULL","ALTER TABLE ONLY \\"public\\".\\"agent_creation_conversations\\"\n    ADD CONSTRAINT \\"agent_creation_conversations_user_id_fkey\\" FOREIGN KEY (\\"user_id\\") REFERENCES \\"auth\\".\\"users\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_creation_events\\"\n    ADD CONSTRAINT \\"agent_creation_events_conversation_id_fkey\\" FOREIGN KEY (\\"conversation_id\\") REFERENCES \\"public\\".\\"agent_creation_conversations\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"agent_creation_logs\\"\n    ADD CONSTRAINT \\"agent_creation_logs_agent_configuration_id_fkey\\" FOREIGN KEY (\\"agent_configuration_id\\") REFERENCES \\"public\\".\\"agent_configurations\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"agent_creation_logs\\"\n    ADD CONSTRAINT \\"agent_creation_logs_performed_by_fkey\\" FOREIGN KEY (\\"performed_by\\") REFERENCES \\"auth\\".\\"users\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"agent_skills\\"\n    ADD CONSTRAINT \\"agent_skills_agent_configuration_id_fkey\\" FOREIGN KEY (\\"agent_configuration_id\\") REFERENCES \\"public\\".\\"agent_configurations\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"agent_usage_analytics\\"\n    ADD CONSTRAINT \\"agent_usage_analytics_agent_configuration_id_fkey\\" FOREIGN KEY (\\"agent_configuration_id\\") REFERENCES \\"public\\".\\"agent_configurations\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"deliverable_versions\\"\n    ADD CONSTRAINT \\"deliverable_versions_deliverable_id_fkey\\" FOREIGN KEY (\\"deliverable_id\\") REFERENCES \\"public\\".\\"deliverables\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"deliverable_versions\\"\n    ADD CONSTRAINT \\"deliverable_versions_task_id_fkey\\" FOREIGN KEY (\\"task_id\\") REFERENCES \\"public\\".\\"tasks\\"(\\"id\\") ON DELETE SET NULL","ALTER TABLE ONLY \\"public\\".\\"deliverables\\"\n    ADD CONSTRAINT \\"deliverables_user_id_fkey\\" FOREIGN KEY (\\"user_id\\") REFERENCES \\"public\\".\\"users\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"departments\\"\n    ADD CONSTRAINT \\"departments_company_id_fkey\\" FOREIGN KEY (\\"company_id\\") REFERENCES \\"public\\".\\"companies\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"kpi_data\\"\n    ADD CONSTRAINT \\"kpi_data_department_id_fkey\\" FOREIGN KEY (\\"department_id\\") REFERENCES \\"public\\".\\"departments\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"kpi_data\\"\n    ADD CONSTRAINT \\"kpi_data_metric_id_fkey\\" FOREIGN KEY (\\"metric_id\\") REFERENCES \\"public\\".\\"kpi_metrics\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"kpi_goals\\"\n    ADD CONSTRAINT \\"kpi_goals_department_id_fkey\\" FOREIGN KEY (\\"department_id\\") REFERENCES \\"public\\".\\"departments\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"kpi_goals\\"\n    ADD CONSTRAINT \\"kpi_goals_metric_id_fkey\\" FOREIGN KEY (\\"metric_id\\") REFERENCES \\"public\\".\\"kpi_metrics\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"llm_models\\"\n    ADD CONSTRAINT \\"llm_models_provider_name_fkey\\" FOREIGN KEY (\\"provider_name\\") REFERENCES \\"public\\".\\"llm_providers\\"(\\"name\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"llm_usage\\"\n    ADD CONSTRAINT \\"llm_usage_conversation_id_fkey\\" FOREIGN KEY (\\"conversation_id\\") REFERENCES \\"public\\".\\"conversations\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"project_steps\\"\n    ADD CONSTRAINT \\"project_steps_project_id_fkey\\" FOREIGN KEY (\\"project_id\\") REFERENCES \\"public\\".\\"projects\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"projects\\"\n    ADD CONSTRAINT \\"projects_conversation_id_fkey\\" FOREIGN KEY (\\"conversation_id\\") REFERENCES \\"public\\".\\"conversations\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"projects\\"\n    ADD CONSTRAINT \\"projects_parent_project_id_fkey\\" FOREIGN KEY (\\"parent_project_id\\") REFERENCES \\"public\\".\\"projects\\"(\\"id\\") ON DELETE SET NULL","ALTER TABLE ONLY \\"public\\".\\"tasks\\"\n    ADD CONSTRAINT \\"tasks_conversation_id_fkey\\" FOREIGN KEY (\\"conversation_id\\") REFERENCES \\"public\\".\\"conversations\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"tasks\\"\n    ADD CONSTRAINT \\"tasks_user_id_fkey\\" FOREIGN KEY (\\"user_id\\") REFERENCES \\"public\\".\\"users\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"user_cidafm_commands\\"\n    ADD CONSTRAINT \\"user_cidafm_commands_command_id_fkey\\" FOREIGN KEY (\\"command_id\\") REFERENCES \\"public\\".\\"cidafm_commands\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"user_cidafm_commands\\"\n    ADD CONSTRAINT \\"user_cidafm_commands_user_id_fkey\\" FOREIGN KEY (\\"user_id\\") REFERENCES \\"public\\".\\"users\\"(\\"id\\") ON DELETE CASCADE","CREATE POLICY \\"Authenticated users can view creation metrics\\" ON \\"public\\".\\"agent_creation_metrics\\" FOR SELECT USING ((\\"auth\\".\\"role\\"() = 'authenticated'::\\"text\\"))","CREATE POLICY \\"Users can create agents\\" ON \\"public\\".\\"agent_configurations\\" FOR INSERT WITH CHECK ((\\"auth\\".\\"uid\\"() = \\"created_by\\"))","CREATE POLICY \\"Users can create their own project steps\\" ON \\"public\\".\\"project_steps\\" FOR INSERT WITH CHECK ((\\"project_id\\" IN ( SELECT \\"p\\".\\"id\\"\n   FROM (\\"public\\".\\"projects\\" \\"p\\"\n     JOIN \\"public\\".\\"conversations\\" \\"c\\" ON ((\\"p\\".\\"conversation_id\\" = \\"c\\".\\"id\\")))\n  WHERE (\\"c\\".\\"user_id\\" = \\"auth\\".\\"uid\\"()))))","CREATE POLICY \\"Users can create their own projects\\" ON \\"public\\".\\"projects\\" FOR INSERT WITH CHECK ((\\"conversation_id\\" IN ( SELECT \\"conversations\\".\\"id\\"\n   FROM \\"public\\".\\"conversations\\"\n  WHERE (\\"conversations\\".\\"user_id\\" = \\"auth\\".\\"uid\\"()))))","CREATE POLICY \\"Users can delete their own project steps\\" ON \\"public\\".\\"project_steps\\" FOR DELETE USING ((\\"project_id\\" IN ( SELECT \\"p\\".\\"id\\"\n   FROM (\\"public\\".\\"projects\\" \\"p\\"\n     JOIN \\"public\\".\\"conversations\\" \\"c\\" ON ((\\"p\\".\\"conversation_id\\" = \\"c\\".\\"id\\")))\n  WHERE (\\"c\\".\\"user_id\\" = \\"auth\\".\\"uid\\"()))))","CREATE POLICY \\"Users can delete their own projects\\" ON \\"public\\".\\"projects\\" FOR DELETE USING ((\\"conversation_id\\" IN ( SELECT \\"conversations\\".\\"id\\"\n   FROM \\"public\\".\\"conversations\\"\n  WHERE (\\"conversations\\".\\"user_id\\" = \\"auth\\".\\"uid\\"()))))","CREATE POLICY \\"Users can modify own agents\\" ON \\"public\\".\\"agent_configurations\\" USING ((\\"auth\\".\\"uid\\"() = \\"created_by\\"))","CREATE POLICY \\"Users can modify skills for own agents\\" ON \\"public\\".\\"agent_skills\\" USING ((EXISTS ( SELECT 1\n   FROM \\"public\\".\\"agent_configurations\\" \\"ac\\"\n  WHERE ((\\"ac\\".\\"id\\" = \\"agent_skills\\".\\"agent_configuration_id\\") AND (\\"ac\\".\\"created_by\\" = \\"auth\\".\\"uid\\"())))))","CREATE POLICY \\"Users can update their own project steps\\" ON \\"public\\".\\"project_steps\\" FOR UPDATE USING ((\\"project_id\\" IN ( SELECT \\"p\\".\\"id\\"\n   FROM (\\"public\\".\\"projects\\" \\"p\\"\n     JOIN \\"public\\".\\"conversations\\" \\"c\\" ON ((\\"p\\".\\"conversation_id\\" = \\"c\\".\\"id\\")))\n  WHERE (\\"c\\".\\"user_id\\" = \\"auth\\".\\"uid\\"()))))","CREATE POLICY \\"Users can update their own projects\\" ON \\"public\\".\\"projects\\" FOR UPDATE USING ((\\"conversation_id\\" IN ( SELECT \\"conversations\\".\\"id\\"\n   FROM \\"public\\".\\"conversations\\"\n  WHERE (\\"conversations\\".\\"user_id\\" = \\"auth\\".\\"uid\\"()))))","CREATE POLICY \\"Users can view active agents\\" ON \\"public\\".\\"agent_configurations\\" FOR SELECT USING (((\\"status\\")::\\"text\\" = 'active'::\\"text\\"))","CREATE POLICY \\"Users can view analytics for own agents\\" ON \\"public\\".\\"agent_usage_analytics\\" FOR SELECT USING ((EXISTS ( SELECT 1\n   FROM \\"public\\".\\"agent_configurations\\" \\"ac\\"\n  WHERE ((\\"ac\\".\\"id\\" = \\"agent_usage_analytics\\".\\"agent_configuration_id\\") AND (\\"ac\\".\\"created_by\\" = \\"auth\\".\\"uid\\"())))))","CREATE POLICY \\"Users can view logs for own agents\\" ON \\"public\\".\\"agent_creation_logs\\" FOR SELECT USING (((EXISTS ( SELECT 1\n   FROM \\"public\\".\\"agent_configurations\\" \\"ac\\"\n  WHERE ((\\"ac\\".\\"id\\" = \\"agent_creation_logs\\".\\"agent_configuration_id\\") AND (\\"ac\\".\\"created_by\\" = \\"auth\\".\\"uid\\"())))) OR (\\"performed_by\\" = \\"auth\\".\\"uid\\"())))","CREATE POLICY \\"Users can view own conversation events\\" ON \\"public\\".\\"agent_creation_events\\" USING ((EXISTS ( SELECT 1\n   FROM \\"public\\".\\"agent_creation_conversations\\" \\"c\\"\n  WHERE ((\\"c\\".\\"id\\" = \\"agent_creation_events\\".\\"conversation_id\\") AND (\\"c\\".\\"user_id\\" = \\"auth\\".\\"uid\\"())))))","CREATE POLICY \\"Users can view own conversations\\" ON \\"public\\".\\"agent_creation_conversations\\" USING ((\\"auth\\".\\"uid\\"() = \\"user_id\\"))","CREATE POLICY \\"Users can view skills for active agents\\" ON \\"public\\".\\"agent_skills\\" FOR SELECT USING ((EXISTS ( SELECT 1\n   FROM \\"public\\".\\"agent_configurations\\" \\"ac\\"\n  WHERE ((\\"ac\\".\\"id\\" = \\"agent_skills\\".\\"agent_configuration_id\\") AND ((\\"ac\\".\\"status\\")::\\"text\\" = 'active'::\\"text\\")))))","CREATE POLICY \\"Users can view their own project steps\\" ON \\"public\\".\\"project_steps\\" FOR SELECT USING ((\\"project_id\\" IN ( SELECT \\"p\\".\\"id\\"\n   FROM (\\"public\\".\\"projects\\" \\"p\\"\n     JOIN \\"public\\".\\"conversations\\" \\"c\\" ON ((\\"p\\".\\"conversation_id\\" = \\"c\\".\\"id\\")))\n  WHERE (\\"c\\".\\"user_id\\" = \\"auth\\".\\"uid\\"()))))","CREATE POLICY \\"Users can view their own projects\\" ON \\"public\\".\\"projects\\" FOR SELECT USING ((\\"conversation_id\\" IN ( SELECT \\"conversations\\".\\"id\\"\n   FROM \\"public\\".\\"conversations\\"\n  WHERE (\\"conversations\\".\\"user_id\\" = \\"auth\\".\\"uid\\"()))))","ALTER TABLE \\"public\\".\\"agent_configurations\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"agent_creation_conversations\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"agent_creation_events\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"agent_creation_logs\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"agent_creation_metrics\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"agent_skills\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"agent_usage_analytics\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"project_steps\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"projects\\" ENABLE ROW LEVEL SECURITY","ALTER PUBLICATION \\"supabase_realtime\\" OWNER TO \\"postgres\\"","GRANT USAGE ON SCHEMA \\"public\\" TO \\"postgres\\"","GRANT USAGE ON SCHEMA \\"public\\" TO \\"anon\\"","GRANT USAGE ON SCHEMA \\"public\\" TO \\"authenticated\\"","GRANT USAGE ON SCHEMA \\"public\\" TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"calculate_completion_percentage\\"(\\"requirements\\" \\"jsonb\\") TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"calculate_completion_percentage\\"(\\"requirements\\" \\"jsonb\\") TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"calculate_completion_percentage\\"(\\"requirements\\" \\"jsonb\\") TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"cleanup_abandoned_conversations\\"() TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"cleanup_abandoned_conversations\\"() TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"cleanup_abandoned_conversations\\"() TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"exec_sql\\"(\\"query\\" \\"text\\", \\"sql_query\\" \\"text\\") TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"exec_sql\\"(\\"query\\" \\"text\\", \\"sql_query\\" \\"text\\") TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"exec_sql\\"(\\"query\\" \\"text\\", \\"sql_query\\" \\"text\\") TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"get_global_model_config\\"() TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"get_global_model_config\\"() TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"get_global_model_config\\"() TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"log_agent_action\\"(\\"p_action\\" character varying, \\"p_agent_id\\" \\"uuid\\", \\"p_details\\" \\"jsonb\\", \\"p_previous_state\\" \\"jsonb\\", \\"p_new_state\\" \\"jsonb\\", \\"p_success\\" boolean, \\"p_error_message\\" \\"text\\") TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"log_agent_action\\"(\\"p_action\\" character varying, \\"p_agent_id\\" \\"uuid\\", \\"p_details\\" \\"jsonb\\", \\"p_previous_state\\" \\"jsonb\\", \\"p_new_state\\" \\"jsonb\\", \\"p_success\\" boolean, \\"p_error_message\\" \\"text\\") TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"log_agent_action\\"(\\"p_action\\" character varying, \\"p_agent_id\\" \\"uuid\\", \\"p_details\\" \\"jsonb\\", \\"p_previous_state\\" \\"jsonb\\", \\"p_new_state\\" \\"jsonb\\", \\"p_success\\" boolean, \\"p_error_message\\" \\"text\\") TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_agent_configurations_updated_at\\"() TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_agent_configurations_updated_at\\"() TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_agent_configurations_updated_at\\"() TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_agent_skills_updated_at\\"() TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_agent_skills_updated_at\\"() TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_agent_skills_updated_at\\"() TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_agent_usage_analytics\\"(\\"p_agent_id\\" \\"uuid\\", \\"p_conversation_increment\\" integer, \\"p_message_increment\\" integer, \\"p_response_time_ms\\" integer, \\"p_error_increment\\" integer, \\"p_unique_user_increment\\" integer) TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_agent_usage_analytics\\"(\\"p_agent_id\\" \\"uuid\\", \\"p_conversation_increment\\" integer, \\"p_message_increment\\" integer, \\"p_response_time_ms\\" integer, \\"p_error_increment\\" integer, \\"p_unique_user_increment\\" integer) TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_agent_usage_analytics\\"(\\"p_agent_id\\" \\"uuid\\", \\"p_conversation_increment\\" integer, \\"p_message_increment\\" integer, \\"p_response_time_ms\\" integer, \\"p_error_increment\\" integer, \\"p_unique_user_increment\\" integer) TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_completion_percentage\\"() TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_completion_percentage\\"() TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_completion_percentage\\"() TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_conversation_timestamps\\"() TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_conversation_timestamps\\"() TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_conversation_timestamps\\"() TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_creation_metrics\\"(\\"p_success\\" boolean, \\"p_creation_time_seconds\\" integer, \\"p_questions_answered\\" integer, \\"p_department\\" character varying) TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_creation_metrics\\"(\\"p_success\\" boolean, \\"p_creation_time_seconds\\" integer, \\"p_questions_answered\\" integer, \\"p_department\\" character varying) TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_creation_metrics\\"(\\"p_success\\" boolean, \\"p_creation_time_seconds\\" integer, \\"p_questions_answered\\" integer, \\"p_department\\" character varying) TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_updated_at_column\\"() TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_updated_at_column\\"() TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_updated_at_column\\"() TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"validate_skill_examples\\"(\\"examples\\" \\"jsonb\\") TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"validate_skill_examples\\"(\\"examples\\" \\"jsonb\\") TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"validate_skill_examples\\"(\\"examples\\" \\"jsonb\\") TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_configurations\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_configurations\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_configurations\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_conversations\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_conversations\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_conversations\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_events\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_events\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_events\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_logs\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_logs\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_logs\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_metrics\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_metrics\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_creation_metrics\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_skills\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_skills\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_skills\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_usage_analytics\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_usage_analytics\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_usage_analytics\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"cidafm_commands\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"cidafm_commands\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"cidafm_commands\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"companies\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"companies\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"companies\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"conversations\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"conversations\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"conversations\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"tasks\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"tasks\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"tasks\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"conversations_with_stats\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"conversations_with_stats\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"conversations_with_stats\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"deliverable_versions\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"deliverable_versions\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"deliverable_versions\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"deliverables\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"deliverables\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"deliverables\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"departments\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"departments\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"departments\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"kpi_data\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"kpi_data\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"kpi_data\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"kpi_goals\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"kpi_goals\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"kpi_goals\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"kpi_metrics\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"kpi_metrics\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"kpi_metrics\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_models\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_models\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_models\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_providers\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_providers\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_providers\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_usage\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_usage\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_usage\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"project_steps\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"project_steps\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"project_steps\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"projects\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"projects\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"projects\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"pseudonym_dictionaries\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"pseudonym_dictionaries\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"pseudonym_dictionaries\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"redaction_patterns\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"redaction_patterns\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"redaction_patterns\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"system_settings\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"system_settings\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"system_settings\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"user_cidafm_commands\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"user_cidafm_commands\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"user_cidafm_commands\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"users\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"users\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"users\\" TO \\"service_role\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON SEQUENCES TO \\"postgres\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON SEQUENCES TO \\"anon\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON SEQUENCES TO \\"authenticated\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON SEQUENCES TO \\"service_role\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON FUNCTIONS TO \\"postgres\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON FUNCTIONS TO \\"anon\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON FUNCTIONS TO \\"authenticated\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON FUNCTIONS TO \\"service_role\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON TABLES TO \\"postgres\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON TABLES TO \\"anon\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON TABLES TO \\"authenticated\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON TABLES TO \\"service_role\\"","RESET ALL"}	golden_master_complete
20250108000000	{"-- Jokes Agent Migration\n-- Creates the necessary database structure for the Productivity Jokes Agent\n\n-- Create jokes_agent table to store joke history and sessions\nCREATE TABLE IF NOT EXISTS jokes_agent (\n    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,\n    session_id TEXT NOT NULL,\n    prompt TEXT NOT NULL,\n    joke_output TEXT NOT NULL,\n    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()\n)","-- Create index for faster session lookups\nCREATE INDEX IF NOT EXISTS idx_jokes_agent_session_id ON jokes_agent(session_id)","CREATE INDEX IF NOT EXISTS idx_jokes_agent_created_at ON jokes_agent(created_at)","-- Create RLS policies for jokes_agent table\nALTER TABLE jokes_agent ENABLE ROW LEVEL SECURITY","-- Policy to allow authenticated users to read their own jokes\nCREATE POLICY \\"Users can view their own jokes\\" ON jokes_agent\n    FOR SELECT USING (auth.uid()::text = session_id OR session_id LIKE 'session_%')","-- Policy to allow authenticated users to insert jokes\nCREATE POLICY \\"Users can insert jokes\\" ON jokes_agent\n    FOR INSERT WITH CHECK (true)","-- Create function to clean up old joke records (older than 30 days)\nCREATE OR REPLACE FUNCTION cleanup_old_jokes()\nRETURNS void\nLANGUAGE plpgsql\nAS $$\nBEGIN\n    DELETE FROM jokes_agent \n    WHERE created_at < NOW() - INTERVAL '30 days';\nEND;\n$$","-- Create a scheduled job to run cleanup weekly (if pg_cron is available)\n-- SELECT cron.schedule('cleanup-jokes', '0 2 * * 0', 'SELECT cleanup_old_jokes();');\n\n-- Insert some sample fallback jokes for error handling\nINSERT INTO jokes_agent (session_id, prompt, joke_output) VALUES\n('fallback', 'error_fallback', 'Why don''t productivity apps ever get stressed? Because they know how to delegate their tasks!'),\n('fallback', 'error_fallback', 'What do you call a programmer who doesn''t comment their code? A mystery novelist!'),\n('fallback', 'error_fallback', 'Why did the spreadsheet go to therapy? It had too many cells of anxiety!'),\n('fallback', 'error_fallback', 'How do you comfort a JavaScript bug? You console it!'),\n('fallback', 'error_fallback', 'Why don''t databases ever get lonely? Because they always have relationships!')\nON CONFLICT DO NOTHING","-- Create a view for joke analytics\nCREATE OR REPLACE VIEW jokes_analytics AS\nSELECT \n    DATE(created_at) as joke_date,\n    COUNT(*) as total_jokes,\n    COUNT(DISTINCT session_id) as unique_sessions,\n    AVG(LENGTH(joke_output)) as avg_joke_length\nFROM jokes_agent \nWHERE session_id != 'fallback'\nGROUP BY DATE(created_at)\nORDER BY joke_date DESC","-- Grant permissions\nGRANT SELECT, INSERT ON jokes_agent TO authenticated","GRANT SELECT ON jokes_analytics TO authenticated"}	jokes_agent_migration
20250113000001	{"-- =====================================\n-- Create Company Schema and Move Company-Related Tables\n-- =====================================\n-- This migration creates a dedicated 'company' schema and moves all\n-- company-related tables from public schema to provide better organization\n-- and prepare for multi-tenancy scenarios.\n\n-- Create the company schema\nCREATE SCHEMA IF NOT EXISTS company","-- Move companies table to company schema\nDO $$\nBEGIN\n  -- Check if table exists in public schema\n  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'companies') THEN\n    -- Move the table\n    ALTER TABLE public.companies SET SCHEMA company;\n    \n    -- Add comment to the table\n    COMMENT ON TABLE company.companies IS 'Company information and metadata';\n  END IF;\nEND $$","-- Move departments table to company schema\nDO $$\nBEGIN\n  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'departments') THEN\n    ALTER TABLE public.departments SET SCHEMA company;\n    \n    COMMENT ON TABLE company.departments IS 'Company departments and organizational structure';\n  END IF;\nEND $$","-- Move kpi_metrics table to company schema\nDO $$\nBEGIN\n  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'kpi_metrics') THEN\n    ALTER TABLE public.kpi_metrics SET SCHEMA company;\n    \n    COMMENT ON TABLE company.kpi_metrics IS 'KPI metric definitions and metadata';\n  END IF;\nEND $$","-- Move kpi_goals table to company schema\nDO $$\nBEGIN\n  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'kpi_goals') THEN\n    ALTER TABLE public.kpi_goals SET SCHEMA company;\n    \n    COMMENT ON TABLE company.kpi_goals IS 'Department KPI goals and targets';\n  END IF;\nEND $$","-- Move kpi_data table to company schema\nDO $$\nBEGIN\n  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'kpi_data') THEN\n    ALTER TABLE public.kpi_data SET SCHEMA company;\n    \n    COMMENT ON TABLE company.kpi_data IS 'Actual KPI data points and measurements';\n  END IF;\nEND $$","-- Update foreign key constraints to reference company schema\nDO $$\nBEGIN\n  -- Update departments foreign key to reference company.companies\n  IF EXISTS (SELECT 1 FROM information_schema.table_constraints \n             WHERE constraint_schema = 'company' \n             AND constraint_name = 'departments_company_id_fkey') THEN\n    ALTER TABLE company.departments DROP CONSTRAINT IF EXISTS departments_company_id_fkey;\n    ALTER TABLE company.departments ADD CONSTRAINT departments_company_id_fkey \n      FOREIGN KEY (company_id) REFERENCES company.companies(id) ON DELETE CASCADE;\n  END IF;\nEND $$","DO $$\nBEGIN\n  -- Update kpi_data foreign keys\n  IF EXISTS (SELECT 1 FROM information_schema.table_constraints \n             WHERE constraint_schema = 'company' \n             AND constraint_name = 'kpi_data_department_id_fkey') THEN\n    ALTER TABLE company.kpi_data DROP CONSTRAINT IF EXISTS kpi_data_department_id_fkey;\n    ALTER TABLE company.kpi_data ADD CONSTRAINT kpi_data_department_id_fkey \n      FOREIGN KEY (department_id) REFERENCES company.departments(id) ON DELETE CASCADE;\n  END IF;\n  \n  IF EXISTS (SELECT 1 FROM information_schema.table_constraints \n             WHERE constraint_schema = 'company' \n             AND constraint_name = 'kpi_data_metric_id_fkey') THEN\n    ALTER TABLE company.kpi_data DROP CONSTRAINT IF EXISTS kpi_data_metric_id_fkey;\n    ALTER TABLE company.kpi_data ADD CONSTRAINT kpi_data_metric_id_fkey \n      FOREIGN KEY (metric_id) REFERENCES company.kpi_metrics(id) ON DELETE CASCADE;\n  END IF;\nEND $$","DO $$\nBEGIN\n  -- Update kpi_goals foreign keys\n  IF EXISTS (SELECT 1 FROM information_schema.table_constraints \n             WHERE constraint_schema = 'company' \n             AND constraint_name = 'kpi_goals_department_id_fkey') THEN\n    ALTER TABLE company.kpi_goals DROP CONSTRAINT IF EXISTS kpi_goals_department_id_fkey;\n    ALTER TABLE company.kpi_goals ADD CONSTRAINT kpi_goals_department_id_fkey \n      FOREIGN KEY (department_id) REFERENCES company.departments(id) ON DELETE CASCADE;\n  END IF;\n  \n  IF EXISTS (SELECT 1 FROM information_schema.table_constraints \n             WHERE constraint_schema = 'company' \n             AND constraint_name = 'kpi_goals_metric_id_fkey') THEN\n    ALTER TABLE company.kpi_goals DROP CONSTRAINT IF EXISTS kpi_goals_metric_id_fkey;\n    ALTER TABLE company.kpi_goals ADD CONSTRAINT kpi_goals_metric_id_fkey \n      FOREIGN KEY (metric_id) REFERENCES company.kpi_metrics(id) ON DELETE CASCADE;\n  END IF;\nEND $$","-- Grant permissions on company schema tables\nGRANT ALL ON SCHEMA company TO anon","GRANT ALL ON SCHEMA company TO authenticated","GRANT ALL ON SCHEMA company TO service_role","-- Grant permissions on all company tables\nDO $$\nDECLARE\n    table_name text;\nBEGIN\n    FOR table_name IN \n        SELECT tablename FROM pg_tables WHERE schemaname = 'company'\n    LOOP\n        EXECUTE format('GRANT ALL ON TABLE company.%I TO anon', table_name);\n        EXECUTE format('GRANT ALL ON TABLE company.%I TO authenticated', table_name);\n        EXECUTE format('GRANT ALL ON TABLE company.%I TO service_role', table_name);\n    END LOOP;\nEND $$","-- Add comments to the schema\nCOMMENT ON SCHEMA company IS 'Company-related data including organizations, departments, and KPI metrics'"}	create_company_schema_and_move_tables
202501160001	{"-- Agent platform base tables\n\n-- Drop legacy filesystem-driven agent tables once we move to database-backed agents\nDROP TABLE IF EXISTS public.agent_usage_analytics CASCADE","DROP TABLE IF EXISTS public.agent_skills CASCADE","DROP TABLE IF EXISTS public.agent_creation_metrics CASCADE","DROP TABLE IF EXISTS public.agent_creation_logs CASCADE","DROP TABLE IF EXISTS public.agent_creation_events CASCADE","DROP TABLE IF EXISTS public.agent_creation_conversations CASCADE","DROP TABLE IF EXISTS public.agent_configurations CASCADE","-- agents table stores metadata, yaml, and derived context/config for runtime\nCREATE TABLE IF NOT EXISTS public.agents (\n    id uuid DEFAULT extensions.uuid_generate_v4() PRIMARY KEY,\n    organization_slug text,\n    slug text NOT NULL,\n    display_name text NOT NULL,\n    description text,\n    agent_type text NOT NULL,\n    mode_profile text NOT NULL,\n    version text,\n    status text DEFAULT 'active',\n    yaml text NOT NULL,\n    agent_card jsonb,\n    context jsonb,\n    config jsonb,\n    created_at timestamptz DEFAULT now(),\n    updated_at timestamptz DEFAULT now(),\n    CONSTRAINT agents_slug_unique UNIQUE (organization_slug, slug)\n)","COMMENT ON TABLE public.agents IS 'Database-backed agent descriptors for the new platform.'","COMMENT ON COLUMN public.agents.organization_slug IS 'Namespace / organization identifier (e.g., demo, my-org).'","COMMENT ON COLUMN public.agents.yaml IS 'Raw YAML/JSON descriptor for auditability.'","COMMENT ON COLUMN public.agents.agent_card IS 'Cached agent card served to clients.'","COMMENT ON COLUMN public.agents.context IS 'System prompt, plan rubric, and reference data.'","COMMENT ON COLUMN public.agents.config IS 'Execution configuration (capabilities, supporting agents, checkpoints, etc.).'","-- organization credentials per org/alias\nCREATE TABLE IF NOT EXISTS public.organization_credentials (\n    id uuid DEFAULT extensions.uuid_generate_v4() PRIMARY KEY,\n    organization_slug text NOT NULL,\n    alias text NOT NULL,\n    credential_type text NOT NULL,\n    encrypted_value bytea NOT NULL,\n    encryption_metadata jsonb DEFAULT '{}'::jsonb,\n    rotated_at timestamptz,\n    created_at timestamptz DEFAULT now(),\n    updated_at timestamptz DEFAULT now(),\n    CONSTRAINT organization_credentials_alias_unique UNIQUE (organization_slug, alias)\n)","COMMENT ON TABLE public.organization_credentials IS 'Encrypted secrets per organization (API keys, service credentials).'","-- conversation plans capture structured plans tied to conversations\nCREATE TABLE IF NOT EXISTS public.conversation_plans (\n    id uuid DEFAULT extensions.uuid_generate_v4() PRIMARY KEY,\n    conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,\n    organization_slug text,\n    agent_slug text NOT NULL,\n    version integer DEFAULT 1,\n    status text DEFAULT 'draft',\n    summary text,\n    plan_json jsonb NOT NULL,\n    created_by uuid,\n    approved_by uuid,\n    created_at timestamptz DEFAULT now(),\n    updated_at timestamptz DEFAULT now()\n)","COMMENT ON TABLE public.conversation_plans IS 'Structured plans generated during plan mode, linked to conversations.'","COMMENT ON COLUMN public.conversation_plans.plan_json IS 'Plan structure including phases, steps, dependencies, checkpoints.'","-- saved orchestrations act as reusable execution recipes for agents\nCREATE TABLE IF NOT EXISTS public.agent_orchestrations (\n    id uuid DEFAULT extensions.uuid_generate_v4() PRIMARY KEY,\n    organization_slug text,\n    agent_slug text NOT NULL,\n    slug text NOT NULL,\n    display_name text NOT NULL,\n    description text,\n    status text DEFAULT 'active',\n    orchestration_json jsonb NOT NULL,\n    prompt_templates jsonb DEFAULT '[]'::jsonb,\n    tags text[] DEFAULT ARRAY[]::text[],\n    version text,\n    created_by uuid,\n    updated_by uuid,\n    created_at timestamptz DEFAULT now(),\n    updated_at timestamptz DEFAULT now(),\n    CONSTRAINT agent_orchestrations_slug_unique UNIQUE (organization_slug, agent_slug, slug)\n)","COMMENT ON TABLE public.agent_orchestrations IS 'Reusable orchestration recipes bound to a specific agent.'","COMMENT ON COLUMN public.agent_orchestrations.orchestration_json IS 'Structured orchestration definition (phases, steps, dependencies).'","COMMENT ON COLUMN public.agent_orchestrations.prompt_templates IS 'Prompt templates with parameter metadata required to launch orchestrations.'","-- orchestration runs instantiate execution of approved plans\nCREATE TABLE IF NOT EXISTS public.orchestration_runs (\n    id uuid DEFAULT extensions.uuid_generate_v4() PRIMARY KEY,\n    plan_id uuid REFERENCES public.conversation_plans(id) ON DELETE SET NULL,\n    origin_type text DEFAULT 'plan',\n    origin_id uuid,\n    orchestration_slug text,\n    prompt_inputs jsonb DEFAULT '{}'::jsonb,\n    organization_slug text,\n    status text DEFAULT 'pending',\n    current_step_index integer,\n    completed_steps jsonb DEFAULT '[]'::jsonb,\n    step_state jsonb DEFAULT '{}'::jsonb,\n    human_checkpoint_id text,\n    metadata jsonb DEFAULT '{}'::jsonb,\n    started_at timestamptz DEFAULT now(),\n    completed_at timestamptz\n)","COMMENT ON TABLE public.orchestration_runs IS 'Live orchestration execution state derived from conversation plans or saved orchestrations.'","COMMENT ON COLUMN public.orchestration_runs.step_state IS 'Per-step status metadata including conversations, deliverables, assignments.'","COMMENT ON COLUMN public.orchestration_runs.origin_type IS 'Execution source (plan, saved_orchestration, ad_hoc).'","COMMENT ON COLUMN public.orchestration_runs.orchestration_slug IS 'Slug of the saved orchestration recipe when origin_type = saved_orchestration.'","COMMENT ON COLUMN public.orchestration_runs.prompt_inputs IS 'Resolved prompt parameter payload provided at orchestration launch.'","-- optional organization reference on users (nullable for legacy accounts)\nALTER TABLE public.users\n    ADD COLUMN IF NOT EXISTS organization_slug text","CREATE INDEX IF NOT EXISTS idx_agents_org_slug ON public.agents(organization_slug)","CREATE INDEX IF NOT EXISTS idx_agents_slug ON public.agents(slug)","CREATE INDEX IF NOT EXISTS idx_conversation_plans_conversation ON public.conversation_plans(conversation_id)","CREATE INDEX IF NOT EXISTS idx_agent_orchestrations_agent ON public.agent_orchestrations(agent_slug)","CREATE INDEX IF NOT EXISTS idx_agent_orchestrations_org ON public.agent_orchestrations(organization_slug)","CREATE INDEX IF NOT EXISTS idx_orchestration_runs_plan ON public.orchestration_runs(plan_id)","CREATE INDEX IF NOT EXISTS idx_org_credentials_org ON public.organization_credentials(organization_slug)"}	agent_platform
202501170001	{"-- Rename legacy project_runs artifacts to orchestration_ equivalents and\n-- backfill saved orchestration support for agents.\n\nBEGIN","-- Rename table and index if they still exist from early migrations.\nALTER TABLE IF EXISTS public.project_runs\n    RENAME TO orchestration_runs","ALTER INDEX IF EXISTS idx_project_runs_plan\n    RENAME TO idx_orchestration_runs_plan","COMMENT ON TABLE public.orchestration_runs IS 'Live orchestration execution state derived from conversation plans or saved orchestrations.'","COMMENT ON COLUMN public.orchestration_runs.step_state IS 'Per-step status metadata including conversations, deliverables, assignments.'","ALTER TABLE IF EXISTS public.orchestration_runs\n    ALTER COLUMN plan_id DROP NOT NULL","ALTER TABLE IF EXISTS public.orchestration_runs\n    DROP CONSTRAINT IF EXISTS orchestration_runs_plan_id_fkey","ALTER TABLE IF EXISTS public.orchestration_runs\n    ADD CONSTRAINT orchestration_runs_plan_id_fkey\n        FOREIGN KEY (plan_id)\n        REFERENCES public.conversation_plans(id)\n        ON DELETE SET NULL","ALTER TABLE IF EXISTS public.orchestration_runs\n    ADD COLUMN IF NOT EXISTS origin_type text DEFAULT 'plan'","ALTER TABLE IF EXISTS public.orchestration_runs\n    ADD COLUMN IF NOT EXISTS origin_id uuid","ALTER TABLE IF EXISTS public.orchestration_runs\n    ADD COLUMN IF NOT EXISTS orchestration_slug text","ALTER TABLE IF EXISTS public.orchestration_runs\n    ADD COLUMN IF NOT EXISTS prompt_inputs jsonb DEFAULT '{}'::jsonb","-- Ensure saved orchestration recipes table is available.\nCREATE TABLE IF NOT EXISTS public.agent_orchestrations (\n    id uuid DEFAULT extensions.uuid_generate_v4() PRIMARY KEY,\n    organization_slug text,\n    agent_slug text NOT NULL,\n    slug text NOT NULL,\n    display_name text NOT NULL,\n    description text,\n    status text DEFAULT 'active',\n    orchestration_json jsonb NOT NULL,\n    prompt_templates jsonb DEFAULT '[]'::jsonb,\n    tags text[] DEFAULT ARRAY[]::text[],\n    version text,\n    created_by uuid,\n    updated_by uuid,\n    created_at timestamptz DEFAULT now(),\n    updated_at timestamptz DEFAULT now(),\n    CONSTRAINT agent_orchestrations_slug_unique UNIQUE (organization_slug, agent_slug, slug)\n)","COMMENT ON TABLE public.agent_orchestrations IS 'Reusable orchestration recipes bound to a specific agent.'","COMMENT ON COLUMN public.agent_orchestrations.orchestration_json IS 'Structured orchestration definition (phases, steps, dependencies).'","COMMENT ON COLUMN public.agent_orchestrations.prompt_templates IS 'Prompt templates with parameter metadata required to launch orchestrations.'","CREATE INDEX IF NOT EXISTS idx_agent_orchestrations_agent ON public.agent_orchestrations(agent_slug)","CREATE INDEX IF NOT EXISTS idx_agent_orchestrations_org ON public.agent_orchestrations(organization_slug)",COMMIT}	orchestration_recipes
202501210001	{"-- Migration: Add `route` column to llm_usage and backfill from is_local\n-- Created: 2025-01-21\n\nBEGIN","-- 1) Add column if it does not exist\nALTER TABLE public.llm_usage\n  ADD COLUMN IF NOT EXISTS route text","-- 2) Backfill existing rows where route is NULL\nUPDATE public.llm_usage\n   SET route = CASE WHEN is_local IS TRUE THEN 'local' ELSE 'remote' END\n WHERE route IS NULL","-- 3) Optional: basic check constraint to keep route normalized\nDO $$\nBEGIN\n  IF NOT EXISTS (\n    SELECT 1\n      FROM pg_constraint\n     WHERE conname = 'llm_usage_route_check'\n  ) THEN\n    ALTER TABLE public.llm_usage\n      ADD CONSTRAINT llm_usage_route_check\n      CHECK (route IS NULL OR route IN ('local','remote'));\n  END IF;\nEND $$",COMMIT}	llm_usage_route
202501210002	{"-- Migration: Index for llm_usage.route for faster route breakdowns\n-- Created: 2025-01-21\n\nBEGIN","CREATE INDEX IF NOT EXISTS llm_usage_route_idx\n  ON public.llm_usage (route)","-- Optional: time-sliced index for common analytics windows\n-- Uncomment if you frequently filter by started_at\n-- CREATE INDEX IF NOT EXISTS llm_usage_route_started_at_idx\n--   ON public.llm_usage (route, started_at DESC);\n\nCOMMIT"}	llm_usage_route_index
202501210003	{"-- Migration: Composite index for llm_usage (route, started_at)\n-- Created: 2025-01-21\n\nBEGIN","CREATE INDEX IF NOT EXISTS llm_usage_route_started_at_idx\n  ON public.llm_usage (route, started_at DESC)",COMMIT}	llm_usage_route_started_at_idx
202501210004	{"-- Migration: Create human_approvals table for gating approvals\n-- Created: 2025-01-21\n\nBEGIN","CREATE TABLE IF NOT EXISTS public.human_approvals (\n  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),\n  organization_slug text NULL,\n  agent_slug text NOT NULL,\n  conversation_id uuid NULL,\n  task_id text NULL,\n  mode text NOT NULL,\n  status text NOT NULL DEFAULT 'pending', -- pending | approved | rejected\n  approved_by text NULL,\n  decision_at timestamptz NULL,\n  metadata jsonb NULL DEFAULT '{}'::jsonb,\n  created_at timestamptz NOT NULL DEFAULT now(),\n  updated_at timestamptz NOT NULL DEFAULT now()\n)","CREATE INDEX IF NOT EXISTS human_approvals_conversation_idx ON public.human_approvals (conversation_id)","CREATE INDEX IF NOT EXISTS human_approvals_status_idx ON public.human_approvals (status)","-- Simple trigger to update updated_at\nCREATE OR REPLACE FUNCTION public.set_timestamp_updated_at()\nRETURNS TRIGGER AS $$\nBEGIN\n  NEW.updated_at = now();\n  RETURN NEW;\nEND;\n$$ LANGUAGE plpgsql","DROP TRIGGER IF EXISTS set_timestamp_updated_at_human_approvals ON public.human_approvals","CREATE TRIGGER set_timestamp_updated_at_human_approvals\nBEFORE UPDATE ON public.human_approvals\nFOR EACH ROW EXECUTE FUNCTION public.set_timestamp_updated_at()",COMMIT}	human_approvals
202510040001	{"-- Migration: Create plans and plan_versions tables\n-- Date: 2025-10-04\n-- Description: Creates plans and plan_versions tables with identical structure to deliverables\n-- Drops old conversation_plan table and replaces with new versioned architecture\n\n-- Drop old conversation_plan and conversation_plans tables if they exist\nDROP TABLE IF EXISTS public.conversation_plan CASCADE","DROP TABLE IF EXISTS public.conversation_plans CASCADE","-- Create plans table (mirrors deliverables structure)\nCREATE TABLE IF NOT EXISTS public.plans (\n  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),\n  conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,\n  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,\n  agent_name TEXT NOT NULL,\n  namespace TEXT NOT NULL,\n  title TEXT NOT NULL,\n  current_version_id UUID,\n  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n\n  -- One plan per conversation constraint\n  CONSTRAINT unique_conversation_plan UNIQUE (conversation_id)\n)","-- Create plan_versions table (mirrors deliverable_versions structure)\nCREATE TABLE IF NOT EXISTS public.plan_versions (\n  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),\n  plan_id UUID NOT NULL REFERENCES public.plans(id) ON DELETE CASCADE,\n  version_number INTEGER NOT NULL,\n  content TEXT NOT NULL,\n  format TEXT NOT NULL DEFAULT 'markdown' CHECK (format IN ('markdown', 'json', 'text')),\n  created_by_type TEXT NOT NULL CHECK (created_by_type IN ('agent', 'user')),\n  created_by_id UUID,\n  task_id UUID,\n  metadata JSONB DEFAULT '{}',\n  is_current_version BOOLEAN DEFAULT false,\n  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n\n  -- Unique constraint on plan_id + version_number\n  CONSTRAINT unique_plan_version UNIQUE (plan_id, version_number)\n)","-- Add foreign key from plans to plan_versions for current_version_id\nDO $$\nBEGIN\n  IF NOT EXISTS (\n    SELECT 1 FROM information_schema.table_constraints \n    WHERE constraint_name = 'fk_plans_current_version' \n    AND table_name = 'plans'\n  ) THEN\n    ALTER TABLE public.plans\n      ADD CONSTRAINT fk_plans_current_version\n      FOREIGN KEY (current_version_id)\n      REFERENCES public.plan_versions(id)\n      ON DELETE SET NULL;\n  END IF;\nEND $$","-- Create indexes for performance\nCREATE INDEX IF NOT EXISTS idx_plans_conversation_id ON public.plans(conversation_id)","CREATE INDEX IF NOT EXISTS idx_plans_user_id ON public.plans(user_id)","CREATE INDEX IF NOT EXISTS idx_plan_versions_plan_id ON public.plan_versions(plan_id)","CREATE INDEX IF NOT EXISTS idx_plan_versions_is_current ON public.plan_versions(is_current_version) WHERE is_current_version = true","CREATE INDEX IF NOT EXISTS idx_plan_versions_task_id ON public.plan_versions(task_id) WHERE task_id IS NOT NULL","-- Create updated_at trigger for plans table\nCREATE OR REPLACE FUNCTION public.update_plans_updated_at()\nRETURNS TRIGGER AS $$\nBEGIN\n  NEW.updated_at = NOW();\n  RETURN NEW;\nEND;\n$$ LANGUAGE plpgsql","DROP TRIGGER IF EXISTS trigger_plans_updated_at ON public.plans","CREATE TRIGGER trigger_plans_updated_at\n  BEFORE UPDATE ON public.plans\n  FOR EACH ROW\n  EXECUTE FUNCTION public.update_plans_updated_at()","-- Add RLS policies (mirroring deliverables)\nALTER TABLE public.plans ENABLE ROW LEVEL SECURITY","ALTER TABLE public.plan_versions ENABLE ROW LEVEL SECURITY","-- Plans policies: users can only access their own plans\nDROP POLICY IF EXISTS plans_select_policy ON public.plans","CREATE POLICY plans_select_policy ON public.plans\n  FOR SELECT\n  USING (auth.uid() = user_id)","DROP POLICY IF EXISTS plans_insert_policy ON public.plans","CREATE POLICY plans_insert_policy ON public.plans\n  FOR INSERT\n  WITH CHECK (auth.uid() = user_id)","DROP POLICY IF EXISTS plans_update_policy ON public.plans","CREATE POLICY plans_update_policy ON public.plans\n  FOR UPDATE\n  USING (auth.uid() = user_id)","DROP POLICY IF EXISTS plans_delete_policy ON public.plans","CREATE POLICY plans_delete_policy ON public.plans\n  FOR DELETE\n  USING (auth.uid() = user_id)","-- Plan versions policies: users can access versions of their plans\nDROP POLICY IF EXISTS plan_versions_select_policy ON public.plan_versions","CREATE POLICY plan_versions_select_policy ON public.plan_versions\n  FOR SELECT\n  USING (\n    EXISTS (\n      SELECT 1 FROM public.plans\n      WHERE public.plans.id = public.plan_versions.plan_id\n      AND public.plans.user_id = auth.uid()\n    )\n  )","DROP POLICY IF EXISTS plan_versions_insert_policy ON public.plan_versions","CREATE POLICY plan_versions_insert_policy ON public.plan_versions\n  FOR INSERT\n  WITH CHECK (\n    EXISTS (\n      SELECT 1 FROM public.plans\n      WHERE public.plans.id = public.plan_versions.plan_id\n      AND public.plans.user_id = auth.uid()\n    )\n  )","DROP POLICY IF EXISTS plan_versions_update_policy ON public.plan_versions","CREATE POLICY plan_versions_update_policy ON public.plan_versions\n  FOR UPDATE\n  USING (\n    EXISTS (\n      SELECT 1 FROM public.plans\n      WHERE public.plans.id = public.plan_versions.plan_id\n      AND public.plans.user_id = auth.uid()\n    )\n  )","DROP POLICY IF EXISTS plan_versions_delete_policy ON public.plan_versions","CREATE POLICY plan_versions_delete_policy ON public.plan_versions\n  FOR DELETE\n  USING (\n    EXISTS (\n      SELECT 1 FROM public.plans\n      WHERE public.plans.id = public.plan_versions.plan_id\n      AND public.plans.user_id = auth.uid()\n    )\n  )","-- Add comments for documentation\nCOMMENT ON TABLE public.plans IS 'Stores plan metadata for agent2agent conversations. One plan per conversation with versioned content.'","COMMENT ON TABLE public.plan_versions IS 'Stores immutable versions of plans. Each edit/refinement creates a new version.'","COMMENT ON COLUMN public.plans.current_version_id IS 'Points to the currently active version of this plan'","COMMENT ON COLUMN public.plan_versions.created_by_type IS 'Whether this version was created by an agent or manually edited by a user'","COMMENT ON COLUMN public.plan_versions.task_id IS 'Reference to the agent task that created this version (if applicable)'","COMMENT ON COLUMN public.plan_versions.metadata IS 'Additional metadata like LLM model used, merge source versions, etc.'"}	create_plans_tables
202502090001	{"-- Migration: add TTL support to task_messages for SSE backlog cleanup\n-- Created: 2025-02-09\n\nBEGIN","-- 1) Create task_messages table if it doesn't exist (align with TaskMessageService expectations)\nCREATE TABLE IF NOT EXISTS public.task_messages (\n  id uuid DEFAULT extensions.uuid_generate_v4() PRIMARY KEY,\n  task_id uuid NOT NULL,\n  user_id uuid,\n  content text NOT NULL,\n  message_type text NOT NULL DEFAULT 'info',\n  progress_percentage numeric,\n  metadata jsonb DEFAULT '{}'::jsonb,\n  created_at timestamptz DEFAULT now(),\n  expires_at timestamptz DEFAULT (now() + interval '1 hour')\n)","COMMENT ON TABLE public.task_messages IS 'Short-lived task streaming messages used for SSE + polling replay.'","-- 2) Ensure expected columns exist when migrating older installs\nALTER TABLE public.task_messages\n  ADD COLUMN IF NOT EXISTS user_id uuid","ALTER TABLE public.task_messages\n  ADD COLUMN IF NOT EXISTS content text","ALTER TABLE public.task_messages\n  ADD COLUMN IF NOT EXISTS message_type text","ALTER TABLE public.task_messages\n  ADD COLUMN IF NOT EXISTS progress_percentage numeric","ALTER TABLE public.task_messages\n  ADD COLUMN IF NOT EXISTS metadata jsonb DEFAULT '{}'::jsonb","ALTER TABLE public.task_messages\n  ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now()","ALTER TABLE public.task_messages\n  ADD COLUMN IF NOT EXISTS expires_at timestamptz DEFAULT (now() + interval '1 hour')","-- 3) Backfill column defaults / constraints\nALTER TABLE public.task_messages\n  ALTER COLUMN message_type SET DEFAULT 'info'","ALTER TABLE public.task_messages\n  ALTER COLUMN metadata SET DEFAULT '{}'::jsonb","ALTER TABLE public.task_messages\n  ALTER COLUMN created_at SET DEFAULT now()","ALTER TABLE public.task_messages\n  ALTER COLUMN expires_at SET DEFAULT (now() + interval '1 hour')","ALTER TABLE public.task_messages\n  ALTER COLUMN expires_at SET NOT NULL","-- 4) Populate expires_at for existing rows lacking a value\nUPDATE public.task_messages\n   SET expires_at = COALESCE(expires_at, COALESCE(created_at, now()) + interval '1 hour')\n WHERE expires_at IS NULL","-- 5) Update legacy column names if an older schema used different names\nDO $$\nBEGIN\n  IF EXISTS (\n    SELECT 1\n    FROM information_schema.columns\n    WHERE table_name = 'task_messages'\n      AND column_name = 'message'\n  ) THEN\n    ALTER TABLE public.task_messages RENAME COLUMN message TO content;\n  END IF;\n  IF EXISTS (\n    SELECT 1\n    FROM information_schema.columns\n    WHERE table_name = 'task_messages'\n      AND column_name = 'event_type'\n  ) THEN\n    ALTER TABLE public.task_messages RENAME COLUMN event_type TO message_type;\n  END IF;\nEND $$","-- 6) Index expiry for cleanup jobs (and composite for task scoped trims)\nCREATE INDEX IF NOT EXISTS idx_task_messages_expires_at\n  ON public.task_messages (expires_at)","CREATE INDEX IF NOT EXISTS idx_task_messages_task_id_expires_at\n  ON public.task_messages (task_id, expires_at)","CREATE INDEX IF NOT EXISTS idx_task_messages_task_id\n  ON public.task_messages (task_id)","CREATE INDEX IF NOT EXISTS idx_task_messages_created_at\n  ON public.task_messages (created_at DESC)",COMMIT}	task_messages_ttl
202502090002	{"-- Migration: add orchestration_steps and orchestration_checkpoints tables\n-- Created: 2025-02-09\n\nBEGIN","-- 1) Ensure orchestration_runs exists (created in prior migrations)\n--    so we can safely reference it as a foreign key.\n\n-- 2) Persistent storage for per-step state within an orchestration run.\nCREATE TABLE IF NOT EXISTS public.orchestration_steps (\n    id uuid DEFAULT extensions.uuid_generate_v4() PRIMARY KEY,\n    orchestration_run_id uuid NOT NULL REFERENCES public.orchestration_runs(id) ON DELETE CASCADE,\n    step_index integer NOT NULL,\n    step_key text,\n    status text NOT NULL DEFAULT 'pending',\n    agent_slug text,\n    input jsonb DEFAULT '{}'::jsonb,\n    output jsonb,\n    metadata jsonb DEFAULT '{}'::jsonb,\n    error jsonb,\n    started_at timestamptz,\n    completed_at timestamptz,\n    created_at timestamptz DEFAULT now(),\n    updated_at timestamptz DEFAULT now(),\n    CONSTRAINT orchestration_steps_unique_per_run UNIQUE (orchestration_run_id, step_index)\n)","COMMENT ON TABLE public.orchestration_steps IS 'Durable record of each orchestration step state.'","COMMENT ON COLUMN public.orchestration_steps.step_key IS 'Optional identifier from plan/orchestration definition.'","COMMENT ON COLUMN public.orchestration_steps.metadata IS 'Execution metadata (progress markers, retries, etc.).'","COMMENT ON COLUMN public.orchestration_steps.error IS 'Latest error payload if the step failed.'","CREATE INDEX IF NOT EXISTS idx_orchestration_steps_run\n    ON public.orchestration_steps (orchestration_run_id)","CREATE INDEX IF NOT EXISTS idx_orchestration_steps_status\n    ON public.orchestration_steps (status)","-- 3) Checkpoints allow long-running orchestrations to resume.\nCREATE TABLE IF NOT EXISTS public.orchestration_checkpoints (\n    id uuid DEFAULT extensions.uuid_generate_v4() PRIMARY KEY,\n    orchestration_run_id uuid NOT NULL REFERENCES public.orchestration_runs(id) ON DELETE CASCADE,\n    step_index integer,\n    label text,\n    state jsonb NOT NULL,\n    metadata jsonb DEFAULT '{}'::jsonb,\n    created_by uuid,\n    created_at timestamptz DEFAULT now()\n)","COMMENT ON TABLE public.orchestration_checkpoints IS 'Serializable snapshots that allow orchestration resumes.'","COMMENT ON COLUMN public.orchestration_checkpoints.state IS 'Serializable execution state at checkpoint.'","CREATE INDEX IF NOT EXISTS idx_orchestration_checkpoints_run\n    ON public.orchestration_checkpoints (orchestration_run_id, created_at DESC)","CREATE INDEX IF NOT EXISTS idx_orchestration_checkpoints_label\n    ON public.orchestration_checkpoints (label)",COMMIT}	orchestration_persistence
20250911	{"-- System settings store and global model config accessor\n\nSET statement_timeout = 0","SET lock_timeout = 0","SET idle_in_transaction_session_timeout = 0","SET client_encoding = 'UTF8'","SET standard_conforming_strings = on","SELECT pg_catalog.set_config('search_path', '', false)","SET check_function_bodies = false","SET xmloption = content","SET client_min_messages = warning","SET row_security = off","-- Key/value JSONB settings table\nCREATE TABLE IF NOT EXISTS public.system_settings (\n    key text PRIMARY KEY,\n    value jsonb NOT NULL,\n    updated_at timestamptz DEFAULT now()\n)","COMMENT ON TABLE public.system_settings IS 'System-wide settings (key/value JSON). Used for global model configuration and feature flags.'","-- Function to fetch the global model configuration\nCREATE OR REPLACE FUNCTION public.get_global_model_config()\nRETURNS jsonb\nLANGUAGE sql\nSTABLE\nAS $$\n  SELECT value FROM public.system_settings WHERE key = 'model_config_global';\n$$","GRANT ALL ON TABLE public.system_settings TO anon","GRANT ALL ON TABLE public.system_settings TO authenticated","GRANT ALL ON TABLE public.system_settings TO service_role","GRANT EXECUTE ON FUNCTION public.get_global_model_config() TO anon","GRANT EXECUTE ON FUNCTION public.get_global_model_config() TO authenticated","GRANT EXECUTE ON FUNCTION public.get_global_model_config() TO service_role"}	add_system_settings_global_model_config
20250913000000	{"-- Fix Claude 4 model names to match Anthropic API\n-- Migration to update database model names to correct Anthropic API model names\n\n-- Update Claude 4 Opus model name to Opus 4.1\nUPDATE public.llm_models\nSET model_name = 'claude-opus-4-1-20250805',\n    display_name = 'Claude Opus 4.1'\nWHERE model_name = 'claude-4-opus' AND provider_name = 'anthropic'","-- Update Claude 4 Sonnet model name\nUPDATE public.llm_models\nSET model_name = 'claude-sonnet-4-20250514',\n    display_name = 'Claude Sonnet 4'\nWHERE model_name = 'claude-4-sonnet' AND provider_name = 'anthropic'","-- Verify the updates\n-- SELECT model_name, provider_name, display_name FROM public.llm_models \n-- WHERE provider_name = 'anthropic' AND model_name LIKE '%4%'"}	fix_claude4_model_names
20250914000000	{"-- Migration: Ensure llm_usage has metrics and PII columns\n-- Date: 2025-09-14\n-- Purpose: Backfill schema in environments missing newer columns used by RunMetadataService\n\n-- Tokens and timing\nALTER TABLE IF EXISTS public.llm_usage\n  ADD COLUMN IF NOT EXISTS input_tokens integer,\n  ADD COLUMN IF NOT EXISTS output_tokens integer,\n  ADD COLUMN IF NOT EXISTS duration_ms integer","-- Cost fields (some environments may already have input/output_cost)\nALTER TABLE IF EXISTS public.llm_usage\n  ADD COLUMN IF NOT EXISTS input_cost numeric,\n  ADD COLUMN IF NOT EXISTS output_cost numeric,\n  ADD COLUMN IF NOT EXISTS total_cost numeric","-- Sanitization and PII fields\nALTER TABLE IF EXISTS public.llm_usage\n  ADD COLUMN IF NOT EXISTS data_sanitization_applied boolean DEFAULT false,\n  ADD COLUMN IF NOT EXISTS sanitization_level text DEFAULT 'none',\n  ADD COLUMN IF NOT EXISTS pii_detected boolean DEFAULT false,\n  ADD COLUMN IF NOT EXISTS pii_types jsonb DEFAULT '[]'::jsonb,\n  ADD COLUMN IF NOT EXISTS pseudonyms_used integer DEFAULT 0,\n  ADD COLUMN IF NOT EXISTS pseudonym_types jsonb DEFAULT '[]'::jsonb,\n  ADD COLUMN IF NOT EXISTS redactions_applied integer DEFAULT 0,\n  ADD COLUMN IF NOT EXISTS redaction_types jsonb DEFAULT '[]'::jsonb","-- Optional helpful index to quickly retrieve a specific run\nDO $$\nBEGIN\n  IF NOT EXISTS (\n    SELECT 1 FROM pg_indexes \n    WHERE schemaname = 'public' \n      AND indexname = 'idx_llm_usage_run_id'\n  ) THEN\n    CREATE INDEX idx_llm_usage_run_id ON public.llm_usage(run_id);\n  END IF;\nEND $$"}	update_llm_usage_metrics
20250914000100	{"-- Migration: Create llm_usage_analytics view used by Admin analytics\n-- Date: 2025-09-14\n\n-- Recreate the analytics view to avoid dependency errors\nDROP VIEW IF EXISTS public.llm_usage_analytics","CREATE VIEW public.llm_usage_analytics AS\nSELECT\n  date_trunc('day', started_at)::date AS date,\n  COALESCE(caller_type, 'unknown') AS caller_type,\n  COUNT(*) AS total_requests,\n  SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS successful_requests,\n  -- Prefer persisted total_cost; if null, compute from input/output\n  COALESCE(SUM(total_cost), SUM(COALESCE(input_cost, 0) + COALESCE(output_cost, 0))) AS total_cost,\n  -- Average duration in ms across rows for this day/type\n  AVG(COALESCE(duration_ms, 0))::numeric AS avg_duration_ms,\n  -- Local vs external split\n  SUM(CASE WHEN is_local IS TRUE THEN 1 ELSE 0 END) AS local_requests,\n  SUM(CASE WHEN is_local IS NOT TRUE THEN 1 ELSE 0 END) AS external_requests\nFROM public.llm_usage\nGROUP BY 1, 2\nORDER BY 1 DESC, 2 ASC","-- Optional: grant select\nGRANT SELECT ON public.llm_usage_analytics TO anon, authenticated, service_role"}	create_llm_usage_analytics_view
20250914000200	{"-- Migration: Enforce uniqueness and presence of run_id in llm_usage\n-- Date: 2025-09-14\n\n-- Ensure run_id is not null\nALTER TABLE IF EXISTS public.llm_usage\n  ALTER COLUMN run_id SET NOT NULL","-- Create unique index on run_id to guarantee single update target per run\nDO $$\nBEGIN\n  IF NOT EXISTS (\n    SELECT 1 FROM pg_indexes\n    WHERE schemaname = 'public' AND indexname = 'llm_usage_run_id_unique'\n  ) THEN\n    CREATE UNIQUE INDEX llm_usage_run_id_unique ON public.llm_usage(run_id);\n  END IF;\nEND $$"}	enforce_llm_usage_run_id_unique
20250915001000	{"-- Migration: Add pseudonym_mappings JSONB column to llm_usage\n-- Purpose: Store actual pseudonym mappings (original, pseudonym, type) per run\n\nALTER TABLE IF EXISTS public.llm_usage\n  ADD COLUMN IF NOT EXISTS pseudonym_mappings jsonb DEFAULT '[]'::jsonb","-- Optional: comment for clarity\nCOMMENT ON COLUMN public.llm_usage.pseudonym_mappings IS 'Array of {original, pseudonym, dataType} objects for this run'"}	add_pseudonym_mappings_to_llm_usage
202510010001	{"-- Migration: Create assets table for stored files (images, etc.)\n-- Created: 2025-10-01\n\nBEGIN","CREATE TABLE IF NOT EXISTS public.assets (\n  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),\n  storage text NOT NULL CHECK (storage IN ('local','supabase')),\n  path text NULL,             -- local filesystem path (relative to IMAGE_STORAGE_DIR)\n  bucket text NULL,           -- supabase storage bucket name\n  object_key text NULL,       -- supabase object key\n  mime text NOT NULL,\n  size bigint NULL,\n  width integer NULL,\n  height integer NULL,\n  hash text NULL,\n  user_id uuid NULL,\n  conversation_id uuid NULL,\n  deliverable_version_id uuid NULL REFERENCES public.deliverable_versions(id) ON DELETE SET NULL,\n  created_at timestamptz NOT NULL DEFAULT now(),\n  updated_at timestamptz NOT NULL DEFAULT now()\n)","CREATE INDEX IF NOT EXISTS assets_conversation_idx ON public.assets (conversation_id)","CREATE INDEX IF NOT EXISTS assets_version_idx ON public.assets (deliverable_version_id)","-- ensure updated_at auto-updates on change\nCREATE OR REPLACE FUNCTION public.set_timestamp_updated_at()\nRETURNS TRIGGER AS $$\nBEGIN\n  NEW.updated_at = now();\n  RETURN NEW;\nEND;\n$$ LANGUAGE plpgsql","DROP TRIGGER IF EXISTS set_timestamp_updated_at_assets ON public.assets","CREATE TRIGGER set_timestamp_updated_at_assets\nBEFORE UPDATE ON public.assets\nFOR EACH ROW EXECUTE FUNCTION public.set_timestamp_updated_at()",COMMIT}	assets
202510010002	{"-- Migration: Extend assets for external references\n-- Created: 2025-10-01\n\nBEGIN","-- Allow 'external' storage type\nALTER TABLE public.assets DROP CONSTRAINT IF EXISTS assets_storage_check","ALTER TABLE public.assets ADD CONSTRAINT assets_storage_check CHECK (storage IN ('local','supabase','external'))","-- Add source_url to store original external URLs\nALTER TABLE public.assets ADD COLUMN IF NOT EXISTS source_url text",COMMIT}	assets_external
202510010004	{"-- Seed OpenAI and Google image function agents under my-org\nBEGIN","DO $$\nDECLARE\n  rec RECORD;\n  payload jsonb;\nBEGIN\n  -- Seed OpenAI image generator\n  SELECT * INTO rec FROM public.agents WHERE organization_slug = 'my-org' AND slug = 'image_openai_generator' LIMIT 1;\n  IF NOT FOUND THEN\n    payload := jsonb_build_object(\n      'metadata', jsonb_build_object(\n        'type','function',\n        'category','image',\n        'displayName','OpenAI Image Generator',\n        'description','Generates images via OpenAI provider'\n      ),\n      'hierarchy', jsonb_build_object(\n        'reports_to','image_orchestrator',\n        'department','images'\n      ),\n      'capabilities', jsonb_build_array('image_generation'),\n      'input_modes', jsonb_build_array('text/plain'),\n      'output_modes', jsonb_build_array('image/png','image/jpeg','application/json'),\n      'configuration', jsonb_build_object(\n        'execution_profile','full_cycle',\n        'execution_capabilities', jsonb_build_object('can_plan', false, 'can_build', true, 'requires_human_gate', false),\n        'function', jsonb_build_object(\n          'language','js',\n          'version','1',\n          'timeout_ms',20000,\n          'code',\n          $CODE$async function handler(input, ctx) {\n  const { prompt, size = '512x512', n = 1, deliverableId = null } = input || {};\n  const out = await ctx.services.images.generate({ prompt, size, n, title: 'OpenAI Images', provider: 'openai', deliverableId });\n  return out;\n}$CODE$\n        )\n      )\n    );\n    INSERT INTO public.agents (\n      organization_slug, slug, display_name, description, agent_type, mode_profile, version, status, yaml, agent_card, context, config\n    ) VALUES (\n      'my-org',\n      'image_openai_generator',\n      'OpenAI Image Generator',\n      'Generates images via OpenAI function handler',\n      'function',\n      'full_cycle',\n      '1.0.0',\n      'active',\n      payload::text,\n      NULL,\n      '{}',\n      (payload - 'metadata')\n    );\n  END IF;\n\n  -- Seed Google image generator (Gemini/Imagen)\n  SELECT * INTO rec FROM public.agents WHERE organization_slug = 'my-org' AND slug = 'image_google_generator' LIMIT 1;\n  IF NOT FOUND THEN\n    payload := jsonb_build_object(\n      'metadata', jsonb_build_object(\n        'type','function',\n        'category','image',\n        'displayName','Google Image Generator',\n        'description','Generates images via Google (Gemini/Imagen) provider'\n      ),\n      'hierarchy', jsonb_build_object(\n        'reports_to','image_orchestrator',\n        'department','images'\n      ),\n      'capabilities', jsonb_build_array('image_generation'),\n      'input_modes', jsonb_build_array('text/plain'),\n      'output_modes', jsonb_build_array('image/png','image/jpeg','application/json'),\n      'configuration', jsonb_build_object(\n        'execution_profile','full_cycle',\n        'execution_capabilities', jsonb_build_object('can_plan', false, 'can_build', true, 'requires_human_gate', false),\n        'function', jsonb_build_object(\n          'language','js',\n          'version','1',\n          'timeout_ms',20000,\n          'code',\n          $CODE$async function handler(input, ctx) {\n  const { prompt, size = '512x512', n = 1, deliverableId = null } = input || {};\n  const out = await ctx.services.images.generate({ prompt, size, n, title: 'Google Images', provider: 'gemini', deliverableId });\n  return out;\n}$CODE$\n        )\n      )\n    );\n    INSERT INTO public.agents (\n      organization_slug, slug, display_name, description, agent_type, mode_profile, version, status, yaml, agent_card, context, config\n    ) VALUES (\n      'my-org',\n      'image_google_generator',\n      'Google Image Generator',\n      'Generates images via Google (Gemini/Imagen) function handler',\n      'function',\n      'full_cycle',\n      '1.0.0',\n      'active',\n      payload::text,\n      NULL,\n      '{}',\n      (payload - 'metadata')\n    );\n  END IF;\nEND$$",COMMIT}	seed_image_function_agent
202510010006	{"-- Seed Image Orchestrator function agent under my-org\nBEGIN","DO $$\nDECLARE\n  rec RECORD;\n  payload jsonb;\nBEGIN\n  SELECT * INTO rec FROM public.agents WHERE organization_slug = 'my-org' AND slug = 'image_orchestrator' LIMIT 1;\n  IF NOT FOUND THEN\n    payload := jsonb_build_object(\n      'metadata', jsonb_build_object(\n        'type','function',\n        'category','image',\n        'displayName','Image Orchestrator',\n        'description','Fans out image generation across multiple providers'\n      ),\n      'hierarchy', jsonb_build_object(\n        'department','images',\n        'team', jsonb_build_array('image_openai_generator','image_google_generator')\n      ),\n      'capabilities', jsonb_build_array('image_generation'),\n      'input_modes', jsonb_build_array('text/plain'),\n      'output_modes', jsonb_build_array('image/png','image/jpeg','application/json'),\n      'configuration', jsonb_build_object(\n        'execution_profile','full_cycle',\n        'execution_capabilities', jsonb_build_object('can_plan', false, 'can_build', true, 'requires_human_gate', false),\n        'function', jsonb_build_object(\n          'language','js',\n          'version','1',\n          'timeout_ms',20000,\n          'code',\n          $CODE$async function handler(input, ctx) {\n  const { prompt, size = '512x512', n = 1, providers = ['openai','gemini'], deliverableId = null } = input || {};\n  let last = null;\n  for (const p of providers) {\n    last = await ctx.services.images.generate({ prompt, size, n, title: 'Image Orchestrator', provider: p, deliverableId });\n  }\n  return last;\n}$CODE$\n        )\n      )\n    );\n\n    INSERT INTO public.agents (\n      organization_slug, slug, display_name, description, agent_type, mode_profile, version, status, yaml, agent_card, context, config\n    ) VALUES (\n      'my-org',\n      'image_orchestrator',\n      'Image Orchestrator',\n      'Fan-out image generation to multiple providers',\n      'function',\n      'full_cycle',\n      '1.0.0',\n      'active',\n      payload::text,\n      NULL,\n      '{}',\n      (payload - 'metadata')\n    );\n  END IF;\nEND$$",COMMIT}	seed_image_orchestrator_agent
202510020101	{"-- Add org/agent scoping and timestamps to pseudonym_dictionaries to match code expectations\nDO $$\nBEGIN\n  IF NOT EXISTS (\n    SELECT 1 FROM information_schema.columns \n    WHERE table_schema = 'public' AND table_name = 'pseudonym_dictionaries' AND column_name = 'organization_slug'\n  ) THEN\n    ALTER TABLE public.pseudonym_dictionaries\n      ADD COLUMN organization_slug text;\n  END IF;\n\n  IF NOT EXISTS (\n    SELECT 1 FROM information_schema.columns \n    WHERE table_schema = 'public' AND table_name = 'pseudonym_dictionaries' AND column_name = 'agent_slug'\n  ) THEN\n    ALTER TABLE public.pseudonym_dictionaries\n      ADD COLUMN agent_slug text;\n  END IF;\n\n  IF NOT EXISTS (\n    SELECT 1 FROM information_schema.columns \n    WHERE table_schema = 'public' AND table_name = 'pseudonym_dictionaries' AND column_name = 'updated_at'\n  ) THEN\n    ALTER TABLE public.pseudonym_dictionaries\n      ADD COLUMN updated_at timestamptz DEFAULT now();\n  END IF;\nEND $$","-- Helpful indexes\nCREATE INDEX IF NOT EXISTS idx_pseudonym_dictionaries_org ON public.pseudonym_dictionaries(organization_slug)","CREATE INDEX IF NOT EXISTS idx_pseudonym_dictionaries_agent ON public.pseudonym_dictionaries(agent_slug)","CREATE INDEX IF NOT EXISTS idx_pseudonym_dictionaries_updated_at ON public.pseudonym_dictionaries(updated_at)"}	pseudonym_dictionaries_org_scope
202510020102	{"-- Add function_code column to agents table\nALTER TABLE public.agents ADD COLUMN IF NOT EXISTS function_code TEXT","-- Add comment to explain the column\nCOMMENT ON COLUMN public.agents.function_code IS 'JavaScript/TypeScript function code for function-type agents'"}	add_function_code_column
202510030001	{"-- Add pseudonym_mappings column to llm_usage table for PII data tracking\n\n-- Add pseudonym_mappings column to llm_usage table if it doesn't exist\nDO $$\nBEGIN\n  IF NOT EXISTS (\n    SELECT 1 FROM information_schema.columns \n    WHERE table_schema = 'public' AND table_name = 'llm_usage' AND column_name = 'pseudonym_mappings'\n  ) THEN\n    ALTER TABLE public.llm_usage\n      ADD COLUMN pseudonym_mappings jsonb;\n  END IF;\nEND $$"}	create_pseudonym_mappings
20251005000001	{"-- Add organization_slug column to conversations table\n-- This properly identifies which organization the conversation belongs to\n-- for database agents (replaces the overloaded agent_type field)\n\nALTER TABLE public.conversations\nADD COLUMN IF NOT EXISTS organization_slug TEXT","-- Create index for efficient lookups by organization\nCREATE INDEX IF NOT EXISTS idx_conversations_organization_slug ON public.conversations(organization_slug)","-- Create index for lookups by organization + agent\nCREATE INDEX IF NOT EXISTS idx_conversations_org_agent ON public.conversations(organization_slug, agent_name)","-- Migrate existing conversations with agent_type that looks like an org slug\n-- (not 'context', 'specialist', 'demo', etc.)\nUPDATE public.conversations\nSET organization_slug = agent_type\nWHERE organization_slug IS NULL\n  AND agent_type NOT IN ('context', 'specialist', 'demo', 'orchestrator')\n  AND agent_type IS NOT NULL\n  AND agent_type != ''","-- Add comment explaining the column\nCOMMENT ON COLUMN public.conversations.organization_slug IS 'Organization slug for database agents (e.g., my-org, acme-corp). NULL for file-based agents.'"}	add_organization_slug_to_conversations
20251005000002	{"-- Add total_cost column to llm_usage table\n-- This stores the sum of input_cost + output_cost for easier querying\n\nALTER TABLE public.llm_usage\nADD COLUMN IF NOT EXISTS total_cost numeric","-- Add comment explaining the column\nCOMMENT ON COLUMN public.llm_usage.total_cost IS 'Total cost (input_cost + output_cost) for this LLM request'","-- Create index for cost analysis queries\nCREATE INDEX IF NOT EXISTS llm_usage_total_cost_idx ON public.llm_usage(total_cost) WHERE total_cost IS NOT NULL"}	add_total_cost_to_llm_usage
20251005000003	{"-- Seed blog_post_writer agent for testing strict A2A protocol\n-- This agent is used in plan-mode, build-mode, and converse-mode API tests\n\nINSERT INTO public.agents (\n  organization_slug,\n  slug,\n  display_name,\n  description,\n  agent_type,\n  mode_profile,\n  status,\n  yaml\n) VALUES (\n  'my-org',\n  'blog_post_writer',\n  'Blog Post Writer',\n  'Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.',\n  'context',\n  'plan-build-converse',\n  'active',\n  '\nname: blog_post_writer\ndisplay_name: Blog Post Writer\ndescription: Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\nagent_type: context\nmode_profile: plan-build-converse\nversion: \\"1.0\\"\nstatus: active\n\nsystem_prompt: |\n  Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\n\n  When creating a plan for a blog post, structure it with the following sections:\n\n  # Blog Post Plan\n\n  ## Title & Topic\n  - Working title\n  - Target topic/theme\n  - Angle or unique perspective\n\n  ## Audience & Purpose\n  - Target audience description\n  - Primary goal (inform, persuade, entertain, etc.)\n  - Reader takeaway\n\n  ## Content Strategy\n  - Word count target\n  - SEO keywords\n  - Key points to cover\n\n  When building a deliverable, create:\n  - Engaging introduction\n  - Clear section headings\n  - Actionable content\n  - Strong conclusion with CTA\n\n  When conversing, provide helpful suggestions for improving blog content.\n\nmodes:\n  plan:\n    enabled: true\n    actions:\n      - create\n      - read\n      - list\n      - edit\n      - set_current\n      - delete_version\n      - merge_versions\n      - copy_version\n      - delete\n\n  build:\n    enabled: true\n    actions:\n      - create\n      - read\n      - list\n      - edit\n      - rerun\n      - set_current\n      - delete_version\n      - merge_versions\n      - copy_version\n      - delete\n\n  converse:\n    enabled: true\n\nllm_defaults:\n  provider: ollama\n  model: llama3.2:1b\n  temperature: 0.7\n'\n) ON CONFLICT (organization_slug, slug) DO UPDATE SET\n  display_name = EXCLUDED.display_name,\n  description = EXCLUDED.description,\n  yaml = EXCLUDED.yaml,\n  updated_at = now()","-- Add agent_card and context\nUPDATE public.agents\nSET\n  agent_card = jsonb_build_object(\n    'system_prompt', 'Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\n\nWhen creating a plan for a blog post, structure it with the following sections:\n\n# Blog Post Plan\n\n## Title & Topic\n- Working title\n- Target topic/theme\n- Angle or unique perspective\n\n## Audience & Purpose\n- Target audience description\n- Primary goal (inform, persuade, entertain, etc.)\n- Reader takeaway\n\n## Content Strategy\n- Word count target\n- SEO keywords\n- Key points to cover\n\nWhen building a deliverable, create:\n- Engaging introduction\n- Clear section headings\n- Actionable content\n- Strong conclusion with CTA\n\nWhen conversing, provide helpful suggestions for improving blog content.'\n  ),\n  context = jsonb_build_object(\n    'plan', jsonb_build_object(\n      'template', 'Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\n\nWhen creating a plan for a blog post, structure it with the following sections:\n\n# Blog Post Plan\n\n## Title & Topic\n- Working title\n- Target topic/theme\n- Angle or unique perspective\n\n## Audience & Purpose\n- Target audience description\n- Primary goal (inform, persuade, entertain, etc.)\n- Reader takeaway\n\n## Content Strategy\n- Word count target\n- SEO keywords\n- Key points to cover\n\nWhen building a deliverable, create:\n- Engaging introduction\n- Clear section headings\n- Actionable content\n- Strong conclusion with CTA\n\nWhen conversing, provide helpful suggestions for improving blog content.'\n    ),\n    'build', jsonb_build_object(\n      'template', 'Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\n\nWhen creating a plan for a blog post, structure it with the following sections:\n\n# Blog Post Plan\n\n## Title & Topic\n- Working title\n- Target topic/theme\n- Angle or unique perspective\n\n## Audience & Purpose\n- Target audience description\n- Primary goal (inform, persuade, entertain, etc.)\n- Reader takeaway\n\n## Content Strategy\n- Word count target\n- SEO keywords\n- Key points to cover\n\nWhen building a deliverable, create:\n- Engaging introduction\n- Clear section headings\n- Actionable content\n- Strong conclusion with CTA\n\nWhen conversing, provide helpful suggestions for improving blog content.'\n    ),\n    'converse', jsonb_build_object(\n      'template', 'Creates SEO-friendly blog posts in Markdown format with clear structure and helpful tone. Supports full mode × action architecture with plans and deliverables.\n\nWhen creating a plan for a blog post, structure it with the following sections:\n\n# Blog Post Plan\n\n## Title & Topic\n- Working title\n- Target topic/theme\n- Angle or unique perspective\n\n## Audience & Purpose\n- Target audience description\n- Primary goal (inform, persuade, entertain, etc.)\n- Reader takeaway\n\n## Content Strategy\n- Word count target\n- SEO keywords\n- Key points to cover\n\nWhen building a deliverable, create:\n- Engaging introduction\n- Clear section headings\n- Actionable content\n- Strong conclusion with CTA\n\nWhen conversing, provide helpful suggestions for improving blog content.'\n    )\n  ),\n  config = jsonb_build_object(\n    'llm_defaults', jsonb_build_object(\n      'provider', 'ollama',\n      'model', 'llama3.2:1b',\n      'temperature', 0.7\n    )\n  )\nWHERE slug = 'blog_post_writer' AND organization_slug = 'my-org'"}	seed_blog_post_writer_agent
202510060001	{"-- Update conversations_with_stats view to include organization_slug\n-- Because CREATE OR REPLACE VIEW cannot change the column list/order,\n-- we drop and recreate the view, then re-grant permissions.\n\n-- Ensure required columns exist on conversations\nALTER TABLE public.conversations\n  ADD COLUMN IF NOT EXISTS ended_at timestamptz,\n  ADD COLUMN IF NOT EXISTS started_at timestamptz,\n  ADD COLUMN IF NOT EXISTS last_active_at timestamptz,\n  ADD COLUMN IF NOT EXISTS metadata jsonb DEFAULT '{}'::jsonb,\n  ADD COLUMN IF NOT EXISTS organization_slug text","DROP VIEW IF EXISTS public.conversations_with_stats","CREATE VIEW public.conversations_with_stats AS\nSELECT\n  c.id,\n  c.user_id,\n  c.agent_name,\n  c.agent_type,\n  c.ended_at,\n  c.started_at,\n  c.last_active_at,\n  c.metadata,\n  c.created_at,\n  c.updated_at,\n  COALESCE(task_stats.task_count, 0)::bigint AS task_count,\n  COALESCE(task_stats.completed_tasks, 0)::bigint AS completed_tasks,\n  COALESCE(task_stats.failed_tasks, 0)::bigint AS failed_tasks,\n  COALESCE(task_stats.active_tasks, 0)::bigint AS active_tasks,\n  c.organization_slug\nFROM public.conversations c\nLEFT JOIN (\n  SELECT\n    t.conversation_id,\n    COUNT(*) AS task_count,\n    COUNT(CASE WHEN t.status::text = 'completed' THEN 1 END) AS completed_tasks,\n    COUNT(CASE WHEN t.status::text = 'failed' THEN 1 END) AS failed_tasks,\n    COUNT(CASE WHEN t.status::text IN ('pending','running') THEN 1 END) AS active_tasks\n  FROM public.tasks t\n  GROUP BY t.conversation_id\n) task_stats ON c.id = task_stats.conversation_id","-- Re-grant permissions (Supabase roles)\nGRANT SELECT ON public.conversations_with_stats TO anon","GRANT SELECT ON public.conversations_with_stats TO authenticated","GRANT SELECT ON public.conversations_with_stats TO service_role"}	update_conversations_with_stats_add_org_slug
\.


--
-- TOC entry 3759 (class 0 OID 16658)
-- Dependencies: 248
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4941 (class 0 OID 0)
-- Dependencies: 238
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 1, false);


--
-- TOC entry 4942 (class 0 OID 0)
-- Dependencies: 264
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_admin
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- TOC entry 4943 (class 0 OID 0)
-- Dependencies: 257
-- Name: hooks_id_seq; Type: SEQUENCE SET; Schema: supabase_functions; Owner: supabase_functions_admin
--

SELECT pg_catalog.setval('supabase_functions.hooks_id_seq', 1, false);


--
-- TOC entry 4109 (class 2606 OID 17405)
-- Name: extensions extensions_pkey; Type: CONSTRAINT; Schema: _realtime; Owner: supabase_admin
--

ALTER TABLE ONLY _realtime.extensions
    ADD CONSTRAINT extensions_pkey PRIMARY KEY (id);


--
-- TOC entry 4104 (class 2606 OID 17389)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: _realtime; Owner: supabase_admin
--

ALTER TABLE ONLY _realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4107 (class 2606 OID 17397)
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: _realtime; Owner: supabase_admin
--

ALTER TABLE ONLY _realtime.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- TOC entry 4169 (class 2606 OID 18055)
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- TOC entry 4075 (class 2606 OID 16494)
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- TOC entry 4192 (class 2606 OID 18161)
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- TOC entry 4148 (class 2606 OID 18179)
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- TOC entry 4150 (class 2606 OID 18189)
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- TOC entry 4073 (class 2606 OID 16487)
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- TOC entry 4171 (class 2606 OID 18048)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- TOC entry 4167 (class 2606 OID 18036)
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- TOC entry 4159 (class 2606 OID 18229)
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- TOC entry 4161 (class 2606 OID 18023)
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- TOC entry 4196 (class 2606 OID 18214)
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 4067 (class 2606 OID 16477)
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 4070 (class 2606 OID 17966)
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- TOC entry 4181 (class 2606 OID 18095)
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- TOC entry 4183 (class 2606 OID 18093)
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 4188 (class 2606 OID 18109)
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- TOC entry 4078 (class 2606 OID 16500)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4154 (class 2606 OID 17987)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 4178 (class 2606 OID 18076)
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- TOC entry 4173 (class 2606 OID 18067)
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 4060 (class 2606 OID 18149)
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- TOC entry 4062 (class 2606 OID 16464)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4205 (class 2606 OID 18595)
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: company; Owner: postgres
--

ALTER TABLE ONLY company.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- TOC entry 4219 (class 2606 OID 18601)
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: company; Owner: postgres
--

ALTER TABLE ONLY company.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- TOC entry 4221 (class 2606 OID 18603)
-- Name: kpi_data kpi_data_pkey; Type: CONSTRAINT; Schema: company; Owner: postgres
--

ALTER TABLE ONLY company.kpi_data
    ADD CONSTRAINT kpi_data_pkey PRIMARY KEY (id);


--
-- TOC entry 4223 (class 2606 OID 18605)
-- Name: kpi_goals kpi_goals_pkey; Type: CONSTRAINT; Schema: company; Owner: postgres
--

ALTER TABLE ONLY company.kpi_goals
    ADD CONSTRAINT kpi_goals_pkey PRIMARY KEY (id);


--
-- TOC entry 4225 (class 2606 OID 18607)
-- Name: kpi_metrics kpi_metrics_pkey; Type: CONSTRAINT; Schema: company; Owner: postgres
--

ALTER TABLE ONLY company.kpi_metrics
    ADD CONSTRAINT kpi_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 4207 (class 2606 OID 18579)
-- Name: conversations agent_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT agent_conversations_pkey PRIMARY KEY (id);


--
-- TOC entry 4290 (class 2606 OID 18945)
-- Name: agent_orchestrations agent_orchestrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_orchestrations
    ADD CONSTRAINT agent_orchestrations_pkey PRIMARY KEY (id);


--
-- TOC entry 4292 (class 2606 OID 18947)
-- Name: agent_orchestrations agent_orchestrations_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_orchestrations
    ADD CONSTRAINT agent_orchestrations_slug_unique UNIQUE (organization_slug, agent_slug, slug);


--
-- TOC entry 4279 (class 2606 OID 18900)
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- TOC entry 4281 (class 2606 OID 18902)
-- Name: agents agents_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_slug_unique UNIQUE (organization_slug, slug);


--
-- TOC entry 4320 (class 2606 OID 19077)
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- TOC entry 4203 (class 2606 OID 18593)
-- Name: cidafm_commands cidafm_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cidafm_commands
    ADD CONSTRAINT cidafm_commands_pkey PRIMARY KEY (id);


--
-- TOC entry 4215 (class 2606 OID 18597)
-- Name: deliverable_versions deliverable_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverable_versions
    ADD CONSTRAINT deliverable_versions_pkey PRIMARY KEY (id);


--
-- TOC entry 4217 (class 2606 OID 18599)
-- Name: deliverables deliverables_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverables
    ADD CONSTRAINT deliverables_pkey PRIMARY KEY (id);


--
-- TOC entry 4300 (class 2606 OID 18995)
-- Name: human_approvals human_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.human_approvals
    ADD CONSTRAINT human_approvals_pkey PRIMARY KEY (id);


--
-- TOC entry 4277 (class 2606 OID 18854)
-- Name: jokes_agent jokes_agent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jokes_agent
    ADD CONSTRAINT jokes_agent_pkey PRIMARY KEY (id);


--
-- TOC entry 4227 (class 2606 OID 18609)
-- Name: llm_models llm_models_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_pkey PRIMARY KEY (provider_name, model_name);


--
-- TOC entry 4229 (class 2606 OID 18611)
-- Name: llm_providers llm_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_providers
    ADD CONSTRAINT llm_providers_pkey PRIMARY KEY (name);


--
-- TOC entry 4233 (class 2606 OID 18613)
-- Name: llm_usage llm_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_usage
    ADD CONSTRAINT llm_usage_pkey PRIMARY KEY (id);


--
-- TOC entry 4237 (class 2606 OID 18615)
-- Name: llm_usage llm_usage_run_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_usage
    ADD CONSTRAINT llm_usage_run_id_key UNIQUE (run_id);


--
-- TOC entry 4317 (class 2606 OID 19051)
-- Name: orchestration_checkpoints orchestration_checkpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orchestration_checkpoints
    ADD CONSTRAINT orchestration_checkpoints_pkey PRIMARY KEY (id);


--
-- TOC entry 4297 (class 2606 OID 18962)
-- Name: orchestration_runs orchestration_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orchestration_runs
    ADD CONSTRAINT orchestration_runs_pkey PRIMARY KEY (id);


--
-- TOC entry 4311 (class 2606 OID 19032)
-- Name: orchestration_steps orchestration_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orchestration_steps
    ADD CONSTRAINT orchestration_steps_pkey PRIMARY KEY (id);


--
-- TOC entry 4313 (class 2606 OID 19034)
-- Name: orchestration_steps orchestration_steps_unique_per_run; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orchestration_steps
    ADD CONSTRAINT orchestration_steps_unique_per_run UNIQUE (orchestration_run_id, step_index);


--
-- TOC entry 4286 (class 2606 OID 18915)
-- Name: organization_credentials organization_credentials_alias_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_credentials
    ADD CONSTRAINT organization_credentials_alias_unique UNIQUE (organization_slug, alias);


--
-- TOC entry 4288 (class 2606 OID 18913)
-- Name: organization_credentials organization_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_credentials
    ADD CONSTRAINT organization_credentials_pkey PRIMARY KEY (id);


--
-- TOC entry 4332 (class 2606 OID 19126)
-- Name: plan_versions plan_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_versions
    ADD CONSTRAINT plan_versions_pkey PRIMARY KEY (id);


--
-- TOC entry 4325 (class 2606 OID 19100)
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- TOC entry 4244 (class 2606 OID 18617)
-- Name: project_steps project_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_steps
    ADD CONSTRAINT project_steps_pkey PRIMARY KEY (id);


--
-- TOC entry 4251 (class 2606 OID 18619)
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- TOC entry 4257 (class 2606 OID 18621)
-- Name: pseudonym_dictionaries pseudonym_dictionaries_original_value_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pseudonym_dictionaries
    ADD CONSTRAINT pseudonym_dictionaries_original_value_key UNIQUE (original_value);


--
-- TOC entry 4259 (class 2606 OID 18623)
-- Name: pseudonym_dictionaries pseudonym_dictionaries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pseudonym_dictionaries
    ADD CONSTRAINT pseudonym_dictionaries_pkey PRIMARY KEY (id);


--
-- TOC entry 4262 (class 2606 OID 18625)
-- Name: redaction_patterns redaction_patterns_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redaction_patterns
    ADD CONSTRAINT redaction_patterns_name_key UNIQUE (name);


--
-- TOC entry 4264 (class 2606 OID 18627)
-- Name: redaction_patterns redaction_patterns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redaction_patterns
    ADD CONSTRAINT redaction_patterns_pkey PRIMARY KEY (id);


--
-- TOC entry 4266 (class 2606 OID 18629)
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- TOC entry 4307 (class 2606 OID 19011)
-- Name: task_messages task_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_messages
    ADD CONSTRAINT task_messages_pkey PRIMARY KEY (id);


--
-- TOC entry 4213 (class 2606 OID 18631)
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- TOC entry 4327 (class 2606 OID 19102)
-- Name: plans unique_conversation_plan; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT unique_conversation_plan UNIQUE (conversation_id);


--
-- TOC entry 4334 (class 2606 OID 19128)
-- Name: plan_versions unique_plan_version; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_versions
    ADD CONSTRAINT unique_plan_version UNIQUE (plan_id, version_number);


--
-- TOC entry 4268 (class 2606 OID 18639)
-- Name: user_cidafm_commands user_cidafm_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_cidafm_commands
    ADD CONSTRAINT user_cidafm_commands_pkey PRIMARY KEY (id);


--
-- TOC entry 4271 (class 2606 OID 18641)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 4273 (class 2606 OID 18643)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4119 (class 2606 OID 17699)
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4121 (class 2606 OID 17709)
-- Name: messages_2025_10_10 messages_2025_10_10_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_10_10
    ADD CONSTRAINT messages_2025_10_10_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4123 (class 2606 OID 17720)
-- Name: messages_2025_10_11 messages_2025_10_11_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_10_11
    ADD CONSTRAINT messages_2025_10_11_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4125 (class 2606 OID 17731)
-- Name: messages_2025_10_12 messages_2025_10_12_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_10_12
    ADD CONSTRAINT messages_2025_10_12_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4127 (class 2606 OID 17742)
-- Name: messages_2025_10_13 messages_2025_10_13_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_10_13
    ADD CONSTRAINT messages_2025_10_13_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4129 (class 2606 OID 17753)
-- Name: messages_2025_10_14 messages_2025_10_14_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_10_14
    ADD CONSTRAINT messages_2025_10_14_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4116 (class 2606 OID 17553)
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- TOC entry 4113 (class 2606 OID 17526)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4139 (class 2606 OID 17896)
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- TOC entry 4081 (class 2606 OID 16517)
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- TOC entry 4141 (class 2606 OID 17906)
-- Name: iceberg_namespaces iceberg_namespaces_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.iceberg_namespaces
    ADD CONSTRAINT iceberg_namespaces_pkey PRIMARY KEY (id);


--
-- TOC entry 4144 (class 2606 OID 17922)
-- Name: iceberg_tables iceberg_tables_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_pkey PRIMARY KEY (id);


--
-- TOC entry 4091 (class 2606 OID 16558)
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- TOC entry 4093 (class 2606 OID 16556)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 4089 (class 2606 OID 16534)
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- TOC entry 4137 (class 2606 OID 17850)
-- Name: prefixes prefixes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT prefixes_pkey PRIMARY KEY (bucket_id, level, name);


--
-- TOC entry 4134 (class 2606 OID 17811)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- TOC entry 4132 (class 2606 OID 17796)
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- TOC entry 4100 (class 2606 OID 16771)
-- Name: hooks hooks_pkey; Type: CONSTRAINT; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER TABLE ONLY supabase_functions.hooks
    ADD CONSTRAINT hooks_pkey PRIMARY KEY (id);


--
-- TOC entry 4098 (class 2606 OID 16761)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER TABLE ONLY supabase_functions.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4201 (class 2606 OID 18238)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: supabase_migrations; Owner: postgres
--

ALTER TABLE ONLY supabase_migrations.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4110 (class 1259 OID 17450)
-- Name: extensions_tenant_external_id_index; Type: INDEX; Schema: _realtime; Owner: supabase_admin
--

CREATE INDEX extensions_tenant_external_id_index ON _realtime.extensions USING btree (tenant_external_id);


--
-- TOC entry 4111 (class 1259 OID 17433)
-- Name: extensions_tenant_external_id_type_index; Type: INDEX; Schema: _realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX extensions_tenant_external_id_type_index ON _realtime.extensions USING btree (tenant_external_id, type);


--
-- TOC entry 4105 (class 1259 OID 17426)
-- Name: tenants_external_id_index; Type: INDEX; Schema: _realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX tenants_external_id_index ON _realtime.tenants USING btree (external_id);


--
-- TOC entry 4076 (class 1259 OID 16495)
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- TOC entry 4050 (class 1259 OID 17976)
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4051 (class 1259 OID 17978)
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4052 (class 1259 OID 17979)
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4157 (class 1259 OID 18057)
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- TOC entry 4190 (class 1259 OID 18165)
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- TOC entry 4146 (class 1259 OID 18145)
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- TOC entry 4944 (class 0 OID 0)
-- Dependencies: 4146
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- TOC entry 4151 (class 1259 OID 17973)
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- TOC entry 4193 (class 1259 OID 18162)
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- TOC entry 4194 (class 1259 OID 18163)
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- TOC entry 4165 (class 1259 OID 18168)
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- TOC entry 4162 (class 1259 OID 18029)
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- TOC entry 4163 (class 1259 OID 18174)
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- TOC entry 4197 (class 1259 OID 18221)
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- TOC entry 4198 (class 1259 OID 18220)
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- TOC entry 4199 (class 1259 OID 18222)
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- TOC entry 4053 (class 1259 OID 17980)
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4054 (class 1259 OID 17977)
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4063 (class 1259 OID 16478)
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- TOC entry 4064 (class 1259 OID 16479)
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- TOC entry 4065 (class 1259 OID 17972)
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- TOC entry 4068 (class 1259 OID 18059)
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- TOC entry 4071 (class 1259 OID 18164)
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- TOC entry 4184 (class 1259 OID 18101)
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- TOC entry 4185 (class 1259 OID 18166)
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- TOC entry 4186 (class 1259 OID 18116)
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- TOC entry 4189 (class 1259 OID 18115)
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- TOC entry 4152 (class 1259 OID 18167)
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- TOC entry 4155 (class 1259 OID 18058)
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- TOC entry 4176 (class 1259 OID 18083)
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- TOC entry 4179 (class 1259 OID 18082)
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- TOC entry 4174 (class 1259 OID 18068)
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- TOC entry 4175 (class 1259 OID 18230)
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- TOC entry 4164 (class 1259 OID 18227)
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- TOC entry 4156 (class 1259 OID 18056)
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- TOC entry 4055 (class 1259 OID 18136)
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- TOC entry 4945 (class 0 OID 0)
-- Dependencies: 4055
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- TOC entry 4056 (class 1259 OID 17974)
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- TOC entry 4057 (class 1259 OID 16468)
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- TOC entry 4058 (class 1259 OID 18191)
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- TOC entry 4318 (class 1259 OID 19083)
-- Name: assets_conversation_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX assets_conversation_idx ON public.assets USING btree (conversation_id);


--
-- TOC entry 4321 (class 1259 OID 19084)
-- Name: assets_version_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX assets_version_idx ON public.assets USING btree (deliverable_version_id);


--
-- TOC entry 4298 (class 1259 OID 18996)
-- Name: human_approvals_conversation_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX human_approvals_conversation_idx ON public.human_approvals USING btree (conversation_id);


--
-- TOC entry 4301 (class 1259 OID 18997)
-- Name: human_approvals_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX human_approvals_status_idx ON public.human_approvals USING btree (status);


--
-- TOC entry 4208 (class 1259 OID 18649)
-- Name: idx_agent_conversations_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_conversations_user_id ON public.conversations USING btree (user_id);


--
-- TOC entry 4293 (class 1259 OID 18971)
-- Name: idx_agent_orchestrations_agent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_orchestrations_agent ON public.agent_orchestrations USING btree (agent_slug);


--
-- TOC entry 4294 (class 1259 OID 18972)
-- Name: idx_agent_orchestrations_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_orchestrations_org ON public.agent_orchestrations USING btree (organization_slug);


--
-- TOC entry 4282 (class 1259 OID 18968)
-- Name: idx_agents_org_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_org_slug ON public.agents USING btree (organization_slug);


--
-- TOC entry 4283 (class 1259 OID 18969)
-- Name: idx_agents_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_slug ON public.agents USING btree (slug);


--
-- TOC entry 4209 (class 1259 OID 19156)
-- Name: idx_conversations_org_agent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_conversations_org_agent ON public.conversations USING btree (organization_slug, agent_name);


--
-- TOC entry 4210 (class 1259 OID 19155)
-- Name: idx_conversations_organization_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_conversations_organization_slug ON public.conversations USING btree (organization_slug);


--
-- TOC entry 4274 (class 1259 OID 18856)
-- Name: idx_jokes_agent_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_jokes_agent_created_at ON public.jokes_agent USING btree (created_at);


--
-- TOC entry 4275 (class 1259 OID 18855)
-- Name: idx_jokes_agent_session_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_jokes_agent_session_id ON public.jokes_agent USING btree (session_id);


--
-- TOC entry 4230 (class 1259 OID 18670)
-- Name: idx_llm_usage_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_llm_usage_created_at ON public.llm_usage USING btree (created_at);


--
-- TOC entry 4231 (class 1259 OID 19059)
-- Name: idx_llm_usage_run_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_llm_usage_run_id ON public.llm_usage USING btree (run_id);


--
-- TOC entry 4314 (class 1259 OID 19058)
-- Name: idx_orchestration_checkpoints_label; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestration_checkpoints_label ON public.orchestration_checkpoints USING btree (label);


--
-- TOC entry 4315 (class 1259 OID 19057)
-- Name: idx_orchestration_checkpoints_run; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestration_checkpoints_run ON public.orchestration_checkpoints USING btree (orchestration_run_id, created_at DESC);


--
-- TOC entry 4295 (class 1259 OID 18973)
-- Name: idx_orchestration_runs_plan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestration_runs_plan ON public.orchestration_runs USING btree (plan_id);


--
-- TOC entry 4308 (class 1259 OID 19040)
-- Name: idx_orchestration_steps_run; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestration_steps_run ON public.orchestration_steps USING btree (orchestration_run_id);


--
-- TOC entry 4309 (class 1259 OID 19041)
-- Name: idx_orchestration_steps_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestration_steps_status ON public.orchestration_steps USING btree (status);


--
-- TOC entry 4284 (class 1259 OID 18974)
-- Name: idx_org_credentials_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_org_credentials_org ON public.organization_credentials USING btree (organization_slug);


--
-- TOC entry 4328 (class 1259 OID 19142)
-- Name: idx_plan_versions_is_current; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_plan_versions_is_current ON public.plan_versions USING btree (is_current_version) WHERE (is_current_version = true);


--
-- TOC entry 4329 (class 1259 OID 19141)
-- Name: idx_plan_versions_plan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_plan_versions_plan_id ON public.plan_versions USING btree (plan_id);


--
-- TOC entry 4330 (class 1259 OID 19143)
-- Name: idx_plan_versions_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_plan_versions_task_id ON public.plan_versions USING btree (task_id) WHERE (task_id IS NOT NULL);


--
-- TOC entry 4322 (class 1259 OID 19139)
-- Name: idx_plans_conversation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_plans_conversation_id ON public.plans USING btree (conversation_id);


--
-- TOC entry 4323 (class 1259 OID 19140)
-- Name: idx_plans_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_plans_user_id ON public.plans USING btree (user_id);


--
-- TOC entry 4240 (class 1259 OID 18671)
-- Name: idx_project_steps_project_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_project_steps_project_id ON public.project_steps USING btree (project_id);


--
-- TOC entry 4241 (class 1259 OID 18672)
-- Name: idx_project_steps_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_project_steps_status ON public.project_steps USING btree (status);


--
-- TOC entry 4242 (class 1259 OID 18673)
-- Name: idx_project_steps_step_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_project_steps_step_index ON public.project_steps USING btree (step_index);


--
-- TOC entry 4245 (class 1259 OID 18674)
-- Name: idx_projects_conversation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_projects_conversation_id ON public.projects USING btree (conversation_id);


--
-- TOC entry 4246 (class 1259 OID 18675)
-- Name: idx_projects_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_projects_created_at ON public.projects USING btree (created_at);


--
-- TOC entry 4247 (class 1259 OID 18676)
-- Name: idx_projects_parent_project_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_projects_parent_project_id ON public.projects USING btree (parent_project_id);


--
-- TOC entry 4248 (class 1259 OID 18677)
-- Name: idx_projects_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_projects_status ON public.projects USING btree (status);


--
-- TOC entry 4249 (class 1259 OID 18678)
-- Name: idx_projects_updated_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_projects_updated_at ON public.projects USING btree (updated_at);


--
-- TOC entry 4252 (class 1259 OID 19089)
-- Name: idx_pseudonym_dictionaries_agent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pseudonym_dictionaries_agent ON public.pseudonym_dictionaries USING btree (agent_slug);


--
-- TOC entry 4253 (class 1259 OID 19088)
-- Name: idx_pseudonym_dictionaries_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pseudonym_dictionaries_org ON public.pseudonym_dictionaries USING btree (organization_slug);


--
-- TOC entry 4254 (class 1259 OID 18679)
-- Name: idx_pseudonym_dictionaries_original_value; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pseudonym_dictionaries_original_value ON public.pseudonym_dictionaries USING btree (original_value);


--
-- TOC entry 4255 (class 1259 OID 19090)
-- Name: idx_pseudonym_dictionaries_updated_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pseudonym_dictionaries_updated_at ON public.pseudonym_dictionaries USING btree (updated_at);


--
-- TOC entry 4260 (class 1259 OID 18680)
-- Name: idx_redaction_patterns_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_redaction_patterns_active ON public.redaction_patterns USING btree (is_active, priority);


--
-- TOC entry 4302 (class 1259 OID 19019)
-- Name: idx_task_messages_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_task_messages_created_at ON public.task_messages USING btree (created_at DESC);


--
-- TOC entry 4303 (class 1259 OID 19016)
-- Name: idx_task_messages_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_task_messages_expires_at ON public.task_messages USING btree (expires_at);


--
-- TOC entry 4304 (class 1259 OID 19018)
-- Name: idx_task_messages_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_task_messages_task_id ON public.task_messages USING btree (task_id);


--
-- TOC entry 4305 (class 1259 OID 19017)
-- Name: idx_task_messages_task_id_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_task_messages_task_id_expires_at ON public.task_messages USING btree (task_id, expires_at);


--
-- TOC entry 4211 (class 1259 OID 18681)
-- Name: idx_tasks_conversation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_conversation_id ON public.tasks USING btree (conversation_id);


--
-- TOC entry 4269 (class 1259 OID 18685)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 4234 (class 1259 OID 18982)
-- Name: llm_usage_route_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX llm_usage_route_idx ON public.llm_usage USING btree (route);


--
-- TOC entry 4235 (class 1259 OID 18983)
-- Name: llm_usage_route_started_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX llm_usage_route_started_at_idx ON public.llm_usage USING btree (route, started_at DESC);


--
-- TOC entry 4238 (class 1259 OID 19065)
-- Name: llm_usage_run_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX llm_usage_run_id_unique ON public.llm_usage USING btree (run_id);


--
-- TOC entry 4239 (class 1259 OID 19157)
-- Name: llm_usage_total_cost_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX llm_usage_total_cost_idx ON public.llm_usage USING btree (total_cost) WHERE (total_cost IS NOT NULL);


--
-- TOC entry 4114 (class 1259 OID 17700)
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- TOC entry 4117 (class 1259 OID 17602)
-- Name: subscription_subscription_id_entity_filters_key; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_key ON realtime.subscription USING btree (subscription_id, entity, filters);


--
-- TOC entry 4079 (class 1259 OID 16523)
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- TOC entry 4082 (class 1259 OID 16545)
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- TOC entry 4142 (class 1259 OID 17912)
-- Name: idx_iceberg_namespaces_bucket_id; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX idx_iceberg_namespaces_bucket_id ON storage.iceberg_namespaces USING btree (bucket_id, name);


--
-- TOC entry 4145 (class 1259 OID 17933)
-- Name: idx_iceberg_tables_namespace_id; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX idx_iceberg_tables_namespace_id ON storage.iceberg_tables USING btree (namespace_id, name);


--
-- TOC entry 4130 (class 1259 OID 17822)
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- TOC entry 4083 (class 1259 OID 17868)
-- Name: idx_name_bucket_level_unique; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX idx_name_bucket_level_unique ON storage.objects USING btree (name COLLATE "C", bucket_id, level);


--
-- TOC entry 4084 (class 1259 OID 17787)
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- TOC entry 4085 (class 1259 OID 17870)
-- Name: idx_objects_lower_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_lower_name ON storage.objects USING btree ((path_tokens[level]), lower(name) text_pattern_ops, bucket_id, level);


--
-- TOC entry 4135 (class 1259 OID 17871)
-- Name: idx_prefixes_lower_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_prefixes_lower_name ON storage.prefixes USING btree (bucket_id, level, ((string_to_array(name, '/'::text))[level]), lower(name) text_pattern_ops);


--
-- TOC entry 4086 (class 1259 OID 16546)
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- TOC entry 4087 (class 1259 OID 17869)
-- Name: objects_bucket_id_level_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX objects_bucket_id_level_idx ON storage.objects USING btree (bucket_id, level, name COLLATE "C");


--
-- TOC entry 4101 (class 1259 OID 16773)
-- Name: supabase_functions_hooks_h_table_id_h_name_idx; Type: INDEX; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE INDEX supabase_functions_hooks_h_table_id_h_name_idx ON supabase_functions.hooks USING btree (hook_table_id, hook_name);


--
-- TOC entry 4102 (class 1259 OID 16772)
-- Name: supabase_functions_hooks_request_id_idx; Type: INDEX; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE INDEX supabase_functions_hooks_request_id_idx ON supabase_functions.hooks USING btree (request_id);


--
-- TOC entry 4335 (class 0 OID 0)
-- Name: messages_2025_10_10_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_10_pkey;


--
-- TOC entry 4336 (class 0 OID 0)
-- Name: messages_2025_10_11_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_11_pkey;


--
-- TOC entry 4337 (class 0 OID 0)
-- Name: messages_2025_10_12_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_12_pkey;


--
-- TOC entry 4338 (class 0 OID 0)
-- Name: messages_2025_10_13_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_13_pkey;


--
-- TOC entry 4339 (class 0 OID 0)
-- Name: messages_2025_10_14_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_14_pkey;


--
-- TOC entry 4396 (class 2620 OID 19085)
-- Name: assets set_timestamp_updated_at_assets; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_timestamp_updated_at_assets BEFORE UPDATE ON public.assets FOR EACH ROW EXECUTE FUNCTION public.set_timestamp_updated_at();


--
-- TOC entry 4395 (class 2620 OID 18999)
-- Name: human_approvals set_timestamp_updated_at_human_approvals; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_timestamp_updated_at_human_approvals BEFORE UPDATE ON public.human_approvals FOR EACH ROW EXECUTE FUNCTION public.set_timestamp_updated_at();


--
-- TOC entry 4397 (class 2620 OID 19145)
-- Name: plans trigger_plans_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_plans_updated_at BEFORE UPDATE ON public.plans FOR EACH ROW EXECUTE FUNCTION public.update_plans_updated_at();


--
-- TOC entry 4393 (class 2620 OID 18690)
-- Name: project_steps update_project_steps_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_project_steps_updated_at BEFORE UPDATE ON public.project_steps FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4394 (class 2620 OID 18691)
-- Name: projects update_projects_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON public.projects FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4390 (class 2620 OID 17558)
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_admin
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- TOC entry 4385 (class 2620 OID 17878)
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- TOC entry 4386 (class 2620 OID 17866)
-- Name: objects objects_delete_delete_prefix; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER objects_delete_delete_prefix AFTER DELETE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- TOC entry 4387 (class 2620 OID 17864)
-- Name: objects objects_insert_create_prefix; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER objects_insert_create_prefix BEFORE INSERT ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.objects_insert_prefix_trigger();


--
-- TOC entry 4388 (class 2620 OID 17865)
-- Name: objects objects_update_create_prefix; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER objects_update_create_prefix BEFORE UPDATE ON storage.objects FOR EACH ROW WHEN (((new.name <> old.name) OR (new.bucket_id <> old.bucket_id))) EXECUTE FUNCTION storage.objects_update_prefix_trigger();


--
-- TOC entry 4391 (class 2620 OID 17874)
-- Name: prefixes prefixes_create_hierarchy; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER prefixes_create_hierarchy BEFORE INSERT ON storage.prefixes FOR EACH ROW WHEN ((pg_trigger_depth() < 1)) EXECUTE FUNCTION storage.prefixes_insert_trigger();


--
-- TOC entry 4392 (class 2620 OID 17863)
-- Name: prefixes prefixes_delete_hierarchy; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER prefixes_delete_hierarchy AFTER DELETE ON storage.prefixes FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- TOC entry 4389 (class 2620 OID 17775)
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- TOC entry 4342 (class 2606 OID 17434)
-- Name: extensions extensions_tenant_external_id_fkey; Type: FK CONSTRAINT; Schema: _realtime; Owner: supabase_admin
--

ALTER TABLE ONLY _realtime.extensions
    ADD CONSTRAINT extensions_tenant_external_id_fkey FOREIGN KEY (tenant_external_id) REFERENCES _realtime.tenants(external_id) ON DELETE CASCADE;


--
-- TOC entry 4350 (class 2606 OID 17960)
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4354 (class 2606 OID 18049)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 4353 (class 2606 OID 18037)
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- TOC entry 4352 (class 2606 OID 18024)
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4359 (class 2606 OID 18215)
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4340 (class 2606 OID 17993)
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 4356 (class 2606 OID 18096)
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4357 (class 2606 OID 18169)
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- TOC entry 4358 (class 2606 OID 18110)
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4351 (class 2606 OID 17988)
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4355 (class 2606 OID 18077)
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4366 (class 2606 OID 18865)
-- Name: departments departments_company_id_fkey; Type: FK CONSTRAINT; Schema: company; Owner: postgres
--

ALTER TABLE ONLY company.departments
    ADD CONSTRAINT departments_company_id_fkey FOREIGN KEY (company_id) REFERENCES company.companies(id) ON DELETE CASCADE;


--
-- TOC entry 4367 (class 2606 OID 18870)
-- Name: kpi_data kpi_data_department_id_fkey; Type: FK CONSTRAINT; Schema: company; Owner: postgres
--

ALTER TABLE ONLY company.kpi_data
    ADD CONSTRAINT kpi_data_department_id_fkey FOREIGN KEY (department_id) REFERENCES company.departments(id) ON DELETE CASCADE;


--
-- TOC entry 4368 (class 2606 OID 18875)
-- Name: kpi_data kpi_data_metric_id_fkey; Type: FK CONSTRAINT; Schema: company; Owner: postgres
--

ALTER TABLE ONLY company.kpi_data
    ADD CONSTRAINT kpi_data_metric_id_fkey FOREIGN KEY (metric_id) REFERENCES company.kpi_metrics(id) ON DELETE CASCADE;


--
-- TOC entry 4369 (class 2606 OID 18880)
-- Name: kpi_goals kpi_goals_department_id_fkey; Type: FK CONSTRAINT; Schema: company; Owner: postgres
--

ALTER TABLE ONLY company.kpi_goals
    ADD CONSTRAINT kpi_goals_department_id_fkey FOREIGN KEY (department_id) REFERENCES company.departments(id) ON DELETE CASCADE;


--
-- TOC entry 4370 (class 2606 OID 18885)
-- Name: kpi_goals kpi_goals_metric_id_fkey; Type: FK CONSTRAINT; Schema: company; Owner: postgres
--

ALTER TABLE ONLY company.kpi_goals
    ADD CONSTRAINT kpi_goals_metric_id_fkey FOREIGN KEY (metric_id) REFERENCES company.kpi_metrics(id) ON DELETE CASCADE;


--
-- TOC entry 4360 (class 2606 OID 18697)
-- Name: conversations agent_conversations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT agent_conversations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 4380 (class 2606 OID 19078)
-- Name: assets assets_deliverable_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_deliverable_version_id_fkey FOREIGN KEY (deliverable_version_id) REFERENCES public.deliverable_versions(id) ON DELETE SET NULL;


--
-- TOC entry 4363 (class 2606 OID 18737)
-- Name: deliverable_versions deliverable_versions_deliverable_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverable_versions
    ADD CONSTRAINT deliverable_versions_deliverable_id_fkey FOREIGN KEY (deliverable_id) REFERENCES public.deliverables(id) ON DELETE CASCADE;


--
-- TOC entry 4364 (class 2606 OID 18742)
-- Name: deliverable_versions deliverable_versions_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverable_versions
    ADD CONSTRAINT deliverable_versions_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- TOC entry 4365 (class 2606 OID 18747)
-- Name: deliverables deliverables_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverables
    ADD CONSTRAINT deliverables_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 4381 (class 2606 OID 19134)
-- Name: plans fk_plans_current_version; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT fk_plans_current_version FOREIGN KEY (current_version_id) REFERENCES public.plan_versions(id) ON DELETE SET NULL;


--
-- TOC entry 4371 (class 2606 OID 18777)
-- Name: llm_models llm_models_provider_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_provider_name_fkey FOREIGN KEY (provider_name) REFERENCES public.llm_providers(name) ON DELETE CASCADE;


--
-- TOC entry 4372 (class 2606 OID 18782)
-- Name: llm_usage llm_usage_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_usage
    ADD CONSTRAINT llm_usage_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- TOC entry 4379 (class 2606 OID 19052)
-- Name: orchestration_checkpoints orchestration_checkpoints_orchestration_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orchestration_checkpoints
    ADD CONSTRAINT orchestration_checkpoints_orchestration_run_id_fkey FOREIGN KEY (orchestration_run_id) REFERENCES public.orchestration_runs(id) ON DELETE CASCADE;


--
-- TOC entry 4378 (class 2606 OID 19035)
-- Name: orchestration_steps orchestration_steps_orchestration_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orchestration_steps
    ADD CONSTRAINT orchestration_steps_orchestration_run_id_fkey FOREIGN KEY (orchestration_run_id) REFERENCES public.orchestration_runs(id) ON DELETE CASCADE;


--
-- TOC entry 4384 (class 2606 OID 19129)
-- Name: plan_versions plan_versions_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_versions
    ADD CONSTRAINT plan_versions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- TOC entry 4382 (class 2606 OID 19103)
-- Name: plans plans_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- TOC entry 4383 (class 2606 OID 19108)
-- Name: plans plans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4373 (class 2606 OID 18787)
-- Name: project_steps project_steps_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_steps
    ADD CONSTRAINT project_steps_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- TOC entry 4374 (class 2606 OID 18792)
-- Name: projects projects_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- TOC entry 4375 (class 2606 OID 18797)
-- Name: projects projects_parent_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_parent_project_id_fkey FOREIGN KEY (parent_project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- TOC entry 4361 (class 2606 OID 18802)
-- Name: tasks tasks_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- TOC entry 4362 (class 2606 OID 18807)
-- Name: tasks tasks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 4376 (class 2606 OID 18812)
-- Name: user_cidafm_commands user_cidafm_commands_command_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_cidafm_commands
    ADD CONSTRAINT user_cidafm_commands_command_id_fkey FOREIGN KEY (command_id) REFERENCES public.cidafm_commands(id) ON DELETE CASCADE;


--
-- TOC entry 4377 (class 2606 OID 18817)
-- Name: user_cidafm_commands user_cidafm_commands_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_cidafm_commands
    ADD CONSTRAINT user_cidafm_commands_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4347 (class 2606 OID 17907)
-- Name: iceberg_namespaces iceberg_namespaces_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.iceberg_namespaces
    ADD CONSTRAINT iceberg_namespaces_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_analytics(id) ON DELETE CASCADE;


--
-- TOC entry 4348 (class 2606 OID 17928)
-- Name: iceberg_tables iceberg_tables_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_analytics(id) ON DELETE CASCADE;


--
-- TOC entry 4349 (class 2606 OID 17923)
-- Name: iceberg_tables iceberg_tables_namespace_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES storage.iceberg_namespaces(id) ON DELETE CASCADE;


--
-- TOC entry 4341 (class 2606 OID 16535)
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4346 (class 2606 OID 17851)
-- Name: prefixes prefixes_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT "prefixes_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4343 (class 2606 OID 17797)
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4344 (class 2606 OID 17817)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4345 (class 2606 OID 17812)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- TOC entry 4552 (class 0 OID 16488)
-- Dependencies: 241
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4573 (class 0 OID 18155)
-- Dependencies: 289
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4564 (class 0 OID 17953)
-- Dependencies: 280
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4551 (class 0 OID 16481)
-- Dependencies: 240
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4568 (class 0 OID 18042)
-- Dependencies: 284
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4567 (class 0 OID 18030)
-- Dependencies: 283
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4566 (class 0 OID 18017)
-- Dependencies: 282
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4574 (class 0 OID 18205)
-- Dependencies: 290
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4550 (class 0 OID 16470)
-- Dependencies: 239
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4571 (class 0 OID 18084)
-- Dependencies: 287
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4572 (class 0 OID 18102)
-- Dependencies: 288
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4553 (class 0 OID 16496)
-- Dependencies: 242
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4565 (class 0 OID 17983)
-- Dependencies: 281
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4570 (class 0 OID 18069)
-- Dependencies: 286
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4569 (class 0 OID 18060)
-- Dependencies: 285
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4549 (class 0 OID 16458)
-- Dependencies: 237
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4580 (class 3256 OID 18824)
-- Name: project_steps Users can create their own project steps; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can create their own project steps" ON public.project_steps FOR INSERT WITH CHECK ((project_id IN ( SELECT p.id
   FROM (public.projects p
     JOIN public.conversations c ON ((p.conversation_id = c.id)))
  WHERE (c.user_id = auth.uid()))));


--
-- TOC entry 4581 (class 3256 OID 18826)
-- Name: projects Users can create their own projects; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can create their own projects" ON public.projects FOR INSERT WITH CHECK ((conversation_id IN ( SELECT conversations.id
   FROM public.conversations
  WHERE (conversations.user_id = auth.uid()))));


--
-- TOC entry 4582 (class 3256 OID 18827)
-- Name: project_steps Users can delete their own project steps; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can delete their own project steps" ON public.project_steps FOR DELETE USING ((project_id IN ( SELECT p.id
   FROM (public.projects p
     JOIN public.conversations c ON ((p.conversation_id = c.id)))
  WHERE (c.user_id = auth.uid()))));


--
-- TOC entry 4583 (class 3256 OID 18829)
-- Name: projects Users can delete their own projects; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can delete their own projects" ON public.projects FOR DELETE USING ((conversation_id IN ( SELECT conversations.id
   FROM public.conversations
  WHERE (conversations.user_id = auth.uid()))));


--
-- TOC entry 4589 (class 3256 OID 18858)
-- Name: jokes_agent Users can insert jokes; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can insert jokes" ON public.jokes_agent FOR INSERT WITH CHECK (true);


--
-- TOC entry 4584 (class 3256 OID 18832)
-- Name: project_steps Users can update their own project steps; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can update their own project steps" ON public.project_steps FOR UPDATE USING ((project_id IN ( SELECT p.id
   FROM (public.projects p
     JOIN public.conversations c ON ((p.conversation_id = c.id)))
  WHERE (c.user_id = auth.uid()))));


--
-- TOC entry 4585 (class 3256 OID 18834)
-- Name: projects Users can update their own projects; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can update their own projects" ON public.projects FOR UPDATE USING ((conversation_id IN ( SELECT conversations.id
   FROM public.conversations
  WHERE (conversations.user_id = auth.uid()))));


--
-- TOC entry 4588 (class 3256 OID 18857)
-- Name: jokes_agent Users can view their own jokes; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can view their own jokes" ON public.jokes_agent FOR SELECT USING ((((auth.uid())::text = session_id) OR (session_id ~~ 'session_%'::text)));


--
-- TOC entry 4586 (class 3256 OID 18841)
-- Name: project_steps Users can view their own project steps; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can view their own project steps" ON public.project_steps FOR SELECT USING ((project_id IN ( SELECT p.id
   FROM (public.projects p
     JOIN public.conversations c ON ((p.conversation_id = c.id)))
  WHERE (c.user_id = auth.uid()))));


--
-- TOC entry 4587 (class 3256 OID 18843)
-- Name: projects Users can view their own projects; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can view their own projects" ON public.projects FOR SELECT USING ((conversation_id IN ( SELECT conversations.id
   FROM public.conversations
  WHERE (conversations.user_id = auth.uid()))));


--
-- TOC entry 4577 (class 0 OID 18845)
-- Dependencies: 312
-- Name: jokes_agent; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.jokes_agent ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4579 (class 0 OID 19113)
-- Dependencies: 325
-- Name: plan_versions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.plan_versions ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4597 (class 3256 OID 19153)
-- Name: plan_versions plan_versions_delete_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY plan_versions_delete_policy ON public.plan_versions FOR DELETE USING ((EXISTS ( SELECT 1
   FROM public.plans
  WHERE ((plans.id = plan_versions.plan_id) AND (plans.user_id = auth.uid())))));


--
-- TOC entry 4595 (class 3256 OID 19151)
-- Name: plan_versions plan_versions_insert_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY plan_versions_insert_policy ON public.plan_versions FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM public.plans
  WHERE ((plans.id = plan_versions.plan_id) AND (plans.user_id = auth.uid())))));


--
-- TOC entry 4594 (class 3256 OID 19150)
-- Name: plan_versions plan_versions_select_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY plan_versions_select_policy ON public.plan_versions FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.plans
  WHERE ((plans.id = plan_versions.plan_id) AND (plans.user_id = auth.uid())))));


--
-- TOC entry 4596 (class 3256 OID 19152)
-- Name: plan_versions plan_versions_update_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY plan_versions_update_policy ON public.plan_versions FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM public.plans
  WHERE ((plans.id = plan_versions.plan_id) AND (plans.user_id = auth.uid())))));


--
-- TOC entry 4578 (class 0 OID 19091)
-- Dependencies: 324
-- Name: plans; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.plans ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4593 (class 3256 OID 19149)
-- Name: plans plans_delete_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY plans_delete_policy ON public.plans FOR DELETE USING ((auth.uid() = user_id));


--
-- TOC entry 4591 (class 3256 OID 19147)
-- Name: plans plans_insert_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY plans_insert_policy ON public.plans FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- TOC entry 4590 (class 3256 OID 19146)
-- Name: plans plans_select_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY plans_select_policy ON public.plans FOR SELECT USING ((auth.uid() = user_id));


--
-- TOC entry 4592 (class 3256 OID 19148)
-- Name: plans plans_update_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY plans_update_policy ON public.plans FOR UPDATE USING ((auth.uid() = user_id));


--
-- TOC entry 4575 (class 0 OID 18504)
-- Dependencies: 305
-- Name: project_steps; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.project_steps ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4576 (class 0 OID 18517)
-- Dependencies: 306
-- Name: projects; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4557 (class 0 OID 17685)
-- Dependencies: 268
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4554 (class 0 OID 16509)
-- Dependencies: 243
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4561 (class 0 OID 17886)
-- Dependencies: 277
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4562 (class 0 OID 17897)
-- Dependencies: 278
-- Name: iceberg_namespaces; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.iceberg_namespaces ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4563 (class 0 OID 17913)
-- Dependencies: 279
-- Name: iceberg_tables; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.iceberg_tables ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4556 (class 0 OID 16551)
-- Dependencies: 245
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4555 (class 0 OID 16524)
-- Dependencies: 244
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4560 (class 0 OID 17841)
-- Dependencies: 276
-- Name: prefixes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.prefixes ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4558 (class 0 OID 17788)
-- Dependencies: 274
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4559 (class 0 OID 17802)
-- Dependencies: 275
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4598 (class 6104 OID 16388)
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION supabase_realtime OWNER TO postgres;

--
-- TOC entry 4679 (class 0 OID 0)
-- Dependencies: 4677
-- Name: DATABASE postgres; Type: ACL; Schema: -; Owner: postgres
--

GRANT CREATE ON DATABASE postgres TO supabase_etl_admin;
GRANT ALL ON DATABASE postgres TO dashboard_user;


--
-- TOC entry 4681 (class 0 OID 0)
-- Dependencies: 23
-- Name: SCHEMA auth; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA auth TO anon;
GRANT USAGE ON SCHEMA auth TO authenticated;
GRANT USAGE ON SCHEMA auth TO service_role;
GRANT ALL ON SCHEMA auth TO supabase_auth_admin;
GRANT ALL ON SCHEMA auth TO dashboard_user;
GRANT USAGE ON SCHEMA auth TO postgres;


--
-- TOC entry 4683 (class 0 OID 0)
-- Dependencies: 25
-- Name: SCHEMA company; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA company TO anon;
GRANT ALL ON SCHEMA company TO authenticated;
GRANT ALL ON SCHEMA company TO service_role;


--
-- TOC entry 4684 (class 0 OID 0)
-- Dependencies: 16
-- Name: SCHEMA extensions; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA extensions TO anon;
GRANT USAGE ON SCHEMA extensions TO authenticated;
GRANT USAGE ON SCHEMA extensions TO service_role;
GRANT ALL ON SCHEMA extensions TO dashboard_user;


--
-- TOC entry 4686 (class 0 OID 0)
-- Dependencies: 14
-- Name: SCHEMA net; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA net TO supabase_functions_admin;
GRANT USAGE ON SCHEMA net TO postgres;
GRANT USAGE ON SCHEMA net TO anon;
GRANT USAGE ON SCHEMA net TO authenticated;
GRANT USAGE ON SCHEMA net TO service_role;


--
-- TOC entry 4687 (class 0 OID 0)
-- Dependencies: 20
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;


--
-- TOC entry 4688 (class 0 OID 0)
-- Dependencies: 17
-- Name: SCHEMA realtime; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA realtime TO postgres;
GRANT USAGE ON SCHEMA realtime TO anon;
GRANT USAGE ON SCHEMA realtime TO authenticated;
GRANT USAGE ON SCHEMA realtime TO service_role;
GRANT ALL ON SCHEMA realtime TO supabase_realtime_admin;


--
-- TOC entry 4689 (class 0 OID 0)
-- Dependencies: 24
-- Name: SCHEMA storage; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA storage TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA storage TO anon;
GRANT USAGE ON SCHEMA storage TO authenticated;
GRANT USAGE ON SCHEMA storage TO service_role;
GRANT ALL ON SCHEMA storage TO supabase_storage_admin;
GRANT ALL ON SCHEMA storage TO dashboard_user;


--
-- TOC entry 4690 (class 0 OID 0)
-- Dependencies: 13
-- Name: SCHEMA supabase_functions; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA supabase_functions TO postgres;
GRANT USAGE ON SCHEMA supabase_functions TO anon;
GRANT USAGE ON SCHEMA supabase_functions TO authenticated;
GRANT USAGE ON SCHEMA supabase_functions TO service_role;
GRANT ALL ON SCHEMA supabase_functions TO supabase_functions_admin;


--
-- TOC entry 4691 (class 0 OID 0)
-- Dependencies: 19
-- Name: SCHEMA vault; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA vault TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA vault TO service_role;


--
-- TOC entry 4698 (class 0 OID 0)
-- Dependencies: 471
-- Name: FUNCTION email(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.email() TO dashboard_user;


--
-- TOC entry 4699 (class 0 OID 0)
-- Dependencies: 368
-- Name: FUNCTION jwt(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.jwt() TO postgres;
GRANT ALL ON FUNCTION auth.jwt() TO dashboard_user;


--
-- TOC entry 4701 (class 0 OID 0)
-- Dependencies: 403
-- Name: FUNCTION role(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.role() TO dashboard_user;


--
-- TOC entry 4703 (class 0 OID 0)
-- Dependencies: 400
-- Name: FUNCTION uid(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.uid() TO dashboard_user;


--
-- TOC entry 4704 (class 0 OID 0)
-- Dependencies: 388
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.armor(bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4705 (class 0 OID 0)
-- Dependencies: 327
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4706 (class 0 OID 0)
-- Dependencies: 417
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.crypt(text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4707 (class 0 OID 0)
-- Dependencies: 336
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.dearmor(text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4708 (class 0 OID 0)
-- Dependencies: 444
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4709 (class 0 OID 0)
-- Dependencies: 416
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4710 (class 0 OID 0)
-- Dependencies: 328
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4711 (class 0 OID 0)
-- Dependencies: 465
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.digest(text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4712 (class 0 OID 0)
-- Dependencies: 353
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4713 (class 0 OID 0)
-- Dependencies: 391
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4714 (class 0 OID 0)
-- Dependencies: 335
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4715 (class 0 OID 0)
-- Dependencies: 458
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4716 (class 0 OID 0)
-- Dependencies: 343
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.gen_salt(text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4717 (class 0 OID 0)
-- Dependencies: 438
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4719 (class 0 OID 0)
-- Dependencies: 467
-- Name: FUNCTION grant_pg_cron_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_cron_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO dashboard_user;


--
-- TOC entry 4721 (class 0 OID 0)
-- Dependencies: 450
-- Name: FUNCTION grant_pg_graphql_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.grant_pg_graphql_access() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4723 (class 0 OID 0)
-- Dependencies: 387
-- Name: FUNCTION grant_pg_net_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_net_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO dashboard_user;


--
-- TOC entry 4724 (class 0 OID 0)
-- Dependencies: 457
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4725 (class 0 OID 0)
-- Dependencies: 367
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4726 (class 0 OID 0)
-- Dependencies: 414
-- Name: FUNCTION pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4727 (class 0 OID 0)
-- Dependencies: 341
-- Name: FUNCTION pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4728 (class 0 OID 0)
-- Dependencies: 434
-- Name: FUNCTION pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4729 (class 0 OID 0)
-- Dependencies: 430
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4730 (class 0 OID 0)
-- Dependencies: 359
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4731 (class 0 OID 0)
-- Dependencies: 396
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4732 (class 0 OID 0)
-- Dependencies: 431
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4733 (class 0 OID 0)
-- Dependencies: 464
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4734 (class 0 OID 0)
-- Dependencies: 372
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4735 (class 0 OID 0)
-- Dependencies: 370
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4736 (class 0 OID 0)
-- Dependencies: 373
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4737 (class 0 OID 0)
-- Dependencies: 422
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4738 (class 0 OID 0)
-- Dependencies: 446
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4739 (class 0 OID 0)
-- Dependencies: 443
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4740 (class 0 OID 0)
-- Dependencies: 455
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4741 (class 0 OID 0)
-- Dependencies: 350
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4742 (class 0 OID 0)
-- Dependencies: 460
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4743 (class 0 OID 0)
-- Dependencies: 376
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4744 (class 0 OID 0)
-- Dependencies: 397
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4745 (class 0 OID 0)
-- Dependencies: 393
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4746 (class 0 OID 0)
-- Dependencies: 337
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4747 (class 0 OID 0)
-- Dependencies: 374
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4748 (class 0 OID 0)
-- Dependencies: 334
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4749 (class 0 OID 0)
-- Dependencies: 411
-- Name: FUNCTION pgrst_ddl_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_ddl_watch() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4750 (class 0 OID 0)
-- Dependencies: 382
-- Name: FUNCTION pgrst_drop_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_drop_watch() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4752 (class 0 OID 0)
-- Dependencies: 419
-- Name: FUNCTION set_graphql_placeholder(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.set_graphql_placeholder() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4753 (class 0 OID 0)
-- Dependencies: 405
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4754 (class 0 OID 0)
-- Dependencies: 404
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4755 (class 0 OID 0)
-- Dependencies: 352
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4756 (class 0 OID 0)
-- Dependencies: 348
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4757 (class 0 OID 0)
-- Dependencies: 360
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4758 (class 0 OID 0)
-- Dependencies: 408
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_nil() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4759 (class 0 OID 0)
-- Dependencies: 346
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4760 (class 0 OID 0)
-- Dependencies: 448
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4761 (class 0 OID 0)
-- Dependencies: 401
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4762 (class 0 OID 0)
-- Dependencies: 381
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4763 (class 0 OID 0)
-- Dependencies: 398
-- Name: FUNCTION graphql("operationName" text, query text, variables jsonb, extensions jsonb); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO postgres;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO anon;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO authenticated;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO service_role;


--
-- TOC entry 4764 (class 0 OID 0)
-- Dependencies: 453
-- Name: FUNCTION http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer); Type: ACL; Schema: net; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO postgres;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO anon;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO authenticated;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO service_role;


--
-- TOC entry 4765 (class 0 OID 0)
-- Dependencies: 439
-- Name: FUNCTION http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer); Type: ACL; Schema: net; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO postgres;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO anon;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO authenticated;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO service_role;


--
-- TOC entry 4766 (class 0 OID 0)
-- Dependencies: 440
-- Name: FUNCTION get_auth(p_usename text); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION pgbouncer.get_auth(p_usename text) FROM PUBLIC;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO pgbouncer;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO postgres;


--
-- TOC entry 4767 (class 0 OID 0)
-- Dependencies: 435
-- Name: FUNCTION calculate_completion_percentage(requirements jsonb); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.calculate_completion_percentage(requirements jsonb) TO anon;
GRANT ALL ON FUNCTION public.calculate_completion_percentage(requirements jsonb) TO authenticated;
GRANT ALL ON FUNCTION public.calculate_completion_percentage(requirements jsonb) TO service_role;


--
-- TOC entry 4768 (class 0 OID 0)
-- Dependencies: 329
-- Name: FUNCTION cleanup_abandoned_conversations(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.cleanup_abandoned_conversations() TO anon;
GRANT ALL ON FUNCTION public.cleanup_abandoned_conversations() TO authenticated;
GRANT ALL ON FUNCTION public.cleanup_abandoned_conversations() TO service_role;


--
-- TOC entry 4769 (class 0 OID 0)
-- Dependencies: 428
-- Name: FUNCTION cleanup_old_jokes(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.cleanup_old_jokes() TO anon;
GRANT ALL ON FUNCTION public.cleanup_old_jokes() TO authenticated;
GRANT ALL ON FUNCTION public.cleanup_old_jokes() TO service_role;


--
-- TOC entry 4770 (class 0 OID 0)
-- Dependencies: 447
-- Name: FUNCTION exec_sql(query text, sql_query text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.exec_sql(query text, sql_query text) TO anon;
GRANT ALL ON FUNCTION public.exec_sql(query text, sql_query text) TO authenticated;
GRANT ALL ON FUNCTION public.exec_sql(query text, sql_query text) TO service_role;


--
-- TOC entry 4771 (class 0 OID 0)
-- Dependencies: 363
-- Name: FUNCTION get_global_model_config(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_global_model_config() TO anon;
GRANT ALL ON FUNCTION public.get_global_model_config() TO authenticated;
GRANT ALL ON FUNCTION public.get_global_model_config() TO service_role;


--
-- TOC entry 4773 (class 0 OID 0)
-- Dependencies: 469
-- Name: FUNCTION log_agent_action(p_action character varying, p_agent_id uuid, p_details jsonb, p_previous_state jsonb, p_new_state jsonb, p_success boolean, p_error_message text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.log_agent_action(p_action character varying, p_agent_id uuid, p_details jsonb, p_previous_state jsonb, p_new_state jsonb, p_success boolean, p_error_message text) TO anon;
GRANT ALL ON FUNCTION public.log_agent_action(p_action character varying, p_agent_id uuid, p_details jsonb, p_previous_state jsonb, p_new_state jsonb, p_success boolean, p_error_message text) TO authenticated;
GRANT ALL ON FUNCTION public.log_agent_action(p_action character varying, p_agent_id uuid, p_details jsonb, p_previous_state jsonb, p_new_state jsonb, p_success boolean, p_error_message text) TO service_role;


--
-- TOC entry 4774 (class 0 OID 0)
-- Dependencies: 361
-- Name: FUNCTION set_timestamp_updated_at(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.set_timestamp_updated_at() TO anon;
GRANT ALL ON FUNCTION public.set_timestamp_updated_at() TO authenticated;
GRANT ALL ON FUNCTION public.set_timestamp_updated_at() TO service_role;


--
-- TOC entry 4775 (class 0 OID 0)
-- Dependencies: 345
-- Name: FUNCTION update_agent_configurations_updated_at(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_agent_configurations_updated_at() TO anon;
GRANT ALL ON FUNCTION public.update_agent_configurations_updated_at() TO authenticated;
GRANT ALL ON FUNCTION public.update_agent_configurations_updated_at() TO service_role;


--
-- TOC entry 4776 (class 0 OID 0)
-- Dependencies: 330
-- Name: FUNCTION update_agent_skills_updated_at(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_agent_skills_updated_at() TO anon;
GRANT ALL ON FUNCTION public.update_agent_skills_updated_at() TO authenticated;
GRANT ALL ON FUNCTION public.update_agent_skills_updated_at() TO service_role;


--
-- TOC entry 4778 (class 0 OID 0)
-- Dependencies: 454
-- Name: FUNCTION update_agent_usage_analytics(p_agent_id uuid, p_conversation_increment integer, p_message_increment integer, p_response_time_ms integer, p_error_increment integer, p_unique_user_increment integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_agent_usage_analytics(p_agent_id uuid, p_conversation_increment integer, p_message_increment integer, p_response_time_ms integer, p_error_increment integer, p_unique_user_increment integer) TO anon;
GRANT ALL ON FUNCTION public.update_agent_usage_analytics(p_agent_id uuid, p_conversation_increment integer, p_message_increment integer, p_response_time_ms integer, p_error_increment integer, p_unique_user_increment integer) TO authenticated;
GRANT ALL ON FUNCTION public.update_agent_usage_analytics(p_agent_id uuid, p_conversation_increment integer, p_message_increment integer, p_response_time_ms integer, p_error_increment integer, p_unique_user_increment integer) TO service_role;


--
-- TOC entry 4779 (class 0 OID 0)
-- Dependencies: 451
-- Name: FUNCTION update_completion_percentage(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_completion_percentage() TO anon;
GRANT ALL ON FUNCTION public.update_completion_percentage() TO authenticated;
GRANT ALL ON FUNCTION public.update_completion_percentage() TO service_role;


--
-- TOC entry 4780 (class 0 OID 0)
-- Dependencies: 399
-- Name: FUNCTION update_conversation_timestamps(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_conversation_timestamps() TO anon;
GRANT ALL ON FUNCTION public.update_conversation_timestamps() TO authenticated;
GRANT ALL ON FUNCTION public.update_conversation_timestamps() TO service_role;


--
-- TOC entry 4782 (class 0 OID 0)
-- Dependencies: 421
-- Name: FUNCTION update_creation_metrics(p_success boolean, p_creation_time_seconds integer, p_questions_answered integer, p_department character varying); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_creation_metrics(p_success boolean, p_creation_time_seconds integer, p_questions_answered integer, p_department character varying) TO anon;
GRANT ALL ON FUNCTION public.update_creation_metrics(p_success boolean, p_creation_time_seconds integer, p_questions_answered integer, p_department character varying) TO authenticated;
GRANT ALL ON FUNCTION public.update_creation_metrics(p_success boolean, p_creation_time_seconds integer, p_questions_answered integer, p_department character varying) TO service_role;


--
-- TOC entry 4783 (class 0 OID 0)
-- Dependencies: 427
-- Name: FUNCTION update_plans_updated_at(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_plans_updated_at() TO anon;
GRANT ALL ON FUNCTION public.update_plans_updated_at() TO authenticated;
GRANT ALL ON FUNCTION public.update_plans_updated_at() TO service_role;


--
-- TOC entry 4784 (class 0 OID 0)
-- Dependencies: 410
-- Name: FUNCTION update_updated_at_column(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_updated_at_column() TO anon;
GRANT ALL ON FUNCTION public.update_updated_at_column() TO authenticated;
GRANT ALL ON FUNCTION public.update_updated_at_column() TO service_role;


--
-- TOC entry 4785 (class 0 OID 0)
-- Dependencies: 384
-- Name: FUNCTION validate_skill_examples(examples jsonb); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.validate_skill_examples(examples jsonb) TO anon;
GRANT ALL ON FUNCTION public.validate_skill_examples(examples jsonb) TO authenticated;
GRANT ALL ON FUNCTION public.validate_skill_examples(examples jsonb) TO service_role;


--
-- TOC entry 4786 (class 0 OID 0)
-- Dependencies: 442
-- Name: FUNCTION apply_rls(wal jsonb, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO service_role;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO supabase_realtime_admin;


--
-- TOC entry 4787 (class 0 OID 0)
-- Dependencies: 423
-- Name: FUNCTION broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO postgres;
GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO dashboard_user;


--
-- TOC entry 4788 (class 0 OID 0)
-- Dependencies: 459
-- Name: FUNCTION build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO postgres;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO anon;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO service_role;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO supabase_realtime_admin;


--
-- TOC entry 4789 (class 0 OID 0)
-- Dependencies: 383
-- Name: FUNCTION "cast"(val text, type_ regtype); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO postgres;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO dashboard_user;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO anon;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO authenticated;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO service_role;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO supabase_realtime_admin;


--
-- TOC entry 4790 (class 0 OID 0)
-- Dependencies: 364
-- Name: FUNCTION check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO postgres;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO anon;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO authenticated;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO service_role;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO supabase_realtime_admin;


--
-- TOC entry 4791 (class 0 OID 0)
-- Dependencies: 466
-- Name: FUNCTION is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO postgres;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO anon;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO service_role;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO supabase_realtime_admin;


--
-- TOC entry 4792 (class 0 OID 0)
-- Dependencies: 413
-- Name: FUNCTION list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO service_role;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO supabase_realtime_admin;


--
-- TOC entry 4793 (class 0 OID 0)
-- Dependencies: 395
-- Name: FUNCTION quote_wal2json(entity regclass); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO postgres;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO anon;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO authenticated;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO service_role;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO supabase_realtime_admin;


--
-- TOC entry 4794 (class 0 OID 0)
-- Dependencies: 462
-- Name: FUNCTION send(payload jsonb, event text, topic text, private boolean); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO postgres;
GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO dashboard_user;


--
-- TOC entry 4795 (class 0 OID 0)
-- Dependencies: 356
-- Name: FUNCTION subscription_check_filters(); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO postgres;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO dashboard_user;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO anon;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO authenticated;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO service_role;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO supabase_realtime_admin;


--
-- TOC entry 4796 (class 0 OID 0)
-- Dependencies: 415
-- Name: FUNCTION to_regrole(role_name text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO postgres;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO anon;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO authenticated;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO service_role;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO supabase_realtime_admin;


--
-- TOC entry 4797 (class 0 OID 0)
-- Dependencies: 463
-- Name: FUNCTION topic(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.topic() TO postgres;
GRANT ALL ON FUNCTION realtime.topic() TO dashboard_user;


--
-- TOC entry 4798 (class 0 OID 0)
-- Dependencies: 432
-- Name: FUNCTION http_request(); Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

REVOKE ALL ON FUNCTION supabase_functions.http_request() FROM PUBLIC;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO postgres;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO anon;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO authenticated;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO service_role;


--
-- TOC entry 4799 (class 0 OID 0)
-- Dependencies: 342
-- Name: FUNCTION _crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO service_role;


--
-- TOC entry 4800 (class 0 OID 0)
-- Dependencies: 332
-- Name: FUNCTION create_secret(new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- TOC entry 4801 (class 0 OID 0)
-- Dependencies: 449
-- Name: FUNCTION update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- TOC entry 4803 (class 0 OID 0)
-- Dependencies: 241
-- Name: TABLE audit_log_entries; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.audit_log_entries TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.audit_log_entries TO postgres;
GRANT SELECT ON TABLE auth.audit_log_entries TO postgres WITH GRANT OPTION;


--
-- TOC entry 4805 (class 0 OID 0)
-- Dependencies: 289
-- Name: TABLE flow_state; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.flow_state TO postgres;
GRANT SELECT ON TABLE auth.flow_state TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.flow_state TO dashboard_user;


--
-- TOC entry 4808 (class 0 OID 0)
-- Dependencies: 280
-- Name: TABLE identities; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.identities TO postgres;
GRANT SELECT ON TABLE auth.identities TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.identities TO dashboard_user;


--
-- TOC entry 4810 (class 0 OID 0)
-- Dependencies: 240
-- Name: TABLE instances; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.instances TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.instances TO postgres;
GRANT SELECT ON TABLE auth.instances TO postgres WITH GRANT OPTION;


--
-- TOC entry 4812 (class 0 OID 0)
-- Dependencies: 284
-- Name: TABLE mfa_amr_claims; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_amr_claims TO postgres;
GRANT SELECT ON TABLE auth.mfa_amr_claims TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_amr_claims TO dashboard_user;


--
-- TOC entry 4814 (class 0 OID 0)
-- Dependencies: 283
-- Name: TABLE mfa_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_challenges TO postgres;
GRANT SELECT ON TABLE auth.mfa_challenges TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_challenges TO dashboard_user;


--
-- TOC entry 4816 (class 0 OID 0)
-- Dependencies: 282
-- Name: TABLE mfa_factors; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_factors TO postgres;
GRANT SELECT ON TABLE auth.mfa_factors TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_factors TO dashboard_user;


--
-- TOC entry 4817 (class 0 OID 0)
-- Dependencies: 290
-- Name: TABLE one_time_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.one_time_tokens TO postgres;
GRANT SELECT ON TABLE auth.one_time_tokens TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.one_time_tokens TO dashboard_user;


--
-- TOC entry 4819 (class 0 OID 0)
-- Dependencies: 239
-- Name: TABLE refresh_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.refresh_tokens TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.refresh_tokens TO postgres;
GRANT SELECT ON TABLE auth.refresh_tokens TO postgres WITH GRANT OPTION;


--
-- TOC entry 4821 (class 0 OID 0)
-- Dependencies: 238
-- Name: SEQUENCE refresh_tokens_id_seq; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO dashboard_user;
GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO postgres;


--
-- TOC entry 4823 (class 0 OID 0)
-- Dependencies: 287
-- Name: TABLE saml_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_providers TO postgres;
GRANT SELECT ON TABLE auth.saml_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_providers TO dashboard_user;


--
-- TOC entry 4825 (class 0 OID 0)
-- Dependencies: 288
-- Name: TABLE saml_relay_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_relay_states TO postgres;
GRANT SELECT ON TABLE auth.saml_relay_states TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_relay_states TO dashboard_user;


--
-- TOC entry 4827 (class 0 OID 0)
-- Dependencies: 242
-- Name: TABLE schema_migrations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE auth.schema_migrations TO postgres WITH GRANT OPTION;


--
-- TOC entry 4830 (class 0 OID 0)
-- Dependencies: 281
-- Name: TABLE sessions; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sessions TO postgres;
GRANT SELECT ON TABLE auth.sessions TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sessions TO dashboard_user;


--
-- TOC entry 4832 (class 0 OID 0)
-- Dependencies: 286
-- Name: TABLE sso_domains; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_domains TO postgres;
GRANT SELECT ON TABLE auth.sso_domains TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_domains TO dashboard_user;


--
-- TOC entry 4835 (class 0 OID 0)
-- Dependencies: 285
-- Name: TABLE sso_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_providers TO postgres;
GRANT SELECT ON TABLE auth.sso_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_providers TO dashboard_user;


--
-- TOC entry 4838 (class 0 OID 0)
-- Dependencies: 237
-- Name: TABLE users; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.users TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.users TO postgres;
GRANT SELECT ON TABLE auth.users TO postgres WITH GRANT OPTION;


--
-- TOC entry 4840 (class 0 OID 0)
-- Dependencies: 293
-- Name: TABLE companies; Type: ACL; Schema: company; Owner: postgres
--

GRANT ALL ON TABLE company.companies TO anon;
GRANT ALL ON TABLE company.companies TO authenticated;
GRANT ALL ON TABLE company.companies TO service_role;


--
-- TOC entry 4842 (class 0 OID 0)
-- Dependencies: 298
-- Name: TABLE departments; Type: ACL; Schema: company; Owner: postgres
--

GRANT ALL ON TABLE company.departments TO anon;
GRANT ALL ON TABLE company.departments TO authenticated;
GRANT ALL ON TABLE company.departments TO service_role;


--
-- TOC entry 4844 (class 0 OID 0)
-- Dependencies: 299
-- Name: TABLE kpi_data; Type: ACL; Schema: company; Owner: postgres
--

GRANT ALL ON TABLE company.kpi_data TO anon;
GRANT ALL ON TABLE company.kpi_data TO authenticated;
GRANT ALL ON TABLE company.kpi_data TO service_role;


--
-- TOC entry 4846 (class 0 OID 0)
-- Dependencies: 300
-- Name: TABLE kpi_goals; Type: ACL; Schema: company; Owner: postgres
--

GRANT ALL ON TABLE company.kpi_goals TO anon;
GRANT ALL ON TABLE company.kpi_goals TO authenticated;
GRANT ALL ON TABLE company.kpi_goals TO service_role;


--
-- TOC entry 4848 (class 0 OID 0)
-- Dependencies: 301
-- Name: TABLE kpi_metrics; Type: ACL; Schema: company; Owner: postgres
--

GRANT ALL ON TABLE company.kpi_metrics TO anon;
GRANT ALL ON TABLE company.kpi_metrics TO authenticated;
GRANT ALL ON TABLE company.kpi_metrics TO service_role;


--
-- TOC entry 4849 (class 0 OID 0)
-- Dependencies: 247
-- Name: TABLE pg_stat_statements; Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON TABLE extensions.pg_stat_statements TO postgres WITH GRANT OPTION;


--
-- TOC entry 4850 (class 0 OID 0)
-- Dependencies: 246
-- Name: TABLE pg_stat_statements_info; Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON TABLE extensions.pg_stat_statements_info TO postgres WITH GRANT OPTION;


--
-- TOC entry 4854 (class 0 OID 0)
-- Dependencies: 316
-- Name: TABLE agent_orchestrations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.agent_orchestrations TO anon;
GRANT ALL ON TABLE public.agent_orchestrations TO authenticated;
GRANT ALL ON TABLE public.agent_orchestrations TO service_role;


--
-- TOC entry 4862 (class 0 OID 0)
-- Dependencies: 314
-- Name: TABLE agents; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.agents TO anon;
GRANT ALL ON TABLE public.agents TO authenticated;
GRANT ALL ON TABLE public.agents TO service_role;


--
-- TOC entry 4863 (class 0 OID 0)
-- Dependencies: 323
-- Name: TABLE assets; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.assets TO anon;
GRANT ALL ON TABLE public.assets TO authenticated;
GRANT ALL ON TABLE public.assets TO service_role;


--
-- TOC entry 4864 (class 0 OID 0)
-- Dependencies: 292
-- Name: TABLE cidafm_commands; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.cidafm_commands TO anon;
GRANT ALL ON TABLE public.cidafm_commands TO authenticated;
GRANT ALL ON TABLE public.cidafm_commands TO service_role;


--
-- TOC entry 4866 (class 0 OID 0)
-- Dependencies: 294
-- Name: TABLE conversations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.conversations TO anon;
GRANT ALL ON TABLE public.conversations TO authenticated;
GRANT ALL ON TABLE public.conversations TO service_role;


--
-- TOC entry 4867 (class 0 OID 0)
-- Dependencies: 295
-- Name: TABLE tasks; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tasks TO anon;
GRANT ALL ON TABLE public.tasks TO authenticated;
GRANT ALL ON TABLE public.tasks TO service_role;


--
-- TOC entry 4868 (class 0 OID 0)
-- Dependencies: 326
-- Name: TABLE conversations_with_stats; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.conversations_with_stats TO anon;
GRANT ALL ON TABLE public.conversations_with_stats TO authenticated;
GRANT ALL ON TABLE public.conversations_with_stats TO service_role;


--
-- TOC entry 4869 (class 0 OID 0)
-- Dependencies: 296
-- Name: TABLE deliverable_versions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.deliverable_versions TO anon;
GRANT ALL ON TABLE public.deliverable_versions TO authenticated;
GRANT ALL ON TABLE public.deliverable_versions TO service_role;


--
-- TOC entry 4870 (class 0 OID 0)
-- Dependencies: 297
-- Name: TABLE deliverables; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.deliverables TO anon;
GRANT ALL ON TABLE public.deliverables TO authenticated;
GRANT ALL ON TABLE public.deliverables TO service_role;


--
-- TOC entry 4871 (class 0 OID 0)
-- Dependencies: 318
-- Name: TABLE human_approvals; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.human_approvals TO anon;
GRANT ALL ON TABLE public.human_approvals TO authenticated;
GRANT ALL ON TABLE public.human_approvals TO service_role;


--
-- TOC entry 4872 (class 0 OID 0)
-- Dependencies: 312
-- Name: TABLE jokes_agent; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.jokes_agent TO anon;
GRANT ALL ON TABLE public.jokes_agent TO authenticated;
GRANT ALL ON TABLE public.jokes_agent TO service_role;


--
-- TOC entry 4873 (class 0 OID 0)
-- Dependencies: 313
-- Name: TABLE jokes_analytics; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.jokes_analytics TO anon;
GRANT ALL ON TABLE public.jokes_analytics TO authenticated;
GRANT ALL ON TABLE public.jokes_analytics TO service_role;


--
-- TOC entry 4874 (class 0 OID 0)
-- Dependencies: 302
-- Name: TABLE llm_models; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.llm_models TO anon;
GRANT ALL ON TABLE public.llm_models TO authenticated;
GRANT ALL ON TABLE public.llm_models TO service_role;


--
-- TOC entry 4875 (class 0 OID 0)
-- Dependencies: 303
-- Name: TABLE llm_providers; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.llm_providers TO anon;
GRANT ALL ON TABLE public.llm_providers TO authenticated;
GRANT ALL ON TABLE public.llm_providers TO service_role;


--
-- TOC entry 4878 (class 0 OID 0)
-- Dependencies: 304
-- Name: TABLE llm_usage; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.llm_usage TO anon;
GRANT ALL ON TABLE public.llm_usage TO authenticated;
GRANT ALL ON TABLE public.llm_usage TO service_role;


--
-- TOC entry 4879 (class 0 OID 0)
-- Dependencies: 322
-- Name: TABLE llm_usage_analytics; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.llm_usage_analytics TO anon;
GRANT ALL ON TABLE public.llm_usage_analytics TO authenticated;
GRANT ALL ON TABLE public.llm_usage_analytics TO service_role;


--
-- TOC entry 4882 (class 0 OID 0)
-- Dependencies: 321
-- Name: TABLE orchestration_checkpoints; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.orchestration_checkpoints TO anon;
GRANT ALL ON TABLE public.orchestration_checkpoints TO authenticated;
GRANT ALL ON TABLE public.orchestration_checkpoints TO service_role;


--
-- TOC entry 4888 (class 0 OID 0)
-- Dependencies: 317
-- Name: TABLE orchestration_runs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.orchestration_runs TO anon;
GRANT ALL ON TABLE public.orchestration_runs TO authenticated;
GRANT ALL ON TABLE public.orchestration_runs TO service_role;


--
-- TOC entry 4893 (class 0 OID 0)
-- Dependencies: 320
-- Name: TABLE orchestration_steps; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.orchestration_steps TO anon;
GRANT ALL ON TABLE public.orchestration_steps TO authenticated;
GRANT ALL ON TABLE public.orchestration_steps TO service_role;


--
-- TOC entry 4895 (class 0 OID 0)
-- Dependencies: 315
-- Name: TABLE organization_credentials; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.organization_credentials TO anon;
GRANT ALL ON TABLE public.organization_credentials TO authenticated;
GRANT ALL ON TABLE public.organization_credentials TO service_role;


--
-- TOC entry 4900 (class 0 OID 0)
-- Dependencies: 325
-- Name: TABLE plan_versions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.plan_versions TO anon;
GRANT ALL ON TABLE public.plan_versions TO authenticated;
GRANT ALL ON TABLE public.plan_versions TO service_role;


--
-- TOC entry 4903 (class 0 OID 0)
-- Dependencies: 324
-- Name: TABLE plans; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.plans TO anon;
GRANT ALL ON TABLE public.plans TO authenticated;
GRANT ALL ON TABLE public.plans TO service_role;


--
-- TOC entry 4904 (class 0 OID 0)
-- Dependencies: 305
-- Name: TABLE project_steps; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.project_steps TO anon;
GRANT ALL ON TABLE public.project_steps TO authenticated;
GRANT ALL ON TABLE public.project_steps TO service_role;


--
-- TOC entry 4905 (class 0 OID 0)
-- Dependencies: 306
-- Name: TABLE projects; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.projects TO anon;
GRANT ALL ON TABLE public.projects TO authenticated;
GRANT ALL ON TABLE public.projects TO service_role;


--
-- TOC entry 4906 (class 0 OID 0)
-- Dependencies: 307
-- Name: TABLE pseudonym_dictionaries; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.pseudonym_dictionaries TO anon;
GRANT ALL ON TABLE public.pseudonym_dictionaries TO authenticated;
GRANT ALL ON TABLE public.pseudonym_dictionaries TO service_role;


--
-- TOC entry 4907 (class 0 OID 0)
-- Dependencies: 308
-- Name: TABLE redaction_patterns; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.redaction_patterns TO anon;
GRANT ALL ON TABLE public.redaction_patterns TO authenticated;
GRANT ALL ON TABLE public.redaction_patterns TO service_role;


--
-- TOC entry 4909 (class 0 OID 0)
-- Dependencies: 309
-- Name: TABLE system_settings; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.system_settings TO anon;
GRANT ALL ON TABLE public.system_settings TO authenticated;
GRANT ALL ON TABLE public.system_settings TO service_role;


--
-- TOC entry 4911 (class 0 OID 0)
-- Dependencies: 319
-- Name: TABLE task_messages; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.task_messages TO anon;
GRANT ALL ON TABLE public.task_messages TO authenticated;
GRANT ALL ON TABLE public.task_messages TO service_role;


--
-- TOC entry 4912 (class 0 OID 0)
-- Dependencies: 310
-- Name: TABLE user_cidafm_commands; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_cidafm_commands TO anon;
GRANT ALL ON TABLE public.user_cidafm_commands TO authenticated;
GRANT ALL ON TABLE public.user_cidafm_commands TO service_role;


--
-- TOC entry 4914 (class 0 OID 0)
-- Dependencies: 311
-- Name: TABLE users; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.users TO anon;
GRANT ALL ON TABLE public.users TO authenticated;
GRANT ALL ON TABLE public.users TO service_role;


--
-- TOC entry 4915 (class 0 OID 0)
-- Dependencies: 268
-- Name: TABLE messages; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE realtime.messages TO postgres;
GRANT ALL ON TABLE realtime.messages TO dashboard_user;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO anon;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO authenticated;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO service_role;


--
-- TOC entry 4916 (class 0 OID 0)
-- Dependencies: 269
-- Name: TABLE messages_2025_10_10; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_10_10 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_10_10 TO dashboard_user;


--
-- TOC entry 4917 (class 0 OID 0)
-- Dependencies: 270
-- Name: TABLE messages_2025_10_11; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_10_11 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_10_11 TO dashboard_user;


--
-- TOC entry 4918 (class 0 OID 0)
-- Dependencies: 271
-- Name: TABLE messages_2025_10_12; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_10_12 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_10_12 TO dashboard_user;


--
-- TOC entry 4919 (class 0 OID 0)
-- Dependencies: 272
-- Name: TABLE messages_2025_10_13; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_10_13 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_10_13 TO dashboard_user;


--
-- TOC entry 4920 (class 0 OID 0)
-- Dependencies: 273
-- Name: TABLE messages_2025_10_14; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_10_14 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_10_14 TO dashboard_user;


--
-- TOC entry 4921 (class 0 OID 0)
-- Dependencies: 262
-- Name: TABLE schema_migrations; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.schema_migrations TO postgres;
GRANT ALL ON TABLE realtime.schema_migrations TO dashboard_user;
GRANT SELECT ON TABLE realtime.schema_migrations TO anon;
GRANT SELECT ON TABLE realtime.schema_migrations TO authenticated;
GRANT SELECT ON TABLE realtime.schema_migrations TO service_role;
GRANT ALL ON TABLE realtime.schema_migrations TO supabase_realtime_admin;


--
-- TOC entry 4922 (class 0 OID 0)
-- Dependencies: 265
-- Name: TABLE subscription; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.subscription TO postgres;
GRANT ALL ON TABLE realtime.subscription TO dashboard_user;
GRANT SELECT ON TABLE realtime.subscription TO anon;
GRANT SELECT ON TABLE realtime.subscription TO authenticated;
GRANT SELECT ON TABLE realtime.subscription TO service_role;
GRANT ALL ON TABLE realtime.subscription TO supabase_realtime_admin;


--
-- TOC entry 4923 (class 0 OID 0)
-- Dependencies: 264
-- Name: SEQUENCE subscription_id_seq; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO postgres;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO dashboard_user;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO anon;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO authenticated;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO service_role;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO supabase_realtime_admin;


--
-- TOC entry 4925 (class 0 OID 0)
-- Dependencies: 243
-- Name: TABLE buckets; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.buckets TO anon;
GRANT ALL ON TABLE storage.buckets TO authenticated;
GRANT ALL ON TABLE storage.buckets TO service_role;
GRANT ALL ON TABLE storage.buckets TO postgres WITH GRANT OPTION;


--
-- TOC entry 4926 (class 0 OID 0)
-- Dependencies: 277
-- Name: TABLE buckets_analytics; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.buckets_analytics TO service_role;
GRANT ALL ON TABLE storage.buckets_analytics TO authenticated;
GRANT ALL ON TABLE storage.buckets_analytics TO anon;


--
-- TOC entry 4927 (class 0 OID 0)
-- Dependencies: 278
-- Name: TABLE iceberg_namespaces; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.iceberg_namespaces TO service_role;
GRANT SELECT ON TABLE storage.iceberg_namespaces TO authenticated;
GRANT SELECT ON TABLE storage.iceberg_namespaces TO anon;


--
-- TOC entry 4928 (class 0 OID 0)
-- Dependencies: 279
-- Name: TABLE iceberg_tables; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.iceberg_tables TO service_role;
GRANT SELECT ON TABLE storage.iceberg_tables TO authenticated;
GRANT SELECT ON TABLE storage.iceberg_tables TO anon;


--
-- TOC entry 4930 (class 0 OID 0)
-- Dependencies: 244
-- Name: TABLE objects; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.objects TO anon;
GRANT ALL ON TABLE storage.objects TO authenticated;
GRANT ALL ON TABLE storage.objects TO service_role;
GRANT ALL ON TABLE storage.objects TO postgres WITH GRANT OPTION;


--
-- TOC entry 4931 (class 0 OID 0)
-- Dependencies: 276
-- Name: TABLE prefixes; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.prefixes TO service_role;
GRANT ALL ON TABLE storage.prefixes TO authenticated;
GRANT ALL ON TABLE storage.prefixes TO anon;


--
-- TOC entry 4932 (class 0 OID 0)
-- Dependencies: 274
-- Name: TABLE s3_multipart_uploads; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO anon;


--
-- TOC entry 4933 (class 0 OID 0)
-- Dependencies: 275
-- Name: TABLE s3_multipart_uploads_parts; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads_parts TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO anon;


--
-- TOC entry 4935 (class 0 OID 0)
-- Dependencies: 258
-- Name: TABLE hooks; Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

GRANT ALL ON TABLE supabase_functions.hooks TO postgres;
GRANT ALL ON TABLE supabase_functions.hooks TO anon;
GRANT ALL ON TABLE supabase_functions.hooks TO authenticated;
GRANT ALL ON TABLE supabase_functions.hooks TO service_role;


--
-- TOC entry 4937 (class 0 OID 0)
-- Dependencies: 257
-- Name: SEQUENCE hooks_id_seq; Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO postgres;
GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO anon;
GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO authenticated;
GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO service_role;


--
-- TOC entry 4938 (class 0 OID 0)
-- Dependencies: 256
-- Name: TABLE migrations; Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

GRANT ALL ON TABLE supabase_functions.migrations TO postgres;
GRANT ALL ON TABLE supabase_functions.migrations TO anon;
GRANT ALL ON TABLE supabase_functions.migrations TO authenticated;
GRANT ALL ON TABLE supabase_functions.migrations TO service_role;


--
-- TOC entry 4939 (class 0 OID 0)
-- Dependencies: 248
-- Name: TABLE secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.secrets TO service_role;


--
-- TOC entry 4940 (class 0 OID 0)
-- Dependencies: 249
-- Name: TABLE decrypted_secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.decrypted_secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.decrypted_secrets TO service_role;


--
-- TOC entry 2565 (class 826 OID 16603)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- TOC entry 2566 (class 826 OID 16604)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- TOC entry 2564 (class 826 OID 16602)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO dashboard_user;


--
-- TOC entry 2575 (class 826 OID 16682)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON SEQUENCES TO postgres WITH GRANT OPTION;


--
-- TOC entry 2574 (class 826 OID 16681)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON FUNCTIONS TO postgres WITH GRANT OPTION;


--
-- TOC entry 2573 (class 826 OID 16680)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON TABLES TO postgres WITH GRANT OPTION;


--
-- TOC entry 2578 (class 826 OID 16637)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO service_role;


--
-- TOC entry 2577 (class 826 OID 16636)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO service_role;


--
-- TOC entry 2576 (class 826 OID 16635)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO service_role;


--
-- TOC entry 2570 (class 826 OID 16617)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO service_role;


--
-- TOC entry 2572 (class 826 OID 16616)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO service_role;


--
-- TOC entry 2571 (class 826 OID 16615)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO service_role;


--
-- TOC entry 2582 (class 826 OID 16453)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- TOC entry 2558 (class 826 OID 16454)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- TOC entry 2583 (class 826 OID 16452)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- TOC entry 2560 (class 826 OID 16456)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- TOC entry 2584 (class 826 OID 16451)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- TOC entry 2559 (class 826 OID 16455)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- TOC entry 2568 (class 826 OID 16607)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- TOC entry 2569 (class 826 OID 16608)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- TOC entry 2567 (class 826 OID 16606)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES TO dashboard_user;


--
-- TOC entry 2563 (class 826 OID 16508)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO service_role;


--
-- TOC entry 2562 (class 826 OID 16507)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO service_role;


--
-- TOC entry 2561 (class 826 OID 16506)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO service_role;


--
-- TOC entry 2581 (class 826 OID 16753)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: supabase_functions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES TO service_role;


--
-- TOC entry 2580 (class 826 OID 16752)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: supabase_functions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS TO service_role;


--
-- TOC entry 2579 (class 826 OID 16751)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: supabase_functions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES TO service_role;


--
-- TOC entry 3752 (class 3466 OID 16621)
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


ALTER EVENT TRIGGER issue_graphql_placeholder OWNER TO supabase_admin;

--
-- TOC entry 3757 (class 3466 OID 16700)
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


ALTER EVENT TRIGGER issue_pg_cron_access OWNER TO supabase_admin;

--
-- TOC entry 3751 (class 3466 OID 16619)
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


ALTER EVENT TRIGGER issue_pg_graphql_access OWNER TO supabase_admin;

--
-- TOC entry 3758 (class 3466 OID 16703)
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


ALTER EVENT TRIGGER issue_pg_net_access OWNER TO supabase_admin;

--
-- TOC entry 3753 (class 3466 OID 16622)
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


ALTER EVENT TRIGGER pgrst_ddl_watch OWNER TO supabase_admin;

--
-- TOC entry 3754 (class 3466 OID 16623)
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


ALTER EVENT TRIGGER pgrst_drop_watch OWNER TO supabase_admin;

-- Completed on 2025-10-12 12:14:50 UTC

--
-- PostgreSQL database dump complete
--

